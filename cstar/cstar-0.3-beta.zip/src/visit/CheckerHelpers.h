#ifndef CHECKER_HELPERS
#define CHECKER_HELPERS

//Functions used by both TypeChecker and the checks in DisamAndLookup.

#include "ContextVisitor.h"

class CheckerHelpers : public ContextVisitor {
public:
    /**@return whether fromNode can be treated as a to.*/
    bool convertible(Expr*fromNode, Type to);
    
    /** Check whether rhsNode can be assigned (with an assignment
     * expression or initial value in a declaration) to something of
     * type lhs.
     * @param missingDimensions Set to true for a
     * 		declaration where there are missing (inferred) array dimensions.
     * 		When there are, array := scalar is not allowed.
     * @param allowConstOnLeft Set to true for initial value of a
     * declaration, so that const int x := y doesn't generate an error.
     * @param assignExpr For error reporting.
     * @return rhsNode, coerced if necessary (see coerce function).
     * */
    Expr* assignableFrom(Node* assignExpr, const Type& lhs, Expr* rhsNode, bool allowConstOnLeft = false);
    
    /** Convert fromNode to type to.
     * @param assignExpr For error reporting.
     * @return Either fromNode (if no special conversion is necessary) 
     * or an explicit cast to to.  Generates an error if the coercion could not be
     * done. */
    Expr* coerce(Node* assignExpr, Expr* fromNode, Type to);
    
    void assignmentChecks(Node* n, const Type& targetType, Expr* rhs);

private:
	/** Common function to implement both convertible and coerce,
	 * which looks for a user-defined cast from the type of fromNode to
	 * to.
	 * @param createNode True iff we should create a node for coercion.
	 * If false, makes it return fromNode if a user-defined cast was found,
	 * 		0 otherwise.
	 */
	Expr* convertibleGeneral(Expr* fromNode, Type to, bool createNode);
    
};

#endif
