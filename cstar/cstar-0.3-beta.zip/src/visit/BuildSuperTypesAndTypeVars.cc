#include "BuildSuperTypesAndTypeVars.h"

#include "ast/ClassDecl.h"
#include "ast/Function.h"
#include "ast/TypeVar.h"
#include "BuildVarDecls.h"

//Don't visit function bodies
Node* BuildSuperTypesAndTypeVars::visit(Function* n) { return n; }

Node* BuildSuperTypesAndTypeVars::visit(ClassDecl* n) {
    //If it's a class implementation, we need to keep track of the superclasses
    //to check that they're the same as the ones already declared.
    vector<Type> superTypes;
    vector<Type> superClasses;
    bool isImpl = n->isImpl();
    
    Type classType(n->getType());
    
    for (vector<SuperClass*>::const_iterator i = n->getSuperClasses().begin();
         i != n->getSuperClasses().end(); ++i)
    {
        if ((*i)->getSuperClass()->getType().isPrimitive())
        {
            compileError << linenum(*i) << 
                "Can't extend primitive types." << endl;
        }
        else
        {
            //First look up the class name in the super class, to make sure
            //it exists.
            auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
            (*i)->accept(varDecls.get());

            Type t = (*i)->getSuperClass()->getType();
            if (t == Type::VOID) continue;  //If there was an error looking up the type
            
            if ((*i)->getKind() == SuperClass::EXTENDS)
            {
                if (isImpl) superClasses.push_back(t);
                else currentSymTable->addSuperClass(n->getName(), t);
            }
            else if ((*i)->getKind() == SuperClass::SUBTYPE_OP)
            {
                //The <: operator creates both a superclass and subtype relation
                if (isImpl)
                {
                    superTypes.push_back(t);
                    superClasses.push_back(t);
                }
                else
                {
                    currentSymTable->addSuperClass(n->getName(), t);
                    currentSymTable->addSuperType(n->getName(), t);
                }
            }
        }
    }
    if (isImpl)
    {
        //Check that the superclasses of the current class body match
        //those of the previous class body.
        if (superTypes != currentSymTable->superTypes(classType) ||
            superClasses != currentSymTable->superClasses(classType))
        {
            compileError << linenum(n) << 
                "Class implementation has different superclasses than the original definition." << endl
                << "  (Original definition found at line "
                << CompileError::getLineInfo(currentSymTable->getPointOfDefn(n->getName(), Type(Type::TYPE, classType))) << ")." << endl;
        }
    }
    return n;
}

void BuildSuperTypesAndTypeVars::postVisit(TypeVar* n) {
	buildTypeVar(n, curAccess);
}
