#ifndef FIX_SUPERTYPES_H
#define FIX_SUPERTYPES_H

/*
 * Remove the IMPLICIT from supertypes.
 * E.g. If we have "class X <: Y, Z extends A",
 * parsing will make Y be SUBTYPE, Z be IMPLICIT and A be EXTENDS.
 * Z should be SUBTYPE instead.
 */

#include "FixedVisitor.h"

class FixSupertypes : public FixedVisitor {
public:
    virtual void postVisit(ClassDecl* n);
};

#endif
