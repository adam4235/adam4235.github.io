#ifndef STMTS_VISITOR_H
#define STMTS_VISITOR_H

//Many of the visitors have to find nodes of a certain type,
//produce some statements (usually declarations) from the node,
//and insert the new statements before that node, plus possibly change
//the node.
//(An example of this type of transformation is:
//>> char c;
//=>
//char c;
//>> c;
//)
//
//This file declares a StmtVisitor class to use as a base
//class for visitors that keep track of new statements to
//be added, and a function (see below) to aid the traversal
//of a Stmts node with one of these visitors.

#include "FixedVisitor.h"

#include <vector>
#include <memory>

using std::auto_ptr;
using std::vector;

class StmtVisitor : public FixedVisitor {
protected:
	vector<Stmt*> stmts;
public:
	vector<Stmt*> stmtsResult() { return stmts; }
};

template<typename Vis>  //Should be constrained to be a StmtVisitor
vector<Stmt*> transStmts2(vector<Stmt*> stmts, bool (*test) (Stmt*), bool visitResult)
{
    vector<Stmt*> newStmts;  //Statements to replace n's statements with
	const vector<Stmt*>& list = stmts;
	for (vector<Stmt*>::const_iterator i = list.begin(); i != list.end(); ++i)
	{
		Stmt* s = *i;
        
		//Traverse Vis with the current statement
		auto_ptr<Vis> v(new Vis());
        if (test == 0 || test(s))
        {
            s = (Stmt*)s->accept(v.get());
            
            //Get the resulting list of new statements generated and insert
            //them just before s
            vector<Stmt*> result = v.get()->stmtsResult();
            if (visitResult) result = transStmts2<Vis>(result, test, visitResult);
            newStmts.insert(newStmts.end(), result.begin(), result.end());
        }
        
		//Insert s as well (possibly modified by the visitor)
		newStmts.push_back(s);
	}
    return newStmts;
}

/** Take a visitor of type StmtVisitor, called Vis,
 * and a Stmts node n.
 * Traverse each statement in n with Vis,
 * inserting the newly generated statements before the
 * statement in question.
 @param test An optional condition to inhibit traversal
 of certain statements.  If a function is supplied, statements
 are only visited if the function returns true for them.
 @param visitResult If set to true, the list of statements that Vis
    produces are recursively visited by Vis.  This continues until there are no
    more statements resulting from the transformation.
 */
template<typename Vis>  //Should be constrained to be a StmtVisitor
void transStmts(Stmts* n, bool (*test) (Stmt*) = 0, bool visitResult = false)
{
    vector<Stmt*> newStmts = transStmts2<Vis>(n->getStmts(), test, visitResult);
	n->setStmtsWithoutDelete(newStmts);
}

#endif

