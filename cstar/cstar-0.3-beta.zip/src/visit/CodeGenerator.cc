#include "CodeGenerator.h"
#include "tempname.h"
#include "whole_ast.h"
#include <cctype>
#include "buildTNFromType.h"

using namespace std;

string CodeGenerator::qualifier() const {
    string retVal = "";
    for (vector<string>::const_iterator i = classQualifier.begin(); i != classQualifier.end(); ++i)
    {
        retVal += *i + "::";
    }
    return retVal;
}

/** Output a function header.*/
void outputFunctionHeader(Function* n, string name) {
    auto_ptr<CodeGenerator> code(new CodeGenerator());
    
    //return type
	if (n->getRetTypeNode() == 0)
		cout << "void";
	else
    {
        bool needAutoPtr = n->getRetType().needAutoPtr() 
            && !isAssign(n->getName());  //The assignment operators shouldn't really return a subclass,
                //so it doesn't need the auto ptr overhead.
        if (needAutoPtr) cout << "csAutoPtr<";
		n->getRetTypeNode()->accept(code.get());
        if (needAutoPtr) cout << "> ";
    }
	cout << " ";

	cout << name << "(";  //function name
	n->getParams()->accept(code.get());  //function parameters
	cout << ")";
    
}

/** Output an enum declaration.  Used both for forward declarations
 and outputting an enum.
 @param isForward True if it's a forward declaration (see ForwardDecls below)*/
void outputEnum(Enum* n, bool isForward = false) {
	//Enums are now just translated as a typedef int for the enum name,
	//and a set of constant values for the enumerators.
	//This eases translation for the "thing" type, because:
	//enum color {R, G, B} e;
	//thing t := e;
	//(color)t;
	//works without problems, because it's the same as an int.
	cout << "typedef int " << n->getName() << ";" << endl;
    
	int value = 0;
	for (vector<string>::const_iterator i = n->getEnumerators().begin(); 
         i != n->getEnumerators().end() ;)
	{
		++value;
        if (isForward) cout << "extern ";
		cout << "const int " << *i;
        if (!isForward) cout << " = " << value;
        cout << ";" << endl;
		++i;
	}
    
}

/** Output a variable declaration.*/
void outputVarDecl(VarDecl* n, string name, bool inCatch, bool omitStatic = false) {
    auto_ptr<CodeGenerator> code(new CodeGenerator());
    Type t = n->getTypeNode()->getType();
    bool needAutoPtr = !inCatch &&   //in the parameter to a catch block, 
            //we don't use csAutoPtr because then you would get:
            //
            //try {
            //  throw C();
            //}
            //catch(csAutoPtr<C>) {}
            //
            //and the catch clause wouldn't catch it because thrown objects
            //that could be converted to the exception type aren't converted in C++.
            
            t.getType() == Type::CLASS;
    if (needAutoPtr)
    {
        //Object
        cout << "csAutoPtr<";
    }
    if (t.hasFlag(Type::CONST_FLAG))
	{
		cout << "const ";
	}
    if (!omitStatic && t.hasFlag(Type::STATIC_FLAG))
    {
        cout << "static ";
    }
	RealCPPArray* arrTypeNode = dynamic_cast<RealCPPArray*>(n->getTypeNode());
	if (arrTypeNode == 0)
	{
		n->getTypeNode()->accept(code.get());
	}
	else
	{
		//Regular C++ array (compiler-generated node for optimization)
		arrTypeNode->getBase()->accept(code.get());
	}
    if (t.hasFlag(Type::REF_FLAG)) cout << "&";
    if (needAutoPtr) cout << "> ";

	cout <<  " ";
    cout << name;
	if (arrTypeNode != 0)
	{
		cout << "[" << arrTypeNode->getSize() << "]";
	}
    
}

/**Output forward declarations at the beginning of the output.
This is necessary because C* allows declarations after use (for globals),
but C++ doesn't.*/
class ForwardDecls : public FixedVisitor {
public:
    //Function is done in the visit method
    //(rather than preVisit)
    //so the function body isn't visited
    Node* visit(Function* n) {
        outputFunctionHeader(n, n->getRealName());
        cout << ";\n";
        return n;
    }
    
    //Don't forward decl the members of a class.
    Node* visit(ClassDecl* n) {
        if (n->isNameSpace()) return n;  //Can't forward declare a namespace
        
        //Because we can't forward decl a  class, we currently have to
        //force class bodies to appear before use of the class, even though other
        //symbols may have their declarations after their use.
        //Hopefully this can be improved in a future version, but it seems
        //very difficult.
        cout << "class " << n->getName() << ";\n";
        
        n->getDecls()->accept(this);  //Have to forward decl the singletons
            //declared at the end of the class.
        
        return n;
    }
    void preVisit(Enum* n) {
        outputEnum(n, true);
    }
    void preVisit(VarDecl* n) {
        cout << "extern ";
        outputVarDecl(n, n->getName(), false);
        cout << ";\n";
    }
    
    Node* visit(CPPInclude* n) {
        cout << "#include " << n->getInclude() << endl;
        return n;
    }
    
    Node* visit(CPPUsing* n) {
        cout << "using ";
        if (n->getIsNamespace())
            cout << "namespace ";
        cout << n->getThingUsing();
        cout << ";\n";
        return n;
    }
    
    Node* visit(CPPBlock* n) {
        const vector<DeclOrDefn*>& list = n->getDecls()->getDecls();
        for (vector<DeclOrDefn*>::const_iterator i = list.begin(); i != list.end(); ++i)
        {
            //Only output includes, nested cpp blocks, and using declarations.
            //Leave all other declarations within cpp blocks out of the output.
            if (dynamic_cast<CPPElement*>(*i) != 0)
            {
                (*i)->accept(this);
            }
        }
        return n;
    }
    
    
};

Node* CodeGenerator::visit(CPPBlock* n) {
    //Don't visit CPPBlocks - their declarations happen during the forward
    //declarations above in ForwardDecls
    return n;
}

void CodeGenerator::preVisit(DeclList* n) {
    if (!currentSymTable->inClass())  //Don't do forward declarations
        //for class bodies - only for the global scope.
    {
        auto_ptr<ForwardDecls> forward(new ForwardDecls());
        n->accept(forward.get());
    }
}

Node* CodeGenerator::visit(BoolConst* n) {
	if (n->getValue()) cout << "true";
	else cout << "false";
	return n;
}
Node* CodeGenerator::visit(IntConst* n) {
	cout << n->getValue();
	return n;
}
Node* CodeGenerator::visit(CharConst* n) {
	cout << '\'' << n->getValue() << '\'';
	return n;
}

Node* CodeGenerator::visit(Variable* n) {
    bool isTypeClassVar = 
        n->getType().getType() == Type::TYPE && n->getType().getReferredType().getType() == Type::CLASS;
    
    if (isTypeClassVar)
    {
        //In the case of variables that refer to types in a member access, have to
        //output the type it refers to if it's a type variable
        //E.g.:
        //class X;
        //type T := X;
        //T.f();   //Have to output X, not T
        cout << n->getType().getReferredType().getFullClassName();
    }
    else
    {
        //Have to output the realName of the variable if it has one
        //(I.e. operator * has to become __times11 or something, and
        //can't be output as *)
        string name = currentSymTable->getRealName(n->getName(), n->getType());
        cout << name;
    }
    return n;
}

Node* CodeGenerator::visit(Block* n) {
	cout << "{\n";
	pushScope(n->getLabel());   //Have to put push and pop, since they were in
		//the function we're overriding too
	n->getStmts()->accept(this);
	popScope();
	cout << "}\n";
	return n;
}

Node* CodeGenerator::visit(Stmts* n) {
	for (vector<Stmt*>::iterator i = n->getStmts().begin();
		i != n->getStmts().end(); ++i)
	{
		(*i)->accept(this);

		/* Some compound statements don't need a semicolon, but neither does
		it hurt much to give them one so they're printed for simplicity. */ 
		cout << ";\n";
	}
	return n;
}

void CodeGenerator::rangeAssign(AssignExpr* n) {
    RangeSubscript* lhs = dynamic_cast<RangeSubscript*>(n->getLeft());
    
    //This function must be called on an assignment where the
    //LHS is a range subscript.
	assert(lhs != 0);

	//Have to find the li to subtract it
	long li = lhs->getBase()->getType().li();

	//Simply call the rangeAssign function from 
	//the C++ array classes (carray and darray)
	lhs->getBase()->accept(this);
	cout << ".rangeAssign(";
	lhs->getLeft()->accept(this);
	cout << "- " << li;
	if (lhs->getRight() != 0)
	{
        //For something like arr[1..] := v, this section is omitted
        //and the ui is calculated in the rangeAssign function during runtime.
		cout << ", ";
		lhs->getRight()->accept(this);
		cout << "- " << li;
	}
	cout << ", ";

	//Output the object being copied to the range assignment
	const Type& arrType = n->getRight()->getType();
	if (!n->isArrayEqualsScalar(currentSymTable) && arrType.getType() != Type::DARRAY)
	{
		cout << "&(";
		n->getRight()->accept(this);
			//If RHS is a static array, we can output its
			//.v internal array and size (since there's no rangeAssign functions
			//in the array classes that take a carray).
			cout << ".v[0]), " << arrType.size();
	}
	else
	{
		//For dynamic arrays, we have to just pass the dynamic array and have the functions
		//extract its size, because we can't evaluate the dynamic array more than once
		//(in case doing so has a side effect).
		n->getRight()->accept(this);
	}
	cout << ")";
}

Node* CodeGenerator::visit(AssignExpr* n) {
	if (n->isRangeAssign())
	{
		rangeAssign(n);
		return n;
	}
	cout << "(";
	n->getLeft()->accept(this);
    string oper = n->getOper();
    if (oper == "\\=") oper = "/=";
	cout << oper;
	
	n->getRight()->accept(this);
	cout << ")";
	return n;
}

Node* CodeGenerator::visit(RangeSubscript* n) {
	n->getBase()->accept(this);
	//Have to find the li to subtract it
	long li = n->getBase()->getType().li();

	cout << ".rangeSubscript(";
	n->getLeft()->accept(this);
	cout << "- " << li;
	if (n->getRight() != 0)
	{
		cout << ", ";
		n->getRight()->accept(this);
		cout << "- " << li;
	}
	cout << ")";
	return n;
}

Node* CodeGenerator::visit(Binop* n) {
	//Get the realName of the operator
	string realName = currentSymTable->getRealName(n->getOper(), n->getName()->getType());
	if (realName == n->getOper())
	{
		cout << "(";
        
        bool bothInt = n->getLeft()->getType().isInt() &&
            n->getRight()->getType().isInt();

		/*If both operands are integer, convert one to double so the /
		operator in C will be floating point division.*/
		if (n->getOper() == "/" && bothInt)
		{
			cout << "double(";
			n->getLeft()->accept(this);
			cout << ")";
		}
		else {
			n->getLeft()->accept(this);
		}

	   /*since we already know they're both integers
			from the parse phase, / in C will be integer division.*/
		string oper = n->getOper();
        if (oper == "\\") oper = "/";

		cout << ' ' << oper << ' ';
		
		n->getRight()->accept(this);
		cout << ")";

		return n;
	}
	else
	{
		return visit((Call*)n);
	}
}

Node* CodeGenerator::visit(Unop* n) {
	//Get the realName of the operator
	string realName = currentSymTable->getRealName(n->getOper(), n->getName()->getType());
	if (realName == n->getOper())
	{
		cout << "(";
		bool postFix = n->isPostFix();
		if (!postFix)
			cout << n->getOper() << " " ; 
		n->getOperand()->accept(this);
		if (postFix)
			cout << " " << n->getOper(); 
		cout << ")";
		return n;
	}
	else
		return visit((Call*)n);
}

Node* CodeGenerator::visit(Subscript* n) {
	cout << "(";
	n->getBase()->accept(this);
	cout << "[";
	n->getElement()->accept(this);
	long li = n->getBase()->getType().li(); 
	if (li != 0) cout << " - " << li;
	cout << ']'; 
	cout << ")";	
	return n;
}

Node* CodeGenerator::visit(ArrayList* n) {
	if (n->getSize() == 0)
		cout << "bottom()";
	else
	{
		cout << "{";
		n->getValues()->accept(this);
		cout << "}";
	}
	return n;
}

Node* CodeGenerator::visit(Exprs* n) {
	for (vector<Expr*>::const_iterator i = n->getExprs().begin(); i != n->getExprs().end();)
	{
		(*i)->accept(this);
		++i;
		if (i != n->getExprs().end())
			cout << ", ";
		else break;
	}
	return n;
}

Node* CodeGenerator::visit(ArrayRange* n) {    /* Range, as in 1..5.
					If we've gotten to this point, the 2 operands must be constants
					and the list must be printed out. */
	IntConst* leftC = dynamic_cast<IntConst*>(n->getLeft()->eval()),
		*rightC = dynamic_cast<IntConst*>(n->getRight()->eval());

	int lower = leftC->getValue(),
		upper = rightC->getValue();
	if (lower > upper) {   //e.g. 5..1.  Must print the integers in reverse order.
		for (int i = lower; i >= upper; i--) {
			cout << i;
			if (i != upper) cout << ", ";
		}
	}
	else {
		for (int i = lower; i <= upper; i++) {
			cout << i; 
			if (i != upper) cout << ", ";
		}
	}
	return n;
}

Node* CodeGenerator::visit(PointerTypeNode* n) {
	//Pointer to array must be translated to a garray, not a darray
	DArrayTypeNode* arr = dynamic_cast<DArrayTypeNode*>(n->getBase());
	if (arr != 0)
	{
		cout << "garray<";
		arr->getBase()->accept(this);
		cout << " >";
	}
	else
	{
		n->getBase()->accept(this);
	}

	Type t = n->getType();
	if (t.getType() == Type::PTR)
		cout << "*";
	else if (t.getType() == Type::CONST_PTR)
		cout << "*const";
#if 0
	else if (t.getType() == Type::REF)
		cout << "&";
#endif
	else
		assert("Invalid type of alias." == "");
	return n;
}

Node* CodeGenerator::visit(UserTypeNode* n) {
    if ( n->getType().getType() == Type::CLASS)
    {
        //See visit(Variable*)
        cout << n->getType().getFullClassName();
    }
    else
        cout << *n->getName();
	return n;
}

Node* CodeGenerator::visit(PrimTypeNode* n) {
	Type toPrint = n->getType();
	toPrint.clearQuals();  //flags were already printed
	cout << toPrint;
	return n;
}

void CodeGenerator::acceptArrayBase(ArrayTypeNode* n) {
    bool autoPtr = n->getBase()->getType().needAutoPtr();
    if (autoPtr) cout << "csAutoPtr<";
    n->getBase()->accept(this); 
    if (autoPtr) cout << "> ";
}

Node* CodeGenerator::visit(SArrayTypeNode* n) {
	cout << "carray<";
    acceptArrayBase(n);
	cout << ", " << n->getType().size()
		<< " >";  //Make sure to print the extra space
			//to avoid the C++ compiler interpreting >> as the 
			//input operator.
	return n;
}

Node* CodeGenerator::visit(RealCPPArray* n) {
	assert(0 == 1);  //Never visit a RealCPPArray in the output - it has been
        //output in visit(VarDecl*)
	return n;
}

Node* CodeGenerator::visit(DArrayTypeNode* n) {
		cout << "darray<";
    acceptArrayBase(n);
	cout << " >";  //See SArrayTypeNode
	return n;
}

Node* CodeGenerator::visit(GlobalVarDecls* n) {
    //Global variables - only output definitions, not declarations.
    //Declarations have already had an "extern" declaration at the top.
    const vector<VarDecl*> & list =  n->getDecls()->getDecls();
    for (vector<VarDecl*>::const_iterator i = list.begin(); i != list.end(); ++i)
    {
        VarDecl* v = *i;
        if (!currentSymTable->inClass() && v->getInitVal() == 0)
        {
        }
        else 
        {
            v->accept(this);
            cout << ";\n";
        }
    }
    return n;
}

Node* CodeGenerator::visit(VarDecl* n) {
    string name = "";
    if (n->isInstanceVar()) name = qualifier();  //prefix type name with the class
        //implementation we're in, if we're in one.
    
    bool omitStatic = false;
    if (name != "") omitStatic = true;  //Don't output static for definitions in class implementations
    
    name += n->getName();
    
    outputVarDecl(n, name, inCatch, omitStatic);
    RealCPPArray* arrTypeNode = dynamic_cast<RealCPPArray*>(n->getTypeNode());

    if (n->getInitVal() == 0)
    {
        if (arrTypeNode == 0 && n->getTypeNode()->hasDynamicDimensions())
        {
            cout << " = ";
            //If there are dynamic dimensions in the array, we have to 
            //output a constructor call to darray or carray
            arrayInitVal(dynamic_cast<ArrayTypeNode*>(n->getTypeNode()), 0);
        }
        
        else if (n->isVirtual())
        {
            //Declarations of objects of virtual classes need to call a special
            //constructor so that a new object of that type isn't allocated
            //(since you're unable to allocate a new object of virtual type).
            //See static_cpp_output/csAutoPtr.cc for the constructor being called.
            cout << " = ";
            outputVarDecl(n, "", inCatch);  //Output the type again
            cout << "(bottom())";
        }
    }
	else
	{
		cout << " = ";
		if (arrTypeNode == 0 && n->getTypeNode()->isArrayEqualsScalar(n->getInitVal()->getType(), currentSymTable))
		{
			//Array := scalar means we need to output a constructor
			//call to darray or carray.
			arrayInitVal(dynamic_cast<ArrayTypeNode*>(n->getTypeNode()), n->getInitVal());
		}
		else
		{
			n->getInitVal()->accept(this);
		}
	}
	return n;
}

void CodeGenerator::arrayInitVal(ArrayTypeNode* tn, Expr* scalarInitVal)
{
	tn->accept(this);  //Print the type node
//	SArrayTypeNode* stn = dynamic_cast<SArrayTypeNode*>(tn);
	DArrayTypeNode* dtn = dynamic_cast<DArrayTypeNode*>(tn);

	//What if there are pointers stuck in here?  How do you translate:
	//int arr[x]@[y];
	//I guess:
	//darray<darray<int>*> arr(y);
	//The x needn't be there at all, it seems.

	cout << "(";
    
    //Sometimes we need just the size.
    //Sometimes we need just the initial value.
    //Sometimes we need both.
    
    //First figure out what we need.
    
    ArrayTypeNode* newBase = dynamic_cast<ArrayTypeNode*>(tn->getBase());
    bool needInitVal = scalarInitVal != 0 || newBase != 0;
    
    bool isArrayEqualsScalar = scalarInitVal != 0 && 
        tn->isArrayEqualsScalar(scalarInitVal->getType(), currentSymTable);
    
    bool needSize = false;
    if (dtn != 0 && dtn->getSize() != 0)
    {
        if (isArrayEqualsScalar) needSize = true;  //The size is needed for array := scalar
        
        //The next 2 conditions equate to saying if (scalarInitVal == 0)
        //But it makes more sense to specify the cases where it's needed, because there are different
        //reasons for each one.
        
        if (!needInitVal) needSize = true;  //It's needed wherever there's no initial value
        
        if (scalarInitVal == 0 && newBase != 0) needSize = true;  //The size is also needed
            //for multidimensional arrays with dynamic bases.
            //E.g.:
            //int arr[x][y]
            //has to output:
            //darray<darray<int> >(y, darray<int>(x))        
    }

    //Now output based on those flags
    if (needSize) 
        dtn->getSize()->accept(this);  //print size

    if (needSize && needInitVal)
        cout << ", ";

    if (needInitVal)
    {
        if (scalarInitVal != 0)
            scalarInitVal->accept(this);   //print initial value
        else
            arrayInitVal(newBase);
    }
    
#if 0
	if (stn != 0)
	{
		if (scalarInitVal != 0)
			scalarInitVal->accept(this);   //print initial value

	}
	else if (dtn != 0)
	{
		//Dynamic arrays need the size output as a parameter to the
		//constructor
		if (dtn->getSize() != 0)
			dtn->getSize()->accept(this);  //print size
		if (scalarInitVal != 0)
		{
			if (dtn->getSize() != 0)
				cout << ", ";
			scalarInitVal->accept(this);   //print initial value
		}
	}
	ArrayTypeNode* newBase = dynamic_cast<ArrayTypeNode*>(tn->getBase());
	if (scalarInitVal == 0 && newBase != 0)
	{
		if (dtn != 0 && dtn->getSize() != 0) cout << ", ";
		arrayInitVal(newBase);   //print initial value
	}
#endif
	cout << ")";
}

Node* CodeGenerator::visit(Decls* n) {
	//Decls has to print semicolons at the
	//end of each declaration (since sometimes
	//there are VarDecls that shouldn't have a 
	//semicolon after them)
    
    //There will always be 1 decl at this point, because of
    //the FlattenDecls visitor
	for (vector<VarDecl*>::const_iterator i = n->getDecls().begin();
			i != n->getDecls().end(); ++i)
	{
		(*i)->accept(this);
		cout << ";" << endl;
	}
	return n;
}

Node* CodeGenerator::visit(For* n) {
	DeclExpr* loopVarDecl;
	Variable* loopVarExpr;
	string varName;
	if ((loopVarDecl = dynamic_cast<DeclExpr*>(n->getLoopVar())) != 0)
		varName = loopVarDecl->getDecl()->getName();
	else if ((loopVarExpr = dynamic_cast<Variable*>(n->getLoopVar())) != 0)
		varName = loopVarExpr->getName();
	else
		assert("Invalid type of expression in for loop" == "");
	
	cout << "for (";
	n->getLoopVar()->accept(this);
	cout << " = ";
	n->getLeft()->accept(this);
	cout << "; " << varName
		<< ((n->getStep() < 0)? " >= " : " <= ");
	n->getRight()->accept(this);
	cout << "; " << varName
		<< " += ";
	cout << n->getStep();
	cout << ")" << endl;
	n->getBody()->accept(this);
	return n;
}

Node* CodeGenerator::visit(InputExpr* n) {
	cout << "(std::cin";
	for (vector<Expr*>::iterator i = n->getInputs().begin();
		i != n->getInputs().end(); ++i)
	{
		cout << " >> ";
		(*i)->accept(this);
	}

	cout << ")";
	return n;
}

Node* CodeGenerator::visit(OutputStmt* n) {
	cout << "std::cout";
	for (vector<Expr*>::iterator i = n->getOutputs().begin();
		i != n->getOutputs().end(); ++i)
	{
		cout << " << ";
		(*i)->accept(this);
	}
	cout << ";" << endl;
	return n;
}

Node* CodeGenerator::visit(Select* n) {
	//Select statements are converted to an if-else block.
	//The select expression needs to be evaluated only once
	//at the start and stored in a variable, which is used
	//in each if condition.
	
	string tmpName = tempName("_select");
	
	cout << "{" << endl;  /*wrap the select statement in {} to protect the scope
		of the temporary variable*/

	/* Initialize the select/switch expression.  This way it only
	needs to be calculated once, which is important in the case
	where it has side effects. */
    TypeNode* tempTN = buildTNFromType(n->getSelectExpr()->getType());
    tempTN->accept(this);  //Can't just output the type, because the output operator
        //for type works differently than the CodeGenerator visit methods on typenodes.
    delete tempTN;
	cout << " " << tmpName
			<< " = ";
	n->getSelectExpr()->accept(this);
	cout << ";" << endl;

	pushScope(n->getSelectBlock()->getLabel());  //Need to push the scope
		//specially, since we're not visiting the block within the select
		//statement.
	
	const vector<Stmt*>& cases = n->getSelectStmts()->getStmts();
	bool emptyCase = false;
	bool firstCase = true;
	for (vector<Stmt*>::const_iterator i = cases.begin(); i != cases.end();)
	{
		CaseStmt* c = dynamic_cast<CaseStmt*>(*i);
		if (c == 0) {
			assert("Internal error: statement in a select wasn't a case statement" == "");
		}
		
		if (emptyCase) {  //if we had an empty case last time
			cout << " || ";
		}
		else {
			cout << (firstCase? "if (" : "else if (");
			firstCase = false;
		}
		
		cout << "(";
		RangedCaseStmt* r;
		if ((r = dynamic_cast<RangedCaseStmt*>(c)) != 0) {
			//case contains a range
			//Check that tmpName is within the range
			cout << tmpName;
			cout << " >= (";
			r->getLeft()->accept(this);
			cout << ") && ";
			cout << tmpName;
			cout << " <= (";
			r->getRight()->accept(this);
			cout << ")";
			
		}
		else if (c->getCaseExpr() == 0)  //Case else
		{
			cout << "0 == 0";
		}
		else 
		{
			//regular case
			//Check for equality
			cout << tmpName;
			cout << " == (";
			c->getCaseExpr()->accept(this);
			cout << ")";
		}
		cout << ")";
		
		Stmt* body = c->getSubStmt();
		
		++i;
		bool closeIf = (body != 0) || (i == cases.end());
		if (closeIf)
			cout << ")";  //close the if
		
		emptyCase = (body == 0);  //Needed for next time around the loop
		if (body != 0)
			body->accept(this);  //do the substatement

	}
	
	popScope();
	cout << "}" << endl;  //close the select statement
	return n;
}

Node* CodeGenerator::visit(Return* n) {
	if (dynamic_cast<RangeSubscript*>(n->getRetVal()) != 0)
	{
		//If we're returning a range subscript (e.g. return arr[1..5]),
		//then we need to do a special transformation, because
		//the rangeSubscript function in darray constructs a darray that
		//points to temporary data, but that data may not exist after returning
		//from the function.
		//The solution used is to put the return expression in a temporary variable,
		//then return the variable.
		//
		//Another solution I thought of using is to simply wrap the return expression
		//in a darray<...>() constructor call.  For some reason that I couldn't figure
		//out, that had no effect.

		string retValName = tempName("_temp");

		//Create and output the type AST node for the temporary.
		TypeNode* constructorType = buildTNFromType(n->getRetVal()->getType());
		constructorType->accept(this);
		delete constructorType;

		cout << " " << retValName << "(";
		n->getRetVal()->accept(this);
		cout << ");" << endl;

		cout << "return " << retValName;
	}
	else
	{
		cout << "return ";
		n->getRetVal()->accept(this);
		cout << ";" << endl;
	}
	return n;
}

Node* CodeGenerator::visit(Function* n) {
    SymbolTable* oldScope = currentSymTable;

    pushFunctionScope(n);
    
//	pushScope(n->getName(), n->getType());   //Have to put push and pop, since they were in
		//the function we're overriding too
	
    if (n->isStatic()) cout << "static ";
    else if (currentSymTable->inClass() && 
             classQualifier.size() == 0 &&   //If we're in a class implementation, don't output virtual,
                //because it isn't supposed to be present in an implementation in C++.
             !n->isFinal()) cout << "virtual ";
    
    if (n->isFriend())
    {
        cout << "friend ";
    }

    string name = n->getRealName();
    name = qualifier() + name;
	outputFunctionHeader(n, name);
    
    if (n->isConst()) cout << " const ";
    
	//function body, or a semicolon if it's a declaration
	if (n->getBody() == 0)
    {
        if (n->isVirtual())
            cout << " = 0";
		cout << ";\n";
    }
	else
	{
		cout << '{' << endl;
		n->getBody()->accept(this);
		cout << '}' << endl;
	}
//	popScope();
    currentSymTable = oldScope;
	return n;
}

Node* CodeGenerator::visit(Params* p) {
	for (vector<Param*>::const_iterator i = p->getParams().begin(); i != p->getParams().end();)
	{
		(*i)->accept(this);
		++i;
		if (i != p->getParams().end()) {
			cout << ", ";
		}
	}
	return p;
}

Node* CodeGenerator::visit(Call* n) {
	n->getName()->accept(this);
	cout << "(";
	n->getArgs()->accept(this);
	cout << ")";
	return n;
}

Node* CodeGenerator::visit(StrConst* n) {
	cout << "\"" << n->getValue() << "\"";
	return n;
}

Node* CodeGenerator::visit(FloatConst* n) {
	//Output it as a long double to prevent loss of precision.
	cout << n->getValue() << "L";
	return n;
}

Node* CodeGenerator::visit(ArrayProp* n) {
	Type arrayType = n->getLeft()->getType();
	ArrayProp::PropType tp = n->getPropType();
	if (arrayType.getType() == Type::ARRAY || tp == ArrayProp::LI)
	{
		//Static array or li use - the property can always be figured
		//out at compile time
		cout << n->getValue();
	}
	else
	{
		//UI or SIZE for a dynamic array
		n->getLeft()->accept(this);
		cout << ".size";
		if (tp == ArrayProp::UI)
		{
			//UI needs an extra compile-time calculated constant
			//added to it.  (Both UI and SIZE begin with a runtime
			//query of the array's size).
			cout << " + (" << arrayType.li() - 1 << ")";
		}
	}
	return n;
}
Node* CodeGenerator::visit(If* n) {
	cout << "if (";
	n->getCond()->accept(this);
	cout << ")";
	n->getIf()->accept(this);
	if (n->getElse() != 0) {
		cout << "else ";
		n->getElse()->accept(this);
	}
	return n;
}

Node* CodeGenerator::visit(While* n) {
	if (n->isDoWhile()) {
		cout << "do ";
		n->getBody()->accept(this);
		cout << " while (";
		n->getCond()->accept(this);
		cout << ");" << endl;
	}
	else {
		cout << "while (";
		n->getCond()->accept(this);
		cout << ") ";
		n->getBody()->accept(this);
	}
	return n;
}

Node* CodeGenerator::visit(Goto* n) {
	cout << "goto " << n->getTarget() << ";" << endl;
	return n;
}

Node* CodeGenerator::visit(Break* n) {
	cout << "break;" << endl;
	return n;
}

Node* CodeGenerator::visit(Continue* n) {
	cout << "continue;" << endl;
	return n;
}

Node* CodeGenerator::visit(LabelledStmt* n) {
	cout << n->getLabel() << ": ";
	n->getSubStmt()->accept(this);
	return n;
}

Node* CodeGenerator::visit(Cast* n) {
    cout << "(";
    bool autoPtr = n->getSubject()->needAutoPtr();
    bool isThing = n->getSubject()->getType().getType() == Type::THING;
    if (autoPtr)
    {
        //Since you can't cast to a subtype when the cast type is a class,
        //we have to get the ptr from the csAutoPtr object, which is a pointer
        //to an object, and use dynamic cast to get a pointer to the desired class
        //type, then take the value of the result and copy it to a temporary object of 
        //the desired type.
        //
        //It should be OK if the target type is abstract, because you can take the value
        //of a pointer to an abstract type in C++.
        n->getTargetType()->accept(this);
        
        cout << "(*(dynamic_cast<";
        n->getTargetType()->accept(this);
        cout << "*>(";
        n->getSubject()->accept(this);
        cout << ".ptr)))";
    }
    
    else 
    {
        if (isThing)
        {
            //Casts from type thing to another type can't be done as normal casts.
            //The special "cast" function defined in class thing must be used instead.
            //This is because the expression (X)t, for t of type thing, is interpreted
            //as a constructor call for class X (if X is a class), rather than as a cast.

            //For certain types, call a special cast function defined in thing.cc.
            Type toType(n->getTargetType()->getType());
            string funToCall = "";
            if (toType.getType() == Type::CLASS)
            {  
                funToCall = "toClass";
            }
            else if (toType.getType() == Type::CONST_PTR)
            {
                funToCall = "toConstPtr";
            }
            else if (toType.getType() == Type::PTR)
            {
                funToCall = "toPtr";
            }
            if (funToCall != "")
            {
                cout << "(";
                n->getSubject()->accept(this);
                cout << ")." << funToCall << "<";
                n->getTargetType()->accept(this);
                cout << ">()";
                cout << ")";  //bracket around the whole cast
                return n;
            }
            
            //At this point, we're casting from thing to a primitive type.
            //Just use the operator int, etc. defined in thing.cc, i.e.
            //just do a normal cast.
        }
        cout << "(";
        n->getTargetType()->accept(this);
        cout << ")";
        n->getSubject()->accept(this);
    }
    cout << ")";
	return n;
}

Node* CodeGenerator::visit(Enum* n) {
    outputEnum(n);
    
	//output the initial variables
	n->getDecls()->accept(this);
    
	return n;
	
}

Node* CodeGenerator::visit(ValueOf* n) {

	cout << "(";

	if (n->getType().getType() == Type::DARRAY)
	{
		//Value of a pointer to array must call the "construct" function
		cout << "(";
		n->getBaseExpr()->accept(this);
		cout << ")->construct()";
	}
	else
	{
		cout << "*";
		n->getBaseExpr()->accept(this);
	}

	cout << ")";
	return n;
}

Node* CodeGenerator::visit(AddressOf* n) {
	cout << "(";
	cout << "&";
    
    bool autoPtr = n->getBaseExpr()->needAutoPtr();
    if (autoPtr)
        cout << "(*(";
	n->getBaseExpr()->accept(this);
    if (autoPtr) 
        cout << ").ptr)";
    
	cout << ")";
	return n;
}

Node* CodeGenerator::visit(NullConst* n) {
	cout << "0";
	return n;
}

Node* CodeGenerator::visit(ExprStmt* n) {
	n->getExpr()->accept(this);
	cout << ";";
	return n;
}

Node* CodeGenerator::visit(TypeVar* n) {
	//Do nothing - all uses of the type variable should have been replaced
	//with the type by now.
	return n;
}

Node* CodeGenerator::visit(IfExpr* n) {
	cout << "((";
	n->getIfCond()->accept(this);
	cout << ")? (";
	n->getIfPart()->accept(this);
	cout << ") : (";
	n->getElsePart()->accept(this);
	cout << "))";
	return n;
}

Node* CodeGenerator::visit(New* n) {
	cout << "new ";
	n->getTypeNode()->accept(this);
	cout << "(";
	ArrayTypeNode* atn = dynamic_cast<ArrayTypeNode*>(n->getTypeNode());
	size_t numArgs = n->getArgs()->size();
	if (atn == 0)
		n->getArgs()->accept(this);
        
    //new array expressions - if they have an initial value, it's either an array := scalar
    //initialization or a copying of an array into the newly allocated memory.
	else if (numArgs == 0)
	{
		arrayInitVal(atn, 0);
	}
	else if (numArgs == 1)
	{
		arrayInitVal(atn, n->getArgs()->getExprs()[0]);
	}
	else assert ("" == "Array news should have 0 or 1 argument");
	cout << ")";
	return n;
}

Node* CodeGenerator::visit(Delete* n) {
	cout << "delete ";
	n->getVariables()->accept(this);
	return n;
}

void CodeGenerator::compilerGeneratedMembers(ClassDecl* n) {
    //Destructor
    if (n->noDestructor(currentSymTable))
    {
        //We put a virtual destructor in every class, because all inheritance is
        //translated to virtual inheritance.  If a base class has a non-virtual destructor,
        //and something inherits from it with virtual inheritance, then the pointer to the
        //base class doesn't get deleted properly, causing a crash.
        cout << "virtual ~" << n->getName() << "() {}\n";
    }
    
    if (n->hasCopyConstructor(currentSymTable))
    {
        //The copy constructor defined by the user has been converted to an _copy method.
        //Now we need to provide a copy constructor that calls _copy.
        cout << n->getName() << "(const " << n->getName() << "& x)" << "{ _copy(x); }" << endl;
        
        if (!n->hasAssignOperator(currentSymTable))
        {
            //Define the assignment operator automatically, if there's a copy operation
            //defined by no explicit assignment operator.
            
            //= operator header
            cout << n->getName() << "& operator=(const " << n->getName() << "& that) {" << endl;
            
            //check for object identity
            cout << "if (this != &that) {" << endl;
            
            //destruct the current object
            cout << "this->~" << n->getName() << "();" << endl;
            
            //Copy the new object's values into this
            cout << "_copy(that);" << endl;
            
            cout << "}" << endl;
            
            //return a reference to this
            cout << "return *this;" << endl;
            
            cout << "}" << endl;
        }
    }
    
    //Clone method, needed by csAutoPtr
    
    cout << "virtual Thing* _clone() {";
    if (n->isVirtual())
        cout << "throw \"Can't copy a virtual class.\";";
    else
        cout << "return new " << n->getName() << "(*this);";
        
    cout << "}\n";
    
    //Default constructor.
    cout << n->getName() << "()";
    
#if 0
    //Have to output the calls to the super default constructors as well.
    const vector<SuperClass*>& supers = n->getSuperClasses();
    bool first = true;
    for (vector<SuperClass*>::const_iterator i = supers.begin(); i != supers.end(); ++i)
    {
        if (first)
            cout << ": ";
        else
            cout << ", ";
        first = false;
        (*i)->getSuperClass()->accept(this);
        cout << "(b)";
//        cout << *((*i)->getName()) << "(b)";
    }
#endif
    cout << " {}\n";
}

Node* CodeGenerator::visit(ClassDecl* n) {
    pushScope(n->getName(), Type(Type::TYPE, n->getType())); 
    if (n->isImpl())
    {
        //Members in the class implementation need to be qualified with the class name,
        //but the class declaration itself is omitted because C++ doesn't allow more
        //than one body for a class.
        classQualifier.push_back(n->getName());
        n->getBody()->accept(this);
        classQualifier.pop_back();
    }
    else
    {
        cout << "class ";
        cout << qualifier() << n->getName();
        const vector<SuperClass*> & supers = n->getSuperClasses();
        
        
        if (n->getBody() == 0)
            cout << ";\n";
        else
        {
            if (n->getSuperClasses().size() > 0)
            {
                //All inheritance must be virtual, to avoid the diamond inheritance problem.
                //Normally, when you have diamond inheritance in C++, there are multiple copies
                //of the base class's members in the object.
                //Virtual inheritance means there is a pointer to the base classes's members,
                //and therefore only one copy of them, preventing ambiguity errors when accessing
                //the base class or its members.
                cout << ": virtual public ";
                for (vector<SuperClass*>::const_iterator i = supers.begin(); i != supers.end(); ++i)
                {
                    (*i)->getSuperClass()->accept(this);
                    if (i + 1 != supers.end())
                        cout << ", virtual public ";
                }
            }
            else  //All classes must inherit from Thing
            {
                cout << ": virtual public Thing ";
            }
        
            cout << "{\n";
            cout << "public:\n";  //Members in C* are public by default, unlike C++
            
            compilerGeneratedMembers(n);
            
            n->getBody()->accept(this);
            cout << "};\n";

            //Singletons
            n->getDecls()->accept(this);
        }
    }
    popScope();
    return n;
}

Node* CodeGenerator::visit(MemberAccess* n) {
    bool autoPtr = n->getLeft()->needAutoPtr();
    if (autoPtr)
        cout << "(*(";
    n->getLeft()->accept(this);
    if (autoPtr) 
        cout << ").ptr)";
    if (n->getLeft()->getType().getType() == Type::TYPE)
        cout << "::";
    else
        cout << ".";
    cout << n->getRight();
    return n;
}

Node* CodeGenerator::visit(ThisExpr* n) {
    cout << "this";
    return n;
}

Node* CodeGenerator::visit(Constructor* n) {
    string name = qualifier();
    
    if (n->getType().isCopyConstructor(currentSymTable->currentClassType()))
    {
        name += "_copy";
        cout << "void " << name;
    }
    else
    {
        name += currentSymTable->currentClassName();
        cout << name;
    }
    
    cout << "(";
    if (n->getParams()->size() == 0)
    {
        //Default constructor.
        //Give it a junk parameter of type "bottom" so that it doesn't conflict
        //with the compiler generated default constructor, which is intended to 
        //initialize an object with junk.
        cout << "bottom extends";  //Use a name that can't possibly conflict
            //with a C* symbol
    }
    n->getParams()->accept(this);
    cout << ")";
    
    //Initializer list
    if (n->getInitList()->size() > 0)
    {
        cout << ": ";
        
        const vector<Expr*>& list = n->getInitList()->getExprs();
        for (vector<Expr*>::const_iterator i = list.begin(); i != list.end(); )
        {
            (*i)->accept(this);
            ++i;
            if (i != list.end())
                cout << ", ";
        }
    }
    
    pushScope(n->getName(), n->getType()); 

    if (n->getBody() == 0)
        cout << ";" << endl;
    else
    {
        cout << "{" << endl;
        n->getBody()->accept(this);
        cout << "}" << endl;
    }
    popScope();
    return n;
}

Node* CodeGenerator::visit(Initializer* n) {
    n->getName()->accept(this);
    cout << "(";
    n->getValue()->accept(this);
    cout << ")";
    return n;
}

Node* CodeGenerator::visit(Destructor* n) {
    //Destructors are always virtual, because inheritance is always virtual, so that multiple
    //inheritance doesn't cause problems.
    //But don't output virtual if we're in a class implementation.
    if (classQualifier.size() == 0) cout << "virtual ";
    
    string name = "~" + qualifier() + currentSymTable->currentClassName();
    
    cout << name;
    cout << "(";
    cout << ")";
    if (n->getBody() == 0)
        cout << ";" << endl;
    else
    {
        cout << "{" << endl;
        n->getBody()->accept(this);
        cout << "}" << endl;
    }
    return n;
}

Node* CodeGenerator::visit(CCall* n) {
    n->getTypeNode()->accept(this);
    cout << "(";
    if (n->getArgs()->size() == 0)
    {
        //Default constructor.
        //The user generated one got an extra junk parameter (see visit(Constructor*)),
        //so give the call an extra junk argument.
        cout << "bottom()";
    }
    else 
        n->getArgs()->accept(this);
    cout << ")";
    return n;
}

Node* CodeGenerator::visit(TryCatch* n) {
    cout << "try ";
    n->getTryBlock()->accept(this);
    
    //The catches are enclosed in Blocks, so that the exception's scope is
    //only within the catch.  But we can't output braces for the Block.
    const vector<Stmt*>& list = n->getCatches()->getStmts();
    for (vector<Stmt*>::const_iterator i = list.begin(); i != list.end(); ++i)
    {
        Block* b = dynamic_cast<Block*>(*i);
        pushScope(b->getLabel());   //Have to put push and pop, since they were in
		//the function we're overriding too

        assert(b != 0 && b->getStmts()->size() == 1);
        b->getStmts()->getStmts()[0]->accept(this);
        
        popScope();
    }
//    n->getCatches()->accept(this);
    return n;
}

Node* CodeGenerator::visit(Catch* n) {
    cout << "catch (";
    inCatch = true;
    if (n->getParameter() == 0)
        cout << "...";
    else 
        n->getParameter()->accept(this);
    inCatch = false;
    cout << ")";
    n->getBlock()->accept(this);
    return n;
}

Node* CodeGenerator::visit(Throw* n) {
    cout << "throw ";
    if (n->getToThrow() != 0)
        n->getToThrow()->accept(this);
    cout << ";";
    return n;
}
