#ifndef ARRAYTRANSFORM_H_
#define ARRAYTRANSFORM_H_

//Do various transformations on arrays, which are
//considerably more powerful in C* compared to C++.

#include "FixedVisitor.h"

class ArrayTransform : public FixedVisitor {
public:
	virtual void postVisit(RangeSubscript* n);
	virtual void postVisit(Stmts* n);
	virtual void postVisit(New* n);
};

#endif /*ARRAYTRANSFORM_H_*/
