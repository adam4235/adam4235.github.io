#include "BuildVarDecls.h"
#include "buildTNFromType.h"
#include "whole_ast.h"

using namespace std;

Node* BuildVarDecls::visit(UserTypeNode* n) {
	Name* refName = n->getName();
//    SymbolTable* s = symTableOf(n->getName());  //Probably won't work, because in the
        //end we need the type with all the qualifiers contained in it.
  
    try {  
//	if (currentSymTable->exists(refName)) {
		Type lookedUpType = currentSymTable->lookupType(refName);

        if (lookedUpType.getType() == Type::TYPE) {
            lookedUpType = lookedUpType.getReferredType();
            return buildUserTN(n, lookedUpType);
        }
		else {
			compileError << linenum(n) << "`" << *refName << "' is not a type." << endl;
			outputPrevDefn(refName);
			cerr << endl;
		}
	}
	catch (SymbolNotFound& e) {
		compileError << linenum(n) << "Type not found: `" << e.symbol() << "'." << endl;
	}
    catch (AmbiguousSymbol& e) {
        compileError << linenum(n) << "Symbol is ambiguous: `" << e.symbol() << "'." << endl;
    }
    catch (NotClass& e) {
        compileError << linenum(n) << "Not a class: `" << e.symbol() << "'." << endl;
    }
	return n;
}

void BuildVarDecls::postVisit(VarDecl* n) {
    //For declarations of the for T var(...), figure out what the
    //initial value is.
    CCall* cc = dynamic_cast<CCall*>(n->getInitVal());
    if (cc != 0)
    {
        if (n->getType().getType() == Type::CLASS)
        {
            //Constructor call for the initialization - duplicate the TypeNode
            //of the VarDecl for the type of the constructor call.
            TypeNode* tn = n->getTypeNode()->copy();

            cc->setTypeNode(tn);
        }
        else if (cc->getArgs()->size() == 1)
        {
            //E.g. int x(1), which is the same as int x := 1
            n->setInitExpr(cc->getArgs()->snipValue(0));
            delete cc;
        }
        else {
            compileError << linenum(n) << "Wrong number of parameters in initial value, since the variable being declared is not an object." << endl;        
        }
    }
}
