#ifndef BUILDVISITOR_H
#define BUILDVISITOR_H

/** Common base class for the visitor phases to build
 * the symbol table.
 */

/*Building the symbol table and ensuring there are no errors
 * is a complex task.  These are the things that have to be
 * ensured:
 *
-ensure that all symbols have a definition (done by the C++ linker)
-Declaration before use, within a code block, and declaration somewhere in the
compilation unit, for outside a code block.  (Will become trickier with nested
functions, but can ignore those for now.)
-check that when a function or variable is declared multiple times, that the
types are the same (and that the parameters match for functions - will have to
be changed when overloading is supported) - and the same for multiple variable
declarations (which are allowed outside functions, but not inside code blocks).
-Make sure that variables in a function can't shadow the function's
parameters.  This should be doable by putting the function parameters in the
function scope.

Steps:
	-In one compiler pass, add top-level declarations to the symbol table.
	Check for multiple definitions, but allow multiple declarations.
	(That's BuildTopLevel)
	-In the next pass, add local variable declarations to the symbol table.
	Check that used variables have been declared, and that declarations are
	not duplicate within the current scope.  (If the same variable is declared
	in a higher scope, it's OK, because it shadows it.)
	(That's BuildSymTab)
*/

#include "ContextVisitor.h"

class BuildVisitor : public ContextVisitor {
protected:
    Access curAccess;
public:
	BuildVisitor(SymbolTable* s = &symtable) : ContextVisitor(s) { curAccess = PUBLIC; }

	/** Add the enum n to the symbol table */
	virtual void buildEnum(Enum* n, Access a);
    
    /** Add the class declaration n to the symbol table. */
    virtual void buildClass(ClassDecl* n, Access a);
    
    /** Add a type variable to the symbol table. */
	virtual void buildTypeVar(TypeVar* n, Access a);
    
    /** Common method used by buildEnum and buildTypeVar
        to add a type declaration to the symbol table.*/
	virtual bool buildType(Node* n, string name, const Type& type, Access a, bool isDefn);
    
    //Set the current access specifier when you see e.g. "protected:"
    virtual void postVisit(AccessSpec* n);
};

#endif

