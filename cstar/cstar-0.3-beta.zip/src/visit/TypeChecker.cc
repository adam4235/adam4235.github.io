#include "TypeChecker.h"
#include "typeinfo.h"
#include "error.h"
#include "SymbolTable.h"
#include "whole_ast.h"
#include "ArrayConstSearch.h"
#include <memory>

using namespace std;

void notArray(Node* n) {
	compileError << linenum(n) << "Expression is not an array.  Only arrays can be the base operand of the [] operator.\n";
}

void checkForInt(Expr* e, string errPrefix)
{
	const char* endingError = " operand of `..' must have type integer, but doesn't.\n";
	
	if (e != 0)
	{
		const Type& t = e->getType();
		if (!t.isInt())
			compileError << linenum(e) << errPrefix << endingError;
	}
}

/* Check that the range is an integer range */
void TypeChecker::postVisit(RangeSubscript* n) {
	checkForInt(n->getLeft(), "Left");
	checkForInt(n->getRight(), "Right");
		
	if (!n->getBase()->getType().isArray())
		notArray(n->getBase());
}

void TypeChecker::postVisit(Subscript* n) {
	bool baseIsArray = n->getBase()->getType().isArray(); 
	if (!baseIsArray)
		notArray(n->getBase());
	const Type& elementType = n->getElement()->getType();
	if (!elementType.isInt())
		compileError << linenum(n->getElement()) << "Subscript must have integer type, but doesn't.\n";
}

void checkDimsWithInitval(TypeNode* tn) {
	const TypeNode* badNode = tn->checkDimsWithInitval();
	if (badNode != 0) compileError << linenum(badNode) << 
		"Can't give both an initial value and explicit dynamic array dimensions." << endl;
}

void TypeChecker::initialize(TypeNode* tn, Expr** ptrInitVal, Node* n)
{
	bool hasInit;
	Expr* initVal;
	if (ptrInitVal == 0)
	{
		hasInit = false;
		initVal = 0;
	}
	else
	{
		hasInit = *ptrInitVal != 0;
		initVal = *ptrInitVal;
	}
	const Type& t = tn->getType();

	if (hasInit)
	{
		Expr* initExpr = initVal;
		assignmentChecks(n, t, initExpr);
		*ptrInitVal = 
				assignableFrom(n, t, 
					initExpr, 
					true);
		if (tn->isArrayEqualsScalar(initVal->getType(), currentSymTable)) 
		{
			//In array := scalar, the LHS must have the form:
			//int arr[x1][x2]...[xn][y] := scalar
			//where xi are static constants or dynamic values.
			//(If there's a pointer in there somewhere, then the pointer can
			//be a pointer to a dynamic array; see checkPtr called below.)
			ArrayTypeNode* atn = dynamic_cast<ArrayTypeNode*>(tn);
			DArrayTypeNode* dtn = dynamic_cast<DArrayTypeNode*>(tn);
			if ((dtn != 0 && dtn->getSize() == 0) || tn->dimensionsOmitted())
			{
				compileError << linenum(tn) << 
					"Missing size for array.  Assignment of array to"
					" scalar requires all sizes to be explicit." << endl;
			}
			else {
				checkDimsWithInitval(atn->getBase());  //The above call to dimensionsOmitted checked
					//for empty dimensions.  This checks for explicit dynamic dimensions.  The only thing
					//still allowed (up to the first pointer) is static dimensions.
			}
		}
		else
		{
			checkDimsWithInitval(tn);
		}
	} 

	const TypeNode* badNode = tn->checkPtr();
	if (badNode != 0)
	{
		compileError << linenum(badNode) << 
			"Can't have a pointer to an array with explicit size.  Leave the size unspecified." << endl;
	}

	if (t.hasFlag(Type::REF_FLAG)) //getType() == Type::REF)
	{
		if (!hasInit)
			compileError << linenum(n) << "Missing initial value for reference." << endl;
		else if (!t.isConst() && !initVal->isLvalue())
			compileError << linenum(n) << "Initial value for non-const reference must be an l-value." << endl;
	}
}

void TypeChecker::postVisit(VarDecl* n) {
    if (n->getType().hasFlag(Type::FINAL_FLAG))
    {
        compileError << linenum(n) << "Variables can't be final." << endl;
    }
    if (n->declaredVirtual())
    {
        compileError << linenum(n) << "Variables can't be virtual." << endl;
    }
    else if (n->getType().hasFlag(Type::FRIEND_FLAG)) 
    {
        compileError << linenum(n) << "Variables can't be friends." << endl;
    }
	initialize(n->getTypeNode(), &(n->initVal), n);
}

void TypeChecker::postVisit(For* n) {
	if (n->getStep() == 0)
		compileError << linenum(n) << "Step of 0 not allowed.\n";
	const Type& varType = n->getLoopVar()->getType(),
		type1 = n->getLeft()->getType(),
		type2 = n->getRight()->getType();
	bool errFound = false; 

	if (type1.isArray()) {
		compileError << linenum(n->getLeft()) << "Array not allowed to the left of `..'.\n";
		errFound = true;
	}
	if (type2.isArray()) {
		compileError << linenum(n->getRight()) << "Array not allowed to the right of `..'.\n";
		errFound = true;
	}
	if (varType.isArray()) {
		compileError << linenum(n->getLoopVar()) << "Array not allowed as a loop counter.\n";
		errFound = true;
	}
	if (!errFound)
	{
		n->setLeftNoDelete(coerce(n, n->getLeft(), varType));
		n->setRightNoDelete(coerce(n, n->getRight(), varType));
	}
}

void TypeChecker::checkStatic(Reference* n, string name) {
    if (!currentSymTable->inFunction()) return;  //If we're not in a function, the error isn't possible.
    bool instanceVar = n->isInstanceVar();
    bool nStatic = n->getType().hasFlag(Type::STATIC_FLAG);
    bool fStatic = currentSymTable->currentFunctionType().hasFlag(Type::STATIC_FLAG);
    if (instanceVar && !nStatic && fStatic)
    {
        compileError << "Can't access instance variable `" << name << "' from a static context." << endl;
    }
}

Node* TypeChecker::visit(MemberAccess* n) {
    //Make a note that the LHS is allowed to be a type.  (Normally types can't
    //be used as a variable.)
    Variable* lhs = dynamic_cast<Variable*>(n->getLeft());
    if (lhs == 0) 
    //skip traversal of the variable if it's the LHS of a MemberAccess, because in that
    //case it's allowed to be a type, so no error checking need be done on it.
        n->getLeft()->accept(this);
    else
        checkStatic(lhs, n->getRight());  //Still need to do the static check for a reference
    checkStatic(n, n->getRight());
    
    return n;
}

void TypeChecker::postVisit(Variable* n) {
    Type t = n->getType(); 
    if (t.getType() == Type::TYPE)
    {
        compileError << linenum(n) << "Type `" << n->getName() << "' "
            "cannot be used as a variable." << endl;
    }
    checkStatic(n, n->getName());
}

void TypeChecker::postVisit(InputExpr* n) {
	//The values in an input statement can't be arrays.
	//(Later, this will be replaced by a check for the existence
	//of an operator matching the operand types). 
	
	vector<Expr*>& list = n->getInputs();
	for (vector<Expr*>::iterator i = list.begin(); i != list.end(); ++i)
	{
		const Type& t = (*i)->getType();
		if (t.isArray())
		{
			compileError << linenum(*i) << "Can't input into an array.\n";
		}
	}
}

void TypeChecker::postVisit(OutputStmt* n) {
	//The values in an output statement can't be arrays.
	//(Later, this will be replaced by a check for the existence
	//of an operator matching the operand types). 
	
	vector<Expr*>& list = n->getOutputs();
	for (vector<Expr*>::iterator i = list.begin(); i != list.end(); ++i)
	{
		const Type& t = (*i)->getType();
		if (t.isArray() && t.getBaseType() != Type::CHAR)
			//Can't output arrays, with the exception of strings
		{
			compileError << linenum(*i) << "Can't output an array.\n";
		}
	}
}

void TypeChecker::postVisit(Select* n) {
	if (n->getSelectExpr()->getType().isArray())
	{
		compileError << linenum(n->getSelectExpr()) << "Can't have an array in a selection statement.\n";
	}
}

void TypeChecker::postVisit(CaseStmt* n) {
	if (n->getCaseExpr() != 0 && n->getCaseExpr()->getType().isArray())
	{
		compileError << linenum(n->getCaseExpr()) << "Can't have an array in a case statement.\n";
	}
}

void TypeChecker::postVisit(RangedCaseStmt* n) {
	checkForInt(n->getLeft(), "Left");
	checkForInt(n->getRight(), "Right");
}

void TypeChecker::postVisit(ArrayProp* n) {
	if (!n->getLeft()->getType().isArray())
	{
		compileError << linenum(n->getLeft()) << "Left hand side of array property expression is not an array.\n";
	}
}

void TypeChecker::postVisit(Return* n) {
	//get return type of current function
	Type returnType = currentSymTable->currentFunctionType().getRetType();
	
    if (returnType == Type::VOID)
    {
        if (n->getRetVal() != 0)
        {
            compileError << linenum(n) << "Can't return a value from a void function." << endl;
        }
    }
	else n->setRetValNoDelete(coerce(n, n->getRetVal(), returnType));
}

//Checks the condition of a while or if to see whether
//it has type bool
void checkCond(Expr* cond) {
	Type condType = cond->getType();
	if (condType.getType() != Type::BOOL)
	{
		compileError << linenum(cond) << "Condition must be a boolean.  `" 
			<< condType << "' is not allowed." << endl;
	}
}

//Check whether a while loop contains an array literal somewhere in it.
//This isn't allowed because array literals are pulled out, so it would
//be difficult to ensure that the expressions in them are re-evaluated
//each time through the loop.
//This check isn't needed for for loops because they only execute each
//of their expressions once.
void checkLoopForArray(Expr* cond) {
	if (containsArrayConst(cond))
	{
		compileError << linenum(cond) << "Can't have array constants in loop conditions.  (Yet.)" << endl;
	}
}

void TypeChecker::postVisit(While* n) {
	checkLoopForArray(n->getCond());
	checkCond(n->getCond());
}

void TypeChecker::postVisit(If* n) {
	checkCond(n->getCond());
}

void TypeChecker::postVisit(Cast* n) {
	Type castType = n->getTargetType()->getType();
    Type subjectType(n->getSubject()->getType());
	if (castType.isArray()) {
		compileError << linenum(n->getTargetType()) << "Can't cast to an array type." << endl;
	}
	else if (castType.isFunction()) {
        //This currently isn't possible.
		compileError << linenum(n->getTargetType()) << "Can't cast to a function type." << endl;
	}
    else if (castType.getType() == Type::CLASS || subjectType.getType() == Type::CLASS)
    {
        //Make sure that the one type is a subtype of the other
        if (!(castType.isSubType(subjectType, currentSymTable) || 
              subjectType.isSubType(castType, currentSymTable)))
        {
            compileError << linenum(n) << "Invalid cast: no relation between type `" 
                << castType << "' and type `" << subjectType << "'." << endl;
        }
    }
}

void TypeChecker::postVisit(ValueOf* n) {
	const Type& baseType = n->getBaseExpr()->getType();
	if (!baseType.isPtr())
	{
		compileError << linenum(n->getBaseExpr()) << "`$' can only be applied to a pointer.  Expression is not a pointer." << endl;
	}
}

void TypeChecker::postVisit(AddressOf* n) {
	if (!n->getBaseExpr()->isLvalue())
	{
		compileError << linenum(n->getBaseExpr()) << "`@' can only be applied to an l-value (storage location).  Expression is not an l-value." << endl;
	}
}

void TypeChecker::postVisit(GlobalVarDecls* n) {
	if (containsArrayConst(n, true))
	{
		//if there was an array constant within composed of non-constants
		compileError << linenum(n) << "Array initializations in global variables may only"
			" be composed of constants." << endl;
	}
}

void TypeChecker::postVisit(DeclExpr* n) {
	compileError << linenum(n) << "Declaration not allowed in this expression.  "
		"Declarations in expressions "
		"only allowed in if conditions, while loop conditions, expression statements, "
		"or input expressions appearing in one of those types of statements"
		"." << endl;
}

void TypeChecker::postVisit(IfExpr* n) {
	checkCond(n->getIfCond());
}

//Break and continue with labels should have been desugared
//in the cases where they're allowed.

void TypeChecker::postVisit(Break* n) {
    if (n->getTarget() != "")
        compileError << linenum(n) << "Not in a loop labelled `" << n->getTarget() << "'." << endl;
}

void TypeChecker::postVisit(Continue* n) {
    if (n->getTarget() != "")
        compileError << linenum(n) << "Not in a loop labelled `" << n->getTarget() << "'." << endl;
}

void TypeChecker::postVisit(CCall* n) {
    Type t(n->getType());
    if (t.hasFlag(Type::VIRTUAL_FLAG))
        compileError << linenum(n) << "Can't instantiate a virtual class `" << t << "'" << endl;
}

void TypeChecker::postVisit(New* n) {
	Type consType = n->getTypeNode()->getType();
	if (consType.getQuals() != Type::NO_FLAG)
	{
		compileError << linenum(n) << "Type in a new expression can't be qualified." << endl;
	}
	else if (consType.isAlias())
	{
		compileError << linenum(n) << "Can't new a pointer or reference." << endl;
	}
	else if (consType.getType() == Type::THING)
	{
		compileError << linenum(n) << "Can't create an object of type thing on the heap." << endl;
	}
	else if (consType.isArray())
	{
		//Arrays may have 0 or 1 arguments
		size_t numArgs = n->getArgs()->size();
		if (numArgs == 0)
		{
			initialize(n->getTypeNode(), 0, n);
		}
		else if (numArgs == 1)
		{
			initialize(n->getTypeNode(), &(n->args->exprs[0]), n);
		}
		else
		{
			compileError << linenum(n) << 
				"Array new expressions may have at most one argument." << endl;
		}
	}
	else if (consType.isPrimitive())
	{
		//Primitive types must have exactly 1 argument
		if (n->getArgs()->size() == 1)
		{
			initialize(n->getTypeNode(), &(n->args->exprs[0]), n);
		}
		else
		{
			compileError << linenum(n) << 
				"Constructors for primitive types must have exactly one argument." << endl;
		}
	}
    else if (consType.isEnum())
    {
        //Enums must have exactly 1 argument
        if (n->getArgs()->size() == 1)
        {
            initialize(n->getTypeNode(), &(n->args->exprs[0]), n);
        }
        else
        {
			compileError << linenum(n) << 
                "Constructors for enums must have exactly one argument." << endl;
		}        
    }
    /*
	else
	{
		//newing a class (user-defined type)
		compileError << linenum(n) << "User-defined types can't be constructed in new expressions.  (Yet.)"
			<< endl;
	}
    */
}

void TypeChecker::postVisit(Delete* n) {
	const vector<Expr*>& list = n->getVariables()->getExprs();
	for (vector<Expr*>::const_iterator i = list.begin(); i != list.end(); ++i)
	{
		const Type& t = (*i)->getType();
		if (!t.isPtr()) {
			compileError << linenum(*i) << "Can only delete pointers.  Expression is not a pointer." << endl;
		}
        if (dynamic_cast<Reference*>(*i) == 0)
        {
            compileError << linenum(*i) << "Can only delete references (names that refer"
                " to a storage location).  Expression is not a reference." << endl;
        }
	}
}

void TypeChecker::postVisit(Function* n)
{
    //Check that parameters don't have qualifiers.
    //This is done here so that we don't need a visit method for each type
    //of parameter (NormalParam, etc).
    const vector<Param*>& list = n->getParams()->getParams();
    for (vector<Param*>::const_iterator i = list.begin(); i != list.end(); ++i)
    {
        if ((*i)->getType().getQuals() != Type::NO_FLAG)
        {
            compileError << linenum(n) << "Parameters may not have qualifiers." << endl;
        }
    }
    
    if (n->isFinal())
    {
        if (!currentSymTable->inClass())
            compileError << linenum(n) << "Only members of classes can be final." << endl;
        if (n->isStatic())
            compileError << linenum(n) << "Static members can't be final." << endl;
        if (n->isVirtual())
        {
            compileError << linenum(n) << "Functions can't be both final and virtual." << endl;
        }
    }
    else if (n->isVirtual())
    {
        if (n->getBody() != 0)
            compileError << linenum(n) << "Virtual methods can't have a body." << endl;
    }
    if (n->isConst())
    {
        if (!currentSymTable->inClass())
            compileError << linenum(n) << "Only members of classes can be const." << endl;
        if (n->isStatic())
            compileError << linenum(n) << "Static members can't be const." << endl;
    }
    if (n->getType().hasFlag(Type::CASE_FLAG))
    {
        if (!currentSymTable->inClass())
            compileError << linenum(n) << "Function cases may only appear in classes." << endl;
    }
    if (n->isStatic())
    {
        if (!currentSymTable->inClass())
            compileError << linenum(n) << "Static functions may only appear in classes." << endl;
    }
    if (n->isFriend())
    {
        if (!currentSymTable->inClass())
        {
            compileError << linenum(n) << "Friend functions may only appear in classes." << endl;
        }
    }
    else if (n->isOper() && currentSymTable->inClass())
    {
        //Since there would be no way to call the operator, disallow it from being defined yet.
        compileError << linenum(n) << "Non-friend operators may not be members of classes.  (Yet.)" << endl;
    }
    
    if (n->getType().hasFlag(Type::REF_FLAG)) {
        compileError << linenum(n) << "Can't have a reference to a function.  (Yet.)" << endl;
    }
    
	//Make sure user-defined casts have the proper form
	//and aren't defining a cast that isn't needed.
	if (isUserCast(n->getName()))
	{
		if (n->getParams()->getParams().size() != 1)
		{
			compileError << linenum(n) << "User-defined casts must have exactly one parameter." << endl;
		}
		else
		{
			Type retType = n->getRetType();
			Type paramType = n->getParams()->getParams()[0]->getType();
			if (paramType.isSubType(retType, currentSymTable))
			{
				compileError << linenum(n) << "Type `" << paramType << 
					"' is already a subtype of type `" << retType << "'.  Can't define a cast"
					" from a subtype to a supertype." << endl;
			}
		}
	}
	else if (n->isMain())
	{
		//Typecheck the main function
		Type t = n->getType();
		string usageError = "  `main' must have no parameters or a single parameter of type char[][].";
		if (t.getRetType() != Type::INT)
		{
			compileError << linenum(n) << "`main' must return an int." << endl;
		}
		else if (t.getParams().size() > 1)
		{
			compileError << linenum(n) << "Too many parameters to `main'." << usageError << endl;
		}
		else if (t.getParams().size() == 1 && !n->isMainWithArgs())
		{
			compileError << linenum(n) << "Invalid parameter to main." << usageError << endl;
		}
	}
}

void TypeChecker::postVisit(Goto* n) {
    const string& label = n->getTarget();
    bool labelExists = currentSymTable->exists(label);
    if (!(labelExists &&
        currentSymTable->lookUpType(label) == Type::LABEL))
    {
        compileError << linenum(n) << "Label not found: `" << label << "'" << endl;
    }
}

void TypeChecker::postVisit(AccessSpec* n) {
    if (!currentSymTable->inClass()) {
        compileError << linenum(n) << 
            "Access specifiers can only appear in class bodies." << endl;
    }
}

//Do the checks needed for namespaces
class NameSpaceChecker : public FixedVisitor {
public:
    Node* visit(Constructor* n)
    {
        compileError << linenum(n) << "Constructors not allowed in namespaces." << endl;
        return n;
    }
    Node* visit(Destructor* n)
    {
        compileError << linenum(n) << "Destructors not allowed in namespaces." << endl;
        return n;
    }
    Node* visit(Function* n) { return n; }  //elide function bodies
};


Node* TypeChecker::visit(ClassDecl* n) {
	pushScope(n->getName(), Type(Type::TYPE, n->getType()));
    FixedVisitor::doClass(n);
    
    if (n->isNameSpace())
    {
        auto_ptr<NameSpaceChecker> namespaceCheck(new NameSpaceChecker());
        n->accept(namespaceCheck.get());
    }
    
    if (n->getBody() != 0 && !n->hasCopyConstructor(currentSymTable) && currentSymTable->hasPointer())
    {
        cerr << "Warning: Class `" << n->getName() << 
            "' contains pointer members, but no copy constructor.  "
            "Defining a deep copy is probably necessary." << endl;
    }
	popScope();
    return n;
}

void TypeChecker::postVisit(Catch* n) {
    if (n->getParameter() != 0 && n->getParameter()->getType().hasFlag(Type::VIRTUAL_FLAG))
    {
        compileError << linenum(n) << "Can't catch a virtual type.  (Yet.)" << endl;
    }
}
