#include "CheckCPPBlocks.h"
#include "whole_ast.h"

using namespace std;

Node* CheckCPPBlocks::visit(CPPBlock* n) 
{
	return n;
}

void CheckCPPBlocks::postVisit(CPPUsing* n) 
{
	compileError << linenum(n) << "Using statements may only appear inside cpp blocks." << endl;
}

void CheckCPPBlocks::postVisit(CPPInclude* n) 
{
	compileError << linenum(n) << "Include statements may only appear inside cpp blocks." << endl;
}

