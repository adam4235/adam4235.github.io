#include "BuildVisitor.h"
#include "BuildVarDecls.h"
#include "ast/Enum.h"
#include "ast/TypeVar.h"
#include "ast/ClassDecl.h"
#include "ast/AccessSpec.h"

using namespace std;

void BuildVisitor::buildEnum(Enum* n, Access a) {
	if (buildType(n, n->getName(), n->getType(), a, true))
	{
		currentSymTable->addEnumerators(n, a);  //Add the enum and all its enumerators
	}
}

void BuildVisitor::buildClass(ClassDecl* n, Access a) {
    string name = n->getName();
    const Type& type = Type(Type::TYPE, n->getType());  //Have to wrap it in type because that's
        //what would be in the symbol table.
    
    if (currentSymTable->hasDefn(name, type))
    {
        //If a class body already exists, then the 2nd class body is an implementation.
        //Don't need to add the type, since it's already there.
        n->setImpl();
    }
#if 0
    else if (currentSymTable->existsThisScope(name, type))
    {
        //Class body following a class declaration (such as class X).
        //Do nothing, because the class would already be in the symbol table.
    }
#endif
	else 
    {
         buildType(n, n->getName(), n->getType(), a, n->getBody() != 0);
    }

    
}

bool BuildVisitor::buildType(Node* n, string name, const Type& type, Access a, bool isDefn) {

	//Add variable to the symbol table	
	if (currentSymTable->existsThisScope(name)) {
		compileError << linenum(n) << "Duplicate definition of `" <<
			name << "'.  ";
		outputPrevDefn(name, currentSymTable->lookUpType(name));
		cerr << endl;
		return false;
	}
	else
	{
		currentSymTable->addType(n, name, type, a, isDefn);
		return true;
	}
}

void BuildVisitor::buildTypeVar(TypeVar* n, Access a) {
	//First look up any referenced types in the type decl
	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->accept(varDecls.get());

	buildType(n, n->getName(), n->getType(), a, true);
}

void BuildVisitor::postVisit(AccessSpec* n) {
    curAccess = n->getAccess();
}
