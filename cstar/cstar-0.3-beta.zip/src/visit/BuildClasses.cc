#include "BuildClasses.h"
#include "passes.h"
#include "ast/ClassDecl.h"
#include "ast/Function.h"

//Don't visit function bodies
Node* BuildClasses::visit(Function* n) { return n; }

Node* BuildClasses::visit(ClassDecl* n) {
    if (n->getBody() != 0)
    {
        
        //Get the first class body in the case of the current one being a class
        //implementation.
        //This works because getPointOfDefn returns the definition of the first
        //occurrence of the symbol.
        Type t(Type::TYPE, n->getType());
        ClassDecl* originalClass = 0;
        if (n->isImpl())
            originalClass = dynamic_cast<ClassDecl*>(currentSymTable->getPointOfDefn(n->getName(), t));
        
        pushScope(n->getName(), t); 
        
        
        //Recursively do all the stuff within the class body that was done at the top level
        //(BuildTopLevel, adding supertypes, adding further classes, etc.)
        if (!errorFound) bPasses(n->getBody(), currentSymTable, originalClass, n->isNameSpace());
        
        popScope();
    }
    return n;
}

