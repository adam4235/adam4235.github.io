#include "BuildSymTab.h"
#include "tempname.h"
#include "whole_ast.h"
#include "BuildVarDecls.h"
#include "passes.h"
#include "BuildTypes.h"

using namespace std;

Node* BuildSymTab::visit(Block* n) {
	
	//Make up a name for the block
	string blockName = tempName("block");
	n->setLabel(blockName);
	
	//Push the scope
	currentSymTable = currentSymTable->addScope(blockName);

	//Do the substatements
	n->getStmts()->accept(this);
	
	//Pop the scope
	popScope();
	return n;
}

Node* BuildSymTab::visit(ClassDecl* n) {
//local class
    compileError << linenum(n) << "Local classes not allowed.  (Yet.)" << endl;
    return n;
#if 0
    if (n->getBody() == 0)
        compileError << linenum(n) << "Class declarations not allowed in function bodies." << endl;
    if (n->isNameSpace())
        compileError << linenum(n) << "Namespaces not allowed in function bodies." << endl;

    //Call BuildTypes on the class
    if (!errorFound)
    {
        auto_ptr<BuildTypes> buildTypes(new BuildTypes());
        n->accept(buildTypes.get());
     
        symtable.print();  //DEBUG
        cout << endl;
        cerr << endl;
        exit(1);
        
        Type t(Type::TYPE, n->getType());
        
        pushScope(n->getName(), t); 
        
        //Recursively do all the stuff within the class body that was done at the top level
        //(BuildTopLevel, adding supertypes, adding further classes, etc.)
        if (!errorFound) bPasses(n->getBody(), currentSymTable);
        
        popScope();
    }
    return n;
#endif
}

void BuildSymTab::postVisit(Cast* n) {
	//Casts also need any user types looked up
	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->accept(varDecls.get());
}

void BuildSymTab::postVisit(New* n) {
	//New expressions also need any user types looked up
    auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
    n->getTypeNode()->accept(varDecls.get());
}

void BuildSymTab::preVisit(VarDecl* n) {
	SymbolTable* s = currentSymTable;

	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->accept(varDecls.get());

#if 0
	cout << "BuildSymTab: Type of " << n->getName() << ": " << n->getType() << endl;
#endif

	if (n->getInitVal() == 0 && n->getType().isConst())
	{
		compileError << linenum(n) << "Missing initial expression for const." << endl;
	}

	if (n->getName() == "") return;  //parameter declarations
		//with the name omitted within function declarations

	if (n->getType() == Type::VOID) return;  //Means there was an 
		//error looking up the type
	
	//Add variable to the symbol table	
	if (currentSymTable->existsThisScope(n->getName())) {
		compileError << linenum(n) << "Duplicate definition of `" <<
			n->getName() << "'.  ";
		outputPrevDefn(n->getName(), currentSymTable->lookUpType(n->getName()));
		cerr << endl;
	}
	else if (!currentSymTable->add(n, PUBLIC, true))  //true means it's definitely a definition
		//All VarDecls within code blocks are definitions.
	{
		assert(0 == 1);
	}

	assert(s == currentSymTable);
}

//It has to be a previsit so that any initial variables in the enum
//declaration will then get handled by the preVisit(VarDecl*) function.
void BuildSymTab::preVisit(Enum* n) {
	buildEnum(n, PUBLIC);
}

Node* BuildSymTab::visit(TypeVar* n) {
	buildTypeVar(n, PUBLIC);
	return n;
}

Node* BuildSymTab::visit(AssignExpr* n) {
	//Skip checking the name of an assignment expression, because we know
	//= is a valid method.
	n->getArgs()->accept(this);
	return n;
}

Node* BuildSymTab::visit(Variable* n) {
	//Check that the variable has been defined before this point.
    //Can't be done in TypeChecker because definition must come before use for local variables.
	SymbolTable* s = currentSymTable;
    string name = n->getName();
	if (!currentSymTable->exists(name)) {
    
        //The variable might be an implicit MemberAccess with this as the LHS
        if (currentSymTable->inClass())
        {
            Type classType = currentSymTable->currentClassType();
            if (currentSymTable->hasMember(classType, name)) {
                ThisExpr* thisExpr = new ThisExpr();
                thisExpr->setType(classType);
                MemberAccess* retVal = new MemberAccess(new ValueOf(thisExpr), n->getName());
                delete n;
                return retVal;
            }
        }
		compileError << linenum(n) << "Variable not found: `" << n->getName() << "'" << endl;
	}
	assert(s == currentSymTable);
	return n;
}

void BuildSymTab::preVisit(LabelledStmt* n) {
    string label = n->getLabel();
    if (currentSymTable->exists(label)) {
        compileError << linenum(n) << "Duplicate definition of `" <<
            label << "'.  ";
		outputPrevDefn(label, currentSymTable->lookUpType(label));
		cerr << endl;
    }
    else currentSymTable->addLabel(label);
}

void BuildSymTab::postVisit(ThisExpr* n) {
    if (!currentSymTable->inClass()) 
    {
        compileError << linenum(n) << "`this' can only appear in a class." << endl;
    }
    else if (currentSymTable->currentFunctionType().hasFlag(Type::STATIC_FLAG)) 
    {
        compileError << linenum(n) << "`this' can't be used in a static function." << endl;
    }
    else
    {
        Type thisType = currentSymTable->currentClassType();
        if (currentSymTable->currentFunctionType().hasFlag(Type::CONST_FLAG))
            thisType = constOf(thisType);
        n->setType(thisType);
    }
}

void BuildSymTab::postVisit(IfExpr* n) {
    //An if expression needs to know its symbol table to be able to
    //calculate its type.
    n->setSymTable(currentSymTable);
}

Node* BuildSymTab::visit(Constructor* n) {
    ContextVisitor::visit((Function*)n);  //Don't visit the initializer list of a constructor,
        //because that would cause its variables to be prefixed with "this".
    return n;
}
