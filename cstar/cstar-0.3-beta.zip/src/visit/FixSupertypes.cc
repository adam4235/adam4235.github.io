#include "FixSupertypes.h"

#include "ast/ClassDecl.h"

void FixSupertypes::postVisit(ClassDecl* n) {
    //Keep track of the last kind of superclass we saw, so that
    //IMPLICIT supertypes can be converted to that kind.
    SuperClass::Kind lastKind = SuperClass::IMPLICIT;
    
    for (vector<SuperClass*>::iterator i = n->superClasses.begin();
         i != n->superClasses.end(); ++i)
    {
        
        if ((*i)->getKind() == SuperClass::IMPLICIT)
        {
            if (lastKind == SuperClass::IMPLICIT)
            {
                compileError << linenum(*i) << "Expected: extends or <: preceding superclass." << endl;
                return;
            }
            (*i)->setKind(lastKind);
        }
        else
        {
            lastKind = (*i)->getKind();
        }
    }
}
