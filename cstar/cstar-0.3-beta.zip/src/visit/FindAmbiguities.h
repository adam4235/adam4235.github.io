#ifndef FIND_AMBIGUITIES_H
#define FIND_AMBIGUITIES_H

/** Now that function calls have been disambiguated, there may not be
any ambiguities remaining.  The only way there could be is if there's
a variable or a MemberAccess of function type not being used in a call.
E.g.

f;  //f is a function having multiple overloaded definitions.  Which f?

Give an error in these cases.

*/

#include "ContextVisitor.h"

class FindAmbiguities : public ContextVisitor {
public:
    virtual void postVisit(Variable* n);
    virtual void postVisit(MemberAccess* n);
};

#endif
