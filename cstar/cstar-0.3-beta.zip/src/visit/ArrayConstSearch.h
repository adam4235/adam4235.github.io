#ifndef ARRAYCONSTSEARCH_H
#define ARRAYCONSTSEARCH_H

//Search for array constants (literals), with the option
//to allow array literals that are composed only of constants.

#include "FixedVisitor.h"

class ArrayConstSearch : public FixedVisitor {
private:
	bool result;  //Whether we've found an array constant yet
	bool checkForConsts;  //If true, we're checking that any array constant
		//found is composed only of constant values (as allowed in C++),
		//rather than for the mere existence of array constants.
public:
	ArrayConstSearch(bool constCheck = false) 
		: result(false), checkForConsts(constCheck) {}
	virtual Node* visit(ArrayList* n);
	bool getResult() const { return result; }
};

/** Execute the visitor on n, and return the result.
 * @param checkForConsts - see above. */
bool containsArrayConst(Node* n, bool checkForConsts = false);

#endif

