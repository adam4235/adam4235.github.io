#include "BuildTypes.h"
#include "ast/Function.h"
#include "ast/Enum.h"
#include "ast/ClassDecl.h"

//TODO Later: what about local classes?

//Don't visit function bodies
Node* BuildTypes::visit(Function* n) { return n; }

Node* BuildTypes::visit(Enum* n) {
	buildEnum(n, curAccess);
	return n;
}

void outputOrigClass(ClassDecl* n) {
    cerr << "Original definition of class `" << n->getName() << "' at line " 
    << CompileError::getLineInfo(n) << endl;
}

//Pass to check whether a class is virtual - gets run on the class.
//If a class contains any virtual function within it, then it's virtual,
//because a nested class containing a virtual function means the class is
//virtual, and therefore the containing class is virtual.
//(There are also local classes, but if we don't visit function bodies, that's
//OK)
class CheckVirtual : public FixedVisitor {
public:
    bool isVirtual;
    CheckVirtual() { isVirtual = false; }
    Node* visit(Function* n)
    {
        if (n->hasVirtualFlag()) isVirtual = true;  //We don't
            //know the type of the function yet, so we have to look
            //at the declared flags.
        return n;
    }
};


void BuildTypes::doClass(ClassDecl* n) {
    
    Type typeType(Type::TYPE, n->getType());
    if (n->isImpl())
    {
        ++implLevel;
        
        //Keep track of the first class body for the class n
        //for error reporting during the visiting of sub-AST nodes.
        originalClass = dynamic_cast<ClassDecl*>(currentSymTable->getPointOfDefn(n->getName(), typeType));
    }
    ContextVisitor::visit(n);  //don't forget to visit the body
    if (n->isImpl()) --implLevel;    
}

Node* BuildTypes::visit(ClassDecl* n) {
    if (implLevel > 0)
    {
        if (n->getBody() == 0)
        {
            compileError << linenum(n) << 
            "Declaration of `" << n->getName() << "': Only the first class body may contain declarations." << endl;
            outputOrigClass(originalClass);
        }
        if (!currentSymTable->hasDefn(n->getName(), Type(Type::TYPE, n->getType())))
        {
            compileError << linenum(n) << 
            "No previous definition of `" << n->getName() 
            << "'.  Classes found in class implementations must be implementations." << endl;
            outputOrigClass(originalClass);
        }
        else 
        {
            //Implementations don't get built in the symbol table, because the definition would
            //already be there from before.
            n->setImpl();
            doClass(n);
        }
    }
	else 
    {
        //Check whether the class is virtual before adding it to the symbol table.
        //It only needs to be checked in this case of the if-else because a class implementation
        //won't add any virtual methods.
        auto_ptr<CheckVirtual> checkVirtual(new CheckVirtual());
        n->accept(checkVirtual.get());
        if (checkVirtual.get()->isVirtual) {
            n->setVirtual();
        }
        
        buildClass(n, curAccess);
        doClass(n);
    }
	return n;
}

