#ifndef DISAM_CALL
#define DISAM_CALL

/** Disambiguate calls (do overloading resolution) and look up 
the types of references.  These have to be done together because the LHS of
a MemberAccess depends on calls being disambiguated, and the name of a call
depends on MemberAccesses being looked up (and all expressions having their types).

Also figure out what Calls are really C++-style casts or constructor calls.
*/

#include "CheckerHelpers.h"

class DisamAndLookup : public CheckerHelpers {
public:
    
    /** Figure out which function the call n is calling.
     * (Overload resolution algorithm.)
     * @return True iff there was no error.
     */
    bool disambiguate(AbstractCall* n);
    
    /**@return Whether the arguments args are applicable to
     * the parameters in functionType */
    bool applicable(Exprs* args, const Type& functionType);
    
    virtual Node* visit(CCall* n);
    
    virtual Node* visit(Call* n);  //has to do a visit instead of a postVisit because
        //it might convert calls to C++-style casts.

    //Initializer lists
    virtual Node* visit(Constructor* n);

    virtual void postVisit(Unop* n);
    virtual void postVisit(Binop* n);
    virtual void postVisit(AssignExpr* n);
    virtual void postVisit(MemberAccess* n);
    virtual void postVisit(ArrayList* n);
    virtual void postVisit(Variable* n);
    
    //Check that the default constructor exists for arrays of classes within
    //variable declarations and new expressions.
    virtual void postVisit(VarDecl* n);
    virtual void postVisit(New* n);
    
    /** Typecheck a MemberAccess. */
    void checkMemberAccess(MemberAccess* n);

    /** visit a Call, but not its sub-AST nodes.
    Used by both visit(Call*) and initializer lists.*/
    Expr* visitCall(Call* n);

    /** visit all the different types of calls (either CCall or Call, Binop, Unop, etc)*/
    void doCall(AbstractCall* n);

    /** Lookup the type of a constructor call in the symbol table.
    Might convert it to a cast, if it turns out that it isn't a constructor
    but it might be a valid cast.
    @return The result of maybeCallToCast, or n.  Might delete n. */
    virtual Expr* lookupConstructor(CCall* n);

    /** Convert a call to a cast.
    @param tn A typenode built for the cast.
    @return The cast node.
        Deletes n.*/
    virtual Expr* callToCast(AbstractCall* n, TypeNode* tn);

};

#endif
