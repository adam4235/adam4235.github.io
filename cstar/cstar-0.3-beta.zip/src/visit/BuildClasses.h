#ifndef BUILDCLASSES_H
#define BUILDCLASSES_H

/*
 * Add the bodies of classes to the symbol table, and recursively
 * build the members therein.
 */

#include "BuildVisitor.h"

class BuildClasses : public BuildVisitor {
public:
	BuildClasses(SymbolTable* s = &symtable) : BuildVisitor(s) {}
    
    //Don't visit function bodies
    virtual Node* visit(Function* n);
    virtual Node* visit(ClassDecl* n);
};

#endif
