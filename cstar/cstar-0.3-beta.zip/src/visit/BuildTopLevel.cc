#include "BuildTopLevel.h"
#include "ast/Function.h"
#include "ast/Constructor.h"
#include "ast/Destructor.h"
#include "ast/VarDecl.h"
#include "ast/ClassDecl.h"
#include "BuildVarDecls.h"
#include "error.h"
#include "tempname.h"

using namespace std;

void BuildTopLevel::conflict(Node* n, const string& name) {
	compileError << linenum(n) << "Conflict with previous definition/declaration of `"
		<< name << "'" << endl;
	outputPrevDefn(name);
	cerr << endl;
}

void BuildTopLevel::outputOrigClass() {
    cerr << "Original definition of class `" << originalClass->getName() << "' at line " 
    << CompileError::getLineInfo(originalClass) << endl;
}

void BuildTopLevel::checkMember(Node* n, string name, Type type) {
    if (!currentSymTable->exists(name, type))
    {
        compileError << linenum(n) << 
        "Definition of `" << name << "': Class implementations may only contain members"
        " that have previously been declared.  No previous declaration of `" << name << "' of type `" << type << "'." << endl;
        outputOrigClass();
    }
}

//Don't visit class bodies
Node* BuildTopLevel::visit(ClassDecl* n) { 
    n->getDecls()->accept(this);  //Visit the singletons declared at the end
        //of the class body
    return n; 
}

Node* BuildTopLevel::visit(Function* n) {
	SymbolTable* s = currentSymTable;

    if (m_inNamespace) n->setStatic();  //Everything in a namespace is static

	//First build the types in the function's parameters and return
	//type
	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->getParams()->accept(varDecls.get());
	if (n->getRetTypeNode() != 0) n->getRetTypeNode()->accept(varDecls.get());

	//Now build the type of the function itself
	n->buildType();

    //Add the friend, if it's a friend function
    if (n->isFriend())
    {
        if (!currentSymTable->inClass())
        {
            compileError << linenum(n) << "Friend functions must be declared in a class." << endl;
            return n;
        }
        else
        {
            n->setFriend(currentSymTable->currentClassType());
        }
    }
    
    //Implementation checks
    if (classImpl())
    {
        checkMember(n, n->getName(), n->getType());
        
        if (n->getBody() == 0)
        {
            compileError << linenum(n) << 
            "Declaration of `" << n->getName() << "': Only the first class body may contain declarations." << endl;
            outputOrigClass();
        }
    }
    
	//Finally, add the function to the symbol table.
	if (n->getBody() != 0 && currentSymTable->hasDefn(n->getName(), n->getType())) {
	//Multiple declarations are allowed, but not multiple definitions
		compileError << linenum(n) << "Duplicate definition of `" << n->getName() << "'.  ";
		outputPrevDefn(n->getName(), n->getType());
		cerr << endl;
	}
    else if (currentSymTable->inClass() && !classImpl() &&
             currentSymTable->existsThisScope(n->getName(), n->getType()))
    {
        compileError << linenum(n) << "Class bodies can't contain multiple definitions of a member." << endl;
		outputPrevDefnOrDecl(n->getName(), n->getType());
		cerr << endl;
    }
	else {
        SymbolTable* toAddTo;
        if (n->isFriend())
        {
            //Friend functions get added to the symbol table their enclosing class
            //is in.
            
            toAddTo = currentSymTable->currentClassContainer();
            
            if (n->getBody() == 0)
            {
                //Friend declaration.
                //If there is already a non-friend definition in the toAddTo scope,
                //we have to set that definition to be a friend.
                
                Type friendLessType = n->getType();
                friendLessType.clearFriend();
                
                if (toAddTo->existsThisScope(n->getName(), friendLessType))
                {
                    toAddTo->makeFriendOf(n->getName(), friendLessType, n->getType().getFriendType());
                }
            }
        }
        else toAddTo = currentSymTable;
        
		//Can't have a function of the same name with a different type as
		//in a previous declaration/definition.
		if (toAddTo->addFunction(n, curAccess) == 0) {
			conflict(n, n->getName());
		}
	}
	assert(s == currentSymTable);
	return n;
}

Node* BuildTopLevel::visit(Constructor* n)
{
    if (currentSymTable->inClass())
    {
        return visit((Function*)n);
    }
    else
    {
        compileError << linenum(n) << "Constructors may only appear in classes." << endl;
    }
    return n;
}

Node* BuildTopLevel::visit(Destructor* n)
{
    if (n->getParams()->getParams().size() > 0)
    {
        compileError << linenum(n) << "Destructors can't have parameters." << endl;
    }
    else if (currentSymTable->inClass())
    {
        return visit((Function*)n);
    }
    else
    {
        compileError << linenum(n) << "Destructors may only appear in classes." << endl;
    }
    return n;
}

Node* BuildTopLevel::visit(VarDecl* n) {
	//See visit(Function*)
	
    if (m_inNamespace) n->setStatic();  //Everything in a namespace is static
    
    bool inClass = currentSymTable->inClass();
	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->accept(varDecls.get());

    if (currentSymTable->inClass())
    {
        n->setInstanceVar();  //Keep track of the fact that n is an
        //instance variable
        
        if (n->getInitVal() != 0 && !classImpl())
        {
            //TODO later: when I let instance variables have initial values, still prevent
            //non-const static ones from having an initial value (except in the class implementation.)
            compileError << linenum(n) << "Instance variables can't have initial values.  (Yet.)" << endl;
        }
    }
	
    //Implementation checks
    if (classImpl())
    {
        checkMember(n, n->getName(), n->getType());
        if (!n->getType().hasFlag(Type::STATIC_FLAG) || 
            n->getInitVal() == 0)
        {
            compileError << linenum(n) << 
            "Declaration of `" << n->getName() << "': Only the first class body may contain declarations." << endl;
            outputOrigClass();
        }
    }
    
	if (n->getInitVal() != 0 && currentSymTable->hasDefn(n->getName(), n->getType())) {
		compileError << linenum(n) << "Duplicate definition of `" << n->getName() << "'.  ";
		outputPrevDefn(n->getName(), n->getType());
		cerr << endl;
	}
    else if (inClass && !classImpl() && currentSymTable->existsThisScope(n->getName(), n->getType()))
    {
        compileError << linenum(n) << "Class bodies can't contain multiple definitions of a member." << endl;
		outputPrevDefnOrDecl(n->getName(), n->getType());
		cerr << endl;
    }
	else {
		if (!currentSymTable->add(n, curAccess)) {
			conflict(n, n->getName());
		}
	}

	if (n->getType().isStatic() && !inClass) {
		compileError << linenum(n) << "Global variables can't be static." << endl;
	}
	return n;
}

