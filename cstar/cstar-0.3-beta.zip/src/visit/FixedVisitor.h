#ifndef FIXEDVISITOR_H_
#define FIXEDVISITOR_H_

/** A visitor whose traversal is fixed, so that users can only
 * (and only need to) override the visiting of each node */
//The methods in this visitor also handle replacing the old
//sub-AST node with the one that was returned 
//from visiting the sub-AST node (the Node* result of the visit methods).
//By default, of course, nothing is replaced,
//but the user can override one of these methods and return
//a new node to cause replacement to take place.

#include "Visitor.h"
#include <vector>

class FixedVisitor : public Visitor {
public:

//visit a class.  Used by ContextVisitor as well.
virtual void doClass(ClassDecl* n);

//visit a function.  Used by visit(Constructor) and visit(Destructor) as well.
virtual void doFunction(Function* n);

//See Visitor class for what's going on here
#include "fixedvisitor_visit_methods.h"

//A shortcut to accept a list of values.
//begin and end are STL iterators.
//It didn't seem to work (I forget why), so it was removed
//and lists are done with a loop in each case.
//template<typename T> void acceptList(T begin, T end);
};

#endif /*FIXEDVISITOR_H_*/
