#ifndef PRINTAST_H
#define PRINTAST_H

#include "FixedVisitor.h"
#include <string>

class PrintAST : public FixedVisitor {
private:
	int indent;
public:

//See Visitor.h for what's going on here
#include "print_ast.h"

void print(const std::string& s);

};

#endif

