#include "DisamAndLookup.h"
#include "typeinfo.h"
#include "error.h"
#include "SymbolTable.h"
#include "whole_ast.h"
#include "buildTNFromType.h"

/** Called on the LHS of an assignment expression.
 * Checks that there are the correct number of range subscript brackets
 * in the expression.
 * E.g. if you have arr := arr2, and arr is an array, it would give an
 * error because the user must change it to arr[..] := arr2.
 *
 * @param numAllowedBases The number of dimensions allowed in
 * 	n (i.e. the number of range subscripts we've seen so far)
 */
bool checkArrayLHS(Expr* n, int numAllowedBases)
{
	RangeSubscript* nAsRange;
	if ((nAsRange = dynamic_cast<RangeSubscript*>(n)) == 0)
	{
		Type t = n->getType();
		for (int i = numAllowedBases; i > 0; --i)
		{
			t = t.getBaseType();  //t must be an array because of the
            //typechecking done on the sub-AST branches
		}
		return !t.isArray();
	}
	else 
		return checkArrayLHS(nAsRange->getBase(), numAllowedBases + 1);
}

void invalidLHS(Node* n) {
    compileError << linenum(n) << "Left of `.' operator must be an object, class, or pointer to object." << endl;
}

/** @Return whether retVal was converted to a cast
by lookupConstructor or maybeCallToCast*/
bool becameCast(Node* retVal) {
    return (retVal != 0 && dynamic_cast<Cast*>(retVal) != 0);
}

bool isCast(AbstractCall* n)
{
    assert(n->getType().getType() != Type::AMB);
    
    return (n->getArgs()->size() == 1);
    
}

void DisamAndLookup::postVisit(ArrayList* n) {
	bool noRangesAllowed = n->containsNonConsts();
    
	//Figure out the type of the list of values from the
	//types of all the elements
	Type type(Type::BOT);
	const vector<Expr*> & list = n->getValues()->getExprs();
	for (vector<Expr*>::const_iterator i = list.begin();
         i != list.end(); ++i)
	{
		Type newType = (*i)->getType();
        
		if (dynamic_cast<ArrayRange*>(*i) != 0)
		{
			if (noRangesAllowed)
			{
				//TODO later: If .. becomes an operator that can have variables,
				//inform the user that they could use concatenation instead.
				compileError << linenum(*i) << "Array ranges only allowed in literals "
                "composed entirely of constants." << endl;
				return;
			}
            
			//For ranges of values, e.g. 1..100,
			//we have to consider the base type
			//of the range.
			newType = newType.getBaseType();
		}
        
		type = type.mostGeneral(newType, currentSymTable);
	}
	
	long size = n->getSize();  //The size of the
    //list is not the number of elements in the vector list,
    //but the size calculated during parsing.
    //Remember that we can have array literals like
    //[1..100], which has 1 list item but size 100.
	
	n->setType(Type(type, size));
}

void DisamAndLookup::postVisit(MemberAccess* n) {
    checkMemberAccess(n);
}

Expr* DisamAndLookup::visitCall(Call* n) {
    Type t(n->getName()->getType());
    
	Reference* possibleType = dynamic_cast<Reference*>(n->getName());
	if (possibleType != 0 && t.getType() == Type::TYPE)
	{
        //The "Call", it turns out, is really a C++-style cast or a constructor call
        
        Expr* retVal;
        Type refType(t.getReferredType());
        if (refType.getType() == Type::CLASS)
        {
            //Convert it to a constructor call
            UserTypeNode* tn = new UserTypeNode(possibleType->convertToName());
            tn->setLookedUpType(refType);
            CCall* newN = new CCall(tn, n->snipArgs());
            delete n;
            
            retVal = lookupConstructor(newN);
            if (becameCast(retVal)) return retVal;
            return newN;
        }
        else
        {
            //If it isn't a constructor call, we might still be
            //able to convert it to an upcast or a downcast
            if (isCast(n))
            {
                TypeNode* tn;
                try {
                    tn = buildUserTN(new UserTypeNode(possibleType->convertToName()), refType);
                    return callToCast(n, tn);
                }
                catch(LeftNotClass& e) {
                    //I think this can only happen if possibleType referred to a Type when it wasn't supposed to.
                }
                
            }
        }
	}
	return n;
    
}

Node* DisamAndLookup::visit(Call* n) {
    //Don't forget to visit the function name and arguments too
    FixedVisitor::visit(n);
    Node* retVal = visitCall(n);
    if (!becameCast(retVal)) doCall((Call*)retVal);
    return retVal;
}

Expr* DisamAndLookup::callToCast(AbstractCall* n, TypeNode* tn) {
        //Convert it to a cast
//            TypeNode* tn = buildTNFromType(castType);
            Cast* newN = new Cast(tn, n->getArgs()->snipValue(0));
            delete n;
            return newN;
}

void DisamAndLookup::doCall(AbstractCall* n) {
    
    Type t(n->calleeType());
    if (t == Type::VOID) return;  //Can't disambiguate if there was an error in the function name
    
    bool disamSuccess = true;
    if (t.getType() == Type::AMB)
    {
        disamSuccess = disambiguate(n);  //overloading resolution
    }
    if (disamSuccess)  //Still have to coerce the arguments below
        //if disambiguation was done.  (Also if the type wasn't ambiguous.)
    {
        t = n->calleeType();  //n's callee type may have changed in disambiguate
        if (!t.isFunction())
        {
            compileError << linenum(n) << "Attempt to call a non-function." << endl;
        }
        else
        {
            //Give specific error messages for the most common case of only 1
            //function of the given name
            vector<Type> parameters = t.getParams();
            vector<Expr*> arguments = n->getArgs()->getExprs();
            if (arguments.size() < parameters.size())
            {
                compileError << linenum(n) << "Too few arguments in call.\n";
            }
            else if ( arguments.size() > parameters.size())
            {
                compileError << linenum(n) << "Too many arguments in call.\n";
            }
            else
            {
                std::size_t sz = arguments.size();
                Exprs* args = n->getArgs();
                Exprs* newArgs = new Exprs();
                for (std::size_t i = 0; i < sz; ++i)
                {
                    Type param = parameters[i];
                    Expr* arg = args->snipValue(i);
                    newArgs->add(coerce(arg, arg, param));
                }
                n->setArgs(newArgs);  //deletes args in the process
            }
        }
    }
}
    
void DisamAndLookup::postVisit(Unop* n) {
	if (n->isIncOrDec())
	{
		if (!n->getOperand()->isLvalue())
		{
			compileError << linenum(n->getOperand()) << 
            "Can only use `" << n->getOper() << "' operator on an l-value (storage location)." 
            "  Expression is not an l-value." << endl;
		}
	}
    doCall(n);
}


void DisamAndLookup::postVisit(AssignExpr* n) {
	const Type& targetType = n->getLeft()->getType();
    const Type& sourceType = n->getRight()->getType();
    
    if (targetType == Type::VOID || sourceType == Type::VOID)
    {
        n->Call::disambiguate(Type::VOID);  //Make sure we don't give an error during FindAmbiguities
        
        //There's an error in the LHS or RHS
        return;
    }
	if (!n->getLeft()->isLvalue()) {
		compileError << linenum(n->getLeft()) << "Left hand side of assignment must be an l-value "
        "(storage location).  Expression is not an l-value." << endl;
	}
	else if (n->getLeft()->isConst()) {
		compileError << linenum(n->getLeft()) << "Left hand side of assignment can't be constant." << endl;
	}
	assignmentChecks(n, targetType, n->getRight());
	
	if (!checkArrayLHS(n->getLeft(), 0))
	{
		compileError << linenum(n->getLeft()) << "Left hand side of assignment needs to "
        "be subscripted.  Use [..] for an array copy." << endl;
	}
	n->setRightNoDelete(assignableFrom(n, targetType, n->getRight()));
    if (n->getOper() == "/=" && targetType.isInt())
    {
        compileError << linenum(n) << "Can't have an integer on the LHS of /=, because it's always floating point division in C*.  (Use \\= for integer division.)" << endl;
    }
	if (!errorFound)
	{
        if (n->getOper() == "=")
        {
            //The := operator isn't in the symbol table, so we have to set the type
            //specially for it.
            n->disambiguate();
        }
		else
			doCall(n);  //For +=, -=, etc. we have to typecheck
		//it as a call and look up the operator in the symbol table.
	}
}

void DisamAndLookup::postVisit(Binop* n) {
    if (n->isEnumEquality() || n->isPtrEquality())
    {
        //== and != for enum types
        //won't be in the symbol table.
        //Likewise for == and != for pointers.
        //We have to disambiguate them manually.
        n->disambiguate();
    }
    else
    //Most binary operators are treated like a method call
    //Look up the operator in the symbol table and get the return value.
        doCall(n);
}

bool DisamAndLookup::applicable(Exprs* args, const Type& functionType)
{
	const vector<Expr*>& argList = args->getExprs();
	const vector<Type>& paramList = functionType.getParams();
    
	//#args must = #params for the call to be applicable
	if (argList.size() != paramList.size()) return false;
	vector<Expr*>::const_iterator i = argList.begin();
	vector<Type>::const_iterator j = paramList.begin();
    
	//All the argument types must be subtypes of the parameter types
	for (; i != argList.end() && j != paramList.end(); ++i, ++j)
	{
		if (!convertible((*i), (*j))) return false;
	}
	return true;
}

void noSuchFunction(AbstractCall* n)
{
    compileError << linenum(n) << "No function found to apply to call to "
    << n->getCalleeStr() << " with arguments (";
    const vector<Expr*>& list = n->getArgs()->getExprs();
    for (vector<Expr*>::const_iterator i = list.begin(); i != list.end(); ++i)
    {
        compileError << (*i)->getType();
        if (i + 1 != list.end()) compileError << ", ";
    }
    compileError << ")" << endl;
}

void ambiguousCall(AbstractCall* n, const vector<Type>& choices, const vector<Node*>& linenums)
{
	compileError << linenum(n) << "Ambiguous call to " 
        << n->getCalleeStr() << ": multiple functions match.  Possible matches:" << endl;
    
	vector<Node*>::const_iterator j = linenums.begin();
	for (vector<Type>::const_iterator i = choices.begin(); i != choices.end(); ++i, ++j)
	{
		compileError << *i << " (See line " << CompileError::getLineInfo(*j) << ")" << endl;
	}
}

bool DisamAndLookup::disambiguate(AbstractCall* n) {
	const Type& ambType = n->calleeType();
	if (ambType.getType() != Type::AMB) return true;
    
	//Now we have an ambiguous type to disambiguate as much as possible
	
	//1. Remove any function possibilities that are not applicable
	vector<Type> choices;
	vector<Node*> linenums;
    vector<Node*> allLinenums = ambType.getPointsOfDefnOrDecl();
	vector<Node*>::const_iterator j = allLinenums.begin();
    vector<Type> allChoices = ambType.getChoices();
	for (vector<Type>::const_iterator i = allChoices.begin(); 
         i != allChoices.end(); ++i, ++j)
	{
		if (applicable(n->getArgs(), *i))
		{
            //			cout << "Applicable type: " << *i << endl;  //DEBUG
			choices.push_back(*i);
			linenums.push_back(*j);
		}
	}
    
	if (choices.size() == 0) 
	{
        noSuchFunction(n);
		return false;
	}
    
    //cout << choices.size() << endl;  //DEBUG
	
	//2. Search for a function that's more specific than all the others
	for (vector<Type>::const_iterator i = choices.begin(); i != choices.end(); ++i)
	{
		bool iMostSpecific = true;  //assume it's the most specific until proven otherwise
		for (vector<Type>::const_iterator j = choices.begin(); 
             j != choices.end() && iMostSpecific; ++j)
		{
			if (!i->isMoreSpecific(*j, currentSymTable))
			{
                //				cout << *i << " is not more specific than " << *j << endl;  //DEBUG
				iMostSpecific = false;
			}
            //			else cout << *i << " is more specific than " << *j << endl;  //DEBUG
		}
		if (iMostSpecific)
		{
			n->disambiguate(*i);
            MemberAccess* memAccess = n->getMemberAccess();
            if (memAccess != 0)
            {
                checkMemberAccess(memAccess);
            }
			return true;
		}
	}
	ambiguousCall(n, choices, linenums);
	return false;
}

void DisamAndLookup::checkMemberAccess(MemberAccess* n) {
    //Look up the member to the right of `.' in the struture on the left of `.'
    Type classType = n->getLeft()->getType();
    
    //Can't check if the LHS is void (which means an error occurred.)
    if (classType.getType() == Type::VOID)
        return;
    
    string memberName = n->getRight();
    bool object;  //Whether the LHS is an object (as opposed to a class, whose members are also accessed
    //with . as opposed to :: from C++)
    if (classType.getType() == Type::TYPE)
    {
        object = false;
        classType = classType.getReferredType();
    }
    else 
    {
        //-> operator from C++ replaced with . operator
        while (classType.isPtr())
        {
            classType = classType.getBaseType();
            n->setLeft(new ValueOf(n->snipLeft()));
        }
        
        if (classType.getType() == Type::CLASS)
        {
            object = true;
        }
        else
        {
            invalidLHS(n);
            return;
        }
    }
    if (classType.getType() != Type::CLASS)
    {
        invalidLHS(n);
    }
    else
    {
        Type t;
        if (n->getType() != Type::VOID)
        {
            //If the first time through the type is ambiguous,
            //it will go through the else below, then this function
            //will get called again by disambiguate(Call*) once the
            //type has been disambiguated.
            //
            //In this case, we can't look up the type again, but have to set
            //it to the disambiguated type.
            t = n->getType();
        }
        else
        {
            t = currentSymTable->lookupMember(classType, memberName);
            if (t.getType() == Type::VOID)
            {
                compileError << linenum(n) << "Class `" << classType.getClassName() << 
                "' has no member named `" << memberName << "'." << endl;
                return;
            }
            
            else
            {
                if (t.getType() == Type::AMB)  //The MemberAccess will have
                    //to be re-checked later, in the TypeChecker::postVisit(Call*) function,
                    //becase we can't tell whether it's private, protected, or static
                    //until we know which function is being called.
                    //
                    //Ambiguous types can also happen if the class's superclasses
                    // contained multiple members of a particular
                    //name and different types, 
                    //but in that case there would have been an error 
                    //for that class body in the CheckClasses pass, so it wouldn't
                    //have gotten here.
                {
                    n->setType(t);
                    return;
                }
            }
        }
        if (object && t.getType() == Type::TYPE)
        {
            compileError << linenum(n) << "Can't access a type with an object.  "
            << "Use the name of the class instead." << endl;
        }
        if (object && t.hasFlag(Type::CONST_FLAG) && !classType.isConst())
        {
            compileError << linenum(n) << "Can't access const member `"
            << memberName << "' through a non-const reference." << endl;
        }
        if (object && t.hasFlag(Type::STATIC_FLAG))
        {
            compileError << linenum(n) << "Can't access static member `" << memberName
            << "' with an object variable.  Static members may only be referenced through class names." << endl;
        }
        else if (!object && !t.hasFlag(Type::STATIC_FLAG))
        {
            if (!currentSymTable->inSubclassOf(n->getLeft()->getType()))  //You can say X.f(), where
                //X is a superclass of a class in the current scope.
            {
                compileError << linenum(n) << "Can't access non-static member `"
                << memberName << "' with a class name.  Expression needs to be qualified with an object." << endl;                
            }
        }
        else 
        {
            //If we're in a friend function which has access to the private
            //data of the LHS of the member access, then don't give access errors.
            if (currentSymTable->currentFunctionType().isFriendOf(classType))
            {
                //Do nothing
            }
            else
            {
                Access spec = currentSymTable->lookupAccess(classType, memberName, t);
                if (spec == PROTECTED && !currentSymTable->inSubclassOf(classType))
                {
                    compileError << linenum(n) << "Can't access protected member `" << memberName <<
                    "' from here." << endl;
                }
                else if (spec == PRIVATE && !currentSymTable->inClass(classType))
                {
                    compileError << linenum(n) << "Can't access private member `" << memberName <<
                    "' from here." << endl;
                }
            }
        }
        n->setType(t);
        if (currentSymTable->isInstanceVar(classType, memberName, t))
        {
            n->setInstanceVar();
        }
    }
}

void DisamAndLookup::postVisit(Variable* n) {
    Type t = currentSymTable->lookUpType(n->getName());
    n->setType(t);
}

Expr* DisamAndLookup::lookupConstructor(CCall* n) {
    //Lookup the constructor type (might be ambiguous)
    Type classType(n->getType());
    if (classType.getType() != Type::CLASS)
    {
        //If it's not a class, it might still be a cast, as in a declaration
        //like:
        //int x(1.0);
        if (isCast(n))
        {
            return callToCast(n, n->getTypeNode()->copy());
        }
        else compileError << linenum(n) << "Constructor call doesn't refer to a class." << endl;
    }
    else
    {
        Type cType(currentSymTable->lookupConstructor(classType));
        if (cType == Type::VOID)
        {
            //If the constructor doesn't exist, there may still exist
            //a cast from the argument to classType.
            if (isCast(n))
            {
                return callToCast(n, n->getTypeNode()->copy());
            }
            else compileError << linenum(n) << "Constructor not found." << endl;
        }
        else
            n->setCalleeType(cType);  //Set the callee type to the function type (which has a void return type)
                //of the constructor
    }
    return n;
}

Node* DisamAndLookup::visit(CCall* n) {
    FixedVisitor::visit(n);  //Visit the sub-AST nodes first
    
    Node* retVal = lookupConstructor(n);
    if (becameCast(retVal)) return retVal;
    doCall(n);
    return n;
}

//Check that arrays of classes created with no initial value have a default
//constructor defined for the class.
class FindArrayOfClass : public ContextVisitor {
public:
    FindArrayOfClass(SymbolTable* s) 
        : ContextVisitor(s) {}
    void postVisit(SArrayTypeNode * n) {
        visitArray(n);
    }
    void postVisit(DArrayTypeNode * n) {
        visitArray(n);
    }
private:
    void visitArray(ArrayTypeNode* n) {
        Type classType(n->getBase()->getType());
        if (classType.getType() == Type::CLASS)
        {
            //Check that there's a default constructor
            if (!currentSymTable->hasDefaultConstructor(classType))
            {
                compileError << linenum(n) << "Array of classes require a default constructor." << endl;
            }
        }
    }
};

void DisamAndLookup::postVisit(New* n) {
    auto_ptr<FindArrayOfClass> arrayOfClass(new FindArrayOfClass(currentSymTable));
    n->getTypeNode()->accept(arrayOfClass.get());
}

void DisamAndLookup::postVisit(VarDecl* n) {
    auto_ptr<FindArrayOfClass> arrayOfClass(new FindArrayOfClass(currentSymTable));
    n->getTypeNode()->accept(arrayOfClass.get());
}

//***Initializer lists***

//The challenge here is that the name in an initializer is in the class scope,
//but the value initializing it is in the scope of the function (since it might
//refer to the parameters of the function)

Node* DisamAndLookup::visit(Constructor* n) {
    Exprs* inits = n->getInitList();
    Exprs* newInits = new Exprs();
    for (size_t i = 0; i < inits->size(); ++i)
    {
        Expr* val = inits->snipValue(i);
        
        bool error = false;
        
        Call* call;
        
        //Make sure val is a call
        if ((call = dynamic_cast<Call*>(val)) == 0)
        {
            error = true;
        }
        else
        {
            //Have to visit the name first, so it can be looked up in visitCall
            call->getName()->accept(this);
            
            //Visit the call, which might cause it to be converted to a CCall
            //(meaning the super constructor should be being called)
            val = visitCall(call);
            CCall* ccall;

            if ((ccall = dynamic_cast<CCall*>(val)) != 0) {
                //Check that it's calling a super constructor

                if (!currentSymTable->hasSuperType(currentSymTable->currentClassType(), ccall->getType(), true))
                {
                    compileError << linenum(val) << "`" << ccall->getType() 
                        << "' is not a subclass of the current class." << endl;
                }
            }
            else if ((call = dynamic_cast<Call*>(val)) != 0 
                     && dynamic_cast<Variable*>(call->getName()) != 0)        //Check that the name is a variable
            {
                //Check that it has exactly one arg
                if (call->getArgs()->size() == 1)
                {
                    //convert to an Initializer
                    Initializer* newInit = new Initializer(dynamic_cast<Variable*>(call->snipName()), call->getArgs()->snipValue(0));
                    delete call;
                    
                    //Visit the name of the initializer
                    //newInit->getName()->accept(this);  done above now
                    val = newInit;
                }
                else
                {
                    error = true;
                }
            }
            else
            {
                error = true;
            }
        }

        if (error)
        {
            compileError << linenum(val) << 
                "Initializers in an initializer list must have the form name(value)." 
                << endl;
        }
        else
        {
            //visit arg in the scope of the constructor itself
            AbstractCall* init = dynamic_cast<AbstractCall*>(val);  //initializers should
                //be AbstractCalls (as assignment is kind of like a call)
            assert(init != 0);
            pushScope(n->getName(), n->getType()); 
            init->getArgs()->accept(this);
            popScope();
        }
        
        newInits->add(val);
    }
    n->setInitList(newInits);  //deletes inits, which is now an empty list since
        //the values have been snipped
        
    //Don't forget to visit the body
    pushScope(n->getName(), n->getType()); 
    n->getBody()->accept(this);
    popScope();

    return n;
}
