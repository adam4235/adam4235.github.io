#include "DesugarString.h"
#include "ast/ArrayList.h"
#include "ast/StrConst.h"
#include "ast/OutputStmt.h"
#include "ast/CharConst.h"
#include "ast/Exprs.h"
#include <string>

using namespace std;

Node* DesugarString::visit(StrConst* n) {
	//Convert a string to an array of characters
	Exprs* characters = new Exprs();
	string value = n->getValue();
	bool isBackSlash = false;
	for (size_t i = 0; i < value.size(); ++i)
	{
		if (!isBackSlash && value[i] == '\\')
			isBackSlash = true;
		else
		{
			characters->add(new CharConst(value[i], isBackSlash));
			isBackSlash = false;
		}
		
	}

	Type charArray = Type(Type(Type::CHAR), value.size());
	delete n;
	return new ArrayList(characters, charArray);
}

Node* DesugarString::visit(OutputStmt* n) {
	for (vector<Expr*>::iterator i = n->getOutputs().begin(); i != n->getOutputs().end(); ++i)
	{
		if (dynamic_cast<StrConst*>(*i) == 0)  //Leave strings in output statements as is,
				//for efficiency
			*i = (Expr*)(*i)->accept(this);
	}
	return n;
}

