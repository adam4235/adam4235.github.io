#ifndef CHECK_CLASSES
#define CHECK_CLASSES

//Do error checking for class bodies as a whole, e.g.
//all the multiple inheritance checks, final functions,
//function cases, etc.

#include "ContextVisitor.h"

class CheckClasses : public ContextVisitor {
    virtual void postVisit(ClassDecl* n);
    virtual void postVisit(CPPBlock* n);
};

#endif
