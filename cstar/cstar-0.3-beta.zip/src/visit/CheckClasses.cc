#include "CheckClasses.h"
#include "whole_ast.h"

void CheckClasses::postVisit(ClassDecl* n) {
    if (n->getBody() == 0) return;  //All these checks check the body of the class
    
    //Check for duplicates in the list of superclasses.
    
    vector<Type> types;  //Remember the types seen so far so we can
    //make sure there are no duplicates
    
    for (vector<SuperClass*>::const_iterator i = n->getSuperClasses().begin();
         i != n->getSuperClasses().end(); ++i)
    {
        Type t = (*i)->getSuperClass()->getType();
        for (vector<Type>::const_iterator j = types.begin(); j != types.end(); ++j)
        {
            if (currentSymTable->sameTypes(t, *j))
            {
                compileError << linenum(*i) << "Duplicate super class: " << t << endl;
                return;
            }
        }
        types.push_back(t);
    }
    
    //Do multiple inheritance checks, etc., 
    //by building a list of all the members in n
    currentSymTable->allMembersOf(n->getType());
    
    currentSymTable->checkOverrides(n->getType());
}


void CheckClasses::postVisit(CPPBlock* n) {
    if (currentSymTable->inClass()) {
        compileError << linenum(n) << 
        "cpp blocks can't appear in class bodies." << endl;
    }
}
