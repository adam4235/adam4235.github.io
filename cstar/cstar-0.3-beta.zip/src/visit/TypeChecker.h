#ifndef TYPECHECKER_H_
#define TYPECHECKER_H_

#include "CheckerHelpers.h"

//Do typechecking (error checking)

class TypeChecker : public CheckerHelpers {
protected:
/** Do typechecking on an initialization of something of type tn,
    being inialized with the value *ptrInitVal.
    ptrInitVal is a pointer to pointer because we might need to do
    a coercion on it to get it to a type acceptable for assignment to tn.
    E.g. int x := 1.0 might be valid if we can change 1.0 to int(1.0)
    (if the user has defined an implicit cast from float => int) */
void initialize(TypeNode* tn, Expr** ptrInitVal, Node* n);


/**Check that members aren't referenced from a static context.*/
virtual void checkStatic(Reference* n, string name);


public:
virtual void postVisit(ArrayProp* n);
//virtual void postVisit(ArrayRange* n);
//virtual void postVisit(Block* n);
virtual void postVisit(Cast* n);
virtual void postVisit(CaseStmt* n);
//virtual void postVisit(Const* n);
//virtual void postVisit(DeclList* n);
//virtual void postVisit(DeclOrDefn* n);
//virtual void postVisit(Decls* n);
//virtual void postVisit(DeclStmt* n);
//virtual void postVisit(Expr* n);
//virtual void postVisit(Exprs* n);
//virtual void postVisit(ExprStmt* n);
//virtual void postVisit(FloatConst* n);
virtual void postVisit(For* n);
virtual void postVisit(Function* n);
virtual void postVisit(GlobalVarDecls* n);
virtual void postVisit(InputExpr* n);
//virtual void postVisit(IntConst* n);
//virtual void postVisit(Node* n);
//virtual void postVisit(NormalParam* n);
virtual void postVisit(OutputStmt* n);
//virtual void postVisit(Param* n);
//virtual void postVisit(Params* n);
//virtual void postVisit(PrimType* n);
virtual void postVisit(RangedCaseStmt* n);
virtual void postVisit(RangeSubscript* n);
virtual void postVisit(Return* n);
virtual void postVisit(Select* n);
//virtual void postVisit(Stmt* n);
//virtual void postVisit(Stmts* n);
virtual void postVisit(Subscript* n);
//virtual void postVisit(Type* n);
//virtual void postVisit(UIntConst* n);
virtual void postVisit(VarDecl* n);
virtual void postVisit(Variable* n);
virtual void postVisit(While* n);
virtual void postVisit(If* n);
virtual void postVisit(IfExpr* n);
virtual void postVisit(ValueOf* n);
virtual void postVisit(AddressOf* n);
//virtual void postVisit(BoolConst* n);
virtual void postVisit(DeclExpr* n);
virtual void postVisit(Break* n);
virtual void postVisit(Continue* n);
virtual void postVisit(New* n);
virtual void postVisit(Delete* n);
virtual void postVisit(Goto* n);
virtual void postVisit(AccessSpec* n);
virtual Node* visit(MemberAccess* n);
virtual Node* visit(ClassDecl* n);
virtual void postVisit(CCall* n);
virtual void postVisit(Catch* n);


};

#endif /*TYPECHECKER_H_*/
