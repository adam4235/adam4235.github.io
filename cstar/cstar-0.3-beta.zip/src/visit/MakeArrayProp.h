#ifndef MAKE_ARRAY_PROP_H
#define MAKE_ARRAY_PROP_H

/*
 * Convert X.li, X.ui and X.size to ArrayProp nodes rather than
 * MemberAccess nodes.
 */

#include "FixedVisitor.h"

class MakeArrayProp : public FixedVisitor {
public:
    virtual Node* visit(MemberAccess* n);
};

#endif
