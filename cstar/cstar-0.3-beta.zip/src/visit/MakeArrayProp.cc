#include "MakeArrayProp.h"
#include "ast/MemberAccess.h"
#include "ast/ArrayProp.h"

Node* MakeArrayProp::visit(MemberAccess* n) {
    string property(n->getRight());
    ArrayProp* retVal;
    if (property == "li")
        retVal = new ArrayProp(n->snipLeft(), ArrayProp::LI);
    else if (property == "ui")
        retVal = new ArrayProp(n->snipLeft(), ArrayProp::UI);
    else if (property == "size")
        retVal = new ArrayProp(n->snipLeft(), ArrayProp::SIZE);
    else
        return n;
    delete n;
    return retVal;
}
