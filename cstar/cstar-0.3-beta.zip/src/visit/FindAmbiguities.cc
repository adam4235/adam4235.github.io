#include "FindAmbiguities.h"
#include "ast/Variable.h"
#include "ast/MemberAccess.h"

void check(Reference* n, string name) {
    if (n->getType().getType() == Type::AMB)
    {
        compileError << linenum(n) << "`" << name
            << "' is ambiguous." << endl;
    }
}

void FindAmbiguities::postVisit(Variable* n)
{
    string name(n->getName());
    check(n, name);
    Type t(n->getType());
    if (!t.getType() == Type::AMB && !t.getType() == Type::VOID)
    {
        if (currentSymTable->exists(name, t)
                                    && currentSymTable->isInstanceVar(name, t))
        {
            //Variables have to be set to be instance variables if they are instance variables
            // after disambiguation, in case some ambiguous choices are instance variables
            //and others not.  (This probably isn't really possible, but it's simpler to do it
            //this way.)
            n->setInstanceVar();
        }
    }
}

void FindAmbiguities::postVisit(MemberAccess* n)
{
    check(n, n->getRight());
}

