#ifndef BUILDSUPERTYPES_H
#define BUILDSUPERTYPES_H

/*
 * Add the superclasses and supertypes of a class to the symbol table.
 Also add type variables.
 
 These things have to be done in the same pass because they mutually depend on
 each other - the value of a type variable may be a nested class in a superclass,
 and a superclass may refer to a type variable.
  */

#include "BuildVisitor.h"

class BuildSuperTypesAndTypeVars : public BuildVisitor {
public:
	BuildSuperTypesAndTypeVars(SymbolTable* s = &symtable) : BuildVisitor(s) {}

    //Don't visit function bodies
    Node* visit(Function* n);
        
    virtual Node* visit(ClassDecl* n);
    
    virtual void postVisit(TypeVar* n);
    
};

#endif
