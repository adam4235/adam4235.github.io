#ifndef CODEGENERATOR_H_
#define CODEGENERATOR_H_

//Final pass to output the C++ code from the AST.

#include "ContextVisitor.h"

class CodeGenerator : public ContextVisitor {
public:
CodeGenerator() : ContextVisitor() 
{
    inCatch = false;
}

virtual Node* visit(ArrayList* n);
virtual Node* visit(ArrayProp* n);
virtual Node* visit(ArrayRange* n);
virtual Node* visit(Binop* n);
virtual Node* visit(Block* n);
virtual Node* visit(Call* n);
//virtual Node* visit(CaseStmt* n);
virtual Node* visit(Cast* n);
//virtual Node* visit(Const* n);
//virtual Node* visit(DeclList* n);
//virtual Node* visit(DeclOrDefn* n);
virtual Node* visit(Decls* n);
//virtual Node* visit(DeclStmt* n);
virtual Node* visit(Enum* n);
//virtual Node* visit(Expr* n);
virtual Node* visit(Exprs* n);
virtual Node* visit(ExprStmt* n);
virtual Node* visit(FloatConst* n);
virtual Node* visit(For* n);
virtual Node* visit(Function* n);
//virtual Node* visit(GlobalVarDecls* n);
virtual Node* visit(InputExpr* n);
virtual Node* visit(IntConst* n);
virtual Node* visit(CharConst* n);
//virtual Node* visit(Node* n);
//virtual Node* visit(NormalParam* n);
virtual Node* visit(OutputStmt* n);
//virtual Node* visit(Param* n);
virtual Node* visit(Params* n);
//virtual Node* visit(PrimType* n);
//virtual Node* visit(RangedCaseStmt* n);
virtual Node* visit(RangeSubscript* n);
virtual Node* visit(Return* n);
virtual Node* visit(Select* n);
//virtual Node* visit(Stmt* n);
virtual Node* visit(Stmts* n);
virtual Node* visit(StrConst* n);
virtual Node* visit(Subscript* n);
//virtual Node* visit(Type* n);
virtual Node* visit(Unop* n);
virtual Node* visit(VarDecl* n);
virtual Node* visit(Variable* n);
virtual Node* visit(If* n);
virtual Node* visit(IfExpr* n);
virtual Node* visit(While* n);
virtual Node* visit(Break* n);
virtual Node* visit(Continue* n);
virtual Node* visit(Goto* n);
virtual Node* visit(LabelledStmt* n);
virtual Node* visit(AssignExpr* n);
virtual Node* visit(ValueOf* n);
virtual Node* visit(AddressOf* n);
virtual Node* visit(NullConst* n);
virtual Node* visit(BoolConst* n);
virtual Node* visit(UserTypeNode* n);
virtual Node* visit(DArrayTypeNode* n);
virtual Node* visit(SArrayTypeNode* n);
virtual Node* visit(PointerTypeNode* n);
virtual Node* visit(PrimTypeNode* n);
virtual Node* visit(RealCPPArray* n);
virtual Node* visit(TypeVar* n);
virtual Node* visit(New* n);
virtual Node* visit(Delete* n);
//virtual Node* visit(CPPInclude* n);
virtual Node* visit(CPPBlock* n);
//virtual Node* visit(CPPUsing* n);
virtual Node* visit(ClassDecl* n);
virtual Node* visit(MemberAccess* n);
virtual Node* visit(ThisExpr* n);
virtual Node* visit(GlobalVarDecls* n);
virtual Node* visit(Constructor* n);
virtual Node* visit(Destructor* n);
virtual Node* visit(CCall* n);
virtual Node* visit(Initializer* n);
virtual Node* visit(TryCatch* n);
virtual Node* visit(Catch* n);
virtual Node* visit(Throw* n);

virtual void preVisit(DeclList* n);

/** Convert an assignment expression n, which must
be an array assignment, to 
a call to the rangeAssign functions in the
carray and darray classes */
void rangeAssign(AssignExpr* n);

/** Output compiler-generated constructors, destructor, assignment operator */
void compilerGeneratedMembers(ClassDecl* n);

/** Common function for accepting the base type of an ArrayTypeNode */
void acceptArrayBase(ArrayTypeNode* n);

private:
	/** Output an initial value for an array that had no initial value,
	 * or that was initialized with the scalar scalarInitVal.
	 * Merely declaring it with no initial value in the C++ output
	 * would mean that the dimensions given by the user would be ignored.*/
	void arrayInitVal(ArrayTypeNode* tn, Expr* scalarInitVal = 0);

    vector<string> classQualifier;  //Used to keep track of the prefix needed for
        //member implementations when inside a class implementation
    
    /** Get the class qualifier (see above) when doing a function, etc. implementation */
    string qualifier() const;
    
    bool inCatch;  //Whether we're in the exception parameter of a catch block.
};

#endif /*CODEGENERATOR_H_*/
