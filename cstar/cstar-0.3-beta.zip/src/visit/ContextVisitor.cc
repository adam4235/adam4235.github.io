#include "ContextVisitor.h"
#include "ast/Block.h"
#include "ast/Function.h"
#include "ast/ClassDecl.h"

using namespace std;

void ContextVisitor::outputPrevDefn(const string& name, const Type& t) {
    Node* pointOfDefn = currentSymTable->getPointOfDefn(name, t);
    if (pointOfDefn == 0)  //built-in symbol
        cerr << "(Which is a built-in symbol.)";
    else
        cerr << "Previous definition at line " << 
            CompileError::getLineInfo(pointOfDefn) << ".";
}

void ContextVisitor::outputPrevDefnOrDecl(const string& name, const Type& t) {
    Node* pointOfDefn = currentSymTable->getPointOfDefnOrDecl(name, t);
    outputPrevDefn(pointOfDefn);
}

void ContextVisitor::outputPrevDefn(Node* pointOfDefn) {
    if (pointOfDefn == 0)  //built-in symbol
        cerr << "(Which is a built-in symbol.)";
    else
        cerr << "Previous definition/declaration at line " << 
        CompileError::getLineInfo(pointOfDefn) << ".";
}

void ContextVisitor::outputPrevDefn(const string& name) {
    Node* pointOfDefn = currentSymTable->getPointOfDefnOrDecl(name);
    outputPrevDefn(pointOfDefn);
}

void ContextVisitor::outputPrevDefn(Name* name) {
    Node* pointOfDefn = currentSymTable->getPointOfDefnOrDecl(name);
    outputPrevDefn(pointOfDefn);
}

Node* ContextVisitor::visit(Block* n) {
	preVisit(n);
	pushScope(n->getLabel()); 
	n->getStmts()->accept(this);
	popScope();
	postVisit(n); 
	return n;
}

void ContextVisitor::pushFunctionScope(Function* n) {
    //If n is a friend function, then its scope is not in the current symbol table,
    //if we're in the class that it's the friend of.
    if (n->isFriend())
    {
        Type classType = currentSymTable->currentClassType();
        if (n->getType().isFriendOf(classType))
        {
            currentSymTable = currentSymTable->currentClassContainer();
        }
    }
	pushScope(n->getName(), n->getType()); 
}

Node* ContextVisitor::visit(Function* n) {
	preVisit(n);
    
    SymbolTable* oldScope = currentSymTable;

    pushFunctionScope(n);
    
	n->getParams()->accept(this);
	if (n->getBody() != 0) n->getBody()->accept(this); 
    
    currentSymTable = oldScope;
	//popScope();
	postVisit(n); 
	return n;
}

Node* ContextVisitor::visit(ClassDecl* n) {
	preVisit(n);
	pushScope(n->getName(), Type(Type::TYPE, n->getType()));
    FixedVisitor::doClass(n);
	popScope();
	postVisit(n); 
	return n;
}
