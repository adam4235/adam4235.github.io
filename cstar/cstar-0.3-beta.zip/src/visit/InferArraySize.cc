#include "InferArraySize.h"
#include "whole_ast.h"
#include <list>

using namespace std;

//Skip parameters, which are allowed to omit the array size
//and not have an initial expression
Node* InferArraySize::visit(NormalParam* n) {
	return n;
}

//Figure out the dimensions of the (possibly multidimensional)
//array literal initVal
list<size_t> inferShape(ArrayList* initVal)
{
	const vector<Expr*>& l = initVal->getValues()->getExprs();
	list<size_t> shapeSoFar;
	for (vector<Expr*>::const_iterator i = l.begin(); i != l.end(); ++i)
	{
		ArrayList* valAsArrayList = dynamic_cast<ArrayList*>(*i);
		if (valAsArrayList != 0)
		{
            //Inferring shape of a multidimensional literal
			list<size_t> newShape = inferShape(valAsArrayList);
			if (shapeSoFar.size() == 0)
			{
				shapeSoFar = newShape;
			}
			else if (newShape != shapeSoFar)
			{
				break;  //Can't infer the size in any more detail
					//because there are different sizes
					//(e.g. [[1, 2], [1, 2, 3]] - would infer a shape
					//of thing[2].)
			}
		}
		else
		{
			break;
		}
	}
	shapeSoFar.push_back(initVal->getSize());
	return shapeSoFar;
}

//Return a new version of n with the empty dimensions set according to
//the inferred dimensions initValShape.
TypeNode* setSizes(TypeNode*n, list<size_t> initValShape)
{
	if (initValShape.size() == 0)
	{
		return n;
	}
	else
	{
        //Get the outermost dimension
		size_t currentVal = initValShape.back();
		initValShape.pop_back();
        
		SArrayTypeNode* sTypeNode;
		DArrayTypeNode* dTypeNode = dynamic_cast<DArrayTypeNode*>(n);
		if (dTypeNode != 0 && dTypeNode->getSize() == 0)  //if the getSize() returned
            //non-null, it would mean the user specified both a dynamic size and an
            //initial value, e.g. an array := scalar initialization to fill the new
            //array with many copies of a certain value.
            //In that case we don't infer a new size.
		{
			//Set the size based on the size of the initial expression
			SArrayTypeNode* newTypeNode = 
				new SArrayTypeNode(
						setSizes(dTypeNode->snipBase(), initValShape),  //Recursively
                            //set the inferred sizes of the base of the array
						dTypeNode->getLi(), 
						currentVal - 1 + dTypeNode->getLi(),
						true);  //Have to pass the ui
			newTypeNode->setPos(dTypeNode);  //Retain the same line num
            newTypeNode->setQuals(dTypeNode->getQuals());  //Preserve the type qualifiers
			delete dTypeNode;
			return newTypeNode;
		}
		else if ((sTypeNode = dynamic_cast<SArrayTypeNode*>(n)) != 0)
		{
            //Make sure the user-given size matches the inferred size
			if (sTypeNode->getSize() != currentVal)
			{
				compileError << linenum(sTypeNode) << "Invalid array size: `" << sTypeNode->getSize() << "'." << endl;
			}
			else
			{
                //Recursively set the inferred sizes for the base of the array
				sTypeNode->setBaseNoDelete(setSizes(sTypeNode->snipBase(), initValShape));
			}
		}
		return n;
	}
}

/** Common method for performing size inference on either 
  a variable declaration or a new expression. */
TypeNode* doInference(TypeNode* oldTypeNode, Expr* initVal) {
    if (initVal == 0)
    {
        if (oldTypeNode->dimensionsOmitted()) throw 1;
    }
    else
    {
        //Can only infer the array dimensions if the initval is an arraylist.
        //For other types of expressions (e.g. variables), the shape isn't known
        //yet, because the symbol table hasn't been built yet.
        ArrayList* valAsArrayList = dynamic_cast<ArrayList*>(initVal);
        if (valAsArrayList != 0)
        {
            return setSizes(oldTypeNode, inferShape(valAsArrayList));
        }
    }
    return oldTypeNode;
}

void InferArraySize::postVisit(VarDecl* n) {
    try {
        n->setTypeNodeNoDelete(doInference(n->getTypeNode(), n->getInitVal()));
    }
    catch (int) {
        compileError << linenum(n) << "Missing array size in declaration of `" 
            << n->getName() << "'." << endl;
    }
}

void InferArraySize::postVisit(New* n) {
	size_t numArgs = n->getArgs()->size();
	if (numArgs > 1) return;  //Constructor call
	Expr* initVal;
	if (numArgs == 0) initVal = 0;
	else if (numArgs == 1) initVal = n->getArgs()->getExprs()[0];
	
    try {
        n->setTypeNodeNoDelete(doInference(n->getTypeNode(), initVal));
    }
    catch (int) {
        compileError << linenum(n) << "Missing array size in type of new expression." << endl;
	}
}

