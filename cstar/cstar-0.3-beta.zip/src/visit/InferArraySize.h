#ifndef INFER_ARRAY_SIZE_H
#define INFER_ARRAY_SIZE_H

//Infer the size of the array in a declaration such as:
//int arr[] := [1, 2, 3];
//The type of arr would be inferred to be int[0..2].

#include "FixedVisitor.h"

class InferArraySize : public FixedVisitor {
public:
	virtual Node* visit(NormalParam* n);
	virtual void postVisit(VarDecl* n);
	virtual void postVisit(New* n);
};

#endif

