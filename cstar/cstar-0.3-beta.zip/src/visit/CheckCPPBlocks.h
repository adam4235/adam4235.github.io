#ifndef CHECK_CPP_BLOCKS
#define CHECK_CPP_BLOCKS

//Give errors related to the use of cpp {} blocks.
//Specifically, make sure include and using statements
//only appear within cpp blocks.

#include "FixedVisitor.h"

class CheckCPPBlocks : public FixedVisitor {
public:
	virtual Node* visit(CPPBlock* n);
	virtual void postVisit(CPPUsing* n);
	virtual void postVisit(CPPInclude* n);
};

#endif

