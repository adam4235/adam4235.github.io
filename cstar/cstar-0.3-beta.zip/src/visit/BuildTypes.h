#ifndef BUILDTYPES_H
#define BUILDTYPES_H

#include "BuildVisitor.h"

//Build the types in the top-level of the symbol table
//(currently enums, later classes and other things as well)

class BuildTypes : public BuildVisitor {
private:
    int implLevel;  //How many nested class implementations we're in.
    ClassDecl* originalClass;
public:
	BuildTypes(SymbolTable* s = &symtable) : BuildVisitor(s), implLevel(0) {}

	virtual Node* visit(Enum* n);
	virtual Node* visit(Function* n);
    virtual Node* visit(ClassDecl* n);
    void doClass(ClassDecl* n);

};

#endif

