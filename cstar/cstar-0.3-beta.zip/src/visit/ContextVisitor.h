#ifndef CONTEXTVISITOR_H_
#define CONTEXTVISITOR_H_

/** A visitor that keeps track of the current spot in the
 * symbol table, so that derived classes can look up symbols
 * as they do their traversal. */

#include "SymbolTable.h"
#include "FixedVisitor.h"

class ContextVisitor : public FixedVisitor {
protected:
	SymbolTable* currentSymTable;
public:
	ContextVisitor() {
        //Default to the symbol table for the whole compilation unit.
		currentSymTable = &symtable;
	}
	ContextVisitor(SymbolTable* s) : currentSymTable(s) {}
	
    /** Enter a subscope (block or function) */
	void pushScope(const string& s, const Type& type = Type::BLOCK) {
		currentSymTable = currentSymTable->findScope(s, type);
	}

    /** Enter the scope of the function n.
    It might be a friend function, which means we have to enter
    its scope from the scope of the class it's contained in.*/
    void pushFunctionScope(Function* n);
	
    /** Exit from a subscope (see a right brace, normally) */
	void popScope() {
		assert(!currentSymTable->globalScope());
		pop(&currentSymTable);
	}
	
	/**For cases of duplicate definition, output
	 * the previous place the thing was defined.*/
	void outputPrevDefn(const string& name, const Type& t);

    /** Same, but look for declarations too. */
    void outputPrevDefnOrDecl(const string& name, const Type& t);
    
	/**For cases of conflicting type, output
	 * the previous place the thing was defined/declared.*/
	void outputPrevDefn(const string& name);
	void outputPrevDefn(Node* name);
    void outputPrevDefn(Name* name);

	virtual Node* visit(Block* n);
	virtual Node* visit(Function* n);
	virtual Node* visit(ClassDecl* n);
};

#endif /*CONTEXTVISITOR_H_*/
