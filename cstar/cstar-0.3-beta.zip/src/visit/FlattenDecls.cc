#include "FlattenDecls.h"
#include "whole_ast.h"
#include "StmtVisitor.h"

class FlattenDecl : public StmtVisitor {
public:
    Node* visit(DeclStmt* n);
};

Node* FlattenDecl::visit(DeclStmt* n) {
    vector<VarDecl*>& varDecls = n->getDecls()->decls;

    //Split the decl statement into multiple individual declarations.
    //In the case of single declarations, this loop won't enter its body.
    for (vector<VarDecl*>::iterator j = varDecls.begin(); j != varDecls.end() - 1; ++j)
    {
        stmts.push_back(new DeclStmt(*j));
    }
    
    //Leave the last declaration in n.  The others have been added
    //to the new statement, so delete them.
    varDecls.erase(varDecls.begin(), varDecls.end() - 1);
    return n;
}

void FlattenDecls::postVisit(DeclList* n) {
//This isn't needed anymore - it was only needed when
//multiple declarations of instance variables were allowed in class bodies.
#if 0
    vector<DeclOrDefn*> newDecls;
    const vector<DeclOrDefn*>& oldDecls = n->getDecls();
    
    for (vector<DeclOrDefn*>::const_iterator i = oldDecls.begin(); i != oldDecls.end(); ++i)
    {
        GlobalVarDecls* v;
        if ((v = dynamic_cast<GlobalVarDecls*>(*i)) != 0)
        {
            vector<VarDecl*>& varDecls = v->getDecls()->decls;
            for (vector<VarDecl*>::const_iterator j = varDecls.begin(); j != varDecls.end() - 1; ++j)
            {
                Decls* d = new Decls();
                d->add(*j);
                newDecls.push_back(new GlobalVarDecls(d));
            }
            varDecls.erase(varDecls.begin(), varDecls.end() - 1);
        }
        newDecls.push_back(*i);
    }
#if 0
    //DEBUG
    for (vector<DeclOrDefn*>::const_iterator i = newDecls.begin(); i != newDecls.end(); ++i)
    {
        GlobalVarDecls* v;
        if ((v = dynamic_cast<GlobalVarDecls*>(*i)) != 0)
        {
            VarDecl* var = v->getDecls()->decls[0];
            cout << var->getName() << ": " << var->getType() << endl;
        }
    }
#endif
    //Don't have to delete the old decls because all the pointers in them still exist.
    n->decls = newDecls;
#endif
}

void FlattenDecls::postVisit(Stmts* n) {
    transStmts<FlattenDecl>(n);
}

