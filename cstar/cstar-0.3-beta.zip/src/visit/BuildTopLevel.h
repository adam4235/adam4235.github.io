#ifndef BUILDTOPLEVEL_H_
#define BUILDTOPLEVEL_H_

#include "BuildVisitor.h"

//Initial pass to build the top level of the symbol table.
//(currently functions and global variable declarations).
//In this section, declarations may appear after use, and
//there may be multiple declarations.

class BuildTopLevel : public BuildVisitor {
private:
    bool m_inNamespace;  //True iff we're in a namespace
	void conflict(Node* n, const string& name);
    ClassDecl* originalClass;  //Whether we're building a class implementation
public:
    /** Check whether a member (function or variable) was previously defined,
    for class implementations.
    @param n The member.
    @param name The member's name.
    @param type The member's type.*/
    void checkMember(Node* n, string name, Type type);
    
    /** Output an error for the original class definition, when in a class
    implementation.*/
    void outputOrigClass();
    
	BuildTopLevel(SymbolTable* s = &symtable, ClassDecl* originalClass = 0, bool m_inNamespace = false) 
        : BuildVisitor(s), m_inNamespace(m_inNamespace), originalClass(originalClass) {}
    virtual Node* visit(ClassDecl* n);
	virtual Node* visit(Function* n);
	virtual Node* visit(VarDecl* n);
    virtual Node* visit(Constructor* n);
    virtual Node* visit(Destructor* n);
    bool classImpl() const { return originalClass != 0; }
};

#endif /*BUILDTOPLEVEL_H_*/
