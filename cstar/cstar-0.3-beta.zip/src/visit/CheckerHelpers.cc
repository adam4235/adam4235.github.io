#include "CheckerHelpers.h"
#include "whole_ast.h"

//Give an error when a type can't t2 be treated as another type t1
void typeError(Node* assignExpr, const Type& t1, const Type& t2)
{
    //Don't give an error if there was an error within the expressions
    if (t1 == Type::VOID || t2 == Type::VOID) return;
    
	compileError << linenum(assignExpr) << "Unmatched types: Can't have " 
    << t1 << " := " 
    << t2 << "." << endl;
}

void CheckerHelpers::assignmentChecks(Node* n, const Type& targetType, Expr* rhs)
{
	const Type& srcType = rhs->getType();
	if (rhs->isLvalue() && srcType.isPtr() && srcType.hasFlag(Type::CONST_FLAG) && !targetType.isConst())
	{
		compileError << linenum(n) << "Can't assign a pointer to constant to"
        " a pointer to non-constant." << endl;
	} 
}

Expr* CheckerHelpers::convertibleGeneral(Expr* fromNode, Type to, bool createNode) {
	Type from = fromNode->getType();
	if (!from.isConst() && to.isConst()) return 0;  //Can't
    //have const := non-const
    
	//Ignore qualifiers like const in determining whether a cast exists
	from.clearQuals();
	to.clearQuals();
    
	string toAsString = Type::typeAsString(to.getType());
    
    //Create the type of the user-defined operator that would have to exist
	vector<Type> params;
	params.push_back(from);
	Type fType = Type(Type::FUNCTION, params, to);
	if (currentSymTable->exists(toAsString, fType))
	{
		if (createNode)
			return new Call(new Variable(toAsString, fType), fromNode);
		else return fromNode;
	}
	else return 0;
}

bool CheckerHelpers::convertible(Expr* fromNode, Type to)
{
	if (fromNode->getType().isSubType(to, currentSymTable)) return true;
	else return convertibleGeneral(fromNode, to, false) != 0;
}

Expr* CheckerHelpers::coerce(Node* assignExpr, Expr* fromNode, Type to)
{
    Type from(fromNode->getType());
    if (from == Type::VOID || to == Type::VOID) return fromNode;  //An error in the types
    
	if (from.isSubType(to, currentSymTable)) return fromNode;  //No coercion necessary
	else 
	{
		Expr* result = convertibleGeneral(fromNode, to, true);
		if (result == 0)
		{
        	compileError << linenum(assignExpr) << "Unmatched types.  Found: " 
            << from << ".  Expected: " 
            << to << "." << endl;
            
			return fromNode;
		}
		else return result;
	}
}

Expr* CheckerHelpers::assignableFrom(Node* assignExpr, const Type& lhs, Expr* rhsNode, bool allowConstOnLeft) {
	const Type& rhs = rhsNode->getType();
    
    //First check whether it can be be assigned by the language's subtyping rules
	if (rhs.isSubType(lhs, currentSymTable, allowConstOnLeft)) return rhsNode;
    
    //Next check whether the user has defined a cast from the RHS to the LHS
	Expr* newRHS = convertibleGeneral(rhsNode, lhs, true);
	if (newRHS != 0) return newRHS;
    
	//Finally, check whether it's a case of array := scalar
	
	//Might have e.g. reference to array := scalar
	Type l = lhs.stripRef(), r = rhs.stripRef();
    
	if (l.isArray())// && !r.isArray())
	{
		if (!r.isSubType(l.getBaseType(), currentSymTable))
		{
            //Error - but should it be an array := scalar error?
            //It seems a normal error is more user-friendly.
#if 0
			compileError << linenum(assignExpr) << "Assignment of array to scalar must have matching types.  ("
            << r << " not a subtype of " << l.getBaseType() << ")" << endl;
#endif
            typeError(assignExpr, lhs, rhs);
		}
		return rhsNode;
	}
    
    //Nothing worked; the assignment is invalid
	typeError(assignExpr, lhs, rhs);
	return rhsNode;
}

