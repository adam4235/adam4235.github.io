#ifndef PASSES_H_
#define PASSES_H_

#include "SymbolTable.h"

class Node;
class SymbolTable;
class ClassDecl;

/** The build passes for lists of top-level 
    declarations or class bodies.  (Run on both.)
    @param currentSymTable The symbol table the set of declarations is being run on
    (for class bodies, it's set to the symbol table of the class).
    @param originalClass Nonzero iff we're running the passes on a class implementation (which
    can only contain implementations of previously declared members).  If we are, it contains
    a pointer to the original class definition, for error reporting purposes.
    @param inNamespace true iff we're in a namespace*/
void bPasses(Node* n, SymbolTable* currentSymTable = &symtable, ClassDecl* originalClass = 0, bool inNamespace = false);

/** Execute all the compiler passes required to output the
 * AST rooted at n */
void passes(Node* n);

#endif /*PASSES_H_*/
