#include "outputArrayClasses.h"
#include <iostream>
#include <cstddef>

using namespace std;

void outputArrayClasses() {
#include "gen_array.h"
	for (size_t line = 0; line < array_size; ++line)
	{
		cout << array_file[line] << endl;
	}
}

