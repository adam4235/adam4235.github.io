#ifndef REPLACE_H_
#define REPLACE_H_

/**Replace an AST node, making sure to delete the old one first.
 */ 
template<typename T>
void replace(T** oldNode, T* newNode) {
	if (*oldNode != 0)
		delete *oldNode;
	*oldNode = newNode;
}

#endif /*REPLACE_H_*/
