#include "buildTNFromType.h"
#include "whole_ast.h"
#include "typeinfo.h"

TypeNode* buildTNFromType(Type t)
{
	TypeNode* retVal;
	Type::Kind kind = t.getType();
	if (t.getType() == Type::DARRAY)
	{
		retVal = new DArrayTypeNode(buildTNFromType(t.getBaseType()), t.li(), 
				new IntConst(2));  //Put in a junk value for size - the value
			//doesn't matter because it should
			//never be used for compiler generated nodes.
	}
	else if (t.isArray())
	{
		retVal = new SArrayTypeNode(buildTNFromType(t.getBaseType()), t.li(), t.ui());
	}
#if 0
	else if (kind == Type::REF)
	{
		retVal = buildTNFromType(t.getBaseType());
		assert(t.hasFlag(Type::REF_FLAG));  //If this can't be assumed, then
			//I have to set that flag in retVal.
	}
#endif
	else if (kind == Type::CONST_PTR)
	{
		retVal = new PointerTypeNode(buildTNFromType(t.getBaseType()), Type::CONST_FLAG);
	}
	else if (kind == Type::PTR)
	{
		retVal = new PointerTypeNode(buildTNFromType(t.getBaseType()), Type::NO_FLAG);
	}
	else
	{
		retVal = new PrimTypeNode(t);
	}
	retVal->setQuals(t.getQuals());
	return retVal;
}

TypeNode* buildUserTN(UserTypeNode* n, const Type& refType) {
    if (refType.getType() == Type::ENUM
        				|| refType.getType() == Type::CLASS
        ) {
        n->setLookedUpType(refType);
        return n;
    }
    else
    {
        //Replace type variables with their values
        TypeNode* newTN = buildTNFromType(refType);
        delete n;
        return newTN;
    }
}
