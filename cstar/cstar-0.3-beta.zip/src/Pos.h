#ifndef POS_H_
#define POS_H_

class Pos {
private:
	unsigned int lineBegin, lineEnd, colBegin, colEnd;
public:
	Pos(unsigned int lineBegin) : 
		lineBegin(lineBegin), lineEnd(0), colBegin(0), colEnd(0) {}
	Pos() : lineBegin(0), lineEnd(0), colBegin(0), colEnd(0) {} 
	unsigned int getErrString() const {
		return lineBegin;
	}
};

#endif /*POS_H_*/
