#include <string>

/** For functions of certain, fixed names, return a realName
 * that they'll be referred to in the C++ output.
 * E.g. findOpName("+") is something like "__add11".
 */
std::string findOpName(const std::string& o);

/**@return Whether o, when used as a function name, is 
 * a user-defined cast.*/
bool isUserCast(const std::string& o);

/**@return Whether the operator o is an assignment operator. */
bool isAssign(const std::string& o);
