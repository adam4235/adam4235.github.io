while (<STDIN>) {
	if (!($_ =~ /[ ]*[#].*/))  #Ignore the gcc-generated lines
		#that look like:
		# #1 "array_classes.cc"
		#telling you the line it was included from.
	{
		print;
	}
}

