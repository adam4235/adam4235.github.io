private:
	void rangeCheck(std::size_t i)
	{
		if (i >= size) throw RangeError();
	}
	void rangeCheck(std::size_t x, std::size_t y)
	{
		if (x > y) throw RangeError();
		rangeCheck(y);
	}
	static void sizeCheck(std::size_t thisSize, std::size_t thatSize)
	{
		if (thisSize != thatSize) throw RangeError();
	}

public:
	//Range subscript (this[x..y])
	darray<T> rangeSubscriptNoCheck(std::size_t x, std::size_t y)
	{
		return darray<T>(y - x + 1, &(v[x]));
	}

	//Range subscript (this[x..y])
	darray<T> rangeSubscriptNoCheck(std::size_t x)
	{
		return rangeSubscriptNoCheck(x, size - 1);
	}

	//Range subscript (this[x..y])
	darray<T> rangeSubscript(std::size_t x, std::size_t y)
	{
		rangeCheck(x, y);
		return rangeSubscriptNoCheck(x, y);
	}

	//Range subscript (this[x..])
	darray<T> rangeSubscript(std::size_t x)
	{
		rangeCheck(x);
		return rangeSubscriptNoCheck(x);
	}

	template<typename U>
	darray<T> rangeAssignNoCheck(std::size_t x, const U* thatV, std::size_t thatSize)
	{
		return rangeAssignNoCheck(x, size - 1, thatV, thatSize);
	}

	//Range assignment (this[x..y] := that)
	template<typename U>
	darray<T> rangeAssignNoCheck(std::size_t x, std::size_t y, const U* thatV, std::size_t thatSize)
	{
//Can't always do a memcpy - if U != T, it won't work properly.  (And it also won't work
//if there are copy constructors needed to do a deep copy.)  Perhaps later could modify
//this for efficiency.
//		memcpy(&v[x], thatV, (y - x + 1) * sizeof(T));

		//We have to protect against the case where the source and
		//destination overlap.  For example, arr[1..2] := arr[0..1].
		//
		//A simple, but slow, approach would be to copy arr[0..1] to 
		//a new storage location on the heap, then copy the temporary
		//to arr[1..2], then delete the temporary.
		//
		//The approach I've used below is to copy the elements in
		//reverse order if the source appears before the destination
		//in memory, and in forwards order otherwise.  This ensures that
		//the result is never re-used in the source.
		//(Assuming arrays are stored in contiguous blocks of memory,
		//which I think is true.)
		if ((void*)(&(thatV[0])) < (void*)(&(v[x])))  //src comes before dest;
			//copy in reverse order
		{
			for (std::size_t i = y, j = thatSize - 1; i >= x; --i, --j)
			{
				v[i] = thatV[j];
				if (i == 0) break;  //Since i is unsigned, --i will
					//cause weird stuff when i is 0 and it will still be >= x
			}
		}
		else
		{
			for (std::size_t i = x, j = 0; i <= y; ++i, ++j)
			{
				v[i] = thatV[j];
			}
		}

		return rangeSubscript(x, y);  //The expression can then be used as
			//if it had been this[x..y].
	}

	//Range assignment (this[x..y] := that)
	template<typename U>
	darray<T> rangeAssign(std::size_t x, std::size_t y, const U* thatV, std::size_t thatSize)
	{
		rangeCheck(x, y);
		sizeCheck(y - x + 1, thatSize);
		return rangeAssignNoCheck(x, y, thatV, thatSize);
	}

	//Methods to pass a dynamic array instead of a pointer and size
	template<typename U>
	darray<T> rangeAssign(std::size_t x, std::size_t y, const darray<U>& that)
	{
		return rangeAssign(x, y, that.v, that.size);
	}
	template<typename U>
	darray<T> rangeAssign(std::size_t x, const darray<U>& that)
	{
		return rangeAssign(x, that.v, that.size);
	}

	//Range assignment (this[x..] := that)
	template<typename U>
	darray<T> rangeAssign(std::size_t x, const U* thatV, std::size_t thatSize)
	{
		rangeCheck(x);
		sizeCheck(size - x, thatSize);
		return rangeAssignNoCheck(x, thatV, thatSize);
	}

	//Range assignment (this[x..y] := scalar)
	darray<T> rangeAssignNoCheck(std::size_t x, std::size_t y, const T& that)
	{
		for (std::size_t i = x; i <= y; ++i)
			v[i] = that;
		return rangeSubscript(x, y);  //The expression can then be used as
			//if it had been this[x..y].
	}

	darray<T> rangeAssignNoCheck(std::size_t x, const T& that)
	{
		return rangeAssignNoCheck(x, size - 1, that);
	}

	//Range assignment (this[x..y] := scalar)
	darray<T> rangeAssign(std::size_t x, std::size_t y, const T& that)
	{
		rangeCheck(x, y);
		return rangeAssignNoCheck(x, y, that);
	}

	//Range assignment (this[x..] := scalar)
	darray<T> rangeAssign(std::size_t x, const T& that)
	{
		rangeCheck(x);
		return rangeAssignNoCheck(x, that);
	}


