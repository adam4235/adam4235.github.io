#include "csAutoPtr.cc"
#include <iostream>

using namespace std;

class A {
public:
    virtual int f() { return 1; }
};

class B : public A {
public:
    virtual int f() { return 2; }
};

int main() {
    B b = B();
    csAutoPtr<A> ap(b);
    cout << (*ap.ptr).f() << endl;
}
