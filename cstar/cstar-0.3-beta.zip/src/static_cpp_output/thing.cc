//Exception thrown when you try to cast a thing
//to a type which the value stored in it is not.
class CastError : public Thing {};

class thing {
public:
	union {
		int intVal;  //int
		unsigned int uintVal;  //unsigned int
		float floatVal;  //float

		//For efficiency, double and long double are stored
		//as pointers within the union, with the actual value
		//going on the heap for the case when the thing's value
		//is actually a double or long double.
		//This allows the union to occupy only 4 bytes on a
		//32-bit system, and improves performance when the
		//value isn't double or long double.
		double* doubleVal;  //double
		long double* ldoubleVal;  //long double

		bool boolVal;  //bool
		char charVal;  //char
		Thing* classVal;  //class
		void* ptrVal;  //pointer
		const void* cPtrVal;  //pointer to const
#if 0
//		FUNCTION;  //function type
//		OPER;  //operator
		ARRAY;  //array type
		DARRAY;  //dynamic array
		ENUM;  //Enumeration
		ENUMERATOR;  //A single value within an enumeration
//		TYPE;     //A type name (such as the name of an enum type)
		PTR;  //Pointer
		CONST_PTR;  //Constant pointer
//		REF;  //Reference
//		NUL;  //Null (subtype of every pointer type)
#endif
	} val;

	enum Kind {
		VOID,  //Doesn't hold a valid value
		INT,  //int
		UINT,  //unsigned int
		FLOAT,  //float
		DOUBLE,  //double
		LDOUBLE,  //long double
		BOOL,  //bool
		CHAR,  //char
		CLASS,  //class
		FUNCTION,  //function type
		OPER,  //operator
		ARRAY,  //array type
		DARRAY,  //dynamic array
		ENUM,  //Enumeration
		ENUMERATOR,  //A single value within an enumeration
//		TYPE,     //A type name (such as the name of an enum type)
		PTR,  //Pointer
		PTR_TO_CONST  //pointer to const
	} type;

	//Pointers
	template<typename T>
	thing(T* initVal) {
		val.ptrVal = initVal;
		type = PTR;
	}

	//Pointers
	template<typename T>
	thing(const T* initVal) {
		val.cPtrVal = initVal;
		type = PTR_TO_CONST;
	}


	//Classes
	template<typename T>
	thing(const csAutoPtr<T>& initVal) {
		val.classVal = initVal.ptr->_clone();
		type = CLASS;
	}
	
	//Primitive types
	thing(int v) {
		val.intVal = v;
		type = INT;
	}
	thing(unsigned int v) {
		val.uintVal = v;
		type = UINT;
	}
	thing(float v) {
		val.floatVal = v;
		type = FLOAT;
	}
	thing(double v) {
		val.doubleVal = new double(v);
		type = DOUBLE;
	}
	thing(long double v) {
		val.ldoubleVal = new long double(v);
		type = LDOUBLE;
	}
	thing(bool v) {
		val.boolVal = v;
		type = BOOL;
	}
	thing(char v) {
		val.charVal = v;
		type = CHAR;
	}

	//Casts to get back the original value
    //Defined with a special cast function rather than
    //with an implicit cast.
	operator int() {
		if (type != INT) throw CastError();
		return val.intVal;
	}
	operator unsigned int() {
		if (type != UINT) throw CastError();
		return val.uintVal;
	}
	operator float() {
		if (type != FLOAT) throw CastError();
		return val.floatVal;
	}
	operator double() {
		if (type != DOUBLE) throw CastError();
		return *val.doubleVal;
	}
	operator long double() {
		if (type != LDOUBLE) throw CastError();
		return *val.ldoubleVal;
	}
	operator bool() {
		if (type != BOOL) throw CastError();
		return val.boolVal;
	}
	operator char() {
		if (type != CHAR) throw CastError();
		return val.charVal;
	}
	//classes
	template<typename T>
	T toClass() {
		T* retVal = dynamic_cast<T*>(val.classVal);
		if (retVal == 0) throw CastError();
		return *(retVal);
	}
	//Pointers
	template<typename T>
	T toPtr() {
		if (type != PTR) throw CastError();
		return (T)val.ptrVal;
	}

	//Pointers to constant
	template<typename T>
	T toConstPtr() {
		if (type != PTR_TO_CONST) throw CastError();
		return (T)val.cPtrVal;
	}

	//Destructor
	virtual ~thing()
	{
		if (type == CLASS)
			delete val.classVal;
		else if (type == LDOUBLE)
			delete val.ldoubleVal;
		else if (type == DOUBLE)
			delete val.doubleVal;
	}

	//Default constructor
	thing() {
		type = VOID;
	}

	void copyFrom(const thing& that) {
		type = that.type;
        if (type == CLASS)
            val.classVal = that.val.classVal->_clone();
        else if (type == LDOUBLE)
            val.ldoubleVal = new long double(*that.val.ldoubleVal);
        else if (type == DOUBLE)
            val.doubleVal = new double(*that.val.doubleVal);
        else
		    val = that.val;
	}

	//Copy constructor
	thing(const thing& that) {
		copyFrom(that);
	}
	//Assignment operator
	thing& operator=(const thing& that) {
		if (this != &that) {
			this->~thing();
			copyFrom(that);
		}
		return *this;
	}
};

