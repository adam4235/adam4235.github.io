# Takes some code on standard in.
# Outputs the declaration of an array of strings containing
# that code, so that another program (typically a compiler) can output the code
# without having to store it in a file; i.e. it can be
# stored right in the compiler's executable.

#Also outputs a variable giving the number of lines in the
#code, making it easier to iterate through the array.

#The program takes an argument which is used as a prefix
#to the names of the string array and size variable (in
#case this script is used for multiple code snippets in
#the same compiler).

print "//Generated file: do not edit.\n";
$prefix = $ARGV[0];
print "string " . $prefix . "_file[] = {\n";
$size = 0;
while (<STDIN>) {
	print '"';
	chomp;  #stdin reads newlines.  This removes them.
	s/\\/\\\\/g;  #convert backslashes to 2 backslashes,
			#since they'll be going in a C++ string.
	print;
	print '", ' . "\n";
	++$size;
}

print "};\n";

print "std::size_t " . $prefix . "_size = " . $size . ";\n";

