//A class which all other classes inherit from.
class Thing {
public:
  virtual ~Thing() {}
  virtual Thing* _clone() { throw 0; };  
};

class bottom : public Thing {};

