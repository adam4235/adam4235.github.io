//Auto pointer class which holds
//objects and enables polymorphism on (what the user sees
//as) stack objects.
template<typename T>
class csAutoPtr {
public:
    //Default constructor.
    //Pass it a junk value, to distinguish from the user-defined default
    //constructor.
    csAutoPtr<T>() : ptr (new T()) {
    }

    //Used for virtual classes.
    //You can't construct a new T(), as is done above,
    //when the class is virtual, but it can be initialized with a
    //junk value.  So just give it a null pointer.
    csAutoPtr<T>(bottom b) : ptr(0) {
    }

    //The tricky part of the auto pointer is that
    //when one object is copied to another, it should
    //not truncate it, but should produce a copy of the
    //run-time object.
    //
    //This is handled by the compiler adding a polymorphic clone
    //function to every class, which creates a new copy of
    //the this object on the heap and returns a pointer to it.
    //The clone method is implemented according to the copy
    //constructor (or copy operator) defined by the user.
    //The clone method is called below, and the correct one (which
    //might be a subclass of U) gets called.
    template<typename U>
    void copyFrom(const csAutoPtr<U>& that)
    {
        ptr = dynamic_cast<U*>(that.ptr->_clone());
    }

    template<typename U>
    void copyObject(const U& that)
    {
        ptr = new U();
        //Have to copy the subclass object to ptr,
        //which means we need an alias of type U.
        U* alias = dynamic_cast<U*>(ptr);
        *alias = that;
    }

    csAutoPtr<T>(const csAutoPtr<T>& that) {
        copyFrom(that);
    }

    template<typename U>
    csAutoPtr<T>(const csAutoPtr<U>& that) {
        copyFrom(that);
    }

    template<typename U>
    csAutoPtr<T>(const U& initVal) {
        copyObject(initVal);
    }

    //Destructor doesn't need to be virtual because nothing inherits
    //from csAutoPtr.
    ~csAutoPtr<T>() {
        if (ptr != 0) delete ptr;
    }
    template<typename U>
    bool operator==(const csAutoPtr<U>& that) {
        return *ptr == *(that.ptr);
    }

    csAutoPtr<T>& operator=(const csAutoPtr<T>& that) {
        if (this != &that) {
            delete ptr;
            //See above
            copyFrom(that);
        }
        return *this;
    }

    template<typename U>
    csAutoPtr<T>& operator=(const csAutoPtr<U>& that) {
        if ((csAutoPtr<U>*)this != &that) {
            delete ptr;
            //See above
            copyFrom(that);
        }
        return *this;
    }
    //Need another assignment operator for copying a non-auto
    //pointer.
    template<typename U>
    csAutoPtr<T>& operator=(const U& that) {
        //They'll never be the same object because the types are different.
//        if (this != &that) {
            delete ptr;
            copyObject(that);
//        }
        return *this;
    }

    T* ptr;
};

