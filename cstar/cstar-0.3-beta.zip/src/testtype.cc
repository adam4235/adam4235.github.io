#include "typeinfo.h"
#include <iostream>

using namespace std;

//Unit test code to test the Type class
int main() {

	vector<Type> params;
	params.push_back(Type(Type::DOUBLE));

	//all the constructors
	Type t[] = { 
		Type(Type::VOID), 
		Type(Type::INT), 
		Type(Type(Type::INT), 5, 2), 
		Type(Type::FUNCTION, params, Type(Type::INT)),
		Type(Type(Type::DOUBLE), 5, 2), 
	};
	unsigned int size = sizeof(t) / sizeof(Type);
	assert(size == 5);
	Type tp;
	for (unsigned int i = 0; i < size; ++i)
	{
		tp = t[i];  //copy operator
		cout << tp << endl;   //output operator
	}

#if 0
	t[4].setBaseType(Type(Type::VOID));  //Have to set base to
		//void before combining
	t[4].combine(t[1]);
	assert(t[4] == t[2]);  //combine function, == operator

	t[2].setBaseType(Type(Type::VOID));
	t[2].combine(t[1]);
	assert(t[2] != t[3]);  //combine function, != operator
	assert(t[4] == t[2]);  //combine function, == operator
#endif

	assert(t[3].getRetType() == t[1]);
	t[1] = Type(Type::DOUBLE);
	assert(t[3].getParams()[0] == t[1]);
	t[4].setSize(7);
	assert(t[4].size() == 7);


	//Test subtypes and functions being more specific
	Type f[] = {
		Type(Type::OPER, vector<Type>(2, Type::INT), Type::INT),
		Type(Type::OPER, vector<Type>(2, Type::FLOAT), Type::FLOAT),
		Type(Type::OPER, vector<Type>(2, Type::DOUBLE), Type::DOUBLE),
		Type(Type::OPER, vector<Type>(2, Type::LDOUBLE), Type::LDOUBLE),
	};
	assert(f[0].isMoreSpecific(f[2]));
	assert(f[1].isMoreSpecific(f[2]));
	assert(f[0].isMoreSpecific(f[3]));
	assert(f[0].isMoreSpecific(f[0]));

	//Test mostGeneral algorithm
	Type t1 = Type::INT;
	Type t2 = Type::DOUBLE;
	Type t3 = Type::BOT;
	Type t4 = Type::FLOAT;
	assert(t1.mostGeneral(t2) == Type::DOUBLE);
	assert(t1.mostGeneral(t3) == Type::INT);
	assert(t1.mostGeneral(t4) == Type::DOUBLE);
	
	//Test constant
	Type t5 = Type::INT;
	t5.setQuals(Type::CONST_FLAG);
	assert(t1.isSubType(Type::INT));
}

