//Generated file - do not edit
virtual void postVisit(AbstractCall* n) { --indent; }
virtual void preVisit(AbstractCall* n) { ++indent; print("AbstractCall"); }
virtual void postVisit(AccessSpec* n) { --indent; }
virtual void preVisit(AccessSpec* n) { ++indent; print("AccessSpec"); }
virtual void postVisit(AddressOf* n) { --indent; }
virtual void preVisit(AddressOf* n) { ++indent; print("AddressOf"); }
virtual void postVisit(ArrayList* n) { --indent; }
virtual void preVisit(ArrayList* n) { ++indent; print("ArrayList"); }
virtual void postVisit(ArrayProp* n) { --indent; }
virtual void preVisit(ArrayProp* n) { ++indent; print("ArrayProp"); }
virtual void postVisit(ArrayRange* n) { --indent; }
virtual void preVisit(ArrayRange* n) { ++indent; print("ArrayRange"); }
virtual void postVisit(ArrayTypeNode* n) { --indent; }
virtual void preVisit(ArrayTypeNode* n) { ++indent; print("ArrayTypeNode"); }
virtual void postVisit(AssignExpr* n) { --indent; }
virtual void preVisit(AssignExpr* n) { ++indent; print("AssignExpr"); }
virtual void postVisit(Binop* n) { --indent; }
virtual void preVisit(Binop* n) { ++indent; print("Binop"); }
virtual void postVisit(Block* n) { --indent; }
virtual void preVisit(Block* n) { ++indent; print("Block"); }
virtual void postVisit(BoolConst* n) { --indent; }
virtual void preVisit(BoolConst* n) { ++indent; print("BoolConst"); }
virtual void postVisit(Break* n) { --indent; }
virtual void preVisit(Break* n) { ++indent; print("Break"); }
virtual void postVisit(CCall* n) { --indent; }
virtual void preVisit(CCall* n) { ++indent; print("CCall"); }
virtual void postVisit(CPPBlock* n) { --indent; }
virtual void preVisit(CPPBlock* n) { ++indent; print("CPPBlock"); }
virtual void postVisit(CPPElement* n) { --indent; }
virtual void preVisit(CPPElement* n) { ++indent; print("CPPElement"); }
virtual void postVisit(CPPInclude* n) { --indent; }
virtual void preVisit(CPPInclude* n) { ++indent; print("CPPInclude"); }
virtual void postVisit(CPPUsing* n) { --indent; }
virtual void preVisit(CPPUsing* n) { ++indent; print("CPPUsing"); }
virtual void postVisit(Call* n) { --indent; }
virtual void preVisit(Call* n) { ++indent; print("Call"); }
virtual void postVisit(CaseStmt* n) { --indent; }
virtual void preVisit(CaseStmt* n) { ++indent; print("CaseStmt"); }
virtual void postVisit(Cast* n) { --indent; }
virtual void preVisit(Cast* n) { ++indent; print("Cast"); }
virtual void postVisit(Catch* n) { --indent; }
virtual void preVisit(Catch* n) { ++indent; print("Catch"); }
virtual void postVisit(CharConst* n) { --indent; }
virtual void preVisit(CharConst* n) { ++indent; print("CharConst"); }
virtual void postVisit(ClassDecl* n) { --indent; }
virtual void preVisit(ClassDecl* n) { ++indent; print("ClassDecl"); }
virtual void postVisit(Const* n) { --indent; }
virtual void preVisit(Const* n) { ++indent; print("Const"); }
virtual void postVisit(Constructor* n) { --indent; }
virtual void preVisit(Constructor* n) { ++indent; print("Constructor"); }
virtual void postVisit(ContainerTypeNode* n) { --indent; }
virtual void preVisit(ContainerTypeNode* n) { ++indent; print("ContainerTypeNode"); }
virtual void postVisit(Continue* n) { --indent; }
virtual void preVisit(Continue* n) { ++indent; print("Continue"); }
virtual void postVisit(DArrayTypeNode* n) { --indent; }
virtual void preVisit(DArrayTypeNode* n) { ++indent; print("DArrayTypeNode"); }
virtual void postVisit(DeclExpr* n) { --indent; }
virtual void preVisit(DeclExpr* n) { ++indent; print("DeclExpr"); }
virtual void postVisit(DeclList* n) { --indent; }
virtual void preVisit(DeclList* n) { ++indent; print("DeclList"); }
virtual void postVisit(DeclOrDefn* n) { --indent; }
virtual void preVisit(DeclOrDefn* n) { ++indent; print("DeclOrDefn"); }
virtual void postVisit(DeclStmt* n) { --indent; }
virtual void preVisit(DeclStmt* n) { ++indent; print("DeclStmt"); }
virtual void postVisit(Decls* n) { --indent; }
virtual void preVisit(Decls* n) { ++indent; print("Decls"); }
virtual void postVisit(Delete* n) { --indent; }
virtual void preVisit(Delete* n) { ++indent; print("Delete"); }
virtual void postVisit(Destructor* n) { --indent; }
virtual void preVisit(Destructor* n) { ++indent; print("Destructor"); }
virtual void postVisit(Enum* n) { --indent; }
virtual void preVisit(Enum* n) { ++indent; print("Enum"); }
virtual void postVisit(Expr* n) { --indent; }
virtual void preVisit(Expr* n) { ++indent; print("Expr"); }
virtual void postVisit(ExprStmt* n) { --indent; }
virtual void preVisit(ExprStmt* n) { ++indent; print("ExprStmt"); }
virtual void postVisit(Exprs* n) { --indent; }
virtual void preVisit(Exprs* n) { ++indent; print("Exprs"); }
virtual void postVisit(FloatConst* n) { --indent; }
virtual void preVisit(FloatConst* n) { ++indent; print("FloatConst"); }
virtual void postVisit(For* n) { --indent; }
virtual void preVisit(For* n) { ++indent; print("For"); }
virtual void postVisit(Function* n) { --indent; }
virtual void preVisit(Function* n) { ++indent; print("Function"); }
virtual void postVisit(GlobalTypeDecl* n) { --indent; }
virtual void preVisit(GlobalTypeDecl* n) { ++indent; print("GlobalTypeDecl"); }
virtual void postVisit(GlobalVarDecls* n) { --indent; }
virtual void preVisit(GlobalVarDecls* n) { ++indent; print("GlobalVarDecls"); }
virtual void postVisit(Goto* n) { --indent; }
virtual void preVisit(Goto* n) { ++indent; print("Goto"); }
virtual void postVisit(If* n) { --indent; }
virtual void preVisit(If* n) { ++indent; print("If"); }
virtual void postVisit(IfExpr* n) { --indent; }
virtual void preVisit(IfExpr* n) { ++indent; print("IfExpr"); }
virtual void postVisit(Initializer* n) { --indent; }
virtual void preVisit(Initializer* n) { ++indent; print("Initializer"); }
virtual void postVisit(InputExpr* n) { --indent; }
virtual void preVisit(InputExpr* n) { ++indent; print("InputExpr"); }
virtual void postVisit(IntConst* n) { --indent; }
virtual void preVisit(IntConst* n) { ++indent; print("IntConst"); }
virtual void postVisit(LabelledStmt* n) { --indent; }
virtual void preVisit(LabelledStmt* n) { ++indent; print("LabelledStmt"); }
virtual void postVisit(Loop* n) { --indent; }
virtual void preVisit(Loop* n) { ++indent; print("Loop"); }
virtual void postVisit(MemberAccess* n) { --indent; }
virtual void preVisit(MemberAccess* n) { ++indent; print("MemberAccess"); }
virtual void postVisit(Name* n) { --indent; }
virtual void preVisit(Name* n) { ++indent; print("Name"); }
virtual void postVisit(New* n) { --indent; }
virtual void preVisit(New* n) { ++indent; print("New"); }
virtual void postVisit(Node* n) { --indent; }
virtual void preVisit(Node* n) { ++indent; print("Node"); }
virtual void postVisit(NormalParam* n) { --indent; }
virtual void preVisit(NormalParam* n) { ++indent; print("NormalParam"); }
virtual void postVisit(NullConst* n) { --indent; }
virtual void preVisit(NullConst* n) { ++indent; print("NullConst"); }
virtual void postVisit(OutputStmt* n) { --indent; }
virtual void preVisit(OutputStmt* n) { ++indent; print("OutputStmt"); }
virtual void postVisit(Param* n) { --indent; }
virtual void preVisit(Param* n) { ++indent; print("Param"); }
virtual void postVisit(Params* n) { --indent; }
virtual void preVisit(Params* n) { ++indent; print("Params"); }
virtual void postVisit(PointerTypeNode* n) { --indent; }
virtual void preVisit(PointerTypeNode* n) { ++indent; print("PointerTypeNode"); }
virtual void postVisit(PrimTypeNode* n) { --indent; }
virtual void preVisit(PrimTypeNode* n) { ++indent; print("PrimTypeNode"); }
virtual void postVisit(Program* n) { --indent; }
virtual void preVisit(Program* n) { ++indent; print("Program"); }
virtual void postVisit(RangeSubscript* n) { --indent; }
virtual void preVisit(RangeSubscript* n) { ++indent; print("RangeSubscript"); }
virtual void postVisit(RangedCaseStmt* n) { --indent; }
virtual void preVisit(RangedCaseStmt* n) { ++indent; print("RangedCaseStmt"); }
virtual void postVisit(RealCPPArray* n) { --indent; }
virtual void preVisit(RealCPPArray* n) { ++indent; print("RealCPPArray"); }
virtual void postVisit(Reference* n) { --indent; }
virtual void preVisit(Reference* n) { ++indent; print("Reference"); }
virtual void postVisit(Return* n) { --indent; }
virtual void preVisit(Return* n) { ++indent; print("Return"); }
virtual void postVisit(SArrayTypeNode* n) { --indent; }
virtual void preVisit(SArrayTypeNode* n) { ++indent; print("SArrayTypeNode"); }
virtual void postVisit(Select* n) { --indent; }
virtual void preVisit(Select* n) { ++indent; print("Select"); }
virtual void postVisit(Stmt* n) { --indent; }
virtual void preVisit(Stmt* n) { ++indent; print("Stmt"); }
virtual void postVisit(Stmts* n) { --indent; }
virtual void preVisit(Stmts* n) { ++indent; print("Stmts"); }
virtual void postVisit(StrConst* n) { --indent; }
virtual void preVisit(StrConst* n) { ++indent; print("StrConst"); }
virtual void postVisit(Subscript* n) { --indent; }
virtual void preVisit(Subscript* n) { ++indent; print("Subscript"); }
virtual void postVisit(SuperClass* n) { --indent; }
virtual void preVisit(SuperClass* n) { ++indent; print("SuperClass"); }
virtual void postVisit(ThisExpr* n) { --indent; }
virtual void preVisit(ThisExpr* n) { ++indent; print("ThisExpr"); }
virtual void postVisit(Throw* n) { --indent; }
virtual void preVisit(Throw* n) { ++indent; print("Throw"); }
virtual void postVisit(TryCatch* n) { --indent; }
virtual void preVisit(TryCatch* n) { ++indent; print("TryCatch"); }
virtual void postVisit(TypeDecl* n) { --indent; }
virtual void preVisit(TypeDecl* n) { ++indent; print("TypeDecl"); }
virtual void postVisit(TypeDeclStmt* n) { --indent; }
virtual void preVisit(TypeDeclStmt* n) { ++indent; print("TypeDeclStmt"); }
virtual void postVisit(TypeNode* n) { --indent; }
virtual void preVisit(TypeNode* n) { ++indent; print("TypeNode"); }
virtual void postVisit(TypeVar* n) { --indent; }
virtual void preVisit(TypeVar* n) { ++indent; print("TypeVar"); }
virtual void postVisit(Unop* n) { --indent; }
virtual void preVisit(Unop* n) { ++indent; print("Unop"); }
virtual void postVisit(UserTypeNode* n) { --indent; }
virtual void preVisit(UserTypeNode* n) { ++indent; print("UserTypeNode"); }
virtual void postVisit(ValueOf* n) { --indent; }
virtual void preVisit(ValueOf* n) { ++indent; print("ValueOf"); }
virtual void postVisit(VarDecl* n) { --indent; }
virtual void preVisit(VarDecl* n) { ++indent; print("VarDecl"); }
virtual void postVisit(Variable* n) { --indent; }
virtual void preVisit(Variable* n) { ++indent; print("Variable"); }
virtual void postVisit(While* n) { --indent; }
virtual void preVisit(While* n) { ++indent; print("While"); }
