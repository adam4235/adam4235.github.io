#ifndef ACCESS_H
#define ACCESS_H

//An access specifier.
enum Access { PUBLIC, PROTECTED, PRIVATE };

#endif
