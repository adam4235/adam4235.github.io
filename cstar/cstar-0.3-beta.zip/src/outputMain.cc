#include "outputMain.h"
#include <iostream>
#include <cstddef>

using namespace std;

void outputMain() {
	#include "gen_main.h"
	for (size_t line = 0; line < main_size; ++line)
	{
		cout << main_file[line] << endl;
	}
}

