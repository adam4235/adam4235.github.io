/* This file defines the Type class for the compiler.
See the file README.TXT.
Type describes the type information (int/double, array size, etc. )
for both a node in the parse
tree and an entry in the symbol table. */

#ifndef TYPEINFO_CC
#define TYPEINFO_CC

/*The different possible types are 
 given in the declaration of Kind below. */

//In a truly good design, this class would be a base class, with the
//different types being subclasses of it, forming a class hierarchy of types.
//But in C++, that's too difficult, because you can only have
//polymorphic behaviour for pointers and newed objects, which would
//introduce garbage collection difficulties.  (This is what I did for the
//AST, but it was much more worthwhile to have a class hierarchy for the AST).

#include <vector>
#include <string>
#include <cassert>
#include <fstream>

class Node;
class SymbolTable;

using std::string;
using std::vector;
using std::ostream;

class Type {
public:
	enum Kind {
		VOID = 0,  //No type assigned yet
		INT,  //int
		UINT,  //unsigned int
		FLOAT,  //float
		DOUBLE,  //double
		LDOUBLE,  //long double
		BOOL,  //bool
		CHAR,  //char
		FUNCTION,  //function type
//		OPER,  //operator
		ARRAY,  //array type
		DARRAY,  //dynamic array
		BLOCK,  //block (of statments)
        LABEL, //label (for a statement)
		ENUM,  //Enumeration
		ENUMERATOR,  //A single value within an enumeration
        CLASS,   //Class
		TYPE,     //A type referring to another type, including a variable of type "type".
    //Class definitions actually have the type Type(TYPE, Type(CLASS, ...)),
    //While variables of object type have type Type(CLASS, ...).
    //Likewise for enum definitions and variables of enum types.
    //The reason for this is that in a statment like:
    //var := value
    //we have to call isSubType to check whether the assignment is valid,
    //so var needs to have class type.
    //However, we also need to be able to distinguish references to types from references to objects,
    //as an assignment like:
    //Shape := 1
    //must give an error that a type may not be used as a variable.
    //Type variables (type t := int) also have type TYPE (which means type t := Shape can't
    //be distinguished from the definition of the Shape class, but that's not a problem.)
    
		PTR,  //Pointer
		CONST_PTR,  //Constant pointer
//		REF,  //Reference
		NUL,  //Null (subtype of every pointer type)
		BOT,  //Bottom (subtype of every type).  Can't actually have
			//variables of this type, but [] is an array of bottom.
		THING,  //The supertype of all other types
		AMB   //ambiguous type - it could be one of many types.
			//In this case, the possibilities can be acquired from
			//"getChoices()"
	};

	//Type qualifiers
	enum Quals {
		NO_FLAG = 0,
		CONST_FLAG = 1,
		REF_FLAG = 2,
		STATIC_FLAG = 4,
        FINAL_FLAG = 8, 
        CASE_FLAG = 16,  //Function case
        VIRTUAL_FLAG = 32, 
        FRIEND_FLAG = 64
	};

private:
	Kind type;

	Quals quals;  //The type qualifiers attached to the type

	//This stuff could possibly be made more efficient using unions
	//or something, since for arrays you only need the array variables,
	//and for functions you only need the function variables.
	//But using unions required 2 more dereferences before getting to
	//the variables themselves.

	//ARRAYS:
	size_t m_size;  /* The number of elements, for arrays */
	long m_li;                 /* Lower index, for arrays */
	Type* baseType;  //Base type for array

    bool m_overridesSomething;  //True iff it's a function that has been found
        //to override another function

	//FUNCTIONS:
	//Note: the Type*s point to new Types that have
	//to be deleted when this typeinfo is deleted.
	vector<Type>* parameters;  //Parameters of the function
		//Making it a pointer to a vector saves memory for
		//Types that aren't functions.
	Type* returnType;  //Return type for functions
	vector<Node*>* pointsOfDefnOrDecl;  //For an ambiguous type,
		//all the places where the different choices were defined/declared

	//ENUMS:
	vector<string>* enumerators;  //The possible values
		//of the enumeration.
		//Also used for the ENUMERATOR type - constants
		//of type ENUMERATOR puts only 1 item in this
		//list, namely their name

	//CLASS:
	string* refName;

    //Used by the copy constructor and assigment operator to
    //copy t into this type.
	void copyFrom(const Type& t);
	
	//Used by all the constructors to initialize everything.
	void initAll();

    //For friend functions, the type that the function is a friend of
    //(i.e. the class containing it)
    Type* friendType;
    
public:
    //KIND
    
	/** @return The type (kind) of this type (int, double, array, function, ...) */
	Kind getType() const { return type; }

	/**@return Whether the type is a primitive type*/
	bool isPrimitive() const;
    
    bool isInt() const {
        return type == INT || type == UINT;
    }
    
	bool isArray() const { return type == ARRAY || type == DARRAY; }
	
	/** @return Whether this is a function (or operator) */
    bool isFunction() const { 
        return type == FUNCTION; 
    }

    /** @return Whether the type is a class definition (TYPE(CLASS)) */
    bool isClassDefn() const {
        return type == TYPE && getReferredType().getType() == CLASS;
    }
    
	/**@return whether this is an enum*/
	bool isEnum() const { return type == ENUM; }
    
	/**@return whether this is an enumerator*/
	bool isEnumerator() const { return type == ENUMERATOR; }
    
    /**@return Whether it's an enum or an enumerator*/
    bool isEnumVal() const { return isEnum() || isEnumerator(); }
    
	/**@return Whether this type is an alias type (reference, pointer, const pointer). */
	bool isAlias() const {
		return hasFlag(REF_FLAG) || isPtr();
	}
	bool isPtr() const {
		return type == PTR || type == CONST_PTR;
	}
    bool isPtrVal() const {
        return isPtr() || type == NUL;
    }

    /**@return Whether it's an object type and in need of outputting the csAutoPtr transformation
    to implement the object model wherein a variable of class type can hold an object of that type
    or a subclass.
    Searching for all the calls to this function in CodeGenerator 
    should give all the node types involved in the
    object model transformation.*/
    bool needAutoPtr() const { return type == CLASS; }

    //FLAGS/QUALS
    
	/**@return Whether flag, a type qualifier, is set for this type.*/
	bool hasFlag(Quals flag) const {
		return (quals & flag) == flag;
	}

	/**Add the type qualifiers specified in flag.*/
	void setQuals(Quals flag) {
		quals = Quals(quals | flag);
	}
	/**Clear all type qualifiers.*/
	void clearQuals() {
		quals = NO_FLAG;
	}

	/**Clear flag, or do nothing if flag is already set*/
	void clearQuals(Quals flag) {
		if (hasFlag(flag)) quals = Quals(quals - flag);
	}

	/**@return The type qualifiers for this */
	Quals getQuals() {
		return quals;
	}

	/**@return Whether the type is constant. */
	bool isConst() const { 
		if (type == PTR) return false;
		else if (type == CONST_PTR) return true;
		else return hasFlag(CONST_FLAG); 
	}
    
    /**@return whether the type is a plain constant
     (not ptr to const*/
    bool isNonPtrConst() const {
        if (isPtr()) return false;
		else return hasFlag(CONST_FLAG); 
    }        

	bool isStatic() const {
		return hasFlag(STATIC_FLAG);
	}

	/** Return a type with the prefixed "reference to"
	 * removed, if any.*/
	Type stripRef() const;

	//ARRAYS:
	/** Get the base type for an array type*/
	Type getBaseType() const {
		assert(isArray() || isPtr());
		return *baseType; 
	}
	/** Set the base type */
	void setBaseType(const Type& baseType) {
		assert(isArray() || isPtr());
		if (this->baseType != 0)
		{
			delete this->baseType;
		}
		this->baseType = new Type(baseType);  
	}
	
	/** @return the upper index of the array*/
	long ui() const {
		assert(type == ARRAY);
		return m_size - 1 + m_li;
	}
	/** @return the size of the array */
	size_t size() const { 
		return m_size; 
	}
	/** @return the lower index of the array */
	long li() const { 
		assert(isArray());
		return m_li; 
	}
	
	/** Set the size of the array to size.
	 * Called after the size has been calculated from the
	 * array initializer.*/
	void setSize(size_t size) {
		m_size = size;
	}
	
	//FUNCTIONS:

//Note that many of the get functions below can't return
//a const &, if they're returning the value of something,
//because the value of something is a temporary and you can't
//return a reference to a temporary.
	
	/** Get the return type */
	Type getRetType() const {
		assert(isFunction());
		return *returnType;
	}

	/** Get the parameters */
	vector<Type> getParams() const {
		assert(isFunction());
		return *parameters;
	}

	vector<Node*> getPointsOfDefnOrDecl() const {
		assert(type == AMB);
		return *pointsOfDefnOrDecl;
	}

    bool overridesSomething() const { 
        assert(isFunction());
        return m_overridesSomething; 
    }
    void foundOverride() { 
        assert(isFunction());
        m_overridesSomething = true; 
    }
    
    /**@rerturn Whether the type is a copy constructor for the class classType.*/
    bool isCopyConstructor(const Type& classType) const;
    
	/** @return Whether the function represented by this is
	 * more specific that the function represented by that.
	 * Both types must be functions.*/
	bool isMoreSpecific(const Type& that, SymbolTable* currentSymTable) const;

    void setFriend(Type classType)
    {
        assert(isFunction());
        friendType = new Type(classType);
    }
    
    bool isFriendOf(Type classType)
    {
        if (friendType == 0) return false;
        else return *friendType == classType;
    }
    
    void clearFriend() {
        delete friendType;
        friendType = 0;
        clearQuals(FRIEND_FLAG);
    }
    
    Type getFriendType() {
        assert(friendType != 0);
        return *friendType;
    }
    
	vector<string> getEnumerators() const {
		assert(isEnum());
		return *enumerators;
	}

    string getEnumeratorVal() const {
		assert(isEnumerator());
		return (*enumerators)[0];
	}

	//AMBIGUOUS TYPES:
    vector<Type> getChoices() const {
        assert(getType() == AMB);
        return *parameters;
    }
    
    
	//TYPE types:
	Type getReferredType() const {
		assert(type == TYPE); 
		return *baseType; 
	}
	
    //CLASS types:
    string getClassName() const {
        assert(type == CLASS);
        return *refName;
    }

    /** Get the class type containing the current class type.
    Nested class definitions in the symbol table don't actually get
    stored this way, but when referenced with dot qualification, e.g. X.Y,
    the container class is needed to be able to find the class.*/
    Type getContainerClass() const {
        assert(type == CLASS);
        return *baseType;
    }
    
    //Get the dot-separated class name
    string getFullClassName() const;
    
    /*Remove the container class and return it.
    If the class doesn't have a container class, return curClassType.*/
    Type extractContainerClass(const Type& curClassType);
    
    /** Set the container of a class in a dot-separated list */
    void setContainerClass(const Type& container) {
        //container should have type Type(TYPE, Type(CLASS, ...))
        assert(type == TYPE && container.type == CLASS);
        *baseType->baseType = container;
    }
    
	/* Create a type info structure for an array */
	Type(const Type& baseType, size_t arr_size, long li = 0);

	/* Create a new dynamic array type */
	Type(Kind type, Type referredType, long li);

	/* Create a new type info structure for a scalar */
	Type(Kind type);

	/* Create a new type info structure for a function or operator*/
	Type(Kind type, const vector<Type>& parameters, const Type& returnType);

	/* Create a new type type (i.e. the type of a name which refers to a type) */
	Type(Kind type, Type referredType);

	/* Create a new enum or enumerator type. */
	Type(Kind type, const vector<string>& enumerators);

	/* Create a new type reference (which has to be looked up
	 * in the symbol table) or a class. */
	Type(Kind type, string name);

	/* Create a new ambiguous type*/
	Type(Kind type, const vector<Type>& choices, const vector<Node*>& pointsOfDefnOrDecl);
	
	/* Create a new unknown type */
	Type();

	/* Copy constructor */
	Type(const Type& t);
	Type& operator=(const Type& t);
	
	bool operator==(const Type& that) const;
	bool operator!=(const Type& that) const {
		return !(*this == that);
	}

	/** @return Whether this is a subtype of that 
	 * @param allowConstOnLeft For declarations, you're allowed to have
	 * 		const := non-const.  Set this flag to true in those situations.*/
	bool isSubType(const Type& that, SymbolTable* currentSymTable, bool allowConstOnLeft = false) const;

	/** @return The common supertype that both this and that is
	 * a subtype of (least upper bound). */
	Type mostGeneral(const Type& that, SymbolTable* currentSymTable) const;

	/** @return A list of the immediate supertype to this type. */
	vector<Type> superTypes(SymbolTable* currentSymTable) const;

    /** @return Whether this and that are similar, ignoring qualifiers */
    bool similarTo(const Type& that) const;

    /** @return Whether this, which must be a function,
    overrides that, which must also be a function.
    If the declaration is such that it's an erroneous override (e.g. this is
    not a function case), still returns true.*/
    bool overrides(const Type& that) const;
    
    /** For functions, determines whether the definitions match sufficiently,
    already knowing that `this' overrides `that'.
    For example, if the return types of this and that differ, this->overrides(that)
    would return true, but this->defnMatches(that) would return false.
    */
    bool defnMatches(Type that) const;
    
    /** Determines whether both types are functions that are overloaded. */
    
    bool isOverloaded(Type that) const {
        return isFunction() && that.isFunction() && !defnMatches(that);
    }
    
	/**Output*/
	friend ostream& operator<<(ostream& os, const Type& t);
	static char *typeAsString(Type::Kind t);
	 
	virtual ~Type();
};

/**@return t with const set.*/
inline Type constOf(Type t) {
	t.setQuals(Type::CONST_FLAG);
	return t;
}

#endif
