/* This is the main entry point for the compiler.
See the file README.TXT.
 */

#include "error.h"
#include <new>
#include <cstdio>

using namespace std;

int yyparse();

void noMoreMemory() {
	cerr << "Out of memory.\n";
	abort();
}

extern FILE* yyin;  //The lex input stream (defaults to stdin)

int main(int argc, char** argv) {
	set_new_handler(noMoreMemory);  //Make sure the program
		//exits properly if it runs out of memory.

    //Deal with command-line arguments
    if (argc > 2)
    {
        cout << "Usage: " << argv[0] << " [infile]" << endl;
        cout << "Takes C* input file from standard input (or infile) and translates to C++ on standard output." << endl;
        return 1;
    }
    else if (argc > 1)
    {
        //Take the input from the file the user specified, rather than standard input
        yyin = fopen(argv[1], "r");
        if (!yyin)
        {
            cout << "File not found: " << argv[1] << endl;
            perror("Error returned by system: ");
            return 1;
        }
    }

    setbuf(stdout, NULL);  //Automatically flush stdout, so I can figure out where things are getting printed
	yyparse();  //Do the translation
    if (argc > 1) fclose(yyin);
    
	return errorFound? 1 : 0;
}
