void outputCsAutoPtr();
