#include "outputCsAutoPtr.h"

#include <iostream>
#include <cstddef>

using namespace std;

void outputCsAutoPtr() {
#include "gen_csAutoPtr.h"
	for (size_t line = 0; line < csAutoPtr_size; ++line)
	{
		cout << csAutoPtr_file[line] << endl;
	}
}

