#include "passes.h"
#include "ast/Node.h"
#include "parser.h"
#include "error.h"
#include "all_passes.h"
#include "SymbolTable.h"
#include "outputArrayClasses.h"
#include "outputThing.h"
#include "outputMain.h"
#include "outputCsAutoPtr.h"

#include <memory>

using namespace std;

//Output the bottom and Thing classes, which are used often.
void outputBaseClasses()
{
    cout << "class Thing {" << endl;
    cout << "public:" << endl;
    cout << "virtual ~Thing() {}" << endl;
    cout << "virtual Thing* _clone() { throw 0; }" << endl;
    cout << "};" << endl;

    cout << "class bottom : public Thing {};" << endl << endl;
}

void bPasses(Node* n, SymbolTable* currentSymTable, ClassDecl* originalClass, bool inNamespace) {
    auto_ptr<BuildSuperTypesAndTypeVars> superTypes(new BuildSuperTypesAndTypeVars(currentSymTable));
	auto_ptr<BuildTopLevel> topBuilder(new BuildTopLevel(currentSymTable, originalClass, inNamespace));
    auto_ptr<BuildClasses> classBuilder(new BuildClasses(currentSymTable));
    n->accept(superTypes.get());
    
    n->accept(topBuilder.get());  //Add other top-level declarations
    //to the symbol table 
    //(now that their type can be referenced)
#if 0
    symtable.print();
#endif
    n->accept(classBuilder.get());
        
}

void passes(Node* n) {
    //Stuff to fix up after parsing
	auto_ptr<InferArraySize> inferArray(new InferArraySize());
	auto_ptr<DesugarString> deString(new DesugarString());
    auto_ptr<MakeArrayProp> arrayProp(new MakeArrayProp());
    auto_ptr<FixSupertypes> fixSuper(new FixSupertypes());
    auto_ptr<PullOutDeclExpr> pull(new PullOutDeclExpr());
	auto_ptr<BreakContinue> brkCon(new BreakContinue());
    
    //Building types / disambiguation
    auto_ptr<BuildTypes> typeBuilder(new BuildTypes(&symtable));
    auto_ptr<FindCodeBlocks> builder(new FindCodeBlocks());
    auto_ptr<CheckClasses> checkClasses(new CheckClasses());
    auto_ptr<DisamAndLookup> disam(new DisamAndLookup());
    
    //Error checking
    auto_ptr<FindAmbiguities> amb(new FindAmbiguities());
    auto_ptr<TypeChecker> tc(new TypeChecker());
    auto_ptr<CheckCPPBlocks> cpp(new CheckCPPBlocks());
    
    //Transformations
	auto_ptr<FlattenDecls> flatten(new FlattenDecls());
	auto_ptr<ArrayTransform> array(new ArrayTransform());
    
    //Code output
	auto_ptr<CodeGenerator> code(new CodeGenerator());
    
    //Debugging
	auto_ptr<PrintAST> printAST(new PrintAST());
	
	//Add type declarations (including classes) to the symbol table
    symtable.addBuiltIns();
    
	try {
		n->accept(inferArray.get());  //infer array sizes
        
		n->accept(deString.get());  //Convert strings to char[]

        n->accept(arrayProp.get());
        
        n->accept(fixSuper.get());
        
		n->accept(pull.get());  //Convert declarations in statements to
			//the declarations followed by the statement

#ifdef DEBUG
		n->accept(printAST.get());  //DEBUG
		return;
#endif

		n->accept(brkCon.get());  //Break and continue with labels

        n->accept(typeBuilder.get());  //Add type declarations

        bPasses(n);
        
		n->accept(builder.get());  //Add all other declarations
			//to the symbol table 
	
#ifdef DEBUG
	symtable.print();
        return;

	ContextVisitor* cv = new ContextVisitor();
	n->accept(cv);
	assert(cv->getSymTable() == &symtable);
	delete cv;
#endif

        n->accept(checkClasses.get());
        
        n->accept(disam.get());
        
        n->accept(amb.get());
        
        
		n->accept(tc.get());   //typechecking (and error checking)

		n->accept(cpp.get());  //Check for errors related to cpp {} blocks

#if 0
		symtable.print();
#endif

		n->accept(flatten.get());

		n->accept(array.get());  //array transformations
					
        
        outputBaseClasses();
        
        outputCsAutoPtr();
        
		outputThing();
        
		if (io_used) cout << "#include <iostream>\n";
        cout << "#include <cassert>\n";
        
		if (array_used)
		{
			outputArrayClasses();
		}

		n->accept(code.get());        //code generation

		if (argv_used)
			outputMain();
	}
	catch (const CompileError& ce) {
		//Catching the compile error merely prevents any future passes from being run.
	}
}
