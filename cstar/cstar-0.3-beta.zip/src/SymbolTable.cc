/*Implementation file for SymbolTable.h.  See that file. */

#include "SymbolTable.h"
#include "ast/Function.h"
#include "ast/VarDecl.h"
#include "ast/Enum.h"
#include "ast/Name.h"

#include <algorithm>

using namespace std;

//****Constructors/destructors*****

symtab_entry::symtab_entry(const Type& type, SymbolTable* parent, bool isDefn, Node* pointOfDefn, Access curAccess, string realName, bool isInstanceVar)
	: type(type), parent(parent), pointOfDefnOrDecl(pointOfDefn), isDefn(isDefn), realName(realName), isInstanceVar(isInstanceVar)
{
	if (type.isFunction() || type.getType() == Type::BLOCK || type.isClassDefn())
		//Entries which have a scope within them need a child symbol table
		child = new SymbolTable(this);
	else
		child = 0;
	assert(parent != 0);
    access = curAccess;
}

symtab_entry::symtab_entry(const symtab_entry& c) 
	: type(c.type), parent(c.parent), 
	pointOfDefnOrDecl(c.pointOfDefnOrDecl), isDefn(c.isDefn), realName(c.realName), access(c.access), isInstanceVar(c.isInstanceVar)
{
	if (c.child == 0)
		child = 0;
	else
	{
	   //make a copy of the old SymbolTable, but ensure that its scope is set to
	   //this symtab_entry instead of that of the copy
		child = new SymbolTable(*c.child, this);
	}
}

symtab_entry::~symtab_entry()
{
	if (child != 0) delete child;
}

SymbolTable::SymbolTable(symtab_entry* scope) : 
	multimap<string, symtab_entry>(), scope(scope)
{
}

SymbolTable::SymbolTable(const SymbolTable& c, symtab_entry* scope) : 
	multimap<string, symtab_entry>(c), scope(scope)													 
{
}


//*****Add built-in operators*****

void SymbolTable::addOper(string name, const Type& op1, const Type& op2, Type retVal, string realName) {
	vector<Type> parameters;
	parameters.push_back(op1);
	if (op2.getType() != Type::VOID) parameters.push_back(op2);
	symtab_entry newEntry(Type(Type::FUNCTION, parameters, retVal), this, true, 0, PUBLIC, realName);
	insert(make_pair(name, newEntry));
}

void SymbolTable::addRel(string oper) {
//These are all needed so that duplicate definitions can
//be prevented when users try to redefine the built-in operators.
	addOper(oper, Type::LDOUBLE, Type::LDOUBLE, Type::BOOL);
	addOper(oper, Type::DOUBLE, Type::DOUBLE, Type::BOOL);
	addOper(oper, Type::FLOAT, Type::FLOAT, Type::BOOL);
	addOper(oper, Type::INT, Type::INT, Type::BOOL);
}

void SymbolTable::addEquality(string oper) {
	addRel(oper);
	addOper(oper, Type::CHAR, Type::CHAR, Type::BOOL);
	addOper(oper, Type::BOOL, Type::BOOL, Type::BOOL);
}

void SymbolTable::addArithmetic(string oper, bool unary) {
    //We need all these different operators so that the result type will
    //be correct.
	addOper(oper, Type::DOUBLE, unary? Type::VOID : Type::DOUBLE, Type::DOUBLE);
	addOper(oper, Type::LDOUBLE, unary? Type::VOID : Type::LDOUBLE, Type::LDOUBLE);
	addOper(oper, Type::FLOAT, unary? Type::VOID : Type::FLOAT, Type::FLOAT);
	addOper(oper, Type::INT, unary? Type::VOID : Type::INT, Type::INT);
}

void SymbolTable::addBuiltIns() {
	assert(globalScope());

	//Arithmetic operators and the corresponding equality operators
	string arithOpers[] = { "+", "-", "*", "/", "%" };
	string eqOpers[] = { "=", "+=", "-=", "*=", "/=", "%=" };
	for (unsigned int i = 0; i < sizeof(arithOpers) / sizeof(string); ++i)
	{
		addArithmetic(arithOpers[i]);
		addArithmetic(eqOpers[i]);
	}
	
	addOper("\\", Type::INT, Type::INT, Type::INT); //, "__builtin_idiv11");
	addOper("\\=", Type::INT, Type::INT, Type::INT); //, "__builtin_idivequal11");
	addArithmetic("-", true);

	//Relational operators
	string relOpers[] = { "<", ">", "<=", ">=" };
	for (unsigned int i = 0; i < sizeof(relOpers) / sizeof(string); ++i)
	{
		addRel(relOpers[i]);
	}
	addEquality("==");
	addEquality("!=");

	//Logical operators
	addOper("and", Type::BOOL, Type::BOOL, Type::BOOL);
	addOper("or", Type::BOOL, Type::BOOL, Type::BOOL);
	addOper("not", Type::BOOL, Type::VOID, Type::BOOL);

	//Increment and decrement
	addOper("++", Type::INT, Type::VOID, Type::INT);
	addOper("--", Type::INT, Type::VOID, Type::INT);
    
    //Assert
	vector<Type> parameters;
	parameters.push_back(Type::BOOL);
	symtab_entry newEntry(Type(Type::FUNCTION, parameters, Type::VOID), this, true, 0, PUBLIC);
	insert(make_pair("assert", newEntry));    
}


//******Add functions*******

SymbolTable::iterator 
SymbolTable::changeDefn(const string& name, const symtab_entry& newEntry) {
    if (newEntry.isDefn)  //Definition
    {
        assert(!hasDefn(name, newEntry.type));  //Can't have a duplicate defn
#ifdef DEBUG
        try {
            if (getPointOfDefn(name, newEntry.type) != 0) {
                cout << name << endl;
                cout << newEntry.type << endl;
            }
        }
        catch (SymbolNotFound s) {
            cout << name << endl;
            cout << newEntry.type << endl;
            assert(0 == 1);
        }
#endif
        return setPointOfDefn(name, newEntry.type, newEntry.pointOfDefnOrDecl);
          //Set it to have a definition
    }
    else return lookupInScope(name, newEntry.type);
}

bool SymbolTable::add(VarDecl* n, Access curAccess, bool alwaysDefn)
{
	string variable = n->getName();
	Node* initVal = n->getInitVal();
	
	bool defn = (initVal != 0 || alwaysDefn);  //Whether it's a 
		//definition (as opposed to a declaration)

	symtab_entry newEntry(n->getTypeNode()->getType(), this, defn, n, curAccess, "", n->isInstanceVar());
	
    if (existsThisScope(variable))
    {
        if (lookUpType(variable) != newEntry.type)
        	//It's an error to have 2 declarations (or a declaration and a definition) for
            //variables of the same name but different types.
            return false;
        else
        {
            changeDefn(variable, newEntry);
            return true;
        }
    }

	insert(make_pair(variable, newEntry));
	return true;
}

void SymbolTable::addLabel(const string& label)
{
    SymbolTable* toAddTo = currentFunction()->child;
    assert(!exists(label));
    symtab_entry newEntry(Type::LABEL, this, false, 0, PUBLIC);
    toAddTo->insert(make_pair(label, newEntry));
}

void SymbolTable::addType(Node* n, string name, const Type& type, Access curAccess, bool isDefn)
{
	assert(name != "");

	//Add the enum, class, or type variable to the symbol table

	assert(!existsThisScope(name));

	symtab_entry newEntry(Type(Type::TYPE, type), this, isDefn, n, curAccess);
	insert(make_pair(name, newEntry));
}

string SymbolTable::addEnumerators(Enum* n, Access curAccess)
{
	//Add all the enumerators
	
	for (vector<string>::const_iterator i = n->getEnumerators().begin();
			i != n->getEnumerators().end(); ++i)
	{
		const string& enumerator = *i;

		vector<string> enumerators(1);  //Used to create the type
			//of the enumerator - it needs its name in the
			//type info.
		enumerators[0] = enumerator;

		if (existsThisScope(enumerator)) return enumerator;

		Type t(Type::ENUMERATOR, enumerators);
		symtab_entry newEntry(t, this, true, n, curAccess);
		insert(make_pair(enumerator, newEntry));
	}
	return "";
}

SymbolTable* SymbolTable::addFunction(Function* n, Access curAccess)
{
	string funcName = n->getName();
    string realName = "";
    if (n->isMainWithArgs())
    {
        realName = "__csMain11";
        argv_used = true;
    }
    else realName = findOpName(funcName);

    n->setRealName(realName);  //Store it in the function so it doesn't have
        //to be looked up later.
    
	Type t = n->getType();
	symtab_entry newEntry(t, this, (n->getBody() != 0), n, curAccess, realName); 

    if (existsThisScope(funcName, newEntry.type))  //functions
        //can be overloaded, so it's only a redeclaration if
        //the types are the same.
        //It's OK if there are functions with different return types,
        //because they will just result in an ambiguity when you try
        //to call them.
    {
		iterator retVal = changeDefn(funcName, newEntry); 
		return retVal->second.child;        
    }
    
	return insertAndReturnEntry(funcName, newEntry).child;
	
//		return newEntry.child;    This doesn't work because newEntry was
//only a temporary symbol table entry that has been copied into the 
//symbol table.
//	return lookup(funcName).child;  This option would be inefficient
}

SymbolTable* SymbolTable::addScope(const string& name)
{
	symtab_entry newEntry(Type(Type::BLOCK), this, false, 0, PUBLIC);
	return insertAndReturnEntry(name, newEntry).child;
}

const symtab_entry& SymbolTable::insertAndReturnEntry(const string& name, const symtab_entry& newEntry)
{
	//The insert function returns the thing inserted
	iterator ptrToEntry = insert(make_pair(name, newEntry));
    
	//The inserted thing was the <name, entry> pair - get the entry part of it
	const symtab_entry& actualNewEntry = ptrToEntry->second;
	return actualNewEntry;
}

bool equalsIgnoreFriend(Type t1, Type t2)
{
    t1.clearFriend();
    t2.clearFriend();
    return t1 == t2;
}

//***Lookup functions***

SymbolTable::iterator 
SymbolTable::lookupInScope(const string& symbol, const Type& type)
{
	for (iterator i = begin(); i != end(); ++i)
	{
        string curSymbol = i->first;
        Type curType = i->second.type;
		if (curSymbol == symbol && equalsIgnoreFriend(curType, type))
			return i;
	}
	throw SymbolNotFound(symbol);
}

vector<symtab_entry*> SymbolTable::lookup(const string& symbol, const Type& t, bool requireDefn, bool inScope) const
{
    SymbolTable* symTableToCheck = const_cast<SymbolTable*>(this); 
	while (0 == 0)
	{
		vector<symtab_entry*> retVal;
		for (iterator i = symTableToCheck->begin(); i != symTableToCheck->end(); ++i)
		{
			if (i->first == symbol)
			{
                Type potentialMatchingType = i->second.type;
                bool matches = (t == Type::VOID || equalsIgnoreFriend(t, potentialMatchingType));
				if (matches &&
					(!requireDefn || (i->second).isDefn))
				{
					retVal.push_back(&(i->second));
					if (t != Type::VOID) return retVal;  //speed things up
				}
			}
		}
        
		if (retVal.size() > 0) return retVal;
		
		/*
		 It seems i->second is a reference to an existing object,
		 so it's OK to return it.  The below test was used to verify that.
         {
         iterator j =
         symTableToCheck->multimap<string, symtab_entry>::find(symbol);
         assert( &(i->second) == &(j->second));
         return i->second;
         }
         */
		if (symTableToCheck->globalScope() || inScope) throw SymbolNotFound(symbol);
		symTableToCheck = symTableToCheck->scope->parent;
	}
}

bool SymbolTable::exists(const string& symbol, const Type& t)
{
	try {
		vector<symtab_entry*> result = lookup(symbol, t);
		return result.size() > 0;
	}
	catch(const SymbolNotFound& s) {
		return false;
	}
}

bool SymbolTable::exists(const string& symbol)
{
	try {
		lookup(symbol);
	}
	catch(const SymbolNotFound& s) {
		return false;
	}
	return true;
}

bool SymbolTable::hasMember(const Type& classType, const string& symbol)
{
	try {
		lookupMember(classType, symbol);
	}
	catch(const SymbolNotFound& s) {
		return false;
	}
	return true;
}

bool SymbolTable::existsThisScope(const string& symbol)
{
	return (find(symbol) != end());
}

bool SymbolTable::existsThisScope(const string& symbol, const Type& t)
{
	try {
		lookupInScope(symbol, t);
	}
	catch(const SymbolNotFound& err)
	{
		return false;
	}
	return true;
}

void SymbolTable::makeFriendOf(const string& symbol, const Type& t, const Type& classType)
{
    iterator toBefriend = lookupInScope(symbol, t);
    toBefriend->second.type.setQuals(Type::FRIEND_FLAG);
    toBefriend->second.type.setFriend(classType);
}

//***Point of definition/declaration functions***

Node* SymbolTable::getPointOfDefnOrDecl(const string& name, const Type& type)
{
	return getDefnOrDeclGeneral(name, type, false);
}

Node* SymbolTable::getPointOfDefnOrDecl(const string& name)
{
    return getDefnOrDeclGeneral(name, Type::VOID, false);
}

Node* SymbolTable::getPointOfDefn(const string& name, const Type& type)
{
	return getDefnOrDeclGeneral(name, type, true);
}

Node* SymbolTable::getDefnOrDeclGeneral(const string& name, const Type& type, bool requireDefn) {
	const vector<symtab_entry*> result = lookup(name, type, requireDefn);
    if (result.size() == 0) throw SymbolNotFound(name);
    else return result[0]->pointOfDefnOrDecl;
}

Node* SymbolTable::getPointOfDefnOrDecl(Name* name)
{
	pair<symtab_entry*, Type> result = lookup(name);
    return result.first->pointOfDefnOrDecl;
}

SymbolTable::iterator 
SymbolTable::setPointOfDefn(const string& name, 
	const Type& type, Node* pointOfDefn) 
{
	for (iterator i = begin(); i != end(); ++i)
	{
		if (i->first == name && i->second.type == type)
		{
			i->second.pointOfDefnOrDecl = pointOfDefn;
			i->second.isDefn = true;
			return i;
		}
	}
	throw SymbolNotFound(name);
}

bool SymbolTable::hasDefn(const string& name, const Type& type) {
	try {
		//getPointOfDefn(name, type);
        lookup(name, type, true);
	}
	catch(SymbolNotFound& err)
	{
		return false;
	}
	return true;
}

/**Look up a symbol which has a sub-scope (e.g. a function or block).*/
SymbolTable* SymbolTable::findScope(const string& symbol, const Type& type) {
	iterator i = lookupInScope(symbol, type);
	const symtab_entry& entry = i->second;
	if (entry.child == 0)
		throw symbol + " not a scope.";
	return entry.child;
}

Type SymbolTable::lookUpType(const string& s) {
	vector<symtab_entry*> result = lookup(s);
	assert(result.size() >= 1);
	if (result.size() == 1)
	{
		return result[0]->type;
	}
	//From here on, we have an ambiguous type - i.e.
	//there are multiple things named s in the symbol table.
    return ambTypeOf(result);
}

Type SymbolTable::lookupType(Name* n) {
    pair<symtab_entry*, Type> result = lookup(n);
    Type retVal(result.first->type);
    if (result.second != Type::VOID)
    {
        //the 2nd returned value from lookup is the qualifier representing the
        //class the entry is found in.  Have to set that as the container class
        //in the type to return.
        retVal.setContainerClass(result.second);
    }
    return retVal;
}

Type SymbolTable::ambTypeOf(vector<symtab_entry*> entries) const {
	vector<Type> choices;
	vector<Node*> pointsOfDefnOrDecl;
	for (vector<symtab_entry*>::iterator i = entries.begin();
         i != entries.end(); ++i)
	{
		choices.push_back((*i)->type);
		pointsOfDefnOrDecl.push_back((*i)->pointOfDefnOrDecl);
	}
	return Type(Type::AMB, choices, pointsOfDefnOrDecl);    
}

//***Other functions***

const symtab_entry*const SymbolTable::currentFunction() const {
	//Keep going up to the parent scope until it's a function.
	symtab_entry* curScope = scope;
	if (curScope == 0) return 0;
	while (!(curScope->type).isFunction()) {
		curScope = curScope->parent->scope;
        if (curScope == 0) return 0;
	}
	return curScope;
}

const symtab_entry*const SymbolTable::inClassGeneral(Type classType, bool anyClass, bool checkSuper) const
{
	//Keep going up to the parent scope until it's a class.
    
    classType = Type(Type::TYPE, classType);  //The symbol table contains classes 
        //specified as Type(TYPE, Type(CLASS, ...)), but the
        //parameter is just a Type(CLASS, ...)
	symtab_entry* curScope = scope;
    if (globalScope()) return 0;
    do {
        Type curType = curScope->type;
        if (curType.isClassDefn())
        {
            if (anyClass) return curScope;
            else if (classType == curType) return curScope;
            if (checkSuper && hasSuperType(curType, classType, true)) return curScope;
        }
		curScope = curScope->parent->scope;
	} while (curScope != 0);
	return curScope;
}

string SymbolTable::getRealName(const string& name, const Type& type) {
	try {
        vector<symtab_entry*> result = lookup(name, type);
        if (result.size() == 0) return "";
        string retVal = result[0]->realName;
        if (retVal == "") return name;
        else return retVal;
	}
	catch (SymbolNotFound e) {
		return name;  //Made-up variables won't be in the symbol table.
        //They don't have a realName, so just return them.
	}
	
}

void SymbolTable::addSuperGeneral(string className, Type superClass, bool superType) {
    vector<symtab_entry*> result = lookup(className, Type::VOID, true);
    assert(result.size() == 1);
    symtab_entry* classEntry = result[0];
    if (superType)
        classEntry->superTypes.push_back(superClass);
    else
        classEntry->superClasses.push_back(superClass);
}

void SymbolTable::addSuperClass(string className, Type superClass) {
    addSuperGeneral(className, superClass, false);
}

void SymbolTable::addSuperType(string className, Type superClass) {
    addSuperGeneral(className, superClass, true);
}

const symtab_entry* SymbolTable::lookupClass(Type classType) const {
    string className = classType.getClassName();
    if (classType.getContainerClass() != Type::VOID)
    {
        //If the class needs to be dereferenced (e.g. if classType is X.Y)
        //then we have to recursively call lookupClass several times to get
        //the symbol table of the container.
        SymbolTable* container = lookupClass(classType.getContainerClass())->child;
        return container->lookupClass(Type(Type::CLASS, className));
    }
    vector<symtab_entry*> result = lookup(className, Type(Type::TYPE, classType), true);
    assert(result.size() == 1);  //Classes can't be ambiguous
    return result[0];
}

pair<symtab_entry*, Type> SymbolTable::lookup(Name* name) {
    if (name->getQualifier() == 0)
    {
        //If it's just a simple name, do a regular lookup
        vector<symtab_entry*> result = lookup(name->getName());
        if (result.size() > 1) throw AmbiguousSymbol(name->getName());
        return make_pair(result[0], Type::VOID);
    }
    else {
        //First lookup the type of the LHS
        Type leftType = lookupType(name->getQualifier());
        
        if (leftType.isClassDefn()) 
        {
            //Now lookup the member on the RHS in the class on the LHS.
            //Return the LHS to be attached as the container class of the RHS
            Type classType = leftType.getReferredType();
            vector<symtab_entry*> result = lookupMemberGeneral(classType, name->getName());
            if (result.size() > 1) throw AmbiguousSymbol(name->getName());
            else if (result.size() == 0) throw SymbolNotFound(name->getName());
            else return make_pair(result[0], classType);
        }
        else
            throw NotClass(name->getQualifier()->getName());
    }
}

bool SymbolTable::hasSuperType(Type classType, Type superType, bool superClass) const {
    vector<Type> result = superClass? superClasses(classType) : superTypes(classType);
    for (vector<Type>::iterator i = result.begin(); i != result.end(); ++i)
    {
        if (*i == superType ||
            hasSuperType(*i, superType, superClass)) return true;
    }
    return false;
}

SymbolTable SymbolTable::allMembersOf(Type classType, bool giveErrors) {

/* The pseudocode for this algorithm is as follows.
 allMembersOf C
 
 for each superclass B of C
    for each member m in B
        if m is in C
            overloaded = true
            for each member m' with the same name as m in C
                if m or m' isn't a function
                    give a duplicate definition error
                    overloaded = false
                else if m' and m have matching definitions (overriding)
                    check that overriding is done correctly
                    overloaded = false
                if (overloaded) add m to the return value
        else if m is in the return value
            check that m and all the ones in the return value are overloaded functions.  If not, give the diamond inheritance error.
 
        else
            add m to the return value
 
 add all members of C to the return value, and return it.  (For each member, check that if it's a function case, it overrode something.)
 
*/

    SymbolTable retVal;

    const symtab_entry* classEntry = lookupClass(classType);
    const vector<Type>& superClasses = classEntry->superClasses;
    for (vector<Type>::const_iterator i = superClasses.begin(); i != superClasses.end(); ++i)
    {  //for each superclass
        SymbolTable result = allMembersOf(*i, false);
//        cout << "Symbol table for " << (*i).getClassName() << endl;  //DEBUG
//        result.print();  //DEBUG
        for (iterator j = result.begin(); j != result.end(); ++j)
        {  //for each member of the superclass
            string mName = (*j).first;
            Type mType = (*j).second.type;
            Node* mNode = (*j).second.pointOfDefnOrDecl;
            if (classEntry->child->existsThisScope(mName))
            {
                bool overloaded = true;
                
                vector<symtab_entry*> entriesNamedM = classEntry->child->lookup(mName, Type::VOID, false, true);
                for (vector<symtab_entry*>::iterator entry = entriesNamedM.begin(); entry != entriesNamedM.end(); ++entry)
                {

                    //Overriding - the entry in classEntry is overriding m
                    Type& typeInClass = (*entry)->type;  //Has to be a reference because we have
                        //to set the foundOverride flag for the Type stored in the symbol table.
                    Node* classNode = (*entry)->pointOfDefnOrDecl;
                    if (!typeInClass.isFunction() || !mType.isFunction())
                    {
                        if (giveErrors) compileError << linenum(classNode) << "Symbol `" << mName
                            << "' was already defined at line "
                            << CompileError::getLineInfo(mNode)
                            << "." << endl;
                        overloaded = false;
                    }
                    else if (mName == "this")  //Constructor - can't override anything
                    {}
                    else if (typeInClass.overrides(mType))
                    {
                        if (mType.hasFlag(Type::FINAL_FLAG))
                        {
                            if (giveErrors) compileError << linenum(classNode) << "Can't override `" << mName
                                << "' defined at " << CompileError::getLineInfo(mNode) 
                                << ", because it's declared final." << endl;
                        }
                        else if (!typeInClass.hasFlag(Type::CASE_FLAG))
                        {
                            if (giveErrors) compileError << linenum(classNode) << "Can't override `" << mName
                                << "' defined at line " << CompileError::getLineInfo(mNode)
                                << ", because the overriding function must be declared a function case." 
                                << endl;
                        }
                        else if (mType.hasFlag(Type::STATIC_FLAG))
                        {
                            if (giveErrors) compileError << linenum(classNode) << "Can't override function `" 
                                << mName << "' defined at line " << CompileError::getLineInfo(mNode) 
                                << " because it's static." << endl;
                        }
                        else if (!typeInClass.defnMatches(mType))
                        {
                            if (giveErrors) compileError << linenum(classNode) << "Overriding definition of `" << mName
                                << "' doesn't match the definition of the function it's overriding at line "
                                << CompileError::getLineInfo(mNode) << "." << endl;
                        }
                        //Remember that we've found a method that overrides the one in the current class
                        typeInClass.foundOverride();
                        overloaded = false;
                    }
                    
                }
                if (overloaded) retVal.insert(*j);  //Overloaded function
            }
            else 
            {
                //m is only in the super class, but it might have also been in other super classes.
                bool errorFound = false;
                for (iterator memberInOtherSuperclass = retVal.begin(); 
                    memberInOtherSuperclass != retVal.end(); ++ memberInOtherSuperclass)
                {
                    if (memberInOtherSuperclass->first == mName)
                    {
                        symtab_entry n = memberInOtherSuperclass->second;
                        if (!n.type.isOverloaded(mType) 
                            && n.pointOfDefnOrDecl != mNode  //This condition is needed for the case
                                //of diamond inheritance, where n and m are actually the same member
                                //in a common superclass.
                        )
                        {
                            errorFound = true;
                            
                            //If m was already found in another superclass, but not in the current class.
                            //This is the diamond inheritance problem
                            if (giveErrors) compileError << linenum(classEntry->pointOfDefnOrDecl)
                                << "Multiple inheritance error: member `" << mName
                                << "' is found in multiple superclasses (at line "
                                <<  CompileError::getLineInfo(mNode) << " and line "
                                <<  CompileError::getLineInfo(n.pointOfDefnOrDecl) << ").  ";
                            if (n.type.isFunction() && mType.isFunction())
                            {
                                if (giveErrors) compileError << "Functions can be disambiguated by providing a function case in the derived class.";
                            }
                            if (giveErrors) compileError << "\n";
                        }
                    }
                }
                if (!errorFound) retVal.insert(*j);  //Either it wasn't already in the return value,
                    //or only overloaded functions were found there.
            }
        }
    }
    
    for (iterator i = classEntry->child->begin(); i != classEntry->child->end(); ++i)
    {
        retVal.insert(*i);  //Add the member to the return value
    }
    
    return retVal;
}

void SymbolTable::checkOverrides(Type classType)
{
    const symtab_entry* classEntry = lookupClass(classType);
   
    //Check that there are no function cases left that didn't override anything
    for (iterator i = classEntry->child->begin(); i != classEntry->child->end(); ++i)
    {  //for each member in the current class
        Type t = (*i).second.type;
        if (t.isFunction() && t.hasFlag(Type::CASE_FLAG) && !t.overridesSomething())
        {
            Node* badNode = i->second.pointOfDefnOrDecl;
            compileError << linenum(badNode)
                << "A function case must override something.  `"
                << i->first << "' doesn't override anything." << endl;
        }
    }
}

void addChoice(vector<Type>* resultSoFar, const Type& t) {
    for (vector<Type>::iterator i = (*resultSoFar).begin(); i != (*resultSoFar).end(); ++i)
    {
        //Don't add t if it's similar to a type that's already there.  (E.g. same parameter
        //types but different return type or different qualifiers.)
        if ((*i).similarTo(t)) return;
    }
    resultSoFar->push_back(t);
}

Type SymbolTable::lookupMember(Type classType, string name, bool noSuper) const
{
    vector<symtab_entry*> result = lookupMemberGeneral(classType, name, noSuper);
    if (result.size() > 1)
        return ambTypeOf(result);
    else if (result.size() == 1)
        return result[0]->type;
    else
        return Type::VOID;
}

bool SymbolTable::hasConstructor(Type classType) const
{
    assert(classType.getType() == Type::CLASS);
    return lookupMember(classType, "this", true) != Type::VOID;
}

Type SymbolTable::lookupConstructor(Type classType) const
{
    assert(classType.getType() == Type::CLASS);
    return lookupMember(classType, "this", true);
}

bool SymbolTable::hasDefaultConstructor(Type classType) const
{
    vector<symtab_entry*> result = lookupMemberGeneral(classType, "this", true);
    for (vector<symtab_entry*>::const_iterator i = result.begin(); i != result.end(); ++i)
    {
        Type functionType((*i)->type);
        if (functionType.getType() == Type::FUNCTION && functionType.getParams().size() == 0)
        {
            return true;
        }
    }
    return false;
}

bool SymbolTable::isInstanceVar(Type classType, string name, Type type)
{
    vector<symtab_entry*> result = lookupMemberGeneral(classType, name);
    for (vector<symtab_entry*>::const_iterator i = result.begin(); i != result.end(); ++i)
    {
        if ((*i)->type == type) return (*i)->isInstanceVar;
    }
    throw SymbolNotFound(name);
}

bool SymbolTable::isInstanceVar(string name, Type type)
{
    vector<symtab_entry*> result = lookup(name, type);
    //Since we're looking up a member of a certain type, there
    //should't be multiple different ones.
    assert(result.size() == 1);
    return result[0]->isInstanceVar;
}

vector<symtab_entry*> SymbolTable::lookupMemberGeneral(Type classType, string name, bool noSuper) const
{
    //First check for the member in the current class.
    const symtab_entry* classEntry = lookupClass(classType);
    vector<symtab_entry*> resultSoFar;
    try {
        resultSoFar = classEntry->child->lookup(name, Type::VOID, false, true);
        //If found in the current class, we still need to look in superclasses, for 
        //the possibility of overloaded functions.

        if (noSuper) return resultSoFar;
    }
    catch (SymbolNotFound& e) {}
    
    //Look in the superclasses, and combine all the results into one result
    const vector<Type>& supers = classEntry->superClasses;
    for (vector<Type>::const_iterator i = supers.begin(); i != supers.end(); ++i)
    {
        vector<symtab_entry*> result = lookupMemberGeneral(*i, name);
        
        //Insert the entries in result into resultSoFar, but don't insert duplicates
        //(because then there would be an extraneous ambiguity error when trying to call
        //a function in a base class)
        for (vector<symtab_entry*>::iterator j = result.begin(); j != result.end(); ++j)
        {
            bool dontInsert = false;
            for (vector<symtab_entry*>::iterator k = resultSoFar.begin(); k != resultSoFar.end(); ++k)
            {
                if (*j == *k)
                {
                    dontInsert = true;
                    break;
                }
            }
            if (!dontInsert) resultSoFar.push_back(*j);
        }
    }

    return resultSoFar;

}

bool SymbolTable::sameTypes(Type t1, Type t2)
{
    if (t1 == t2) return true;
    
    if (globalScope())
    {
        return false;  //If we're in the global scope,
        //then the types can't possibly be the same usless they're ==.
    }
    
    const symtab_entry* curClass = currentClass();
    assert(curClass != 0);
    Type curClassType = curClass->type;
    curClassType = curClassType.getReferredType();
    Type c1 = t1.extractContainerClass(curClassType), c2 = t2.extractContainerClass(curClassType);
    if (t1 != t2) return false;  //base types have to be the same

    //By this point, at least one side must have a container class.
    //Otherwise, if they were equal, it would have returned true at the start,
    //and if they were unequal, it would have returned true in the previous
    //statement.

    //We have to do the recursive call from within the symbol table of the equal base types.
    string name = t1.getClassName();
    Type t(Type::TYPE, t1);
    vector<symtab_entry*> baseType = lookup(name, t);
    return baseType[0]->parent->scope->parent->sameTypes(c1, c2);
}

Access SymbolTable::lookupAccess(Type classType, string name, Type memberType) {
//    cout << "Looking up access for " << memberType << endl;  //DEBUG
    bool foundResult = false;
    Access retVal;
    vector<symtab_entry*> result = lookupMemberGeneral(classType, name);
    for (vector<symtab_entry*>::iterator i = result.begin(); i != result.end(); ++i)
    {
        if ((*i)->type == memberType)
        {
//            cout << linenum((*i)->pointOfDefnOrDecl) << endl;  //DEBUG
            retVal = (*i)->access;
            if (foundResult)
                //It shouldn't be possible for there to be multiple
                //members of the same type in the class when lookupAccess is called.
                //If there are, there should have been an error in CheckClasses, and
                //the compiler has a bug.
                throw AmbiguousSymbol(name);
            else 
                foundResult = true;
        }
    }
    if (foundResult) return retVal;
    else throw SymbolNotFound(name);
}

//***Print function***

void printBlocks(int indent, ostream& os) {
	for (int ind = 0; ind < indent; ++ind)
		os << "  ";  //2 spaces per indentation
}

string accessStr(Access a) {
    if (a == PUBLIC)
        return "public";
    else if (a == PROTECTED)
        return "protected";
    else if (a == PRIVATE)
        return "private";
    assert("Unknown access" == "");
    return "";
}

void SymbolTable::print(int depth, ostream& os, int indent) const {
	if (depth == 0) return;
	for (const_iterator i = begin();
		i != end(); ++i)
	{
		printBlocks(indent, os);
		
		os << accessStr(i->second.access) << " " << i->first << ": " << i->second.type;
        if (i->second.realName != "") os << " (realname: " << i->second.realName << ")";
        if (i->second.isDefn) os << " (Definition)";
		const SymbolTable* child = i->second.child;
		if (child != 0)
		{
			os << " {\n";
			child->print(depth - 1, os, indent + 1);
			printBlocks(indent, os);
			os << "}";
		}
		os << "\n";
	}
}

bool SymbolTable::hasPointer() const {
    //The symbol table is a map of pairs from a name to a symtab_entry,
    //the latter of which contains the type.
    //So just search each entry and check the type.
    for (const_iterator i = begin(); i != end(); ++i)
    {
        Type t = i->second.type;
        if (t.isPtr())
            return true;
    }
    return false;
}

SymbolTable symtable;

