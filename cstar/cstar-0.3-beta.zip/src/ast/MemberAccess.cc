#include "MemberAccess.h"
#include "Variable.h"
#include "Name.h"

Name* MemberAccess::convertToName() const {
    Variable* v = dynamic_cast<Variable*>(left);
    if (v != 0) return new Name(new Name(v->getName()), member);
    MemberAccess* m = dynamic_cast<MemberAccess*>(left);
    if (m != 0) return new Name(m->convertToName(), member);
    throw LeftNotClass();  //Something went wrong if a MemberAccess which is a type
        //has things other than variables and member accesses on the LHS
}
