#ifndef ABSTRACT_CALL_H
#define ABSTRACT_CALL_H

//A class for different kinds of calls 
//(function calls and constructor calls, and maybe others)

#include "Exprs.h"
#include "replace.h"
#include "MemberAccess.h"

class AbstractCall : public Expr {
protected:
	Exprs* args;  //Arguments to the call.
public:
	AbstractCall(Exprs* args)
    : args(args)
	{}
	
    AbstractCall(Expr* arg)
        : args(new Exprs())
    {
        args->add(arg);
    }
    
	virtual ~AbstractCall() {
		delete args;
	}
	Exprs*const getArgs() const { return args; }
	void setArgs(Exprs* newArgs) {
		replace(&args, newArgs);
	}
    
    Exprs* snipArgs() {
        Exprs* retVal = args;
        args = 0;
        return retVal;
    }
    
    /* Get the type of the thing being called (function type
    or constructor type).
    Before disambiguation, might be an ambiguous type.*/
    virtual Type calleeType() const = 0;
    virtual void setCalleeType(const Type& t) = 0;
    
    /** @return A string representation of the callee */
    virtual string getCalleeStr() const = 0;
    
	virtual Type getType() const {
		if (calleeType().getType() == Type::AMB)
			return Type::VOID;
        else if (!calleeType().isFunction())
            return Type::VOID;
		else return calleeType().getRetType();
	}
	
	/** Set which function the target is actually referring to,
	 * if it was ambiguous before.*/
	void disambiguate(const Type& t) 
    {
        setCalleeType(t);
    }

    /** If the callee is a MemberAccess, return it; otherwise, return 0. */
    virtual MemberAccess* getMemberAccess() const 
    { 
        return 0;
    }
#include "accept.h"
    
};

#endif
