#ifndef INITIALIZER_H
#define INITIALIZER_H

#include "Expr.h"

class Initializer : public AbstractCall {
private:
    Variable* name;
public:
    Initializer(Variable* name, Expr* value)
        : AbstractCall(value), name(name) {}
    ~Initializer() {
        delete name;
    }
    
    Variable*const getName() const { return name; }
    Expr*const getValue() const { return getArgs()->getExprs()[0]; }
    Type getType() const { return name->getType(); }
    virtual Type calleeType() const { return getType(); }
    virtual void setCalleeType(const Type& t) {
        assert("Shouldn't be called." == "");
    }
    virtual string getCalleeStr() const {
        return name->getName();
    }

#include "accept.h"
};

#endif
