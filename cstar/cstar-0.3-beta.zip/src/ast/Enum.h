#ifndef ENUM_H
#define ENUM_H

//Enumeration
//

#include "TypeDecl.h"
#include <vector>
#include <string>
using std::vector;
using std::string;

class Enum : public TypeDecl {
private:
	vector<string> enumerators;  //The choices in the enumeration
public:
//	Enum() : TypeDecl() {}
	const string& getName() { return name; }
	void add(const string& name) { enumerators.push_back(name); }
	void setName(const string& newName) { name = newName; }
#include "accept.h"
	const vector<string>& getEnumerators() { return enumerators; }
	void buildType() {
		setType(Type(Type::ENUM, enumerators));
	}

};

#endif

