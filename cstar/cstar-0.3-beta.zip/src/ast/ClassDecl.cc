#include "ClassDecl.h"
#include "SymbolTable.h"

bool ClassDecl::noDestructor(SymbolTable* currentSymTable) const
{ 
    assert(currentSymTable->inClass());
    return !currentSymTable->hasMember(currentSymTable->currentClassType(), "destruct");
}

bool isCopyConstructor(Type t, Type classType)
{
    if (t.getType() == Type::AMB)
    {
        const vector<Type>& list = t.getChoices();
        for (vector<Type>::const_iterator i = list.begin(); i != list.end(); ++i)
        {
            if (i->isCopyConstructor(classType)) return true;
        }
        return false;
    }
    else return t.isCopyConstructor(classType);
    
}

bool ClassDecl::hasCopyConstructor(SymbolTable* currentSymTable) const
{
    assert(currentSymTable->inClass());
    Type classType(currentSymTable->currentClassType());
    Type t = currentSymTable->lookupConstructor(classType);
    return isCopyConstructor(t, classType);
}

bool ClassDecl::hasAssignOperator(SymbolTable* currentSymTable) const
{
    assert(currentSymTable->inClass());
    Type classType(currentSymTable->currentClassType());

    Type t = currentSymTable->lookupMember(classType, "=");

    //We can check whether the function type found is a copy constructor,
    //because the parameter to the = operator must be the same as that for the
    //copy constructor.
    return isCopyConstructor(t, classType);
}

Type ClassDecl::getType() const {
    //Have to take virtual into account too
    Type t = TypeDecl::getType();
    if (m_isVirtual)
        t.setQuals(Type::VIRTUAL_FLAG);  //add the virtual flag
    return t;
}
