#ifndef RANGESUBSCRIPT_H_
#define RANGESUBSCRIPT_H_

#include "Expr.h"
#include "replace.h"

//An array slice, e.g.
//A[1..3]

class RangeSubscript : public Expr {
private:
	Expr* base;
	
	//The expression to the left and right of the ..
	//If, for example, left is null, it means the
	//expression was something like A[..3]
	//(beginning of array to 3)
	Expr* left;
	Expr* right;
public:
	Expr*const getBase() { return base; }
	Expr*const getLeft() { return left; }
	Expr*const getRight() { return right; }
	RangeSubscript(Expr* base, Expr* left, Expr* right) :
		base(base), left(left), right(right)
	{}
	void setLeft(Expr* l) {
		replace(&left, l);
	}
	void setRight(Expr* r) {
		replace(&right, r);
	}
	virtual ~RangeSubscript() {
		delete base;
		if (left != 0)
			delete left;
		if (right != 0)
			delete right;
	}
	virtual bool isLvalue() const {
		return true;
	}
	virtual Type getType() const
	{
		//TODO later: Typechecking here could be improved if
		//we inferred the type to be static sometimes.
		//However, this would require us to have RangeAssign
		//expressions, because otherwise
		//arr[1..5] := arr2[x..y]
		//, where x and y are variables, would fail typechecking.

		//You can't calculate the size of a range assignment
		//in general, because the ranges might be variables.
		Type baseType = base->getType().getBaseType();
#if 0
        bool isSArr = false;
        long leftVal, rightVal;
        if (base->getType().getType() == Type::ARRAY)
        {
            //Only if the base is a static array can the range subscript be static
            if ((left == 0 || left->isIntConst()) && (right == 0 || right->isIntConst()))
            {
                if (left == 0) leftVal = base->getType().li();
                else leftVal = left->getIntValue();
                if (right == 0) rightVal = base->getType().ui();
                else rightVal = right->getIntValue();
                isSArr = true;
            }
        }
        if (isSArr)
            return Type(baseType, rightVal-leftVal+1);
        else
#endif
            Type retVal = Type(Type::DARRAY, baseType, 0);
            if (base->getType().isConst()) {
                retVal.setQuals(Type::CONST_FLAG);
            }
            return retVal;
	}
#include "accept.h"

};

#endif /*RANGESUBSCRIPT_H_*/
