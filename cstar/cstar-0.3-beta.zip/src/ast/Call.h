#ifndef CALL_H_
#define CALL_H_

//function call

#include "AbstractCall.h"
#include "Variable.h"

class Call : public AbstractCall {
protected:
	Expr* name;  //The function being called (currently must be a Variable.
        //Later, first class functions are planned.)
public:
	Call(Expr* name, Exprs* args)
		: AbstractCall(args), name(name)
	{}

    Exprs* buildArgs(Expr* arg1, Expr* arg2) {
        Exprs* args = new Exprs();
        if (arg1 != 0) args->add(arg1);
		if (arg2 != 0) args->add(arg2);
        return args;
    }
    
	//Convenience constructor for constructing Binops and Unops
	Call(Expr* name, Expr* arg1 = 0, Expr* arg2 = 0)
		: AbstractCall(buildArgs(arg1, arg2)), name(name)
	{
	}
	virtual ~Call() {
		delete name;
	}
	Expr*const getName() const { return name; }

    Expr*const snipName() {
        Expr* retVal = name;
        name = 0;
        return retVal;
    }
	virtual bool isLvalue() const {
		return getType().hasFlag(Type::REF_FLAG);
	}
	
	/** Set which function the target is actually referring to,
	 * if it was ambiguous before.*/
	virtual void setCalleeType(const Type& t) {
		Reference* nameAsVar = dynamic_cast<Reference*>(name);
		assert(nameAsVar != 0);  //Only variables could possibly
			//be ambiguous because only a name could be referring to
			//multiple things of the same name
		nameAsVar->setType(t);
	}

    virtual Type calleeType() const {
        return name->getType();
    }
    
    virtual string getCalleeStr() const {
        Variable* v = dynamic_cast<Variable*>(name);
        if (v == 0) return "function";
        else return v->getName();
    }

    virtual MemberAccess* getMemberAccess() const
    {
        return dynamic_cast<MemberAccess*>(name);
    }

	friend class ArrayLiteralTransform;
#include "accept.h"
};

#endif /*CALL_H_*/
