#ifndef FUNCTION_H_
#define FUNCTION_H_

//Function definition (or declaration)

#include "Params.h"
#include "DeclOrDefn.h"
#include "Stmts.h"
#include "replace.h"
#include "TypeNode.h"
#include "opname.h"
#include <string>

using std::string;

class Function : public DeclOrDefn {
private:
	Type type;
	string name;  //Name of the function
	Params* params;  //Function parameters
	TypeNode* retType;  //Return type
	Stmts* body;  //If null, we have a declaration
    string realName;
    Type::Quals quals;  //Final or const specifications for class member functions
protected:
	void setType(const Type& that) { type = that; }
public:
    void setRealName(const string newRealName) {
        assert(realName == "");
        realName = newRealName;
    }
    string getRealName() const { return realName; }
	Type getType() const { return type; }
	virtual ~Function() {
		delete params;
		if (body != 0)
			delete body;
		if (retType != 0)
			delete retType;
	}
	Function(string name, Params* params, TypeNode* retType, Type::Quals newQuals = Type::NO_FLAG, bool isCase = false) :
		name(name), params(params), retType(retType), body(0), realName("")
    {
        quals = newQuals;
        if (isCase) {
            quals = Type::Quals(quals | Type::CASE_FLAG);
        }
//        cout << "In function.h for " << name << " with quals " << quals << endl;  //DEBUG
	}

	virtual string getName() { return name; }
	virtual Params*const getParams() { return params; }
	virtual TypeNode*const getRetTypeNode() const { return retType; }
	virtual Type getRetType() 
	{ 
		if (retType == 0) return Type::VOID;
		else return retType->getType(); 
	}
	virtual Stmts*const getBody() { return body; }
	
	/** Check that all parameters of the function have a name.
	 * Function declarations are allowed to omit the name, but
	 * definitions must include it.*/
	virtual void checkAllParamsNamed();
	
	/** Construct and set the type of the function from the
	 * types of its components.*/
	virtual void buildType();
	virtual void setBody(Stmts* newBody) { replace(&body, newBody); } 
	virtual bool isMain() const {
		return name == "main";
	}
    
    /**@return Whether this function is the main 
    method and takes command-line arguments (properly).*/
	virtual bool isMainWithArgs() const;
    
    virtual bool isFinal() const { return getType().hasFlag(Type::FINAL_FLAG); }
    virtual bool isConst() const { return getType().hasFlag(Type::CONST_FLAG); }
    virtual bool isStatic() const { return getType().hasFlag(Type::STATIC_FLAG); }
    virtual bool isVirtual() const { return getType().hasFlag(Type::VIRTUAL_FLAG); }
    virtual bool isFriend() const { return getType().hasFlag(Type::FRIEND_FLAG); }

    virtual bool hasVirtualFlag() const { return (quals & Type::VIRTUAL_FLAG) == Type::VIRTUAL_FLAG; }

    /** Make the function static. */
    void setStatic();
    
    /** Set the friend class of the function to classType */
    void setFriend(Type classType);

    /** @return Whether the function is an operator. */
    bool isOper() const;
#include "accept.h"
};

#endif /*FUNCTION_H_*/
