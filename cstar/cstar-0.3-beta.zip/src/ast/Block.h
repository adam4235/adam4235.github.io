#ifndef BLOCK_H_
#define BLOCK_H_

//Block of statements within {}

#include "Stmts.h"

class Block : public Stmt {
private:
	string label;  //Used to be able to refer to the block	
		//within the symbol table
	Stmts* stmts;
public:
	Block(Stmts* stmts) : label(""), stmts(stmts) {}
	
	/** Construct a block containing one statement, stmt */
	Block(Stmt* stmt) {
        label = "";
		stmts = new Stmts();
		stmts->add(stmt);
	}
	
	virtual const string& getLabel() const { return label; }
	virtual void setLabel(const string& l) { label = l; }

	virtual ~Block() {
		delete stmts;
	}
	
	Stmts*const getStmts() { return stmts; }
#include "accept.h"
};

#endif /*BLOCK_H_*/
