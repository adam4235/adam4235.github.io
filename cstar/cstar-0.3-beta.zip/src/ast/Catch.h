#ifndef CATCH_H
#define CATCH_H

//Catch statement

#include "Stmt.h"
#include "Param.h"

class Catch : public Stmt {
private:
    Param* parameter;    //The exception being caught.  If 0, it means catch(...).
    Stmt* block;   //The statements in the catch block.
public:
    Catch(Param* parameter, Stmt* block)
        : parameter(parameter), block(block) {}
    virtual ~Catch()
    {
        if (parameter != 0) delete parameter;
        delete block;
    }
    Param*const getParameter() const { return parameter; }
    Stmt*const getBlock() const { return block; }
#include "accept.h"
};

#endif
