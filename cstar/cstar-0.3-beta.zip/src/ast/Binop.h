#ifndef BINOP_H_
#define BINOP_H_

//Binary operation (*, +, etc.)
//Includes user-defined binary operators, as well as "and", etc.

#include "Call.h"
#include "Variable.h"
#include <string>

using std::string;

class Binop : public Call {
public:
	Binop(const string& oper, Expr* left, Expr* right) :
		Call(new Variable(oper), left, right) 
	{
	}
	
	Expr*const getLeft() const { return getArgs()->getExprs()[0]; }
	Expr*const getRight() const { return getArgs()->getExprs()[1]; }
	Expr* snipLeft() { 
		return args->snipValue(0);
	}
	Expr* snipRight() { 
		return args->snipValue(1);
	}

	void setRightNoDelete(Expr* newRight) {
		args->exprs[1] = newRight;
	}
	string getOper() const { 
		Variable* oper = dynamic_cast<Variable*>(name);
		assert(oper != 0);
		return oper->getName();
	}
	void setFunType(const Type& t) {
		Reference* oper = dynamic_cast<Reference*>(name);
		assert(oper != 0);
		oper->setType(t);
	}

    /**@return Whether it's an == or != for enum types.
    */
    bool isEnumEquality() const;
        
    /**@return Whether it's an == or != for pointer types.*/
    bool isPtrEquality() const;
        
    /** Disambiguate == and !=, 
    which aren't in the symbol table for pointer types and enum types. */
    void disambiguate();
        
    virtual Type getType() const {
        //Enum == and != operators aren't in the symbol table,
        //so have to return bool for them in a special case.
        if (isEnumEquality() || isPtrEquality()) { return Type::BOOL; }
        else return Call::getType();
    }
    
#include "accept.h"
	
};

#endif /*BINOP_H_*/
