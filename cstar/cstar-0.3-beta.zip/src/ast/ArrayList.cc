#include "ArrayList.h"
#include "ArrayRange.h"

void ArrayList::setSize() {
	size_t size = 0;
	const vector<Expr*> & list = getValues()->getExprs();
	for (vector<Expr*>::const_iterator i = list.begin();
		i != list.end(); ++i)
	{
		//The size of values in array literals should always be known
		//(expressions have size 1, and only constants are allowed
		//in X..Y)
		ArrayRange* iAsRange = dynamic_cast<ArrayRange*>(*i);
		if (iAsRange == 0)
			++size;
		else
		{
			const Type& newType = (*i)->getType();
			size += newType.size();  //remember that i might
				//be a range of values (e.g. 1..10)
		}
		
	}
	setType(Type(Type(Type::VOID), size));
}

bool ArrayList::containsNonConsts() const {
	const vector<Expr*>& list = getValues()->getExprs();
	for (vector<Expr*>::const_iterator i = list.begin(); i != list.end(); ++i)
	{
		ArrayRange* iAsRange = dynamic_cast<ArrayRange*>(*i);
		if (iAsRange != 0)
		{
            //Array ranges (e.g. [1..100]) are constant if the beginning
            //and ending are constant.
			if (!iAsRange->getLeft()->isRealConst() ||
				!iAsRange->getRight()->isRealConst())
			{
				return true;
			}
		}
		else if (!(*i)->isRealConst())
			return true;
	}
	return false;
}

