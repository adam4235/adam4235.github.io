#ifndef DECLLIST_H_
#define DECLLIST_H_

//List of top-level declarations

#include <vector>
#include "DeclOrDefn.h"

using std::vector;

class DeclList : public Node {
private:
	vector<DeclOrDefn*> decls;
public:
//	DeclList() {}
	virtual ~DeclList() {
		for (vector<DeclOrDefn*>::iterator i = decls.begin(); 
			i != decls.end(); ++i)
		{
			DeclOrDefn* d = *i;
			delete d;
		}
	}
	virtual void add(DeclOrDefn* d) { decls.push_back(d); }
	virtual const vector<DeclOrDefn*> & getDecls() { return decls; }

#include "accept.h"

};

#endif /*DECLLIST_H_*/
