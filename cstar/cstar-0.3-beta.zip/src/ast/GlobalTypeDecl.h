#ifndef GLOBAL_TYPE_DECL_H
#define GLOBAL_TYPE_DECL_H

//A type declaration appearing in the global scope
//Like GlobalVarDecls but for types

#include "DeclOrDefn.h"
#include "TypeDecl.h"

class GlobalTypeDecl : public DeclOrDefn {
private:
	TypeDecl* typeDecl;
public:
	GlobalTypeDecl(TypeDecl* typeDecl) : typeDecl(typeDecl) {}
	TypeDecl*const getTypeDecl() { return typeDecl; }
	virtual ~GlobalTypeDecl() {
		delete typeDecl;
	}
#include "accept.h"
};

#endif

