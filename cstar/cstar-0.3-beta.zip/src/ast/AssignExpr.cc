#include "AssignExpr.h"
#include "RangeSubscript.h"

void AssignExpr::disambiguate()
{
    vector<Type> params;
    Type leftType(getLeft()->getType());
    params.push_back(leftType);
    params.push_back(getRight()->getType());
    Call::disambiguate(Type(Type::FUNCTION, params, leftType));  //The return 
        //type of := is the type of the LHS
}

bool AssignExpr::isRangeAssign() const {
    return getOper() == "=" && dynamic_cast<RangeSubscript*>(getLeft()) != 0;
}

bool AssignExpr::isArrayEqualsScalar(SymbolTable* currentSymTable) const {
    RangeSubscript* lhs = dynamic_cast<RangeSubscript*>(getLeft());
    if (lhs == 0) 
        return false;
    else
        return getRight()->getType().isSubType(lhs->getBase()->getType().getBaseType(), currentSymTable);
}
