#ifndef THIS_EXPR_H
#define THIS_EXPR_H

/*
 * Use of "this".
 */

#include "Expr.h"

class ThisExpr : public Expr {
private:
    Type type;
public:
    ThisExpr() 
        : type(Type::VOID) {}
    
    virtual ~ThisExpr() {}
    
    virtual Type getType() const { return type; }
    virtual void setType(const Type& newType) { 
        //A this is a const pointer to the type of the class
        //it's found in.
        type = Type(Type::CONST_PTR, newType); }
#include "accept.h"
};

#endif
