#ifndef NAME_H
#define NAME_H

//A name, possibly qualified with a dot-separated name on the left.

#include "Node.h"
#include <string>

using namespace std;

class Name : public Node {
private:
    Name* qualifier;  //The LHS of the dot
    string name;   //The RHS of the dot
public:
    Name(Name* qualifier, string name) 
        : qualifier(qualifier), name(name) {}
    Name(string name)
        : qualifier(0), name(name) {}
    virtual ~Name() {
        if (qualifier != 0) delete qualifier;
    }
    
    //Needed by UserTypeNode to be able to copy a Name.
    virtual Name* copy() {
        if (qualifier == 0)
            return new Name(name);
        else
            return new Name(qualifier->copy(), name);
    }
    
    Name*const getQualifier() const { return qualifier; }
    string getName() const { return name; }
    
    friend ostream& operator<<(ostream& os, const Name& n)
    {
        if (n.qualifier != 0)
        {
            os << *n.qualifier << ".";  //recursively output the LHS
        }
        os << n.name;
        return os;
    }

#include "accept.h"
};

#endif
