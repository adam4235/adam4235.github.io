#ifndef ASSIGNEXPR_H_
#define ASSIGNEXPR_H_

//Assignment expression (:=, +=, etc.)

#include "Binop.h"

class AssignExpr : public Binop {
public:
	
	AssignExpr(string oper, Expr* lhs, Expr* rhs)
		: Binop(oper, lhs, rhs)
	{}
	
#include "accept.h"
	
	/**@return true iff the binop is an assignment with an array on the
	 * left */
	bool isRangeAssign() const;
    
    /**@return Whether the LHS is an array of the type
        of the LHS (which means assign all the elements of the
        array the value in the RHS)*/
	bool isArrayEqualsScalar(SymbolTable* currentSymTable) const;
    
    //Set the type of the =.
    //This has to be done specially because = isn't in the symbol table.
    virtual void disambiguate();
    
	virtual Type getType() const {
		//The type of a X := Y is the type of X
		return getLeft()->getType();
	}
};

#endif /*ASSIGNEXPR_H_*/
