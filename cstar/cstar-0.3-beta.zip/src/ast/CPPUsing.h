#ifndef CPP_USING_H
#define CPP_USING_H

#include "CPPElement.h"

class CPPUsing : public CPPElement {
private:
	string thingUsing;  //The name the "using" directive refers to
	bool isNamespace;  //Whether it's a "using namespace"
public:
#include "accept.h"
	CPPUsing(const string& thingUsing)
		: thingUsing(thingUsing), isNamespace(false) {}
	virtual ~CPPUsing() {
	}
	string getThingUsing() const { return thingUsing; }
	bool getIsNamespace() const { return isNamespace; }
	void append(string s) {
		thingUsing += "::" + s;
	}
	void setNamespace() {
		isNamespace = true;
	}

};

#endif

