#ifndef VARDECL_H_
#define VARDECL_H_

//Declaration of a variable.
//This class only contains a type and a single name,
//and an optional initial expression.  A declaration of
//several variables in one statement is handled by the DeclStmt
//node.

#include <string>
#include "Expr.h"
#include "replace.h"
#include "SArrayTypeNode.h"

class VarDecl : public Node {
private:
	TypeNode* type;  //Type of the declaration
	string name;  //Name of the declaration
	Expr* initVal;  //Initial value (optional)
    bool m_isInstanceVar;  //True iff it's an instance variable
public:
	VarDecl(TypeNode* t, string name, Expr* initVal = 0) 
		: type(t), name(name), initVal(initVal), m_isInstanceVar(false) {}

	virtual ~VarDecl() {
		delete type;
		if (initVal != 0) delete initVal;
	}

	TypeNode*const getTypeNode() const { return type; }
	string getName() const { return name; }
	Expr*const getInitVal() const { return initVal; }
	Expr*const snipInitVal() {
		Expr* retVal = initVal;
		initVal = 0;
		return retVal;
	}

	Type getType() const { return type->getType(); }

	void setTypeNodeNoDelete(TypeNode* typeNode) { type = typeNode; }
	void setInitExprNoDelete(Expr* newInitVal) { initVal = newInitVal; }
	
	virtual void setInitExpr(Expr* newInitVal) {
		replace(&initVal, newInitVal);
	}
    
    bool isInstanceVar() const { return m_isInstanceVar; }
    void setInstanceVar() { m_isInstanceVar = true; }

    //Whether the variable is referring to a virtual class.
    bool isVirtual() const;
    
    //Whether the variable was declared with the virtual flag (which isn't allowed).
    bool declaredVirtual() const;
    
    /** Make the declaration static.*/
    void setStatic();
    
	friend class TypeChecker;
#include "accept.h"
};

#endif
