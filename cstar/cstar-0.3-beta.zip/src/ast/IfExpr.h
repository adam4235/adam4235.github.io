#ifndef IF_EXPR_H
#define IF_EXPR_H

//A conditional expression
//E.g. int x := if (y == 1) 0 else y;

#include "Expr.h"

class IfExpr : public Expr {
private:
	Expr* ifCond;
	Expr* ifPart;
	Expr* elsePart;
    SymbolTable* currentSymTable;  //The symbol table where the if is
        //found, which is needed to compute its type (since class types might
        //need to be looked up).
public:
#include "accept.h"
	IfExpr(Expr* ifCond, Expr* ifPart, Expr* elsePart) 
		: ifCond(ifCond), ifPart(ifPart), elsePart(elsePart) {}

	virtual ~IfExpr() {
		delete ifCond;
		delete ifPart;
		delete elsePart;
	}

	Expr*const getIfCond() const { return ifCond; }
	Expr*const getIfPart() const { return ifPart; }
	Expr*const getElsePart() const { return elsePart; }

    void setSymTable(SymbolTable* s) { currentSymTable = s; }
    
	virtual Type getType() const {
		//The type of the if-else is the most general type
		//of the 2 possible expressions
		Type t1 = ifPart->getType(), t2 = elsePart->getType();
		return t1.mostGeneral(t2, currentSymTable);
	}
};

#endif

