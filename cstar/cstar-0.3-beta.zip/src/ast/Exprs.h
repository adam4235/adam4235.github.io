#ifndef EXPRS_H_
#define EXPRS_H_

/*A list of expressions.
 */
 
#include <vector>
#include "Expr.h"

using std::vector;

class Exprs : public Node {
private:
	vector<Expr*> exprs;	
public:
	size_t size() const { return exprs.size(); }
	virtual const vector<Expr*>& getExprs() { return exprs; }
    
    /** Removes the value at index i of the array of expressions
    and returns it.  (A null value is left behind; the array doesn't change size)*/
	virtual Expr* snipValue(vector<Expr*>::size_type i) {
		Expr* retVal = exprs[i];
		exprs[i] = 0;
		return retVal;
	}
	Exprs() {}
	virtual void add(Expr* e) { exprs.push_back(e); }
    void setNoDelete(size_t i, Expr* value) {
        exprs[i] = value;
    }
	virtual ~Exprs() {
		for (vector<Expr*>::iterator i = exprs.begin(); 
			i != exprs.end(); ++i)
		{
			delete *i;
		}
	}
    
	friend class ArrayLiteralTransform;
	friend class Binop;
	friend class TypeChecker;
#include "accept.h"
};

#endif /*EXPRS_H_*/
