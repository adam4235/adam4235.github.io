#ifndef REAL_CPP_ARRAY_h
#define REAL_CPP_ARRAY_h

//A compiler-generated node representing an array that
//should be translated as a C++ array, rather than one 
//of class carray

#include "SArrayTypeNode.h"

class RealCPPArray : public SArrayTypeNode {
public:
	RealCPPArray(TypeNode* base, size_t size) 
		: SArrayTypeNode(base, size) {}
#include "accept.h"
};

#endif

