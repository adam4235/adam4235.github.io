#ifndef PROGRAM_H
#define PROGRAM_H

//A node for the whole program

#include "DeclList.h"

class Program : public Node {
private:
    DeclList* top;
public:
    virtual ~Program() {
        delete top;
    }
    Program(DeclList* top) 
        : top(top) {}
    
	virtual void onAccept() {
		//Prevent future visitor passes from being run when an error
		//has occurred.
		if (errorFound) throw compileError;
	}
#include "accept.h"
    
};

#endif
