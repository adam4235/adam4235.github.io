#ifndef DESTRUCTOR_H
#define DESTRUCTOR_H

//Destructor definition (or declaration) of a class

#include "Function.h"

class Destructor : public Function {
public:
    Destructor(Params* params) : Function("destruct", params, 0) {}
    virtual ~Destructor() {}
#include "accept.h"    
};

#endif
