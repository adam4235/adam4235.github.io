#ifndef CLASSDECL_H
#define CLASSDECL_H

/*
 * A class declaration or definition.
 */

#include "TypeDecl.h"
#include "SuperClass.h"
#include "DeclList.h"

class ClassDecl : public TypeDecl {
private:
    vector<SuperClass*> superClasses;  //Superclasses
    DeclList* body;  //Members
    bool m_isImpl;  //Whether the class body is an implementation
        //(2nd class body, which can only contain definitions of
        //things merely declared).
    
    bool m_isVirtual;  //Whether the class is virtual (can't be instantiated).
        //A class is virtual if it contains any virtual methods.

    bool m_isNameSpace;  //True if it's a namespace definition
public:
    ClassDecl(bool m_isNameSpace = false)
        : TypeDecl(), superClasses(vector<SuperClass*>()), body(0), m_isImpl(false), m_isNameSpace(m_isNameSpace)
    {}
    
    virtual ~ClassDecl() {
        delete body;
        for (vector<SuperClass*>::iterator i = superClasses.begin();
             i != superClasses.end(); ++i)
        {
            delete *i;
        }
    }
    
    const vector<SuperClass*>& getSuperClasses() const { return superClasses; }
    DeclList*const getBody() const { return body; }
    
    virtual void addSuperClass(SuperClass* n) {
        superClasses.push_back(n);
    }
    virtual void setName(char* newName) {
        name = string(newName);
    }
    virtual void setBody(DeclList* newBody) {
        body = newBody;
    }
    void buildType() {
		setType(Type(Type::CLASS, name));
	}
    
    Type getType() const;
        
    /**@return True iff the class doesn't contain a user-defined destructor.
    If not, we have to generate a virtual destructor that does nothing,
    because all inheritance is virtual so proper cleanup of the vptr to the base
    class may need to be done.
    @param currentSymTable The current symbol table in which to look for a destructor.*/
    virtual bool noDestructor(SymbolTable* currentSymTable) const;
    
    /**@return True iff the class contains a copy constructor. */
    virtual bool hasCopyConstructor(SymbolTable* currentSymTable) const;
    
    /**@return True iff the class contains an assignment operator that
    copies the object.*/
    virtual bool hasAssignOperator(SymbolTable* currentSymTable) const;

    bool isImpl() const { return m_isImpl; }
    void setImpl() { m_isImpl = true; }
    
    bool isVirtual() const { return m_isVirtual; }
    void setVirtual() { m_isVirtual = true; }

    bool isNameSpace() const { return m_isNameSpace; }
friend class FixSupertypes;
#include "accept.h"
};

#endif
