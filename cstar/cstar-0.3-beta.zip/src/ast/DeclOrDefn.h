#ifndef DECLORDEFN_H_
#define DECLORDEFN_H_

//Node representing any top-level declaration (function, class, etc.)

#include "Node.h"

class DeclOrDefn : public Node {
public:
#include "accept.h"
};

#endif /*DECLORDEFN_H_*/
