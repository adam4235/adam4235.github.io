#include "Binop.h"

void Binop::disambiguate()
{
    vector<Type> params;
    params.push_back(getLeft()->getType());
    params.push_back(getRight()->getType());
    Call::disambiguate(Type(Type::FUNCTION, params, Type::BOOL));  //== and != always return a bool.
}

bool Binop::isEnumEquality() const {
    const Type& type1 = getLeft()->getType().stripRef(),
    type2 = getRight()->getType().stripRef();
    
    if (getOper() == "==" || getOper() == "!=")
    {
        if ((type1.isEnumVal() && type2.isEnumVal()) && 
            (type1.isSubType(type1, 0) || type2.isSubType(type2, 0)))
        {
            //Enums must have == and != operators, but they
            //can't be added to the symbol table because that would
            //cause the other == and != operators to be shadowed.
            return true;
        }
    }
    return false;
}

bool Binop::isPtrEquality() const {
    const Type& type1 = getLeft()->getType().stripRef(),
    type2 = getRight()->getType().stripRef();
    if (getOper() == "==" || getOper() == "!=")
    {
        if (type1.isPtrVal() && type2.isPtrVal()) return true;
    }
    return false;
}
