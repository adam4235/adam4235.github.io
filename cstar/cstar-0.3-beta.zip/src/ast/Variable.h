#ifndef VARIABLE_H_
#define VARIABLE_H_

//A reference to a variable 
//(including the name of a function in a call)

#include <string>
#include "Reference.h"
#include "Name.h"

using std::string;

class Variable : public Reference {
private:
	string name;
public:
	Variable(string name) 
		: Reference(Type::VOID), name(name) {}
	Variable(char* name) 
		: Reference(Type::VOID), name(string(name)) {}

	/** Compiler-generated AST nodes should use the following
	 * constructor, because they must give a type to the
	 * variable.*/
	Variable(string name, Type type) 
		: Reference(type), name(name) {}

	virtual ~Variable() {} 

	string getName() const { return name; }

    virtual Name* convertToName() const { return new Name(getName()); }

#include "accept.h"
};

#endif /*VARIABLE_H_*/
