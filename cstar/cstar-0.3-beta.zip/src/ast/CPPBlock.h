#ifndef CPPBLOCK_H
#define CPPBLOCK_H

//A block of C++ declarations and includes, for compatability.

#include "DeclList.h"
#include "CPPElement.h"

class CPPBlock : public CPPElement {
private:
	DeclList* decls;
public:
#include "accept.h"

	CPPBlock(DeclList* decls)
		: decls(decls) {}
	virtual ~CPPBlock() {
		delete decls;
	}
	DeclList*const getDecls() const { return decls; }
};

#endif

