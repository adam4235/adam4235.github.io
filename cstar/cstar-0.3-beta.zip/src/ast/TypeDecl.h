#ifndef TYPE_DECL_H
#define TYPE_DECL_H

//A type declaration (enum, class, etc.)

#include "Decls.h"

class TypeDecl : public Node {
private:
	Type type;  //Type of the declaration
	Decls* initVariables;  //All type declarations can optionally have a
		//list of variables of that type following the type declaration.
protected:
	void setType(const Type& that) { type = that; }
	string name;  //All type declarations need a name, even if it's made up.
public:
	const string& getName() const { return name; }
	virtual Type getType() const { return type; }
	TypeDecl() : Node(), name("") {
		initVariables = new Decls();
	}
	virtual ~TypeDecl() {
		assert(initVariables != 0);
		delete initVariables;
	}
	Decls*const getDecls() { return initVariables; }
	void setDecls(Decls* decls) {
		replace(&initVariables, decls); 
	}
#include "accept.h"
};

#endif

