#ifndef ARRAYLIST_H_
#define ARRAYLIST_H_

//List of values having type array.
//E.g. [1, 2, 3].

#include "Exprs.h"

class ArrayList : public Expr {
private:
	Exprs* values;   //The values in the list
	Type type;  //The type that has been calculated
	bool m_isCPPInitializer;  //True if the array list is
		//now a C++ array initializer, which means it
		//doesn't need further processing in visit/ArrayTransform.
public:
	/** Compiler-generated AST nodes should pass a type.*/
	ArrayList(Exprs* values, Type type = Type::VOID) 
		: values(values), type(type), m_isCPPInitializer(false) {}

	virtual ~ArrayList() {
		delete values;
	}
	Exprs*const getValues() const { return values; }

	/* Set the size of the list (in the Type) by counting
	 * the values in the list */
	void setSize();
    
    /** @return Whether the array list contains elements that aren't
        constant (which is significant because C++ doesn't allow those
        types of arrays) */
	bool containsNonConsts() const;
    
	virtual Type getType() const {
//		assert(type != Type::VOID);  //Make sure the type has been set
		return type;
	}
	virtual long getSize() const {
		return type.size();
	}
	virtual void setType(const Type& newType) { type = newType; }
	void makeCPPInitializer() { m_isCPPInitializer = true; }
	bool isCPPInitializer() const { return m_isCPPInitializer; }
#include "accept.h"
};

#endif /*ARRAYLIST_H_*/
