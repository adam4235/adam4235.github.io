#ifndef SUPERCLASS_H
#define SUPERCLASS_H

/*
 * The name of a superclass in the header of a class declaration.
 */

#include "TypeNode.h"
#include "UserTypeNode.h"
#include "Name.h"

class SuperClass : public Node {
public:
    enum Kind {
        EXTENDS, SUBTYPE_OP, IMPLICIT};
private:
    //Whether it was declared with <:, extends, or within
    //a list of multiple superclasses (e.g. the Z in class X <: Y, Z).
    Kind kind;
    
    //A TypeNode storing the type of the superclass
    TypeNode* superClass;
public:
    SuperClass(TypeNode* superClass, Kind kind)
        : kind(kind), superClass(superClass)
    {}
    virtual ~SuperClass() {
        delete superClass;
    }
    
    Name* getName() {
        UserTypeNode* tn = dynamic_cast<UserTypeNode*>(superClass);
        assert(tn != 0);
        return tn->getName();
    }
    Kind getKind() const { return kind; }
    void setKind(Kind newKind) { kind = newKind; }
    TypeNode*const getSuperClass() const { return superClass; }
#include "accept.h"
};

#endif
