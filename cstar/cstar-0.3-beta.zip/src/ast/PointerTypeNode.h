#ifndef POINTER_TYPE_NODE_H
#define POINTER_TYPE_NODE_H

//The AST for the type in a pointer declaration

#include "ContainerTypeNode.h"

class PointerTypeNode : public ContainerTypeNode {
private:
	Type::Quals ptr_quals;  //The qualifiers of the pointer itself
		//(rather than the qualifiers of the thing the pointer is
		//pointing at)
public:
	virtual TypeNode* copy() const 
	{
		return new PointerTypeNode(base, ptr_quals);
	}
	PointerTypeNode(TypeNode* base, Type::Quals ptr_quals)
		: ContainerTypeNode(base), ptr_quals(ptr_quals)
	{
	}

	virtual const TypeNode* checkPtr() const {
		if (dynamic_cast<SArrayTypeNode*>(base) != 0) return base;  //Can't
			//have a pointer to a static array.
		else return base->checkDimsWithInitval();
	}

	Type getTypeWoQuals() const {
		return Type((ptr_quals == Type::CONST_FLAG)? Type::CONST_PTR : Type::PTR, baseType());
	}
#include "accept.h"
};

#endif

