#ifndef ACCESS_SPEC_H
#define ACCESS_SPEC_H

/*
 * An access specifier declaration within a class body
 */

#include "DeclOrDefn.h"

#include "access.h"

class AccessSpec : public DeclOrDefn {
private:
    Access kind;
public:
    AccessSpec(Access kind)
        : kind(kind)
    {}
    Access getAccess() const { return kind; }
    
#include "accept.h"
};

#endif
