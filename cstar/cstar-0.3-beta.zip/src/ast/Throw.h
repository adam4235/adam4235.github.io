#ifndef THROW_H
#define THROW_H

//Throw statement

#include "Stmt.h"
#include "Expr.h"

class Throw : public Stmt {
private:
    Expr* toThrow;  //Throw expression.  If 0, it's a throw within a catch
                    //meaning re-throw the caught exception.
public:
    Throw(Expr* toThrow) 
        : toThrow(toThrow) {}
    virtual ~Throw() {
        if (toThrow != 0) delete toThrow;
    }
    
    Expr*const getToThrow() const { return toThrow; }
#include "accept.h"
};

#endif
