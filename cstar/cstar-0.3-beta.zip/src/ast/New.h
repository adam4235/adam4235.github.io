#ifndef NEW_H
#define NEW_H

//A new expression
//	-Can't new or delete arrays (dynamic arrays are meant to avoid that)

#include "Expr.h"
#include "TypeNode.h"
#include "Exprs.h"

class New : public Expr {
private:
	TypeNode* typeNode;
	Exprs* args;
public:
#include "accept.h"
	TypeNode*const getTypeNode() const { return typeNode; }
	Exprs*const getArgs() const { return args; }
	New(TypeNode* typeNode, Exprs* args) 
		: typeNode(typeNode), args(args) {}

	virtual ~New() {
		delete typeNode;
		delete args;
	}

	virtual Type getType() const {
		//Can't change a new expression, so it's constant
		return constOf(Type(Type::PTR, typeNode->getType()));
	}
	void setTypeNodeNoDelete(TypeNode* newTypeNode) { typeNode = newTypeNode; }
	friend class TypeChecker;
};

#endif

