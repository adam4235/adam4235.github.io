#ifndef IF_H
#define IF_H

//If-else block

#include "Expr.h"
#include "Stmt.h"

class If : public Stmt {
private:
	Expr* cond;
	Stmt* ifPart;
	Stmt* elsePart;
public:
	If(Expr* cond, Stmt* ifPart, Stmt* elsePart)
		: cond(cond), ifPart(ifPart), elsePart(elsePart)
	{}
	virtual Expr*const getCond() const { return cond; }
	virtual Stmt*const getIf() const { return ifPart; }
	virtual Stmt*const getElse() const { return elsePart; }
	virtual ~If() {
		delete cond;
		delete ifPart;
		if (elsePart != 0)
			delete elsePart;
	}
#include "accept.h"

};

#endif

