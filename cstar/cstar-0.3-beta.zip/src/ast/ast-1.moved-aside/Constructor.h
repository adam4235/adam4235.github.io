/*
 *  Constructor.h
 *  cstar_xcode
 *
 *  Created by Adam Richard on 12/08/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

