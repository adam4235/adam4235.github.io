#include "Function.h"
#include "error.h"
#include "opname.h"

using namespace std;

void Function::checkAllParamsNamed() {
	const vector<Param*>& list = params->getParams();
	for (vector<Param*>::const_iterator i = list.begin(); i != list.end(); ++i)
	{
		if ((*i)->getName() == "")
		{
			compileError << linenum(*i) << "Parameter must be given a name." << endl;
		}
	}
}

void Function::buildType() {
	vector<Type> params;
	
	//We must get extract the parameters of the function because they're part 
	//of the type
	//of the function, to be stored in the Type structure
	const vector<Param*>& list = getParams()->getParams(); 
	for (vector<Param*>::const_iterator i = list.begin(); i != list.end(); ++i)
	{
	//for each parameter
		params.push_back(Type((*i)->getType()));
	}

	Type newType = Type(Type::FUNCTION, params, getRetType());
    newType.setQuals(quals);
    
    setType(newType);
}

void Function::setFriend(Type classType) {
    Type t = getType();
    t.setFriend(classType);
    setType(t);
}

bool Function::isMainWithArgs() const
{
    if (!isMain()) return false;

    Type t = getType();
    
    //Check that t is a function taking char[][]
    if (t.getParams().size() != 1) return false;
    t = t.getParams()[0];
    if (!t.isArray()) return false;
    t = t.getBaseType();
    if (!t.isArray()) return false;
    t = t.getBaseType();
    return t.getType() == Type::CHAR;
}

void Function::setStatic()
{
    quals = Type::Quals(quals | Type::STATIC_FLAG);
}

bool Function::isOper() const {
    return findOpName(name) != name;
}
