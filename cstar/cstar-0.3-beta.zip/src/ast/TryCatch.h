#ifndef TRY_CATCH_H
#define TRY_CATCH_H

//Try-catch block

#include "Stmts.h"

class TryCatch : public Stmt {
private:
    Stmt* tryBlock;  //The statements in the try block
    Stmts* catches;  //The catch blocks (each one is a Stmt)
public:
    TryCatch(Stmt* tryBlock, Stmts* catches)
        : tryBlock(tryBlock), catches(catches) {}
    virtual ~TryCatch() {
        delete tryBlock;
        delete catches;
    }
    
    Stmt*const getTryBlock() const { return tryBlock; }
    Stmts*const getCatches() const { return catches; }
#include "accept.h"
};

#endif
