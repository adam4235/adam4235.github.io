#ifndef REFERENCE_H
#define REFERENCE_H

//Common base class for something that refers to a symbol to look up.

#include "Expr.h"

class Reference : public Expr {
private:
    Type type;  //The type that's been looked up
    bool m_isInstanceVar;  //Whether it refers to an instance variable.
protected:
    Reference(Type type) : type(type), m_isInstanceVar(false) {}
public:
    virtual void setType(const Type& that) { type = that; }
    
    virtual Type getType() const { 
		return type; 
	}
    
	virtual bool isLvalue() const {
		return true;
	}
    
    bool isInstanceVar() const { return m_isInstanceVar; }
    void setInstanceVar() { m_isInstanceVar = true; }
    
    virtual Name* convertToName() const = 0;

#include "accept.h"
    
};

#endif
