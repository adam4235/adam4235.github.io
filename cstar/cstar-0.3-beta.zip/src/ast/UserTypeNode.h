#ifndef USER_TYPE_NODE_H
#define USER_TYPE_NODE_H

//Node for a reference to a user-defined type
//(e.g. when you have a variable of class type Point,
//this node holds the name "Point" to be looked up later.)

#include "TypeNode.h"
#include "Name.h"

class UserTypeNode : public TypeNode {
private:
	Type type;
	Name* name;  //The name of the type being referred to
public:
	Name* getName() const { return name; }
	virtual TypeNode* copy() const
	{
		UserTypeNode* retVal = new UserTypeNode(name->copy());
        retVal->setLookedUpType(type);
        return retVal;
	}
    
    UserTypeNode(Name* n) 
        : name(n) {}
    
    virtual ~UserTypeNode() { delete name; }
    
	virtual Type getTypeWoQuals() const { return type; }

	/** Set the type.  Called when looking up the type being
	 * referred to.*/
	virtual void setLookedUpType(Type newType) {
		type = newType;	
	}
#include "accept.h"
};

#endif

