#ifndef MEMBER_ACCESS_H
#define MEMBER_ACCESS_H

/*
 * Accessing the member of an object (. operator)
 */

#include "Reference.h"
#include "Name.h"
#include <string>

//Exception used by convertToName function below
class LeftNotClass {};

using namespace std;

class MemberAccess : public Reference {
private:
    Expr* left;  //the left of the .
    string member;  //The right of the . (always has to be a name;
        //x.y.z means (x.y).z
        //)

public:
    MemberAccess(Expr* left, string right)
        : Reference(Type::VOID), left(left), member(right)
    {}
    
    Expr*const getLeft() const { return left; }
    string getRight() const { return member; }
    
    Expr* snipLeft() {
        Expr* retVal = left;
        left = 0;
        return retVal;
    }
    
    void setLeft(Expr* newLeft) {
        assert(left == 0);
        left = newLeft;
    }
    
    /** When the type of a MemberAccess is TYPE, then it should be
    a dot-separated list of names, and convertable to a Name.
    Return a new Name object representing this MemberAccess.*/
    virtual Name* convertToName() const;
    
#include "accept.h"
};

#endif
