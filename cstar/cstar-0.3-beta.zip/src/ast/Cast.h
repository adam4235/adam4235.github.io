#ifndef CAST_H
#define CAST_H

//Cast

#include "Expr.h"
#include "TypeNode.h"

class Cast : public Expr {
private:
	TypeNode* targetType;
	Expr* subject;
public:
	Cast(TypeNode* targetType, Expr* subject) : targetType(targetType), subject(subject) {}
	virtual ~Cast() {
		delete targetType;
		delete subject;
	}
#include "accept.h"

	TypeNode*const getTargetType() { return targetType; }
	Expr*const getSubject() { return subject; }
	Expr*const snipSubject() {
		Expr* retVal = subject;
		subject = 0;
		return retVal;
	}
	virtual Type getType() const {
		return targetType->getType();
	}

    //A cast won't be of type csAutoPtr, but of the class type specified in the cast.
    virtual bool needAutoPtr() const {
        return false;
    }
    
};

#endif

