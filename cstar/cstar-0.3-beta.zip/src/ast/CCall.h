#ifndef CCALL_H
#define CCALL_H

//Constructor call

#include "TypeNode.h"
#include "AbstractCall.h"

class CCall : public AbstractCall {
private:
    TypeNode* type;  //The class type being constructed.
        //If null, then it's the shorthand initial value in a declaration
        //(e.g. Point p(1, 2))
    Type m_calleeType;  //Store the callee type, looked up in the symbol table.
public:
    CCall(TypeNode* type, Exprs* args) 
        : AbstractCall(args), type(type) {}
    virtual ~CCall() {
        if (type != 0) delete type;
    }
    
    void setTypeNode(TypeNode* newTypeNode) {
        assert(type == 0);
        type = newTypeNode;
    }
    TypeNode*const getTypeNode() const {
        return type;
    }
    
    virtual Type getType() const {
        return type->getType();
    }
    
    virtual Type calleeType() const {
        return m_calleeType;
    }
    
    virtual void setCalleeType(const Type& t)
    {
        m_calleeType = t;
    }
    
    string getCalleeStr() const { return "constructor"; }

#include "accept.h"
};

#endif
