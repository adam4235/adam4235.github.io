#ifndef DECLSTMT_H_
#define DECLSTMT_H_

//A declaration of (potentially a list of) variables,
//with a common type and refining types for each of the
//variables in the list.
//Note the difference between a DeclStmt and a DeclList,
//which is a list of top-level declarations 
//(functions, classes, etc.)

#include "VarDecl.h"
#include "Stmt.h"
#include "Decls.h"

class DeclStmt : public Stmt {
private:
	Decls* decls;
public:
	DeclStmt(Decls* decls) : decls(decls) {}
	
	//Convenience constructor to declare a decl statement
	//with only one decl
	DeclStmt(VarDecl* decl) {
		decls = new Decls();
		decls->add(decl);
	}

	virtual ~DeclStmt() {
		delete decls;
	}
	virtual Decls*const getDecls() const { return decls; }
#include "accept.h"
};

#endif /*DECLSTMT_H_*/
