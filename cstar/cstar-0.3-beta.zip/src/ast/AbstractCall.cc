/*
 *  AbstractCall.cc
 *  cstar_xcode
 *
 *  Created by Adam Richard on 13/08/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "AbstractCall.h"

