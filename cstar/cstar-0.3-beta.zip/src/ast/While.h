#ifndef WHILE_H
#define WHILE_H

//While or do-while loop

#include "Loop.h"
#include "Expr.h"

class While : public Loop {
private:
	Expr* cond;
	bool m_isDoWhile;
public:
	While(Expr* cond, Stmt* body, bool m_isDoWhile = false) 
		: Loop(body), cond(cond), m_isDoWhile(m_isDoWhile) {}
	virtual Expr*const getCond() const { return cond; }
    
    /** @return true if it's a do {} while loop,
     false if it's a while loop*/
	virtual bool isDoWhile() const { return m_isDoWhile; }
	virtual ~While() { delete cond; }
#include "accept.h"

};

#endif

