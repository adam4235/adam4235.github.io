#ifndef NULLCONST_H
#define NULLCONST_H

//Null constant

#include "Const.h"

class NullConst : public Const {
public:
	virtual ~NullConst() {}
	virtual Type getType() const {
		return Type::NUL;
	}
#include "accept.h"
};

#endif

