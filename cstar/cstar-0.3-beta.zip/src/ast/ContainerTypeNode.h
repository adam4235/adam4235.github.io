#ifndef CONTAINER_TYPE_NODE_H
#define CONTAINER_TYPE_NODE_H

//A base class for a type node for a type that holds another type.

#include "TypeNode.h"

class ContainerTypeNode : public TypeNode {
protected:
	TypeNode* base;  //The type this TypeNode is a container of

	ContainerTypeNode(TypeNode* base) : TypeNode(), base(base) {}

	/** A Type representing the type this TypeNode is a container of */
	Type baseType() const {
		if (base == 0) return Type::VOID;
		else return base->getType();
	}
public:
	TypeNode*const getBase() const { return base; }
	TypeNode*const snipBase() {
		TypeNode* retVal = base;
		base = 0;
		return retVal;
	}
	void setBaseNoDelete(TypeNode* newBase) {
		base = newBase;
	}
    
    /** @return a deep copy of this type node.
        Needed in the combineEach algorthm for 
        parsing array and pointer declarators.*/
	virtual TypeNode* copy() const = 0;

	/** Take the type specifier of a declaration and
	 * its declarators and combine them into one TypeNode
	 * to make the type of a variable.
	 * The declarators parameter potentially gets modified
	 * to receive as its base TypeNode the type specifier,
	 * and the whole thing is also returned.*/
	static TypeNode* combine(TypeNode* typespec, TypeNode* declarators) {
		if (declarators == 0)
			return typespec;
		else {
			ContainerTypeNode* newDeclarators = dynamic_cast<ContainerTypeNode*>(declarators);
			assert(newDeclarators != 0);
            Type::Quals quals = typespec->getQuals();  //The quals have to apply to the
                //outermost type.  E.g. ref double arr[3] is a reference to an array, not an
                //array of references.
            typespec->setQuals(Type::NO_FLAG);
			TypeNode* recResult = combine(typespec, newDeclarators->getBase());
			newDeclarators->base = recResult;
            newDeclarators->setQuals(quals);
			return newDeclarators;
		}
	}

	virtual bool hasDynamicDimensions() const {
		return base->hasDynamicDimensions();
	}
	virtual const TypeNode* checkDimsWithInitval() const {
		return base->checkDimsWithInitval();
	}
	virtual const TypeNode* checkPtr() const {
		return base->checkPtr();
	}
	
	virtual ~ContainerTypeNode() {
		if (base != 0)
			delete base;
	}
#include "accept.h"
};

#endif

