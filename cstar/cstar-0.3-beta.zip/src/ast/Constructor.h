#ifndef CONSTRUCTOR_H
#define CONSTRUCTOR_H

//The constructor definition (or declaration) for a class

#include "Function.h"
#include "Exprs.h"
#include "replace.h"

class Constructor : public Function {
private:
    Exprs* initList;  //Initializer list
public:
    //A constructor has a void return type
    Constructor(Params* params, Exprs* initList) 
        : Function("this", params, 0), initList(initList) {}
    virtual ~Constructor() {
        delete initList;
    }
    
    Exprs*const getInitList() const { return initList; }
    void setInitList(Exprs* newInitList) {
        replace(&initList, newInitList);
    }
    
#include "accept.h"
};

#endif
