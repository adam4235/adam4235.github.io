#ifndef STMT_H_
#define STMT_H_

//Base class for a statement

#include "Node.h"

class Stmt : public Node {
public:
	Stmt() {}
#include "accept.h"

};

#endif /*STMT_H_*/
