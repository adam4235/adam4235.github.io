#ifndef CPP_ELEMENT
#define CPP_ELEMENT

//Base class for item inside a cpp{} block.

#include "DeclOrDefn.h"

class CPPElement : public DeclOrDefn {
public:
#include "accept.h"
};

#endif

