#ifndef RETURN_H_
#define RETURN_H_

//Return statement

#include "Stmt.h"
#include "Expr.h"

class Return : public Stmt {
private:
	Expr* retVal;  //Return value.  Can be null, indicating
		//a return from a void function.
public:
	Return(Expr* retVal) : retVal(retVal) {}
	virtual ~Return() {
		if (retVal != 0)
			delete retVal;
	}
	Expr*const getRetVal() { return retVal; }
	void setRetValNoDelete(Expr* newRetVal) { retVal = newRetVal; }
#include "accept.h"
};

#endif /*RETURN_H_*/
