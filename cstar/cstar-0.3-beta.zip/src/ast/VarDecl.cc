#include "VarDecl.h"

bool VarDecl::isVirtual() const
{
    Type t(getType());
//    return t.isClassDefn() && t.getReferredType().hasFlag(Type::VIRTUAL_FLAG); 
    return t.hasFlag(Type::VIRTUAL_FLAG);
}

bool VarDecl::declaredVirtual() const
{
    return (type->getQuals() & Type::VIRTUAL_FLAG) == Type::VIRTUAL_FLAG;
}

void VarDecl::setStatic()
{
    type->setQuals(Type::STATIC_FLAG);
}

