#include "Decls.h"
#include "ContainerTypeNode.h"

void Decls::combineEach(TypeNode* typeSpec) 
{
	for (vector<VarDecl*>::iterator i = decls.begin(); i != decls.end(); ++i)
	{
		VarDecl* varDecl = *i;
		
		//Copy the typeSpec to a duplicate sub-AST, to prevent
		//the AST node from having
		//multiple parents, which could cause various problems.
		//Re-use the parameter for the last typeSpec needed,
		//to save time (as "most" variable declarations only
		//declare 1 variable.)
		TypeNode* newTypeSpec;
		if (i + 1 == decls.end())  //if it's the last element
			newTypeSpec = typeSpec;
		else
			newTypeSpec = typeSpec->copy();  //Prevent the AST node from having
				//multiple parents, which could cause various problems.

		TypeNode* newType = ContainerTypeNode::combine(newTypeSpec, varDecl->getTypeNode());
		varDecl->setTypeNodeNoDelete(newType);
	}
}

