#include "opname.h"

using namespace std;

string findOpNamePart(const string& o)
{
    if (o == "==") return "equalequal";
    if (o == ":=") return "assign";
    
	if (isAssign(o))
		return findOpNamePart(o.substr(0, o.length()-1)) + "equal";

	if (o == "+") return "plus";
	else if (o == "-") return "minus";
	else if (o == "*") return "times";
	else if (o == "/") return "divide";
	else if (o == "\\") return "idivide";
	else if (o == "%") return "percent";
	else if (o == "<") return "lessthan";
	else if (o == ">") return "greaterthan";
	else if (o == "|") return "bor";
	else if (o == "&") return "band";
	else if (o == "and") return "land";
	else if (o == "or") return "lor";
	else if (o == "<<") return "output";
	else if (o == ">>") return "input";
	else if (o == "++") return "inc";
	else if (o == "--") return "dec";
	else if (o == "xor") return "xor";
	else if (o == "**") return "power";
	else if (o == "~") return "bnot";
	else if (o == "not") return "lnot";
	else if (o == "?") return "question";

	//Casts
	else if (isUserCast(o)) return "cast" + o;

	else return o;
}

bool isAssign(const string& o)
{
    if (o == "==") return false;
	if (o.at(o.length()-1) == '=')
		return true;
    return false;
}

bool isUserCast(const string& o)
{
	if (o == "int") return true;
	else if (o == "uint") return true;
	else if (o == "double") return true;
	else if (o == "ldouble") return true;
	else if (o == "float") return true;
	else if (o == "bool") return true;
	else if (o == "char") return true;
	else if (o == "thing") return true;
	else return false;
}
    
string findOpName(const string& name)
{
	//Mangle the opname to reduce the chances it clashes with a user
	//name
	string realNamePart = findOpNamePart(name);
	if (realNamePart == name) return realNamePart;
	else return "_op" + realNamePart + "11";
}

