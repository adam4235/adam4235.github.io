package polyglot.ext.oomatch;

import java.util.*;

//Misc. utility methods
public class Util
{

    /**Check whether two collections are equal.  Necessary because
     * using the equals method from Java appears to cause a LinkedList 
     * with the same elements as an ArrayList to not be considered equal. 
     * @param c1, c2 The collections to compare
     */
    public static boolean collectionsEqual(Collection c1, Collection c2)
    {
        if (c1.size() != c2.size()) return false;
        for (Iterator i = c1.iterator(), j = c2.iterator(); i.hasNext();)
        {
            Object o1 = i.next(), o2 = j.next();
            if (!o1.equals(o2)) return false;
        }
        return true;
    }
}
