package polyglot.ext.oomatch;

import polyglot.main.Report;

/**
 * Extension information for oomatch extension.
 */
public class Topics {
    public static final String oomatch = "oomatch";

    static {
        Report.topics.add(oomatch);
    }
}
