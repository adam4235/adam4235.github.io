package polyglot.ext.oomatch;

/**
 * Version information for oomatch extension
 */
public class Version extends polyglot.main.Version {
    public String name() { return "oomatch"; }

    // define a version number, the default (below) is 0.1.0
    public int major() { return 1; }
    public int minor() { return 0; }
    public int patch_level() { return 0; }
}
