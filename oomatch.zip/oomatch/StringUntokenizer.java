package polyglot.ext.oomatch;

/**A common problem when working with strings is the construction of some kind
 * of list made up of several smaller strings, separated by a separater, such as
 * a comma.  Doing this has the problem that the last item should not have a comma
 * after it, and you sometimes don't know what that last item is.
 * 
 * This class solves that problem once and for all.  You create it and specify the
 * separator, then repeatedly add strings to it, then get the final string from it,
 * at which point it removes the last separator if there is one.
 * 
 * It's called a StringUntokenizer because it's the opposite of the Java StringTokenizer
 * class, which breaks up a string into multiple smaller strings around a separator.
 * 
 * @author Adam Richard
 *
 */
import java.util.*;

public class StringUntokenizer
{

    private String separator;
    private String theString = "";
    
    public StringUntokenizer(String separator)
    {
        super();
        if (separator == null)
            throw new IllegalArgumentException("Separator cannot be null.");
        
        this.separator = separator;
    }

    /**Add s to the string being constructed.*/
    public void add(String s)
    {
        theString += s + separator;
    }
    
    /**Called when the string is finished being constructed, and returns it.*/
    public String get()
    {
        if (theString == "") 
            return theString;
        else 
            return theString.substring(0, theString.length() - separator.length());
    }
    
    //Print a list
    public static void printList(List l)
    {
        StringUntokenizer s = new StringUntokenizer(", ");
        for (Iterator i = l.iterator(); i.hasNext(); )
        {
            Object o = i.next();
            s.add(o.toString());
        }
        System.out.println(s.get());
    }
}
