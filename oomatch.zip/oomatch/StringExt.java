package polyglot.ext.oomatch;

/**A collection of methods that should really be in String.
 * We can't even extend String, since it's final.  What were the Java
 * designers thinking?
 * */

public final class StringExt
{

    /**@return Whether lookFor is contained in lookIn*/
    public static boolean contains(String lookIn, String lookFor)
    {
        return count(lookIn, lookFor) > 0;
        //return !lookIn.replaceFirst(lookFor, "").equals(lookIn);
    }
    
    /**@return The number of occurrances of lookFor in lookIn.
     * Requires lookIn to be non-null.
     * if lookFor is null*/
    public static int count(String lookIn, String lookFor)
    {
        if (lookFor == null || lookFor.equals(""))
            throw new IllegalArgumentException("lookFor must be non-null");
        
        //We should be able to use replaceAll here, but it works on regular expressions,
        //and I want a method that just works on strings.
        
        int count = 0;
        String temp = lookIn; 
        while (!temp.equals(""))
        {
            if (temp.startsWith(lookFor))
            {
                ++count;
            }
            temp = temp.substring(1);
        }
        return count;
    }
    
    /**Returns n copies of toCopy*/
    public static String nCopies(String toCopy, int n)
    {
        String retVal = "";
        for (int i = 0; i < n; ++i)
        {
            retVal += toCopy;
        }
        return retVal;
    }
}
