package polyglot.ext.oomatch;

import polyglot.visit.*;
import polyglot.ast.*;
/**Find places in generated AST nodes where type information hasn't been filled in.
 * For debugging.*/
public class FindMissingTypeInfo extends NodeVisitor
{

    //PrettyPrinter pprinter = new PrettyPrinter();
    
    public FindMissingTypeInfo()
    {
        super();
    }
    /*
     * From the FAQ:
    #  Exprs require Types.
    # LocalDecls, Locals, and Formals require LocalInstances.
    # FieldDecls and Fields require FieldInstances.
    # MethodDecls and Calls require MethodInstances.
    # ConstructorDecls, ConstructorCalls, and News require ConstructorInstances.
    # ClassDecls require ParsedClassTypes.
    */
    public NodeVisitor enter(Node n) 
    {
//        System.out.println(n);
//        System.out.println(n.getClass().toString());
        Error e = new Error("Found missing type.");
        if (n instanceof Expr)
        {
            if (((Expr)n).type() == null)
                throw e;
        }
        else if (n instanceof LocalDecl)
        {
            if (((LocalDecl)n).localInstance() == null)
                throw e;
        }
        else if (n instanceof Local)
        {
            if (((Local)n).localInstance() == null)
                throw e;
        }
        else if (n instanceof Formal)
        {
            if (((Formal)n).localInstance() == null)
                throw e;
        }
        else if (n instanceof Field)
        {
            if (((Field)n).fieldInstance() == null)
                throw e;
        }
        else if (n instanceof FieldDecl)
        {
            if (((FieldDecl)n).fieldInstance() == null)
                throw e;
        }
        else if (n instanceof Call)
        {
            if (((Call)n).methodInstance() == null)
                throw e;
        }
        else if (n instanceof MethodDecl)
        {
            if (((MethodDecl)n).methodInstance() == null)
                throw e;
        }
        else if (n instanceof ConstructorDecl)
        {
            if (((ConstructorDecl)n).constructorInstance() == null)
                throw e;
        }
        else if (n instanceof ConstructorCall)
        {
            if (((ConstructorCall)n).constructorInstance() == null)
                throw e;
        }
        else if (n instanceof New)
        {
            if (((New)n).constructorInstance() == null)
                throw e;
        }
        else if (n instanceof ClassDecl)
        {
            if (((ClassDecl)n).type() == null)
                throw e;
        }
        return this;
    }
}
