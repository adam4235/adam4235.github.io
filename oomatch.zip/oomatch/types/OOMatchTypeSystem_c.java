package polyglot.ext.oomatch.types;

import java.util.Iterator;
import java.util.List;

import polyglot.types.*;
import polyglot.util.Position;
import polyglot.ext.jl.types.TypeSystem_c;
import polyglot.frontend.Source;

public class OOMatchTypeSystem_c extends TypeSystem_c implements OOMatchTypeSystem {
    //Mostly ripped from the super implementation.  Have to return an 
    //OOMatchMethodInstance instead.
    public MethodInstance methodInstance(Position pos, 
            ReferenceType container, Flags flags,
            Type returnType, String name, List argTypes, List excTypes) 
    {
        //The super call is because the super implementation does some checking
        super.methodInstance(pos, container, flags, returnType, name, argTypes, excTypes);
        return new OOMatchMethodInstance(this, pos, container, flags,
                returnType, name, argTypes, excTypes);
    }
    
    //Likewise
    public ConstructorInstance constructorInstance(Position pos,
            ClassType container, Flags flags, List argTypes, List excTypes) 
    {
        super.constructorInstance(pos, container, flags, argTypes, excTypes);
        return new OOMatchConstructorInstance(this, pos, container, flags,
                argTypes, excTypes);
    }
    
    //This method is necessary to compare 2 OOMatch procedures.
    //Polyglot normally only compares their formal types, and not the OOMatch types
    //of their params.
    public boolean equals(TypeObject type1, TypeObject type2)
    {
        if (type1 instanceof Patternable 
                && type2 instanceof Patternable)
        {
            Patternable t1 = (Patternable)type1,
                t2 = (Patternable)type2;
            if (!t1.paramTypes().equals(t2.paramTypes())) return false;
        }
        else if (type1 instanceof AbstractMethodInstance &&
                type2 instanceof AbstractMethodInstance)
        {
            AbstractMethodInstance t1 = (AbstractMethodInstance)type1,
                t2 = (AbstractMethodInstance)type2;
            if (!t1.name().equals(t2.name())) return false;
        }
        return super.equals(type1, type2);
    }
    /*
    public boolean isSubtype(Type type1, Type type2)
    {
        if (type2 instanceof PatternType)
        {
            PatternType t2 = (PatternType)type2;
            return (super.isSubtype(type1, t2.deconstructorType())
                    && OOMatchMethodInstance.checkCompletenessOfList(t2.pattern()));
        }
        else
            return super.isSubtype(type1, type2);
    }
    */
    
    public DeconstructorInstance findMostSpecificDeconstructor(List acceptable,
            ReferenceType container, List pattern, ClassType currClass)
        throws SemanticException
    {
        return (DeconstructorInstance)findProcedure(acceptable, container, pattern, currClass);
    }

    
    //Create class types of a special type so we can tell what's an OOMatch class
    //and what's a plain Java class.
    public ParsedClassType createClassType(LazyClassInitializer init, Source fromSource) {
        //This seems to be Coffer's strategy to make only OOMatch classes get
        //OOMatchClassTypes.  Apparently it works - I've tested it on an external
        //.oom file, and the class in the file got an OOMatchClassType.
        if (! init.fromClassFile())
            return new OOMatchClassType(this, init, fromSource);
        else
            return super.createClassType(init, fromSource);
    }

    //We need to override this to do the same check for deconstructors
    //that's done for methods in the superclass.  So I basically copied the
    //code and changed it for deconstructors.
    public void checkClassConformance(ClassType ct) throws SemanticException {
        super.checkClassConformance(ct);
        
        OOMatchClassType oomCT;
        if (ct instanceof OOMatchClassType)
        {
            oomCT = (OOMatchClassType)ct;
        }
        else return;
        if (ct.flags().isAbstract()) {
            // don't need to check abstract classes and interfaces            
            return;
        }

        // build up a list of superclasses and interfaces that ct 
        // extends/implements that may contain abstract methods that 
        // ct must define.
        List superInterfaces = abstractSuperInterfaces(ct);

        // check each abstract method of the classes and interfaces in
        // superInterfaces
        for (Iterator i = superInterfaces.iterator(); i.hasNext(); ) {
            ReferenceType rt = (ReferenceType)i.next();
            if (!(rt instanceof OOMatchClassType))
            {
                continue;
            }
            OOMatchClassType oomRT = (OOMatchClassType)rt;
            for (Iterator j = oomRT.deconstructors().iterator(); j.hasNext(); ) {
                DeconstructorInstance mi = (DeconstructorInstance)j.next();
                if (!mi.flags().isAbstract()) {
                    // the method isn't abstract, so ct doesn't have to
                    // implement it.
                    continue;
                }

                boolean implFound = false;
                OOMatchClassType curr = oomCT;
                while (curr != null && !implFound) {
                    List possible = curr.deconstructors();
                    for (Iterator k = possible.iterator(); k.hasNext(); ) {
                        DeconstructorInstance mj = (DeconstructorInstance)k.next();
                        if (!mi.isSameProc(mj)) continue;
                        if (!mj.flags().isAbstract() && 
                            ((isAccessible(mi, ct) && isAccessible(mj, ct)) || 
                                    isAccessible(mi, mj.container().toClass()))) {
                            // The method mj may be a suitable implementation of mi.
                            // mj is not abstract, and either mj's container 
                            // can access mi (thus mj can really override mi), or
                            // mi and mj are both accessible from ct (e.g.,
                            // mi is declared in an interface that ct implements,
                            // and mj is defined in a superclass of ct).
                            
                            implFound = true;
                            break;
                        }
                    }

                    if (curr == mi.container()) {
                        // we've reached the definition of the abstract 
                        // method. We don't want to look higher in the 
                        // hierarchy; this is not an optimization, but is 
                        // required for correctness. 
                        break;
                    }
                    
                    if (curr.superType() instanceof OOMatchClassType)
                    {
                        curr = (OOMatchClassType)curr.superType();
                    }
                    else curr = null;
                }


                // did we find a suitable implementation of the method mi?
                if (!implFound && !ct.flags().isAbstract()) {
                    throw new SemanticException(ct.fullName() + " should be " +
                            "declared abstract; it does not define " +
                            mi.signature() + ", which is declared in " +
                            rt.toClass().fullName(), ct.position());
                }
            }
        }
    }

    public void checkMethodFlags(Flags f) throws SemanticException {
        //Allow "inc" for methods
        super.checkMethodFlags(f.clear(OOMFlags.INC));
    }
}
