
package polyglot.ext.oomatch.types;

import java.util.LinkedList;
import java.util.List;

import polyglot.ext.jl.types.ConstructorInstance_c;
import polyglot.types.*;
import polyglot.util.Position;

/** See OOMatchMethodInstance; this class is almost a duplication of that one,
 * which seems necessary because Java lacks multiple inheritance.
 */

public class OOMatchConstructorInstance extends ConstructorInstance_c implements
    Patternable, ConstructorInstance 
{
    protected List children;  //methods in the same class that this method overrides

    protected String realName = "";
    public String realName() { return realName; }
    public void setRealName(String realName) { this.realName = realName; }

    private int id;
    public int getID() { return id; }
    public void setID(int id) { this.id = id; }

    //The number of extra parameters added to the end of the constructor's parameters
    //to avoid a duplicate method definition
    private int junkParams = 0;
    public int junkParams() { return junkParams; }
    public void setJunkParams(int junkParams) { this.junkParams = junkParams; }
    
    public OOMatchConstructorInstance(TypeSystem ts, Position pos,
            ClassType container, Flags flags, List paramTypes, List excTypes)
    {
        super(ts, pos, container, flags, OOMatchMethodInstance.javaTypes(paramTypes), excTypes);
        children = new LinkedList();
        this.paramTypes = paramTypes;
    }
    private List paramTypes;  //The pattern types
    public List paramTypes() { return paramTypes; }
    public OOMatchProcedureInstance paramTypes(List paramTypes)
    {
        OOMatchConstructorInstance n = (OOMatchConstructorInstance) copy();
        n.paramTypes = paramTypes;
        n.formalTypes = OOMatchMethodInstance.javaTypes(paramTypes);
        return n;
    }

    public List children()
    {
        return children;
    }
    public boolean preferred(ProcedureInstance other)
    {
        if (!(other instanceof OOMatchConstructorInstance)) return false;
        return OOMatchMethodInstance.parametersOverride(paramTypes(), 
                ((OOMatchConstructorInstance)other).paramTypes());
    }
    public Type typeOf() { return container(); }

    public boolean hasOnlyFormals()
    {
        return OOMatchMethodInstance.hasOnlyFormalsGeneral(paramTypes());
    }

    public boolean intersectsWith(Patternable other)
    {
        if (other instanceof OOMatchConstructorInstance)
        {
            OOMatchConstructorInstance m = (OOMatchConstructorInstance)other;
            return m.paramTypes().size() == paramTypes().size() &&
                OOMatchMethodInstance.intersection(m.paramTypes(), paramTypes()) != null;
        }
        return false;
    }
    public boolean cantBothApply(Patternable other)
    {
        if (other instanceof OOMatchConstructorInstance)
        {
            OOMatchConstructorInstance m = (OOMatchConstructorInstance)other;
            if (m.paramTypes().size() != paramTypes().size())
                return true;
            return OOMatchMethodInstance.paramsCantBothApply(m.paramTypes(), paramTypes());
        }
        return true;
    }

    public boolean shouldBeRenamed()
    {
        return true;
    }

    public boolean sameName(OOMatchProcedureInstance other)
    {
        return other instanceof OOMatchConstructorInstance;
    }
    private static final long serialVersionUID = 339764406;
    
    public boolean isSameProc(OOMatchProcedureInstance other)
    {
        if (other instanceof OOMatchConstructorInstance)
        {
            OOMatchConstructorInstance m = (OOMatchConstructorInstance)other;
            return paramTypes().equals(m.paramTypes());
        }
        return false;
    }
    private boolean[] isNamedParam = null;
    public boolean[] isNamedParam() { return isNamedParam; }
    public void setIsNamedParam(boolean[] isNamedParam) { 
        this.isNamedParam = isNamedParam; 
    }

    public boolean hasWhereClause() { return false; }
    
    //Flag to set when a dispatcher should not be created for this method.
    //It gets set if it overrides a regular Java method.
    private boolean noDispatcher = false;
    public boolean getNoDispatcher() { return noDispatcher; }
    public void setNoDispatcher() { noDispatcher = true; }

}
