
package polyglot.ext.oomatch.types;

import java.util.*;

import polyglot.ext.jl.types.MethodInstance_c;
import polyglot.ext.oomatch.ast.Param;
import polyglot.types.*;
import polyglot.util.Position;
import polyglot.ast.*;
import polyglot.ext.oomatch.ast.*;

/**Type info for a method.  Handles determining overriding, intersection,
 * and all that other fun stuff.*/
public class OOMatchMethodInstance extends MethodInstance_c implements
        Patternable, AbstractMethodInstance {
    
    public OOMatchMethodInstance() {
        super();
        children = new LinkedList();
    }

    public OOMatchMethodInstance(TypeSystem ts, Position pos,
            ReferenceType container, Flags flags, Type returnType, String name,
            List paramTypes, List excTypes) 
    {
        super(ts, pos, container, flags, returnType, name, javaTypes(paramTypes),
                excTypes);
        this.paramTypes = paramTypes;
        children = new LinkedList();
        isNamedParam = new boolean[paramTypes.size()];
    }

    private boolean hasWhereClause;
    public boolean hasWhereClause() { return hasWhereClause; }
    public OOMatchMethodInstance hasWhereClause(boolean hasWhereClause)
    {
        OOMatchMethodInstance n = (OOMatchMethodInstance) copy();
        n.hasWhereClause = hasWhereClause;
        return n;
    }
   
    //The manual child given in the input with the "|" operator
    private MethodInstance child;
    public void setChild(MethodInstance child)
    {
        this.child = child;
    }
    public MethodInstance getChild() { return child; }

    protected String realName = "";
    public String realName() { return realName; }
    public void setRealName(String realName) { this.realName = realName; }

    protected List children;  //methods in the same class that this method overrides

    private int id;
    public int getID() { return id; }
    public void setID(int id) { this.id = id; }
    
    public List children()
    {
        return children;
    }

    private List paramTypes;  //The pattern types
    public List paramTypes() { return paramTypes; }
    public OOMatchProcedureInstance paramTypes(List paramTypes)
    {
        OOMatchMethodInstance n = (OOMatchMethodInstance) copy();
        n.paramTypes = paramTypes;
        n.formalTypes = javaTypes(paramTypes);
        return n;
    }
    
    /**@return The Java types of a list of parameter types (list of Type)
     * Corresponds to the "type" function from the paper/thesis
     */
    public static List javaTypes(List paramTypes)
    {
        List retVal = new ArrayList(paramTypes.size());
        for (Iterator i = paramTypes.iterator(); i.hasNext(); )
        {
            Object o = i.next();
            if (o instanceof ValueType)
            {
                retVal.add(((ValueType)o).typeOfValue());
            }
            else if (o instanceof PatternType)
            {
                retVal.add(((PatternType)o).deconstructorType());
            }
            else retVal.add(o);
        }
        return retVal;
    }
    
    public boolean preferred(ProcedureInstance other)
    {
        if (!(other instanceof OOMatchMethodInstance)) return false;
        //if (this instanceof DeconstructorInstance || other instanceof DeconstructorInstance)
        //    return false;
        OOMatchMethodInstance m = (OOMatchMethodInstance)other;
        
        //manual overriding
        if (m.getChild() != null && m.getChild().equals(this))
        {
            return true;
        }
        
        if (!m.name().equals(name())) return false;
        if (m.hasWhereClause()) return false;  //Can't override anything with a where clause
        return parametersOverride(paramTypes(), m.paramTypes());
    }

    /** Given 2 methods of the same name, one having parameters first and the other
     * having parameters second, return whether first overrides second.
     * @param tc Needed to look up deconstructors
     * @throws SemanticException
     */
    public static boolean parametersOverride(List first, List second)
    {
        if (first.size() != second.size()) return false;  //If they have
            //a different number of parameters, then there is definitely
            //no overriding taking place.
        
        Iterator i = first.iterator(), j = second.iterator();
        
        while (i.hasNext())
        {
            //first overrides second iff all its parameters are preferred 
            //to second's.
            //If all the parameters match exactly, then it's a duplicate
            //definition, and should be discovered later by Java checking.
            Type firstParam = (Type)(i.next()), 
                  secondParam = (Type)(j.next());
            if (!paramsPreferred(firstParam, secondParam))
                return false;
        }
        return true;
    }

    //An ugly "global" variable that gets set at the creation of the typechecker 
    //(OOMatchTypeCheck).  Seemed better than repeatedly passing it as a parameter.
    public static OOMatchNodeFactory nf = null;
    
    public static boolean isNum(Lit l)
    {
        return l instanceof FloatLit || l instanceof NumLit;
    }
    public static double num(Lit l)
    {
        if (l instanceof FloatLit)
            return ((FloatLit)l).value();
        else
            return ((NumLit)l).longValue();
    }
    /**@return Whether a parameter p1 is preferred over a parameter p2*/
    public static boolean paramsPreferred(Type p1, Type p2)
    {
        //This is the kind of ugliness that could be eliminated with multimethods
        //(or OOMatch)
        if (p1 instanceof ValueType)
        {
            ValueType par1 = (ValueType)p1;
            if (p2 instanceof ValueType)
            {
                ValueType par2 = (ValueType)p2;
                Lit l1 = nf.Lit(par1.position(), par1.constantValue()),
                    l2 = nf.Lit(par2.position(), par2.constantValue());
                double d1, d2;
                if (par1.equals(par2))
                    return true;
                if (isNum(l1) && isNum(l2))
                {
                    d1 = num(l1);
                    d2 = num(l2);
                    
                    //To check that par1.type <: par2.type, as defined by subtyping
                    //among OOMatch primitives, we just need to check whether par1
                    //can be implicitely cast to par2, by Java 4's rules.
                    return d1 == d2 && 
                        par1.typeOfValue().isImplicitCastValid(par2.typeOfValue());
                }
                else return false;
            }
            else if (p2 instanceof PatternType)
                return false;
            else
            {
                return par1.formalPreferred(p2);
            }
        }
        else if (p1 instanceof PatternType)
        {
            PatternType par1 = (PatternType)p1;
            if (p2 instanceof ValueType)
                return false;
            else if (p2 instanceof PatternType)
            {
                PatternType par2 = (PatternType)p2;
                return par1.deconstructorType().isSubtype(par2.deconstructorType())
                    && par1.decon().equals(par2.decon())
                    && parametersOverride(par1.pattern(), par2.pattern());
            }
            else
            {
                return par1.deconstructorType().isSubtype(p2);
            }
        }
        else
        {
            if (p2 instanceof ValueType)
                return false;
            else if (p2 instanceof PatternType)
            {
                return false;
                /*
                PatternType par2 = (PatternType)p2;
                return p1.descendsFrom(par2.deconstructorType())
                    && checkCompletenessOfList(par2.pattern());
                    */
            }
            else
            {
                if (p1 instanceof PrimitiveType && p2 instanceof PrimitiveType)
                {
                    //This captures the subtyping relationships described in the paper.
                    return p1.isImplicitCastValid(p2);
                }
                else return p1.isSubtype(p2);
            }
        }
    }

    /**Given a List<Param>, return a list of their types*/
    public static List typesOf(List params)
    {
        List retVal = new LinkedList();
    
        for (Iterator i = params.iterator(); i.hasNext();)
        {
            Param p = (Param)(i.next());
            
            retVal.add(p.type());
        }
        return retVal;
    }
    
    private static List spotFor(OOMatchProcedureInstance procedure, ClassType theClass)
    {
        if (procedure instanceof ConstructorInstance)
        {
            return theClass.constructors();
        }
        else if (procedure instanceof MethodInstance)
        {
            return theClass.methodsNamed(((MethodInstance)procedure).name());
        }
        else throw new Error("Unrecognized procedure type.");
    }

    /** Given a procedure that is incomplete and a class it's found in, look in the superclass
     * for a procedure to complete it.
     * For example,
     * class A extends B {
     *      void f(0)
     * }
     * is allowed if B contains an f which takes a single int parameter, or if one of
     * its superclasses contains such a method.
     * @param proc  The incomplete procedure (method or constructor).
     * @param theClass The class it's contained in.
     * @param ts  The typesystem.
     * @param isFinal Whether we're looking for a completer that is final
     *      (which would mean proc is overriding a final method, which is an
     *      error)
     * @return  A completer, or null if one can't be found.
     */ 
    public static ProcedureInstance findCompleterInSuperClass(
            Patternable proc, ClassType theClass, TypeSystem ts, 
            boolean isFinal)
    {
        while (0 == 0)
        {
            Type superType = theClass.superType();
            if (superType.equals(ts.Object())
                    || !(superType instanceof ClassType))
            {
                return null;
            }
            theClass = (ClassType)superType;
            Collection possibleMethods = OOMatchClassType.allMethods(
                    spotFor(proc, theClass));
            for (Iterator i = possibleMethods.iterator(); i.hasNext();)
            {
                ProcedureInstance p = (ProcedureInstance)i.next();
                boolean condition;
                if (isFinal)
                    condition = p.flags().isFinal();
                else
                    //in this case, we're checking completeness, and a completer
                    //must have only formal parameters.
                    condition = (!(p instanceof Patternable)) || ((Patternable)p).hasOnlyFormals();
                if (condition && proc.preferred(p))
                //if (proc.overrides(p) && (!onlyFormals || p.hasOnlyFormals()))
                {
                    return p;
                }
            }
        }
    }

    /**@return Whether params consists only of regular Java parameters*/ 
    public static boolean hasOnlyFormalsGeneral(List params)
    {
        for (Iterator p = params.iterator(); p.hasNext(); )
        {
            Type t = (Type)(p.next());
            if (t instanceof ValueType || t instanceof PatternType)
                return false;
        }
        return true;
    }
    public boolean hasOnlyFormals()
    {
        return !hasWhereClause() && hasOnlyFormalsGeneral(paramTypes());
    }
    
    /** Find the most general common set of parameter types which overrides both
     * the methods first and second.
     */
    public static List intersection(Patternable first, Patternable second)
    {
        if (first.paramTypes().size() != second.paramTypes().size())
        {
            throw new Error("Can't call intersection on methods with " +
                    "different numbers of parameters.");
        }
        List retVal = new LinkedList();
        for (Iterator i = first.paramTypes().iterator(), 
                      j = second.paramTypes().iterator();
             i.hasNext(); )
        {
            Type t1 = (Type)i.next(), t2 = (Type)j.next();
            if (t1.isSubtype(t2))
                retVal.add(t1);
            else
            {
                if (!t2.isSubtype(t1)) throw new Error("Can't call " +
                        "intersection on methods which don't override each other.");
                retVal.add(t2);
            }
        }
        return retVal;
    }
    
    public boolean cantBothApply(Patternable other)
    {
        if (other instanceof OOMatchMethodInstance)
        {
            OOMatchMethodInstance m = (OOMatchMethodInstance)other;
            if (m.paramTypes().size() != paramTypes().size())
                return true;
            if (!m.name().equals(name()))
                return true;
            return paramsCantBothApply(m.paramTypes, paramTypes());
        }
        return true;
    }
    
    private static boolean isInterface(Type t)
    {
        if (t instanceof ClassType)
        {
            ClassType ct = (ClassType)t;
            return ct.flags().isInterface();
        }
        else return false;
    }
    
    private static boolean isReference(Type t)
    {
        return t instanceof ReferenceType || t instanceof PatternType;
    }
    
    private static boolean unrelated(Type t1, Type t2)
    {
        return !(t1.isSubtype(t2) || t2.isSubtype(t1));
    }
    public static boolean paramsCantBothApply(List l1, List l2)
    {
        for (Iterator i = l1.iterator(), j = l2.iterator();
            i.hasNext(); )
        {
            Type t[] = new Type[] {(Type)i.next(),
                (Type)j.next()};
            Type[] realType = new Type[2];
            for (int k = 0; k <=1; ++k)
            {
                if (t[k] instanceof PatternType)
                {
                    realType[k] = ((PatternType)(t[k])).deconstructorType();
                }
                else realType[k] = t[k];
            }
            //if unrelated, can't both apply, because Java lacks 
            //multiple inheritance
            if (isReference(realType[0]) && isReference(realType[1])) 
            {
                //both parameters are reference type
                if (isInterface(realType[0]) || isInterface(realType[1]))
                {
                    //one is an interfaces; they might both apply
                }
                if ((unrelated(realType[0], realType[1])))
                    return true;
            }
            else if (intersect(t[0], t[1]) == null)
                return true;
        }
        return false;
    }
    public boolean intersectsWith(Patternable other)
    {
        if (other instanceof OOMatchMethodInstance)
        {
            OOMatchMethodInstance m = (OOMatchMethodInstance)other;
            return m.paramTypes().size() == paramTypes().size() &&
                m.name().equals(name()) &&
                intersection(m.paramTypes(), paramTypes()) != null;
        }
        return false;
    }
    /** Find the most general common set of parameter types which overrides both
     * the methods first and second.
     */
    public static List intersection(List first, List second)
    {
        if (first.size() != second.size())
        {
            return null;
        }
        List retVal = new LinkedList();
        for (Iterator i = first.iterator(), 
                      j = second.iterator();
             i.hasNext(); )
        {

            Type t1 = (Type)i.next(), t2 = (Type)j.next();
            Type inter = intersect(t1, t2);
            if (inter == null) return null;
            else retVal.add(inter);
        }
        return retVal;
    }

    public static Type intersect(Type t1, Type t2)
    {
        if (paramsPreferred(t1, t2))
            return t1;
        else if (paramsPreferred(t2, t1))
            return t2;
        else 
        {
            Type inter = null;
            if (t1 instanceof PatternType)
                inter = intersectPat((PatternType)t1, t2);
            else if (t2 instanceof PatternType)
                inter = intersectPat((PatternType)t2, t1);
            return inter;
        }

    }
    public static Type intersectPat(PatternType first, Type other)
    {
        //This is a case where multimethods would be great
        if (other instanceof ValueType)
            return null;
        else if (other instanceof PatternType)
        {
            PatternType otherAsPat = (PatternType)other; 
            if (!first.decon().equals(otherAsPat.decon()))
                return null;
            ClassType newType = null;
            if (first.deconstructorType().isSubtype(otherAsPat.deconstructorType()))
                newType = first.deconstructorType();
            else if (otherAsPat.deconstructorType().isSubtype(first.deconstructorType()))
                newType = otherAsPat.deconstructorType();
            else
                return null;
            if (first.pattern().size() != otherAsPat.pattern().size())
                return null;
            List inter = intersection(first.pattern(), otherAsPat.pattern());
            return new PatternType_c(first.typeSystem(), 
                    first.position(), newType, inter, first.decon(), "");
        }
        else
        {
            if (first.deconstructorType().isSubtype(other))
                return first;
            else if (other.descendsFrom(first.deconstructorType()))
            {
                PatternType_c retVal = (PatternType_c)first.copy();
                retVal.deconstructorType = (ClassType)other;
                return retVal;
            }
            else return null;
        }
    }

    public Type typeOf() { return returnType(); }

    public String toString()
    {
        String retVal = "method " + flags + " " + returnType() + " " + name() + "("
            + PatternType_c.printParamList(paramTypes()) + ")";
        
        if (!throwTypes().isEmpty())
            //hack: use the printParamList to print the list of types, even though
            //they aren't parameters
            retVal += " throws " + PatternType_c.printParamList(throwTypes());
        if (hasWhereClause)
            retVal += " where (...)";
        return retVal;
    }
    
    public boolean shouldBeRenamed()
    {
        /*
         * I've chosen to rename all user methods, and give them a completer.
         * The alternative - to rename only methods with patterns or children - would
         *  suffer from the following problem:

What if the call to super is intercepted:

class A {
    void f(Point);  //wasn't renamed
}

class B : A {
    void f(Point(int x, int y));  //Gets a completer f(Point)
}

class C : B {
    void f(CoorPoint(0, 0));  //It's dispatcher might find that A.f applies, but B.f doesn't.  It then calls super.f, and B's dispatcher will intercept it, which it shouldn't.  B.f will therefore get checked twice.
}

The problem could easily be solved in C++, but Java doesn't let you call a method of a specific superclass.

A good optimizer can notice that A.f's completer will always call A.f, and, unless
the code is in a library, can optimize it away.

         */
        //don't rename abstract methods
        return !flags().isAbstract() &&
            !isMain() && !noDispatcher;  //don't rename main
        //return !hasOnlyFormals() || children().size() > 0;
    }

    //return whether this method is main.
    public boolean isMain()
    {
        return name().equals("main") && paramTypes.size() == 1 &&
            paramTypes.get(0).equals(ts.arrayOf(ts.String())) &&
            returnType.equals(ts.Void());
    }
    
    public boolean sameName(OOMatchProcedureInstance other)
    {
        return other instanceof OOMatchMethodInstance &&
            ((OOMatchMethodInstance)other).name().equals(name());
    }
    private static final long serialVersionUID = 740140159;
    
    //This should speed up the hash map that stores DAGs of methods
    public int hashCode() {
        int paramHashCode = 0;
        for (Iterator i = paramTypes.iterator(); i.hasNext(); )
            paramHashCode += i.next().hashCode();
        return flags.hashCode() + name.hashCode() + paramHashCode;
    }
    
    public boolean isSameProc(OOMatchProcedureInstance other)
    {
        if (other instanceof OOMatchMethodInstance)
        {
            OOMatchMethodInstance m = (OOMatchMethodInstance)other;
            return m.name().equals(name()) && paramTypes().equals(m.paramTypes()) &&
            !hasWhereClause() && !m.hasWhereClause();
        }
        return false;
    }
    
    //Have to override some methods from Polyglot that check for equality and
    //overriding:
    
    //Have to override this to prevent Polyglot from giving duplicate definitions
    //where there really aren't any (In ClassBody_c.dupliateMethodCheck)
    public boolean isSameMethodImpl(MethodInstance mi)
    {
        return isSameProc((OOMatchProcedureInstance)mi);
    }
    
    public boolean hasFormalsImpl(List formalTypes) {
        return formalTypes.equals(paramTypes());
    }
    
    //Copied from the super implementation, except we have to
    //check the parameter types instead of the formal types to
    //check whether methods are equal.
    public boolean equalsImpl(TypeObject o) {
        if (o instanceof OOMatchMethodInstance) {
            OOMatchMethodInstance i = (OOMatchMethodInstance) o;
            // FIXME: Check excTypes too?
            //(That fixme was present in the equalsImpl copied from the superclass)
            if (this == i) return true;
            return name.equals(i.name())
                && ts.equals(returnType, i.returnType())
                && flags.equals(i.flags())
                && ts.equals(container, i.container())
                && paramTypes().equals(i.paramTypes()) &&
                !hasWhereClause() && !i.hasWhereClause();
        }
        return false;
    }
    public boolean canOverrideImpl(MethodInstance mj, boolean quiet) throws SemanticException {
        //We want to do all the checks in the Polyglot version of this method
        //except the check that the arguments are the same, because they don't need
        //to be.
        //Polyglot's check for final isn't quite right either, so make sure it
        //won't give an error for overiding a final method (we do that check ourselves)
        MethodInstance cp = (MethodInstance)mj.copy();
        cp = cp.formalTypes(this.paramTypes());
        cp = cp.flags(cp.flags().clearFinal());
        //        if (!cp.paramTypes().equals(this.formalTypes()))
            //throw new Error();
        return super.canOverrideImpl(cp, quiet);
    }
    
    /*Array saying whether each parameter is a named parameter (referencing a
     * class variable or other name in the parameter patterns).
     */
    private boolean[] isNamedParam = null;
    public boolean[] isNamedParam() { return isNamedParam; }
    public void setIsNamedParam(boolean[] isNamedParam) { 
        this.isNamedParam = isNamedParam; 
    }

    //Flag to set when a dispatcher should not be created for this method.
    //It gets set if it overrides a regular Java method.
    private boolean noDispatcher = false;
    public void setNoDispatcher() { noDispatcher = true; }
    public boolean noDispatcher() { return noDispatcher; }
}
