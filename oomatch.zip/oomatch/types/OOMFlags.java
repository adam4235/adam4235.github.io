package polyglot.ext.oomatch.types;

import polyglot.types.Flags;

/**New flags for methods, etc. that are in OOMatch but not Java*/
public class OOMFlags extends Flags
{

    public OOMFlags(long bits)
    {
        super(bits);
    }
    public static final Flags INC = createFlag("inc", null);
    private static final long serialVersionUID = 599372818;

}
