package polyglot.ext.oomatch.types;

import polyglot.ext.jl.types.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.types.MethodInstance;
import polyglot.types.Type;

import java.util.*;

import polyglot.types.*;
import polyglot.util.TypedList;

/** Represents a deconstructor in the typesystem. */

public class DeconstructorInstance extends ProcedureInstance_c implements
		AbstractMethodInstance {

	public DeconstructorInstance() {
		super();
	}

    protected List paramNames;
    
    public List paramNames() { return paramNames; }
    
    protected String realName = "";
    public String realName() { return realName; }
    public void setRealName(String realName) { this.realName = realName; }

    String name;
    public String name() { return name; }
    
	public DeconstructorInstance(MethodInstance mi, List params, NormalParam onClause)
    throws SemanticException
/*			TypeSystem ts, Position pos,
			ReferenceType container, Flags flags, Type returnType, String name,
			List formalTypes, List excTypes)*/ 
	{
        /*
		super(mi.typeSystem(), mi.position(), mi.container(), 
				mi.flags(), mi.returnType(), mi.name(), mi.formalTypes(),
				mi.throwTypes());
                */
        super(mi.typeSystem(), mi.position(), mi.container(), mi.flags(),
                mi.formalTypes(), mi.throwTypes());
        this.name = mi.name();
        
        paramNames = new ArrayList(params.size());
        
        List realFormalTypes = new ArrayList(params.size());
        for (Iterator i = params.iterator(); i.hasNext();)
        {
            Object o = i.next();
            if (!(o instanceof NormalParam))
            {
                throw new SemanticException("Deconstructors cannot contain patterns.", mi.position());
            }
            NormalParam p = (NormalParam)(o);
            
            paramNames.add(p.formal().name());
            realFormalTypes.add(p.formal().type().type());
        }
        //set them again, so that the "on" clause won't
        //be included
        this.formalTypes = TypedList.copyAndCheck(realFormalTypes, Type.class, true);
        if (onClause != null)
        {
            //The type of the on clause should have been
            //disambiguated in DeconstructorDecl_c.disambiguate.
            Type t = onClause.formal().type().type();
            
            if (ts.String().equals(t))
                throw new SemanticException("Can't deconstruct String.");
            else if (t instanceof ClassType)
                onType = (ClassType)t;
            else
                throw new SemanticException("\"on\" clause must contain a formal of class type.", onClause.position());
        }
	}
    
    //The type from the "on" clause, or null if there is no "on" clause.
    private ClassType onType = null;
    public ClassType onType() { return onType; }
    
    public List paramTypes() { return formalTypes; }
    
    /** @return Whether pattern, which is a List of Type, matches the types
     * of the deconstructor's parameters exactly (i.e. each parameter's type is
     * the same, and not a strict subtype).
     */
    public boolean exactlyMatch(List pattern)
    {
        return generalMatch(pattern, true);
    }
    
    /** @return Whether pattern, which is a List of Type, can be passed
     * as a list of arguments to this deconstructor.  I.e., whether the
     * arguments can be deconstructed by this deconstructor.
     */
    public boolean match(List pattern)
    {
        return generalMatch(OOMatchMethodInstance.javaTypes(pattern), false);
    }
    
    //Common helper method called by both the above methods
    private boolean generalMatch(List pattern, boolean exactly)
    {
        List deconParams = formalTypes();
        if (deconParams.size() != pattern.size()) return false;
        for (Iterator i = pattern.iterator(), j = deconParams.iterator(); i.hasNext();)
        {
            Type t1 = (Type)(i.next());
            Type t2 = (Type)(j.next());
            if (exactly)
            {
                if (!t1.equals(t2)) return false;
            }
            else
            {
                if (!t1.isSubtype(t2)) return false;
            }
        }
        return true;
    }
    public boolean shouldBeRenamed()
    {
        //All deconstructors need to be renamed because they'll become a method with
        //no parameters later on, which means that overloaded deconstructors would
        //cause a duplicate method definition if they weren't renamed.
        return true;
    }

    public String toString() {
        return "deconstructor " +
                       signature();
    }
	private static final long serialVersionUID =  95518260;  //since MethodInstance
	//is Serializable, this is apparantly necessary.  I don't fully
	//understand it.

    
    //BEGIN junk copied from MethodInstance (stupid Java and lack of multiple
    //inheritance)
    
    private int id;
    public int getID() { return id; }
    public void setID(int id) { this.id = id; }
    
    public boolean isSameProc(OOMatchProcedureInstance other)
    {
        if (other instanceof DeconstructorInstance)
        {
            DeconstructorInstance d = (DeconstructorInstance)other;
            return d.name().equals(name()) && d.formalTypes().equals(formalTypes());
        }
        return false;
    }
    public boolean sameName(OOMatchProcedureInstance other)
    {
        return other instanceof DeconstructorInstance &&
        ((DeconstructorInstance)other).name().equals(name());
    }
    public Type typeOf() { return ts.Boolean(); }
    
    public String signature() {
        return name + "(" + PatternType_c.printParamList(formalTypes) + ")";
    }

    public String designator() {
        return "deconstructor";
    }
    public boolean isCanonical() {
        return container.isCanonical()
            && listIsCanonical(formalTypes)
            && listIsCanonical(excTypes);
        }

}
