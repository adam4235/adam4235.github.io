package polyglot.ext.oomatch.types;

import polyglot.ext.jl.types.Type_c;
import polyglot.types.*;
import polyglot.util.Position;
import polyglot.ast.*;

public class ValueType_c extends Type_c implements ValueType {

    protected Type typeOfValue;
    protected Object constantValue;
    
    public Object constantValue() { return constantValue; }
    
    public Type typeOfValue() { return typeOfValue; }
    
    public ValueType_c(TypeSystem ts, Position pos, Type typeOfValue, Lit value) {
        super(ts, pos);
        this.typeOfValue = typeOfValue;
        this.constantValue = value.constantValue();
    }

    //I don't think this method ever gets called, because the translator never
    //gets to a value type.
    public String translate(Resolver c) {
        return null;
    }

    public String toString() {
        if (constantValue == null)
            return "null";
        else if (constantValue instanceof String)
            return "\"" + constantValue.toString() + "\"";
        else if (constantValue instanceof Character)
            return "'" + constantValue.toString() + "'";
        else
            return constantValue.toString();
    }

    public boolean equalsImpl(TypeObject other) 
    {
        if (other instanceof ValueType)
        {
            ValueType v = (ValueType)other;
            //These next 2 if blocks are necessary because value.constantValue() might be null,
            //and calling .equals on null causes a crash.
            if (constantValue() == null && v.constantValue() == null)
                return true;
            else if (constantValue() == null || v.constantValue() == null)
                return false;
            else
                return constantValue().equals(v.constantValue());
        }
        else return false;
    }
 
    /**@return Whether this type is preferred over a regular type p2*/
    public boolean formalPreferred(Type p2)
    {
        //Yes, this code is horribly ugly, and uses cloning.
        //But I don't know of an alternative, given the limitations of Java.
        if (constantValue() == null)
            return p2 instanceof ReferenceType;
        else if (constantValue() instanceof String)
            return p2.equals(ts.String());
        else if (!ts.isCastValid(typeOfValue, p2))
        {
            return false;
        }
        else if (typeOfValue.isBoolean())
        {
            return p2.isBoolean();
        }
        else if (typeOfValue.isChar())
        {
            char val = ((Character)constantValue).charValue();
            if (p2.isByte())
                return (byte)val == val;
            else if (p2.isShort())
                return (short)val == val;
            else return true;
        }
        else if (typeOfValue.equals(ts.Int()))
        {
            int val = ((Integer)constantValue).intValue();
            if (p2.isByte())
                return (byte)val == val;
            else if (p2.isShort())
                return (short)val == val;
            else if (p2.isChar())
                return (char)val == val;
            else return true;
        }
        else if (typeOfValue.equals(ts.Long()))
        {
            long val = ((Long)constantValue).longValue();
            if (p2.isByte())
                return (byte)val == val;
            else if (p2.isShort())
                return (short)val == val;
            else if (p2.isChar())
                return (char)val == val;
            else if (p2.isInt())
                return (int)val == val;
            else return true;
        }
        else if (typeOfValue.equals(ts.Float()))
        {
            float val = ((Float)constantValue).floatValue();
            if (p2.isByte())
                return (byte)val == val;
            else if (p2.isShort())
                return (short)val == val;
            else if (p2.isChar())
                return (char)val == val;
            else if (p2.isInt())
                return (int)val == val;
            else if (p2.isLong())
                return (long)val == val;
            else return true;
        }
        else if (typeOfValue.equals(ts.Double()))
        {
            double val = ((Double)constantValue).floatValue();
            if (p2.isByte())
                return (byte)val == val;
            else if (p2.isShort())
                return (short)val == val;
            else if (p2.isChar())
                return (char)val == val;
            else if (p2.isInt())
                return (int)val == val;
            else if (p2.isLong())
                return (long)val == val;
            else if (p2.isFloat())
                return (float)val == val;
            else return true;
        }
        else throw new Error("");
    }
    

    private static final long serialVersionUID = 67603471;
}
