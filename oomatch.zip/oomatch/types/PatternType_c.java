package polyglot.ext.oomatch.types;

/** 
 * This implementation contains a delegate ClassType, the type of the pattern's
 * deconstructor, so that this type acts like that type when asked for methods etc.
 * However, for subtyping, it has special functionality to determine whether it's a
 * subtype of another type.
 */

// The need for a delegate is the cause of the seemingly extraneous little methods;
// we can't copy the passed ClassType to this object in the constructor, because
// ClassType is an interface and there's no way in Java to declare that subclasses  
// of an interfaces must provide a copy constructor.

import java.util.Iterator;
import java.util.List;

import polyglot.types.*;
import polyglot.ext.jl.types.Type_c;

import polyglot.util.Position;

public class PatternType_c extends Type_c implements PatternType {

    ClassType deconstructorType;
    List pattern;
    DeconstructorInstance decon;
    
    public ClassType deconstructorType() {
        ClassType onType = decon().onType(); 
        if (onType == null)
            return deconstructorType;
        else
            return onType;
    }
    public List pattern() { return pattern; }
    public DeconstructorInstance decon() { return decon; }
    
    public String varName() { return varName; }
    String varName;
    
    public PatternType_c(TypeSystem ts, Position pos, ClassType deconstructorType, List pattern, DeconstructorInstance decon, String varName)
    {
        super(ts, pos);
        this.deconstructorType = deconstructorType;
        this.pattern = pattern;
        this.decon = decon;
        this.varName = varName;
        isNamedParam = new boolean[pattern.size()];
    }
    
    //I don't think this method ever gets called, because the translator never
    //gets to a pattern type.
    public String translate(Resolver c) {
        return null;
    }

    /**@return whether the pattern of this type exactly
     * matches the types in its deconstructor
     */
    public boolean exactlyMatch()
    {
        return (decon().exactlyMatch(OOMatchMethodInstance.javaTypes(pattern)));
    }

    public boolean equalsImpl(TypeObject other) 
    {
        if (other instanceof PatternType)
        {
            PatternType p = (PatternType)other;
            return decon().equals(p.decon()) && 
                   pattern().equals(p.pattern()) &&
                   deconstructorType().equals(p.deconstructorType());
        }
        else return false;
    }
    
    public static String printParamList(List params)
    {
        String retVal = "";
        Iterator i = params.iterator();
        while (i.hasNext())
        {
            Type p = (Type)(i.next());
            retVal += p;
            if (i.hasNext()) retVal += ", ";
        }
        return retVal;
    }

    public String toString()
    {
        return deconstructorType + "." + decon().name() + "(" + printParamList(pattern()) + ")";
    }
    
    private static final long serialVersionUID = 704824376;
    
    private boolean[] isNamedParam = null;
    public boolean[] isNamedParam() { return isNamedParam; }
    public void setIsNamedParam(boolean[] isNamedParam) { 
        this.isNamedParam = isNamedParam; 
    }
}
