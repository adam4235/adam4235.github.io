package polyglot.ext.oomatch.types;

import java.util.List;

import polyglot.types.*;

/**Any procedure that can contain patterns and have dispatch done on it
 * (currently only regular methods, though constructors might be supported in
 * the future)*/
public interface Patternable extends OOMatchProcedureInstance
{
    /** @return The procedures in the class that override this procedure */
    public List children();
    
    /** @return Whether this procedure overrides other */
    public boolean preferred(ProcedureInstance other);
    
    /** @return True iff this procedure contains no patterns or literals, but
     * only regular Java formal parameters.
     * @return
     */
    public boolean hasOnlyFormals();
    
    /**@return whether this intersects with other*/
    public boolean intersectsWith(Patternable other);
    
    /**@return true iff this and other can't possibly both apply to a call.*/
    public boolean cantBothApply(Patternable other);
    
    /** @return Get the OOMatch types of the parameters (PatternType, etc.) */
    public List paramTypes();
    /** Set the OOMatch types of the parameters */
    public OOMatchProcedureInstance paramTypes(List paramTypes);

    public boolean[] isNamedParam();
    public void setIsNamedParam(boolean[] isNamedParam);

    /** True iff the method has a where clause. */
    public boolean hasWhereClause();
    
    public void setNoDispatcher();

}
