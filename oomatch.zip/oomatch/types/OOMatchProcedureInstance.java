package polyglot.ext.oomatch.types;

import polyglot.types.*;

/** Represents a procedure in the typesystem. */

public interface OOMatchProcedureInstance extends ProcedureInstance {
    
    public String realName();
    
    public void setRealName(String realName);
    
    public void setID(int id);
    public int getID();
    
    /** @return The type it "returns" - for a method, the return type.  For a 
     * constructor, the type of the class it's constructing.
     */
    public Type typeOf();
    
    /** @return Whether p needs a new name to avoid duplicate method definitions. */
    public boolean shouldBeRenamed();
    
    /** @return True if this and other have the same name, or are both constructors. */
    public boolean sameName(OOMatchProcedureInstance other);
    
    /** @return True iff this and other are a duplicate definition. */
    public boolean isSameProc(OOMatchProcedureInstance other);
    

}
