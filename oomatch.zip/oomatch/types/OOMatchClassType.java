package polyglot.ext.oomatch.types;

import java.util.*;

import polyglot.ext.jl.types.ParsedClassType_c;
import polyglot.frontend.Source;
import polyglot.types.*;
import polyglot.util.InternalCompilerError;

/**Represents an OOMatch class.  These need to be distinguished from a Java
 * class (which OOMatch code can use).
 * @author a5richar
 *
 */
public class OOMatchClassType extends ParsedClassType_c implements ParsedClassType
{

    public OOMatchClassType()
    {
        super();
    }

    public OOMatchClassType(TypeSystem ts, LazyClassInitializer init,
            Source fromSource)
    {
        super(ts, init, fromSource);
    }
    
    /**@return All the top-level methods in the class, of the same name as p,
     * after the DAG structure
     * has been built, including incomplete methods that were removed because
     * they had a completer in a superclass.
     * @param p A method used to determine whether to get the constructors, methods,
     * or both.  If null, get both; if a constructor, get constructors; if a method,
     * get methods.
     */
    public List getTopLevelOfType(OOMatchProcedureInstance p)
    {
        List retVal;
        if (p == null)  //null means get both types
        {
            retVal = new LinkedList();
            retVal.addAll(methods());
            retVal.addAll(constructors());
            retVal.addAll(removedTopLevel);
            return retVal;
        }
        
        retVal = new LinkedList(spotForSameName(p, this));
        for (Iterator i = removedTopLevel.iterator(); i.hasNext();)
        {
            Object o = i.next();
            if (o instanceof ConstructorInstance && p instanceof ConstructorInstance)
            {
                retVal.add(o);
            }
            else if (o instanceof MethodInstance && p instanceof MethodInstance)
            {
                MethodInstance m1 = (MethodInstance)o, m2 = (MethodInstance)p;
                if (m1.name().equals(m2.name()))
                    retVal.add(o);
            }
        }
        return retVal;
    }
    
    private List removedTopLevel = new LinkedList();
    
    /** When removing top-level incomplete methods that have a completer in a
     * superclass, they have to be passed to this method so they can be retreived
     * again by calling getTopLevelOfType.
     * @param m The method to save.
     */
    public void saveTopLevel(OOMatchProcedureInstance m) { removedTopLevel.add(m); }
    
    /** Remove procedure from the class, if present.  (It should still be present
     * as children of other procedures.) */
    public void removeProcedure(OOMatchProcedureInstance procedure)
    {
        List members = spotFor(procedure, this);
        members.remove(procedure);
    }
    
    /** @return Either the methods or the constructors of the class, depending
     * on whether procedure is a method or constructor.
     */
    public static List spotFor(OOMatchProcedureInstance procedure, ClassType t)
    {
        if (procedure instanceof ConstructorInstance)
        {
            return t.constructors();
        }
        else if (procedure instanceof MethodInstance)
        {
            return t.methods();
        }
        else throw new Error("Unrecognized procedure type.");
    }

    /** @return Like the previous, but only return methods of the same name
     * as procedure.
     */
    public static List spotForSameName(OOMatchProcedureInstance procedure, ClassType t)
    {
        if (procedure instanceof ConstructorInstance)
        {
            return t.constructors();
        }
        else if (procedure instanceof MethodInstance)
        {
            return t.methodsNamed(((MethodInstance)procedure).name());
        }
        else throw new Error("Unrecognized procedure type.");
    }

    /** Get all methods and their children from methods */
    public static Set allMethods(Collection methods)
    {
        Set retVal = new LinkedHashSet();
        for (Iterator i = methods.iterator(); i.hasNext(); )
        {
            ProcedureInstance p = (ProcedureInstance)i.next();
            retVal.add(p);
            List children = ((Patternable)p).children();
            if (children.contains(p))
            {
                throw new InternalCompilerError("The child of " + p + " is itself.");
            }
            if (p instanceof Patternable)
                retVal.addAll(allMethods(children));
        }
        return retVal;
    }
    
    /** Get the integer ID that the assignment of IDs to methods in this class
     * should start from.  This is to ensure that methods aren't given the same
     * ID that methods in superclasses got.
     */
    public int startingID()
    {
        Type t = superType();
        int retVal = 1;
        while (!t.equals(ts.Object())) {
            if (t instanceof OOMatchClassType)
            {
                OOMatchClassType ct = (OOMatchClassType)t;
                Collection M = allMethods(ct.getTopLevelOfType(null));
                if (retVal + M.size() < retVal)
                {
                    //if overflow can occur
                    throw new ArithmeticException("Can't have more than " + Integer.MAX_VALUE + " methods in a class heirarchy.");
                }
                retVal += M.size();
            }
            t = ((ClassType)t).superType();
        }
        return retVal;
    }
    
    public void setDollarSigns(String dollarSigns) {
        this.dollarSigns = dollarSigns;
    }
    public String getDollarSigns() { return dollarSigns; }
    private String dollarSigns;
    
    private List deconstructors = new LinkedList();
    public List deconstructors() { return deconstructors; }
    public void addDeconstructor(DeconstructorInstance di)
    {
        deconstructors.add(di);
    }
    private static final long serialVersionUID = 494676137;
}
