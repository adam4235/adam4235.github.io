package polyglot.ext.oomatch.types;

import java.util.List;

import polyglot.types.*;

public interface OOMatchTypeSystem extends TypeSystem {
    public DeconstructorInstance findMostSpecificDeconstructor(List acceptable,
            ReferenceType container, List pattern, ClassType currClass)
        throws SemanticException;

}
