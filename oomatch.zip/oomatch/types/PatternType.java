package polyglot.ext.oomatch.types;

/** The type of a pattern in a method header.*/

import java.util.List;

import polyglot.types.*;

public interface PatternType extends Type {
    
    /** Get the deconstructor's exact type */
    public ClassType deconstructorType();
    
    /** Get the pattern as a List of Type */
    public List pattern();
    
    /**The variable name given by the programmer (or "")*/ 
    public String varName();
    
    /** Get the deconstructor that the pattern is deconstructing on
     * (There will always be exactly one which is known at compile time) */
    public DeconstructorInstance decon();
    
    /** @return Whether the pattern exactly matches the corresponding
     * deconstructor, i.e. whether the pattern's types equal
     * the types of the deconstructor's parameters 
     * @return
     */
    public boolean exactlyMatch();
    
    public boolean[] isNamedParam();
    
    public void setIsNamedParam(boolean[] isNamedParam);
}
