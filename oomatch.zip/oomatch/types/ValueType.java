package polyglot.ext.oomatch.types;

/** The type of a literal value in a parameter. */

import polyglot.types.Type;

public interface ValueType extends Type
{
    public Type typeOfValue();
    public Object constantValue();
    public boolean formalPreferred(Type p2);
}
