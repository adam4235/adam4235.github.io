package polyglot.ext.oomatch.types;

/**Any procedure with a name (i.e. not constructors)*/
public interface AbstractMethodInstance extends OOMatchProcedureInstance
{
    /**
     * The method's name.
     */
    String name();

}
