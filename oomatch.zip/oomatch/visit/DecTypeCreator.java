package polyglot.ext.oomatch.visit;

import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ContextVisitor;
import polyglot.ext.oomatch.ast.*;

/** Create an (ambiguous) type for the deconstructor reference.  This way
 * it will get disambiguated later, at the correct time. */
public class DecTypeCreator extends ContextVisitor
{

    public DecTypeCreator(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node n) 
        throws SemanticException 
    {
        if (n instanceof PatternParam)
        {
            return ((PatternParam)n).setDecType(this);
        }
        return n;
    }
}
