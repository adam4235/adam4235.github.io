package polyglot.ext.oomatch.visit;

import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ext.oomatch.ast.*;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ContextVisitor;
import polyglot.visit.NodeVisitor;

/** Find the types of Params in the AST.  Needed to be able to later construct the
 * ProcedureInstances. */

//No longer used.

public class ParamTypesVisitor extends ContextVisitor
{

    public ParamTypesVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v)
    throws SemanticException 
    {
        if (n instanceof Param)
        {
            Param nAsParam = (Param)n;
            return nAsParam.assignType((ParamTypesVisitor)v);
        }
        else return n;
    }

}
