package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.*;
import java.util.*;
import polyglot.util.*;
import polyglot.ext.oomatch.types.*;

/**Transform method calls to pass the extra static type 
 * information to the dispatchers*/

public class TransformCallsVisitor extends ContextVisitor
{

    public TransformCallsVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }

    protected Node leaveCall(Node n)
    throws SemanticException
    {
        if (n instanceof Call)
        {
            Call c = (Call)n;
            OOMatchMethodInstance mi = (OOMatchMethodInstance)c.methodInstance();
            
            if (mi.container() instanceof OOMatchClassType && //Not a Java class
                    
                    //We shouldn't translate only methods that shouldBeRenamed, because
                    //abstract methods are getting extra parameters and so need extra args
                    //as well.
                    !mi.isMain() && !mi.noDispatcher())
            {
                return c.arguments(addNewArgs(c.arguments()));
            }
        }
        /*  constructors aren't being done
        else if (n instanceof New)
        {
            New nw = (New)n;
            if (nw.constructorInstance().container() instanceof OOMatchClassType)
            {
                OOMatchConstructorInstance ci = 
                    (OOMatchConstructorInstance)nw.constructorInstance();
                MethodInstance mi = ts.methodInstance(ci.position(),
                        ci.container(), ci.flags(), ci.container(), ci.realName(),
                        ci.formalTypes(),
                        ci.throwTypes());
                
                TypeNode qual = nf.CanonicalTypeNode(ci.position(), ci.container());
                Call retVal = nf.Call(nw.position(), qual, ci.realName(), addNewArgs(nw.arguments()));
                retVal = retVal.methodInstance(mi);
                retVal = (Call)retVal.type(ci.container());
                return retVal;
            }
        }*/
        
        return n;
    }
    
    public List addNewArgs(List args)
    {
        List newArgs = new ArrayList(args.size() * 2);
        newArgs.addAll(args);
        for (Iterator i = args.iterator(); i.hasNext(); )
        {
            Expr arg = (Expr)i.next();
            Type t = arg.type();
            if (t instanceof ClassType)
            {
                //For anonymous classes, they don't have a class literal
                ClassType ct = (ClassType)arg.type();
                if (ct.isAnonymous())
                    t = ct.superType();
            }

            if (t.equals(ts.Null()))
            {
                newArgs.add(nf.NullLit(arg.position()).type(ts.Null()));
            }
            else newArgs.add(newArg(t, nf, ts));
        }
        return newArgs;
    }

    public static Expr newArg(Type argType, NodeFactory nf, TypeSystem ts)
    {
        Position pos = argType.position();
        Expr newArg;
        /*
        if (argType instanceof PrimitiveType)
        {
            newArg = nf.IntLit(pos, IntLit.INT, idOfType(((PrimitiveType)argType).kind()));
            newArg = newArg.type(ts.Int());
        }
        else 
        {*/
            TypeNode staticType = nf.CanonicalTypeNode(pos, argType);
            newArg = nf.ClassLit(pos, staticType);
            /*
            newArg = nf.Call(pos, (Expr)arg.copy(), "getClass");
            MethodInstance mi = (MethodInstance)ts.Object().methodsNamed("getClass").get(0);
            newArg = ((Call)newArg).methodInstance(mi);
            */
            newArg = newArg.type(ts.Class());
        //}
        return newArg;

    }
}
