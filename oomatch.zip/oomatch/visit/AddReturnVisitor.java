package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.types.*;
import polyglot.visit.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.frontend.*;
import polyglot.util.*;
import java.util.*;

/**Add "return true" statements to deconstructors, so that if the end
 * of their body is reached, it will assume a match occurred.  This is
 * purely for convenience of the programmer.
 * 
 * This feature is no longer offered (it was too hard to implement), 
 * and hence this class isn't currently
 * used.
 */
public class AddReturnVisitor extends ContextVisitor

{
    public AddReturnVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v)
    throws SemanticException 
    {
        if (n instanceof DeconstructorDecl)
        {
            return addReturn((DeconstructorDecl)n);
        }
        else return n;
    }
    
    public Node addReturn(DeconstructorDecl d)
    {
       Position pos = d.position();
       //Create a statement "return true"
       Stmt newReturn = nf.Return(pos, 
                          nf.BooleanLit(pos, true)
                                .type(ts.Boolean()));
       
       //We have to wrap the former body in an "if (true)", with the new 
       //return statement following it.  If we just put the "return true" statement
       //at the end of the body, and there was already sufficient return statements
       //before, Java will give an error that our new statement isn't reachable.
       If newBody = nf.If(pos, nf.BooleanLit(pos, true)
               .type(ts.Boolean()), d.body());
       List newStatements = new ArrayList(2);
       newStatements.add(newBody);
       newStatements.add(newReturn);
       return d.body(nf.Block(pos, newStatements));
       
    }
}
