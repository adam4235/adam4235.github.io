package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.*;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.*;
import polyglot.util.*;
import java.util.*;

/**Convert named parameters to a new formal parameter and a where clause that checks
 * whether the name is equal to the parameter
 */ 
public class DesugarNamedParams extends ContextVisitor
{

    public DesugarNamedParams(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v) 
        throws SemanticException 
    {
        if (n instanceof OOMatchMethodDecl_c)
        {
            OOMatchMethodDecl_c p = (OOMatchMethodDecl_c)n;
            String dollarSigns = "$" + DollarSignCounter.dollarSignsFromFormals(p.formals());
            paramNum = 0;
            Object[] returned = desugarList(p.params(), dollarSigns, p.position(), 
                    new LinkedList(), p.flags().isStatic());
            List newParams = (List)returned[0];
            Expr whereClause = (Expr)returned[1];
            if (whereClause == null) return p;
            
            p = (OOMatchMethodDecl_c)p.params(newParams);
            
            //Have to set the formals too
            p = (OOMatchMethodDecl_c)p.formals(
                    OOMatchMethodDecl_c.formalsIn(newParams, nf));
            
            //Also have to reset the method instance (type information) for the method
            
            //Find the types of the parameters
            List types = new ArrayList(newParams.size());
            boolean[] isNamedParam = new boolean[newParams.size()];
            int paramNum = 0;
            for (Iterator i = newParams.iterator(); i.hasNext();)
            {
                Param newParam = (Param)i.next();
                isNamedParam[paramNum] = newParam instanceof MadeUpParam;
                ++paramNum;
                types.add(newParam.type());
            }
            ClassType t = (ClassType)p.methodInstance().container();
            Collection methodList = t.methods(); 
            //Remove the old method instance
            methodList.remove(p.methodInstance());

            OOMatchMethodInstance newMI = (OOMatchMethodInstance)p.methodInstance().copy();
            newMI = (OOMatchMethodInstance)newMI.paramTypes(types);
            newMI = newMI.hasWhereClause(true);
            newMI = (OOMatchMethodInstance)newMI.formalTypes(
                    OOMatchMethodInstance.javaTypes(types));
            newMI.setIsNamedParam(isNamedParam);

            p = (OOMatchMethodDecl_c)p.methodInstance(newMI);
            
            //Add the new method instance
            methodList.add(newMI);
            
            //Make the new expression the where clause of the method
            if (p.whereClause() != null)
            {
                whereClause = nf.Binary(p.whereClause().position(), p.whereClause(), 
                        Binary.COND_AND, whereClause);
                whereClause = whereClause.type(ts.Boolean());
            }
            p = p.whereClause(whereClause);
            return p;
        }
        else return n;
    }
    
    int paramNum;  //Keeps track of the number of parameters that have already received
        //made-up names, to prevent clashes.
    
    /**Takes a Param.  Returns a pair: a new Param with names made up, and a
     * condition for the where clause.
     * @param p A parameter to transform.
     * @param dollarSigns The dollar signs to use in the made up name for 
     *      the regular parameter.
     * @param decls The declarations that have been seen so far, for doing non-linear
     *      pattern matching.
     * @param isStatic Whether the method being transformed is static.
     * @return
     */
    private Object[] desugarNamedParams(Param p, String dollarSigns, Collection decls,
        boolean isStatic) throws SemanticException 
    {
        Position pos = p.position();
        OOMatchNodeFactory oomNF = (OOMatchNodeFactory)nf;
        TypedNodeFactory tnf = new TypedNodeFactory(oomNF, (OOMatchTypeSystem)ts, pos);
        
        if (p instanceof NamedParam)
        {
            NamedParam np = (NamedParam)p;
            
            //The name of the new regular parameter being made up
            String argName = "arg" + dollarSigns + paramNum;
            ++paramNum;
            
            Expr npAsExpression;  //The named parameter as an expression
            Type paramType;  //The type of the parameter being created.
            
            Formal nlFormal = nonlinearFormal(np.printParam(), decls);
            if (nlFormal != null)
            {
                //Non-linear pattern matching.  If we've seen the name in the named
                //parameter yet, then check whether it's equal to that parameter
                npAsExpression = tnf.Local(nlFormal);
                paramType = nlFormal.type().type();
            }
            else
            {
                //Reference to a field in the class.
                
                //Note that only fields are allowed to be referenced; not local variables.
                //It might be slightly useful to allow references of local variables too,
                //but would complicate this implementation, because then I'd have to
                //have separate cases to create the expression to reference the variable.
                
                //We have to get the type by looking up the field.
                FieldInstance fi = context.findField(np.printParam()); 
                paramType = fi.type();
                
                //Depending on whether the method is static, prefix the field with
                //the name of the class or not.
                Receiver r;
                if (isStatic)
                {
                    r = nf.CanonicalTypeNode(pos, context.currentClass());
                }
                else
                {
                    r = nf.This(pos);
                }
                npAsExpression = tnf.Field(fi, r); 
           }
            
            //Create the new regular parameter to replace the named parameter
            Formal f = tnf.Formal(Flags.NONE, paramType, argName);
            NormalParam paramRetVal = oomNF.MadeUpParam(pos, f);
            
            //The condition to become the "where" clause
            Expr matchCondition = nf.Binary(pos, npAsExpression, 
                    Binary.EQ, tnf.Local(f));
            matchCondition = matchCondition.type(ts.Boolean());
            if (!paramType.isPrimitive())
            {
                //For objects, do the comparison with .equals.
                //Note that objects also need to be prefixed with an == (above),
                //to handle the case where both the variable being referenced and
                //the incoming argument are null (which means a match should occur.)
                Call equalsCall = tnf.Call(npAsExpression, 
                        (MethodInstance)ts.String().methodsNamed("equals").get(0),
                        tnf.Local(f));
                
                //Prefix the call to equals with a check that the receiver of equals
                //isn't null (so that if it is, the match will fail, rather than the
                //program crashing).
                Expr callWithNullCheck =  nf.Binary(
                        pos, tnf.NE(npAsExpression, tnf.NullLit()), Binary.COND_AND, 
                        equalsCall);
                callWithNullCheck = callWithNullCheck.type(ts.Boolean());
                matchCondition = nf.Binary(pos, matchCondition, Binary.COND_OR, 
                        callWithNullCheck);
                matchCondition = matchCondition.type(ts.Boolean());
            }
            return new Object[] { paramRetVal, matchCondition };

        }
        else if (p instanceof PatternParam)
        {
            PatternParam pat = (PatternParam)p;
            Object[] returned = desugarList(pat.pattern(), dollarSigns, 
                    pos, decls, isStatic);
            List newPattern = (List)returned[0];
            pat = pat.pattern(newPattern);
            PatternType patType = (PatternType)pat.type();
            if (patType != null)  //it might be null for anonymous classes
            {
                boolean isNamedParam[] = patType.isNamedParam();
                int paramNum = 0;
                for (Iterator i = newPattern.iterator(); i.hasNext();)
                {
                    Object o = i.next();
                    if (o instanceof MadeUpParam)
                        isNamedParam[paramNum] = true;
                    else
                        isNamedParam[paramNum] = false;
                    ++paramNum;
                }
            }            
            if (pat.formal() != null)
            {
                //Add declarations for non-linear pattern matching
                decls.add(pat.formal());
            }
            return new Object[] { pat, (Expr)returned[1] };
        }
        else
        {
            if (p instanceof NormalParam)
            {
                //Add declarations for non-linear pattern matching
                NormalParam np = (NormalParam)p;
                decls.add(np.formal());
            }
            return new Object[] { p, null };
        }
    }
    
    /** Desugars a list of Params 
     * @return a pair, the first element being a list of new Params, the
     * second being the condition for the "where" clause.*/
    private Object[] desugarList(List l, String dollarSigns, Position pos, 
            Collection decls, boolean isStatic) throws SemanticException 
    {
        Expr matchCond = null;
        List newList = new ArrayList(l.size());
        for (Iterator i = l.iterator(); i.hasNext();)
        {
            Param param = (Param)i.next();
            Object[] returned = desugarNamedParams(param, dollarSigns, decls, isStatic);
            if (matchCond == null)
            {
                matchCond = (Expr)returned[1];
            }
            else
            {
                matchCond = nf.Binary(pos, matchCond, Binary.COND_AND, 
                        (Expr)returned[1]);
                matchCond = matchCond.type(ts.Boolean());
            }
            newList.add(returned[0]);
        }
        return new Object[] { newList, matchCond };
    }
    /** Return the formal in decls named namedParam, or null if there isn't one */
    public static Formal nonlinearFormal(String namedParam, Collection decls)
    {
        for (Iterator i = decls.iterator(); i.hasNext(); )
        {
            Formal f = (Formal)i.next();
            if (f.name().equals(namedParam))
                return f;
        }
        return null;
    }


}
