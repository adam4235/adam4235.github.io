package polyglot.ext.oomatch.visit;

import polyglot.visit.NodeVisitor;
import polyglot.types.*;
import polyglot.ast.*;
import java.util.*;

import polyglot.util.*;

/**Converts the "return true" or "return false" statements in deconstructors
to return an object containing the deconstructed components*/

public class ConvertReturns extends NodeVisitor
{

    public ConvertReturns(List deconFormals, NodeFactory nf, TypeSystem ts)
    {
        super();
        this.deconFormals = deconFormals;
        this.nf = nf;
        this.ts = ts;
    }

    private List deconFormals;
    private NodeFactory nf;
    private TypeSystem ts;
    
    public static TypeNode boxTypeNode(PrimitiveType pType, NodeFactory nf, TypeSystem ts)
    {
        String s = pType.wrapperTypeString(ts);
        Type boxType;
        try {
            boxType = (Type)ts.systemResolver().find(s);
        }
        catch (SemanticException e)
        {
            throw new Error("");
        }
        TypeNode boxTypeNode = nf.CanonicalTypeNode(pType.position(), boxType);
        return boxTypeNode;

    }
    public Node leave(Node old, Node n, NodeVisitor v)
    {
        
        if (n instanceof Return)
        {
            Return nAsReturn = (Return)n;
            
            Position pos = nAsReturn.position();
            
            List args = new ArrayList(deconFormals.size());
            
            //Create the arguments to the call to the constructor
            for (Iterator i = deconFormals.iterator(); i.hasNext(); )
            {
                Formal f = (Formal)(i.next());
                Type fType = f.type().type();
                Local l = nf.Local(pos, f.name());
                l = l.localInstance(f.localInstance());
                l = (Local)l.type(fType);
                if (fType instanceof PrimitiveType)
                {
                    PrimitiveType pType = (PrimitiveType)fType;
                    List boxConsArgs = new ArrayList(1);
                    boxConsArgs.add(l);
                    List boxConsArgTypes = new ArrayList(1);
                    boxConsArgTypes.add(l.type());
                    TypeNode boxTypeNode = boxTypeNode(pType, nf, ts); 
                    New newCall = nf.New(pos, boxTypeNode, boxConsArgs);
                    newCall = (New)newCall.type(boxTypeNode.type());
                    newCall = newCall.constructorInstance(ts.constructorInstance(
                            pos, (ClassType)boxTypeNode.type(), Flags.PUBLIC, boxConsArgTypes, new LinkedList()));
                    args.add(newCall);
                }
                else args.add(l);
            }
            
            //Create new expression
            TypeNode object = nf.CanonicalTypeNode(pos, ts.Object());
            Type arrayType = ts.arrayOf(ts.Object());
            ArrayInit arrayInit = nf.ArrayInit(pos, args);
            arrayInit = (ArrayInit)arrayInit.type(arrayType);
            Expr newExpr = nf.NewArray(pos, object, 1, arrayInit);
            newExpr = newExpr.type(arrayType);
            Expr oldBooleanExpr = nAsReturn.expr();
            
            //Return null if the expression was false
            Stmt nullRet = nf.Return(pos, nf.NullLit(pos).type(ts.Null()));
            
            //Create if statement to replace the return statement, which
            //returns null instead of false, and an object instead of true.
            return nf.If(pos, oldBooleanExpr, nf.Return(pos, newExpr), nullRet);
        }
        else return n;
    }

}
