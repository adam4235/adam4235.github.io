package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ContextVisitor;

/**Set the name of the methods in the AST to be the new name calculated
 * for them.
 */
public class RenameMethodsVisitor extends ContextVisitor
{

    public RenameMethodsVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node n)
    throws SemanticException 
    {
        if (n instanceof OOMatchMethodDecl_c)
        {
            OOMatchMethodDecl_c p = (OOMatchMethodDecl_c)n;
            if (p.oomProcedureInstance().shouldBeRenamed())  //have to check again,
                    //in case the noDispatcher flag got set
                return p.name(p.oomProcedureInstance().realName());

        }
        else if (n instanceof DeconstructorDecl)
        {
            DeconstructorDecl p = (DeconstructorDecl)n;
            return p.name(p.oomProcedureInstance().realName());

        }
        return n;
        
    }
}
