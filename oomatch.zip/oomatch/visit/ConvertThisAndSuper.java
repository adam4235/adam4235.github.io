package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.ContextVisitor;
import polyglot.visit.NodeVisitor;

//Part of translating select blocks.
//Convert references to "this" and "super" to be qualified with the class that the
//select statement appears in (and not the generated anonymous class).
//Not used because select isn't being implemented.
public class ConvertThisAndSuper extends ContextVisitor
{

    private ClassType typeOfSelect;
    public ConvertThisAndSuper(Job job, TypeSystem ts, NodeFactory nf, ClassType typeOfSelect)
    {
        super(job, ts, nf);
        this.typeOfSelect = typeOfSelect;
    }
    protected NodeVisitor enterCall(Node n) throws SemanticException {
        if (n instanceof ClassBody)
        {
            return bypassChildren(n);
        }
        else return this;
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v) throws SemanticException {
        if (n instanceof Special)
        {
            if (!context().currentClass().equals(typeOfSelect))
            {
                throw new SemanticException("Can't have this or super references " +
                        "in a local or anonymous class which is in a select block.  (Yet.)");
            }
            
            Special nAsSpecial = (Special)n;
            //Add a qualifier to the this or super
            return nAsSpecial.qualifier(nf.CanonicalTypeNode(n.position(), typeOfSelect));
            
            //TODO: convert break to return
        }
        else return n;
    }
}
