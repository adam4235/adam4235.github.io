package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.visit.*;
import polyglot.ext.oomatch.ast.*;

/**Determine the number of dollar signs the variables in the dispatch code for
a "let" statement need to avoid clashing with anything else in the method.*/
public class DollarSignsForLet extends NodeVisitor
{
    public DollarSignsForLet()
    {
        super();
    }

    //Set the dollar signs in all the let statements below
    //a particular node in the AST to dollarSigns.
    private class AssignLetDollarSigns extends NodeVisitor {
        public AssignLetDollarSigns(String dollarSigns)
        {
            super();
            this.dollarSigns = dollarSigns;
        }
        private String dollarSigns;
        public Node leave(Node parent, Node n, NodeVisitor v)
        {
            if (n instanceof Let)
            {
                Let l = (Let)n;
                return l.dollarSigns(dollarSigns);
            }
            else return n;
        }
    }
    public Node leave(Node parent, Node n, NodeVisitor v)
    {
        if (n instanceof CodeDecl)
        {
            CodeDecl c = (CodeDecl)n;
            if (c.body() == null) return n;  //Abstract methods
            String dollarSigns = "";
            if (n instanceof ProcedureDecl)
            {
                //count dollar signs in formals
                ProcedureDecl p = (ProcedureDecl)n;
                dollarSigns = dollarSigns + 
                    DollarSignCounter.dollarSignsFromFormals(p.formals());
            }
            //Count dollar signs in body 
            DollarSignCounter counter = new DollarSignCounter();
            counter.visitEdge(c, c.body());
            dollarSigns = dollarSigns + counter.getResult() + "$";

            AssignLetDollarSigns assigner = new AssignLetDollarSigns(dollarSigns);
            Block newBody = (Block)assigner.visitEdge(c, c.body());
            return c.body(newBody);
        }
        else return n;
    }
    
}
