package polyglot.ext.oomatch.visit;

/** Adds deconstructors to the class in the typesystem. 
 * Necessary because we have to process deconstructors before methods, since
 * knowledge of deconstructors is necessary to find the type of method headers.*/

import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ext.oomatch.ast.DeconstructorDecl;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.AddMemberVisitor;
import polyglot.visit.NodeVisitor;

public class AddDeconstructorVisitor extends AddMemberVisitor
{

    public AddDeconstructorVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }

    protected NodeVisitor enterCall(Node n) throws SemanticException {
        if (n instanceof DeconstructorDecl)
            return ((DeconstructorDecl)n).realAddMembersEnter(this);
        else return this;
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v) throws SemanticException {
        if (n instanceof DeconstructorDecl)
            return super.leaveCall(old, n, v);
        else return n;
    }
}
