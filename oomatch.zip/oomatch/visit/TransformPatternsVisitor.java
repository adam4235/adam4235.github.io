package polyglot.ext.oomatch.visit;

import java.util.*;

import polyglot.ast.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.*;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.util.*;
import polyglot.visit.ContextVisitor;

/**Transform OOMatch code to Java.*/
public class TransformPatternsVisitor extends ContextVisitor
{

    public TransformPatternsVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
        mapOfIDToPrim = mapOfIDToPrimitive();
    }

    public Position position()
    {
        return pos;
    }
    protected Node leaveCall(Node n)
    throws SemanticException 
    {
        if (n instanceof OOMatchClassDecl_c)
        {
            OOMatchClassDecl_c nAsClass = (OOMatchClassDecl_c)n;
            classBodyToTrans = nAsClass.body();
            classTypeToTrans = nAsClass.type();
            init(n);
            return nAsClass.body(transformDeconstructors(addCompleters()));
        }
        else if (n instanceof New)
        {
            //Transforming anonymous classes
            New nAsNew = (New)n;
            if (nAsNew.body() == null) return n;  //no anonymous class present
            classBodyToTrans = nAsNew.body();
            classTypeToTrans = nAsNew.anonType();
            init(n);
            return nAsNew.body(transformDeconstructors(addCompleters()));
        }
        else if (n instanceof Let)
        {
            init(n);
            return transformLet((Let)n);
        }
        else return n;
    }

    //initialize variables that are only used to transform each class
    void init(Node n)
    {
        pos = n.position();
        tnf = new TypedNodeFactory((OOMatchNodeFactory)nf, (OOMatchTypeSystem)ts, pos);
    }
    
    Position pos = null;
    ClassBody classBodyToTrans = null;
    ClassType classTypeToTrans = null;
    TypedNodeFactory tnf = null;
    
    private ClassBody transformDeconstructors(ClassBody oldBody)
    {
        List members = oldBody.members();
        List newMembers = new ArrayList(members.size());
        for (Iterator i = members.iterator(); i.hasNext();)
        {
            ClassMember m = (ClassMember)(i.next());
            if (m instanceof DeconstructorDecl)
            {
                DeconstructorDecl d = (DeconstructorDecl)m;
                if (!d.flags().isAbstract())  //abstract deconstructors must
                    //be removed from the output code
                {
                    newMembers.addAll(transformDeconstructor(d));
                }
            }
            else
                newMembers.add(m);
        }
        return oldBody.members(newMembers);
    }
    
    /** Transform d from OOMatch to Java. 
     * @return A List containing the new version of d and a class for its
     *      return value. */
    private List transformDeconstructor(DeconstructorDecl d)
    {
        //convert return statements to return the class associated 
        //with the deconstructor
        ConvertReturns converter = new ConvertReturns(d.formals(), nf, ts);
        Block newBody = (Block)(converter.visitEdge(d, d.body()));
        
        boolean hasOnClause = d.onClause() != null;
        
        //Get the list of formals to make into local variables at the
        //start of the method
        List outFormals = new ArrayList(d.formals());
        if (hasOnClause)
        {
            //For static deconstructors, don't put the class parameter 
            //(the object
            //being deconstructed) at the start of the method.
            outFormals.remove(outFormals.size() - 1);
        }
        
        //Put the formals as local variables in the start of the method
        for (Iterator i = outFormals.iterator(); i.hasNext();)
        {
            Formal f = (Formal)(i.next());
            
            LocalDecl s = tnf.LocalDecl(f.type(), f.name(), null);
            newBody = newBody.prepend(s);
        }
        DeconstructorDecl newDeconstructor = (DeconstructorDecl)(d.body(newBody));
        
        List parameters = new LinkedList();
        if (hasOnClause)
        {
            //Make deconstructors with an "on" clause be static and have the
            //on clause as a parameter.
            parameters.add(newDeconstructor.onClause().formal());
            newDeconstructor = (DeconstructorDecl)newDeconstructor
                .flags(newDeconstructor.flags().Static());
        }
        
        TypeNode objArray = nf.CanonicalTypeNode(position(),ts.arrayOf(ts.Object()));
        //Make the deconstructor have no parameters.
        newDeconstructor = (DeconstructorDecl)(newDeconstructor
                .formals(parameters)
                
                //and an appropriate return type
                .returnType(objArray));

        
        //Now that the parameters have been moved to local variable declarations
        //with no initializations, running an InitChecker should find cases where
        //they don't all get a value (since they're passed to the constructor in the
        //return statement) as well as cases where they're used before they've been
        //given a value.  Java wouldn't have caught these cases otherwise, because
        //deconstructor parameters are assumed by Java to be "in" parameters, and hence,
        //to have a value.
        
        List newMembers = new LinkedList();
        newMembers.add(newDeconstructor);
        return newMembers;
    }

    //The name of the messageFor method in the class t
    private String messageForName(ClassType t)
    {
        return "messageFor" + ((OOMatchClassType)t).startingID() + ((OOMatchClassType)t).getDollarSigns();
    }

    /**@return The MethodInstance for the messageFor method
     * @param t The class with the messageFor method we want*/ 
    private MethodInstance messageForMI(ClassType t)
    {
        Flags flags = Flags.PUBLIC;

        //usually make messageFor static, unless it wouldn't be accessable always
        if (classTypeToTrans.kind() == ClassType.TOP_LEVEL || 
                classTypeToTrans.flags().isStatic())
        {
            flags = flags.Static();
        }
        

        List formalTypes = new LinkedList();
        formalTypes.add(ts.Int());

        //Set the method instances of the two methods (call existing methods?)
        MethodInstance mi = ts.methodInstance(position(), classTypeToTrans, 
                flags, ts.String(), messageForName(t), formalTypes, new LinkedList());

        return mi;

    }
    
    /** Create the messageFor method, which takes a method ID and returns
     * a string representation of the original method with that ID.  Used
     * for printing ambiguity error messages at runtime.
     * @param methods The methods to give messages for.
     */
    private MethodDecl messageFor(Collection methods)
    {
        //Elements of the "switch" statement
        List switchElements = new LinkedList();
        for (Iterator i = methods.iterator(); i.hasNext();)
        {
            OOMatchProcedureInstance p = (OOMatchProcedureInstance)(i.next());
            
            //case part
            Expr caseExpr = nf.IntLit(position(), IntLit.INT, p.getID());
            caseExpr = caseExpr.type(ts.Int());
            switchElements.add(nf.Case(position(), caseExpr));
            
            //return part
            StringLit strLit = nf.StringLit(position(), p.toString());
            strLit = (StringLit)strLit.type(ts.String());
            Stmt stmt = nf.Return(position(), strLit);
            List stmts = new LinkedList();
            stmts.add(stmt);
            switchElements.add(nf.SwitchBlock(position(), stmts));
        }
        
        //Formal parameter
        Formal messageForFormal = nf.Formal(position(), Flags.NONE, 
                nf.CanonicalTypeNode(position(), ts.Int()).type(ts.Int()), "m");
        LocalInstance formalInstance = ts.localInstance(position(), 
                Flags.NONE, ts.Int(), "m");
        messageForFormal = messageForFormal.localInstance(formalInstance);
        List formals = new LinkedList();
        formals.add(messageForFormal);

        //Switch expression
        Local switchExpr = nf.Local(position(), "m");
        switchExpr = (Local)switchExpr.type(ts.Int());
        switchExpr = switchExpr.localInstance(formalInstance);
        
        //Switch statement
        Stmt stmt = nf.Switch(position(), switchExpr, switchElements);
        Block messageForBody = nf.Block(position(), stmt);

        String messageForName = messageForName(classTypeToTrans);
        
        MethodInstance mi = messageForMI(classTypeToTrans);
        
        int methodNum = ((OOMatchClassType)classTypeToTrans).startingID();
        Stmt finalReturn;
        if (methodNum > 1)
        {
            //need a call to the next higher up messageFor
            CanonicalTypeNode tn = nf.CanonicalTypeNode(position(), classTypeToTrans.superType());
            finalReturn = nf.Return(position(), tnf.Call(tn, messageForMI((ClassType)classTypeToTrans.superType()), tnf.Local(messageForFormal)));
        }
        else
        {
            //need a return "", which can never be reached, to avoid a compile error
            finalReturn = nf.Return(position(), 
                    nf.StringLit(position(), "").type(ts.String()));
        }
        messageForBody = messageForBody.append(finalReturn);

        //return value
        TypeNode retType = nf.CanonicalTypeNode(position(), ts.String());
        retType = retType.type(ts.String());

        MethodDecl messageFor = nf.MethodDecl(position(), mi.flags(), retType, 
                messageForName, formals, new LinkedList(), messageForBody);
        messageFor = messageFor.methodInstance(mi);

        return messageFor;
    }
    
    private Expr binAnd(Expr oldExpr, Expr newExpr)
    {
        return binOp(oldExpr, Binary.COND_AND, newExpr);
    }

    /** Returns the op of oldExpr and newExpr, unless oldExpr is null,
     * in which case it returns newExpr.
     * Useful for building up a boolean expression of &&s.
     */
    private Expr binOp(Expr oldExpr, Binary.Operator op, Expr newExpr)
    {
        if (oldExpr == null) return newExpr;
        else 
            return (Binary)nf.Binary(position(), oldExpr, 
                op, newExpr)
                .type(ts.Boolean());
    }

    //Transform a "let" statement
    public Node transformLet(Let letStmt)
    {
        TypedNodeFactory tnf = new TypedNodeFactory((OOMatchNodeFactory)nf, 
                (OOMatchTypeSystem)ts, letStmt.position());
        String dollarSigns = letStmt.dollarSigns();
        
        Object[] returned = dispatch(
                letStmt.lhs().type(), 
                letStmt.rhs(), 
                "retVal" + dollarSigns,
                null,
                true);
        List statements = new LinkedList();

        //Declare the formals in the pattern
        List formals = OOMatchMethodDecl_c.formalsIn(letStmt.lhs().pattern(), nf);
        for (Iterator i = formals.iterator(); i.hasNext(); )
        {
            Formal f = (Formal)i.next();
            statements.add(tnf.LocalDecl(f.type(), f.name(), null));
        }
        
        List blockStatements = new LinkedList();  //statements within the inner
            //block whose scope should be hidden
        
        //Add declarations for deconstructing.
        blockStatements.addAll((List)returned[0]);
        
        //Condition checking whether let assignment succeeded.
        Expr cond = (Expr)returned[1];
        
        //Assign arguments to formals declared if it succeeds.
        Block successBlock = nf.Block(pos);
        List initExpressions = (List)returned[2];
        for (Iterator i = formals.iterator(), j = initExpressions.iterator(); i.hasNext();)
        {
            Formal f = (Formal)i.next();
            Expr init = (Expr)j.next();
            LocalAssign li = tnf.LocalAssign(tnf.Local(f), init); 
            successBlock = successBlock.append(nf.Eval(pos, li));
        }
        
        //Error to throw if it failed.
        Block failureBlock = nf.Block(pos);
        List throwArgs = new ArrayList(1);
        throwArgs.add(tnf.StringLit("Let assignment failed."));
        failureBlock = failureBlock.append(nf.Throw(pos, tnf.New(ts.Error(), throwArgs)));
        
        //Create the if and add it to the statements in the block
        blockStatements.add(nf.If(pos, cond, successBlock, failureBlock));
        
        //Add the block along with the formal declarations
        statements.add(nf.Block(pos, blockStatements));
        
        //The let is replaced by this StmtList
        return new StmtList(pos, statements);
    }

    /**Returns the components of the dispatch code for a particular parameter of
     * a particular child method.
     * @param childParamType The type of the parameter in the child we're checking for
     *      applicability, i.e. for a match.
     * @param variableDeconstructing A Variable for the parent's parameter, which is
     *      the thing getting deconstructed in the call to the deconstructor.
     * @param decResultName The name to give to the variable holding the result
     *      of the deconstructor call.  It's passed as a parameter so that name
     *      clashes are prevented (the first parameter has $1 appended to its 
     *      corresponding variable, the second has $2 appended, etc.)
     * @param staticTypeParam The parameter holding the static type information
     *      of variableDeconstructing
     * @param addArg True iff we should add the argument generated for the call
     *      to the procedure to the 3rd element of the return value (see below).
     *      It always gets added to the 4th element.
     * 
     * @return A 4-tuple.  The elements are:
     *  1. a list of declarations of local variables
     *      (of type LocalAssign)
     *  2. an expression (Expr) to
     *      put in the "if" statement to check for a match
     *  3. a list of arguments to pass to the call to the
     *      child (overriding method). 
     *  4. the arguments from element 3, plus the ones needed to call the "where"
     *      method to check the where clause for a match.  These arguments include
     *      the made-up parameters from single name parameters, while the other
     *      list doesn't.
     */
    private Object[] dispatch(Type childParamType, 
            Expr variableDeconstructing,
            String decResultName, Expr staticTypeParam, boolean addArg)
    {
        LinkedList declList = new LinkedList(), argList = new LinkedList(),
            whereArgList = new LinkedList();
        Expr matchCondition = null;

        //for each type we're matching against
        if (childParamType instanceof PatternType)
        {
            //only patterns affect the deconstructors that get called
            
            PatternType pt = (PatternType)childParamType;
            DeconstructorInstance d = pt.decon();

            //Check that variableDeconstructing is an instanceof pt.deconstructorType(),
            //and cast appropriately (at run-time)
            Expr[] subTypeRet = subTypeCheck(variableDeconstructing, 
                    pt.deconstructorType(), staticTypeParam);
            
            //We want this instanceof check to go in the match condition, but it will
            //already go there below.
            //matchCondition = subTypeRet[0];
            
            if (!pt.varName().equals(""))
            {
                argList.add(subTypeRet[1]);
                whereArgList.add(subTypeRet[1]);
            }
            
            Type decResultType = ts.arrayOf(ts.Object());
            
            //Create the call to the deconstructor
            Call call;
            if (d.onType() == null)
                call = nf.Call(position(), (Expr)subTypeRet[1].copy(), d.realName());
            else
                call = nf.Call(position(), nf.CanonicalTypeNode(position(), d.container()), d.realName(), (Expr)subTypeRet[1].copy());
            
            call = call.methodInstance(ts.methodInstance(
                    position(), d.container(), d.flags(), ts.Boolean(), d.name(), 
                    d.formalTypes(), d.throwTypes()));
            call = (Call)call.type(decResultType);
            
            //Create the variable declaration
            //TypeNode t = nf.CanonicalTypeNode(position(), d.getReturnTypeClass());
            TypeNode t = nf.CanonicalTypeNode(position(), decResultType);
            LocalDecl decResult = tnf.LocalDecl(t, decResultName, tnf.NullLit());
            declList.add(decResult);
            
            //Initialize the variable, if appropriate
            Local l = tnf.Local(decResult);
            LocalAssign la = tnf.LocalAssign(l, call);
            
            //Condition to check before deconstructing the variable
            Expr cond = nf.Binary(position(), (Expr)variableDeconstructing.copy(), 
                    Binary.NE, tnf.NullLit());
            cond = cond.type(ts.Boolean());
            if (subTypeRet[0] != null)
                cond = binAnd((Expr)subTypeRet[0].copy(), cond);  //add instanceof 
                //check before calling deconstructor
            if (variableDeconstructing instanceof ArrayAccess)
            {
                //If it's deconstructing an element of a previous deconstructor 
                //result, first check
                //that the result itself isn't null.
                //i.e. if (retVal != null && retVal[1] != null)
                ArrayAccess varDecAsArrayAccess = (ArrayAccess)variableDeconstructing;
                Expr arrayCheck = nf.Binary(position(), varDecAsArrayAccess.array(), 
                        Binary.NE, tnf.NullLit());
                arrayCheck = arrayCheck.type(ts.Boolean());
                cond = binAnd(arrayCheck, cond);
            }
            cond = cond.type(ts.Boolean());
            declList.add(nf.If(position(), cond, nf.Eval(position(), la)));
            matchCondition = cond;  //add the condition to the match condition too
            
            //Add a check that the deconstructor returned successfully
            Expr successCheck = nf.Binary(position(), tnf.Local(decResult), Binary.NE, tnf.NullLit()).type(ts.Boolean());
            matchCondition = binAnd(matchCondition, successCheck);
            
            if (pt.pattern().size() != d.paramNames().size())
            {
                throw new Error("Overridden methods should have the " +
                        "same number of parameters.");
            }
            
            //Recursively declare the variables needed for any sub-patterns within pt
            int paramNum = 1;
            for (Iterator i = pt.pattern().iterator(), 
                    j = d.paramTypes().iterator();
                 i.hasNext(); ++paramNum)
            {
                Type newChildParamType = (Type)i.next();
                Type decParamType = (Type)j.next();
                Expr arrayIndex = tnf.IntLit(paramNum-1);
                
                Expr newVarDeconstructing = nf.ArrayAccess(position(), tnf.Local(decResult), 
                        arrayIndex);
                newVarDeconstructing = newVarDeconstructing.type(decParamType);
                if (decParamType instanceof PrimitiveType)
                {
                    //unbox the type
                    PrimitiveType primType = (PrimitiveType)decParamType;
                    ClassType boxClass = boxClass(primType);
                    newVarDeconstructing = newVarDeconstructing.type(boxClass);  //reset
                        //the type to be e.g. Integer instead of int (not strictly
                        //necessary)
                    Expr castExpr = tnf.Cast(boxClass, newVarDeconstructing);
                    newVarDeconstructing = tnf.Call(castExpr, unboxMeth(primType));
                }
                
                Object[] returned = dispatch(newChildParamType, 
                        newVarDeconstructing,  
                        decResultName + "$" + paramNum,
                        null,
                        !pt.isNamedParam()[paramNum-1]);
                declList.addAll((List)returned[0]);
                if (returned[1] != null)
                {
                    matchCondition = binAnd(matchCondition, (Expr)returned[1]);
                }
                argList.addAll((List)returned[2]);
                whereArgList.addAll((List)returned[3]);
            }
        }
        else if (childParamType instanceof ValueType)
        {
            //Match a variable in a parent against a literal in a child.
            //The variable in the parent must be a formal (or a literal of the same
            //value, in which case we do nothing)
            //We only need to add a condition to check that the variable equals the
            //value.  (using == or .equals appropriately)
            ValueType vt = (ValueType)childParamType;

            Lit newLit = ((OOMatchNodeFactory)nf).Lit(position(), vt.constantValue());
            newLit = (Lit)newLit.type(vt.typeOfValue());
            
            if (newLit instanceof StringLit)
            {
                //Ask whether vt.value().equals(variableDeconstructing)
                
                //we assume String has only one method named equals
                matchCondition = tnf.Call(newLit, 
                        (MethodInstance)ts.String().methodsNamed("equals").get(0), variableDeconstructing);
            }
            else
            {
                matchCondition = nf.Binary(position(), variableDeconstructing, 
                        Binary.EQ, newLit).type(ts.Boolean());
                        
            }
        }
        else  //child's type is a regular type
        {
            //Check if the corresponding parameter is an instance of the child
            //parameter's type.
            Expr[] subTypeRet = subTypeCheck(variableDeconstructing, childParamType, staticTypeParam);
            matchCondition = subTypeRet[0];
            if (addArg) argList.add(subTypeRet[1]);
            whereArgList.add(subTypeRet[1]);
            if (staticTypeParam != null)  //If we're not in a subpattern
                //(since the static type of values returned from a deconstructor
                //are always the parameter types)
            {
                
                if (matchCondition != null)    //If there's a chance that the parameter
                    //won't apply
                {
                    if (childParamType instanceof PrimitiveType)
                    {
                        //Add a check for method invocation semantics
        
                        matchCondition = methodInvCheck((PrimitiveType)childParamType, staticTypeParam);
                    }
                    else 
                    {
                        //Add a check for null literals
                        Expr nullCheck = tnf.EQ((Expr)variableDeconstructing.copy(), 
                                tnf.NullLit());
                        Expr classLit = tnf.ClassLit(childParamType);
                        MethodInstance isAssignableMI = 
                            (MethodInstance)ts.Class().methodsNamed("isAssignableFrom").get(0);
                        Call subtypeCheck = tnf.Call(classLit, isAssignableMI,
                                staticTypeParam);
                        
                        Expr classNullCheck = staticNullCheck(staticTypeParam);
                        Expr check = binAnd(nullCheck, 
                                binOp(classNullCheck, Binary.COND_OR, subtypeCheck));
                        matchCondition = binOp(matchCondition, Binary.COND_OR, check);
                    }
                }
            }
        }
        
        return new Object[] {declList, matchCondition, argList, whereArgList};
    }
    
    //If the static type parameter is null, it means a null literal
    //was passed for the corresponding parameter.
    private Expr staticNullCheck(Expr staticTypeParam)
    {
        return tnf.EQ((Expr)staticTypeParam.copy(), tnf.NullLit());
    }

    /**@return The method used to get the primitive value from
     * the boxing class t.
     */
    private String unboxMethName(Type t)
    {
        if (t.equals(ts.Boolean()))
            return "booleanValue";
        else if (t.equals(ts.Byte()))
            return "byteValue";
        else if (t.equals(ts.Char()))
            return "charValue";
        else if (t.equals(ts.Double()))
            return "doubleValue";
        else if (t.equals(ts.Float()))
            return "floatValue";
        else if (t.equals(ts.Int()))
            return "intValue";
        else if (t.equals(ts.Long()))
            return "longValue";
        else if (t.equals(ts.Short()))
            return "shortValue";
        else throw new Error();
    }
    
    /**@return The boxing class for the primitive type t*/
    private ClassType boxClass(PrimitiveType t)
    {
        try {
            String wrapper = t.wrapperTypeString(ts);
            return (ClassType)ts.systemResolver().find(wrapper);
        }
        catch(SemanticException e)
        {
            throw new Error();
        }
        
    }
    
    /**@return The unbox method for the primitive type t*/
    private MethodInstance unboxMeth(PrimitiveType t)
    {
        String methodName = unboxMethName(t);
        ClassType boxClass = boxClass(t);
        return (MethodInstance)boxClass.methodsNamed(methodName).get(0);
    }
    
    /** Create the condition to check whether primitive types apply (to implement
     * the method invocation semantics required by OOMatch)
     * @param childParamType The parameter we're trying to dispatch to.
     * @param staticTypeParam The parameter holding the static type information, which
     *      must be method invocation convertible to childParamType for the match to
     *      succeed.
     * @return
     */
    private Expr methodInvCheck(PrimitiveType childParamType, Expr staticTypeParam)
    {
        Expr result = null;
        for (int i = 1; i <= 8; ++i)
        {
            if (methodInvConvertible(i, childParamType))
            {
                //For each type that could cause staticTypeParam to be an instance
                //of childParamType.
                try {
                    PrimitiveType other = ts.primitiveForName(mapOfIDToPrim[i-1].toString());
                    Expr lit = tnf.ClassLit(other);
                    MethodInstance equalsInstance = 
                        (MethodInstance)ts.Object().methodsNamed("equals").get(0);
                    Call equalsCall = tnf.Call(lit, equalsInstance, staticTypeParam);
                    Expr classNullCheck = staticNullCheck(staticTypeParam);

                    result = binOp(result, Binary.COND_OR, 
                            binOp(classNullCheck, Binary.COND_OR,equalsCall));
                }
                catch (SemanticException e)
                {
                    throw new Error();
                }
            }
        }
        return result;
    }
    
    //Keep a map from the integers 1-8 to each primitive type.
    PrimitiveType.Kind[] mapOfIDToPrim;
    
    public static PrimitiveType.Kind[] mapOfIDToPrimitive()
    {
        return new PrimitiveType.Kind[] {
                PrimitiveType.BOOLEAN,
                PrimitiveType.BYTE,
                PrimitiveType.CHAR,
                PrimitiveType.DOUBLE,
                PrimitiveType.FLOAT,
                PrimitiveType.INT,
                PrimitiveType.LONG,
                PrimitiveType.SHORT
        };
    }
    /**@return Whether the primitve type represented by the integer i is 
     * method invocation convertible to t
     */
    private boolean methodInvConvertible(int i, PrimitiveType t)
    {
        try {
            PrimitiveType other = ts.primitiveForName(mapOfIDToPrim[i-1].toString());
            return other.isImplicitCastValid(t);
        }
        catch (SemanticException e)
        {
            throw new Error();
        }
    }
    
    /** Create the code to check whether variableDeconstructing is an instanceof
     * childParamType, and to cast variableDeconstructing to childParamType.
     * 
     * @param variableDeconstructing
     * @param childParamType
     * @param staticTypeParam
     * @return A pair.  If variableDeconstructing is statically an instance of 
     *      childParamType, then nothing needs to be added; 
     *      return { null, variableDeconstructing }.  If it isn't, then it might still
     *      be at run-time; return in the first element an instanceof expression to
     *      check this, and in the second element a cast expression to pass to the 
     *      call to the child method.
     */
    private Expr[] subTypeCheck(Expr variableDeconstructing, 
            Type childParamType, Expr staticTypeParam)
    {
        Expr cond = null, arg = (Expr)variableDeconstructing.copy(); 
        boolean instanceOfNeeded = !variableDeconstructing.type().isSubtype(childParamType);

        //for deconstructor
        //return values, you always have to cast, because variableDeconstructing
        //will be an element of an Object[]
        boolean castNeeded = instanceOfNeeded || variableDeconstructing instanceof ArrayAccess; 
        if (castNeeded)
        {
            //If the variable being matched is not a subtype of the pattern's type,
            //then the match might fail if, at run-time, it's not an instance of the pattern's
            //type.
            arg = tnf.Cast(childParamType, arg);
        }
        if (instanceOfNeeded) {
            Expr v = (Expr)variableDeconstructing.copy();
            if (childParamType instanceof ReferenceType)
            {
                cond = tnf.Instanceof(v, childParamType);
                
                //Add a check that the static type of the argument is either a
                //subtype or supertype of the parameter.  This is only necessary if
                //instanceOfNeeded is true, because if it's false, then
                //arg dynamic type <: arg static type <: dispatcher type <: dispatch to type,
                //and so it automatically happens that the static type is a subtype of 
                //the child's parameter type.
                
                if (staticTypeParam != null)
                {
                    Expr classNullCheck = staticNullCheck(staticTypeParam);
                    MethodInstance isAssignableMI = 
                        (MethodInstance)ts.Class().methodsNamed("isAssignableFrom").get(0);
                    Expr classLit = tnf.ClassLit(childParamType);
    
                    Call subtypeCheck1 = tnf.Call(classLit, isAssignableMI,
                            staticTypeParam);
                    Call subtypeCheck2 = tnf.Call(staticTypeParam, isAssignableMI,
                            classLit);
                    
                    Expr check =  binOp(classNullCheck, Binary.COND_OR, subtypeCheck1);
                    check = binOp(check, Binary.COND_OR, subtypeCheck2);
                    
                    cond = binOp(cond, Binary.COND_AND, check);
                }
            }
            else
            {
                //For primitive types, will always be false by default if the child
                //isn't a subtype of the parent
                cond = tnf.BooleanLit(false);
            }
            
            //Add the variable for the parent pattern or formal to the list
            //of arguments in the call to the child
        }
        return new Expr[] { cond, arg };
        
    }
    
    /** Create the dispatch code for a single procedure pair of parent p and child child. 
     * @param parentParams a list of either Param or Formal.  The latter option is for
     * convenience so that completers can pass their new formals and get the dispatch
     * code.
     * See the dispatch method for the meaning of the return value.
     * */
    private Object[] dispatchForMethod(List parentParams, List childParamTypes, 
            List staticTypeParams,
            String dollarSigns, int methodNumber, boolean[] isNamedParam)
    {
        Expr matchCondition = null;
        List args = new ArrayList(childParamTypes.size());
        List stmts = new LinkedList();
        List whereArgs = new LinkedList();
        
        if (parentParams.size() != childParamTypes.size())
        {
            throw new Error("");
        }
        int paramNum = 1;
        for (Iterator i = childParamTypes.iterator(), 
                j = parentParams.iterator(),
                k = staticTypeParams.iterator();
             j.hasNext(); ++paramNum)
        {
            Type childType = (Type)i.next();
            Object o = j.next();
            Formal parentFormal;
            if (o instanceof NormalParam)
            {
                NormalParam parentParam = (NormalParam)o;
                parentFormal = parentParam.formal();
            }
            else
            {
                throw new Error("");
            }
            
            NormalParam staticTypeParam = (NormalParam)k.next();
            Formal staticTypeFormal = staticTypeParam.formal();
            
            Local staticLocal = tnf.Local(staticTypeFormal);
            
            String retValName = "retVal" + dollarSigns + methodNumber + "$" + paramNum;
            Object[] returned = dispatch(childType, tnf.Local(parentFormal), 
                    retValName, staticLocal, !isNamedParam[paramNum-1]);
            
            stmts.addAll((List)returned[0]);
            if (returned[1] != null)
            {
                if (matchCondition == null)
                {
                    matchCondition = (Expr)returned[1];
                }
                else
                {
                    matchCondition = binAnd(matchCondition, (Expr)returned[1]);
                }
            }
            args.addAll((List)returned[2]);
            whereArgs.addAll((List)returned[3]);
        }
        
        return new Object[] { stmts, matchCondition, args, whereArgs };

    }

    private List staticTypeParams(int num, List nonConflictingFormals)
    {
        //Create the formals to hold the static type info
        List staticFormals = new ArrayList(num);
        
        for (int paramNum = num + 1, numAdded = 0; numAdded < num; ++numAdded, ++paramNum)
        {   String newName;
            boolean conflict;
            do
            {
                conflict = false;
                newName = "arg" + paramNum;
                
                for (Iterator i = nonConflictingFormals.iterator(); i.hasNext(); )
                {
                    NormalParam p = (NormalParam)i.next();
                    if (p.formal().name().equals(newName))
                    {
                        conflict = true;
                        ++paramNum;
                    }
                    break;
                }
            } while (conflict);
            Type sFormType;
            sFormType = ts.Class();
            Formal f = tnf.Formal(Flags.NONE, sFormType, newName);
            staticFormals.add(((OOMatchNodeFactory)nf).NormalParam(
                    position(), f));
        }
        return staticFormals;
    }
    
    /** Do the actual creation of the completer for d 
     * @return The new procedure */
    private OOMatchProcedureDecl createCompleterFor(Patternable m)
    {
        List newParams = OOMatchMethodInstance.javaTypes(m.paramTypes());

        //Create the list of types that the new completer
        //should have
        //List formalTypes = new ArrayList(m.paramTypes().size()); 
        List completingFormals = new ArrayList(newParams.size());
        List argsForSuper = new ArrayList(newParams.size());

        int paramNum = 1;
        for (Iterator p = newParams.iterator(); p.hasNext(); ++paramNum)
        {
            Type toAdd = (Type)p.next();
            
            //The completer doesn't need flags.  The only possible flag a formal (or
            //pattern) could have is final, and there's no problem making the formal
            //in the corresponding completer non-final.  Final in Java only means
            //you can't assign the variable to a different object in the body of that
            //method.
            Flags theFlags = Flags.NONE;
            
            Formal f = tnf.Formal(theFlags, toAdd, "arg" + paramNum);
            argsForSuper.add(tnf.Local(f));
            completingFormals.add(((OOMatchNodeFactory)nf).NormalParam(
                    position(), f));

        }
        
        //Create the formals to hold the static type info
        List staticFormals = staticTypeParams(newParams.size(), Collections.EMPTY_LIST);

        LinkedList stmts = new LinkedList();  //The statements for the completer

        //Declare methodChosen$ (as an int)
        //We can assume there won't be more methods in a class than the size of an int,
        //because if there were, Polyglot must give some kind of error, because 
        //its data structures have Lists of methods, and a List cannot have more items
        //than the size of an int.
        
        String methChosName = "methodChosen";
        LocalDecl methodChosen = tnf.LocalDecl(
                nf.CanonicalTypeNode(position(), ts.Int()).type(ts.Int()), 
                methChosName, tnf.IntLit(0));
        stmts.add(methodChosen);

        Local methChosLocal = tnf.Local(methodChosen);
/*
        Object[] retValFromList = dispatchForList(m, completingFormals, staticFormals, methChosLocal, classTypeToTrans);
        Boolean alwaysTrue = ((Boolean)retValFromList[1]);
        stmts.add(retValFromList[0]);
  */      
        //Could add an optimization here to check whether we can
        //call a super dispatcher instead of putting the dispatch code
        //in the current dispatcher, but this
        //could get complicated and error-prone.  For the prototype implementation,
        //we aren't too concerned about speed, so it might be best to play it safe.
        
        boolean[] finalOrder = {true, false};
        for (int i = 0; i <= 1; ++i)
        {
            boolean finalMode = finalOrder[i];
            ClassType t = classTypeToTrans;
            Boolean alwaysTrue = new Boolean(false);
            while (!(alwaysTrue.booleanValue()) && !t.equals(ts.Object()) && t instanceof OOMatchClassType)
            {
                
                Object[] retValFromList = dispatchForList(m, completingFormals, staticFormals, methChosLocal, t, finalMode);
                stmts.add(retValFromList[0]);
                alwaysTrue = ((Boolean)retValFromList[1]);
                t = (ClassType)t.superType();
            } 
        }
        Position pos = m.position();  //position to use whenever useless position information is needed
        OOMatchProcedureDecl newMember;

        Stmt noMethodThrow = null;

        //No completer in superclass; need to throw an exception
        //if no method found
        
        //Create throw statement
        List noMethodArgs = new ArrayList(1);
        
        //It would be nice to have a better error message, but it doesn't seem
        //feasible, because the message refers to code in the Java intermediate
        //code instead of the OOMatch input.
        noMethodArgs.add(tnf.StringLit("No method found for call."));
        New noMethodNew = tnf.New(ts.Error(), noMethodArgs);
        noMethodThrow = nf.Throw(pos, noMethodNew);

        //Combine all the formals of the new dispatcher
        List allFormals = new ArrayList(completingFormals.size() + staticFormals.size());
        allFormals.addAll(completingFormals);
        allFormals.addAll(staticFormals);
        
        OOMatchMethodInstance mi;
        String dispatcherName;
        Flags disFlags;
        if (m instanceof OOMatchConstructorInstance)
        {
            //DEAD CODE
            dispatcherName = m.realName();
            disFlags = m.flags().Static();
            mi = (OOMatchMethodInstance)ts.methodInstance(m.position(), m.container(), m.flags(),
                    m.container(), dispatcherName, m.formalTypes(), m.throwTypes());
            
            /*
            stmts.add(noMethodThrow);
            Block body = nf.Block(pos, stmts);
            OOMatchConstructorDecl_c cd = (OOMatchConstructorDecl_c)nf.ConstructorDecl(
                    pos, m.flags(), classTypeToTrans.name(), allFormals, m.throwTypes(), body);
            cd = (OOMatchConstructorDecl_c)cd.constructorInstance(ts.constructorInstance(
                    pos, classTypeToTrans, m.flags(), newParams, m.throwTypes() ));
            newMember = cd*/
            
        }
        else if (m instanceof OOMatchMethodInstance)
        {
            mi = (OOMatchMethodInstance)m;
            dispatcherName = mi.name();
            disFlags = m.flags();

        }
        else
        {
            throw new Error("");
        }
        stmts.add(noMethodThrow);

        //Methods in the output can't be labelled "inc"
        disFlags = disFlags.clear(OOMFlags.INC);

        List throwTypes = new ArrayList(m.throwTypes().size());
        for (Iterator i = m.throwTypes().iterator(); i.hasNext(); )
        {
            Type throwType = (Type)i.next();
            throwTypes.add(nf.CanonicalTypeNode(position(), throwType));
        }
        //Atomic a = new Atomic(pos, stmts);
        //List l = new LinkedList();
        //l.add(a);
        //Block body = nf.Block(pos, l);
        Block body = nf.Block(pos, stmts);
        TypeNode retType = nf.CanonicalTypeNode(pos, mi.returnType());
        OOMatchMethodDecl_c md = (OOMatchMethodDecl_c)nf.MethodDecl(
                pos, disFlags, retType, dispatcherName, 
                allFormals, throwTypes, body);
        md = (OOMatchMethodDecl_c)md.methodInstance(ts.methodInstance(
                pos, classTypeToTrans, disFlags, 
                mi.returnType(), 
                dispatcherName, newParams, m.throwTypes()));
        newMember = md;
        return newMember;

    }

    public void printDAG(List dag, List done)
    {
        //DEBUG
        for (Iterator i = dag.iterator(); i.hasNext(); ) {
            DAGNode p = (DAGNode)i.next();
            if (done.contains(p)) continue;
            for (Iterator j = p.children.iterator(); j.hasNext(); )
            {
                DAGNode child = (DAGNode)j.next();
                System.out.println(child.p + " overrides " + p.p);
            }
            done.add(p);
            printDAG(p.children, done);
        }
    }

    //Remove abstract methods from the DAG, and make their children
    //the new top-level methods.
    private Set removeAbstract(Collection methods)
    {
        Set newMethods = new LinkedHashSet(methods.size());
        for (Iterator i = methods.iterator(); i.hasNext();)
        {
            Patternable instance = (Patternable)i.next();
            if (instance.flags().isAbstract())
            {
                Set toAdd = removeAbstract(instance.children());
                newMethods.addAll(toAdd);
            }
            else newMethods.add(instance);
        }
        return newMethods;
    }
    
    /**Create the dispatch code to check whether a list of methods applies
     * 
     * @param p The method that the dispatcher is being created for
     * @param formals The parameters of the new completer
     * @param staticTypeParams The extra parameters holding static type info
     * @param methChosLocal The integer variable declared to hold the method chosen
     * @param t The class constaining the methods being dispatched to
     * @param finalMode Whether we're only dispatching to final methods.  The final
     *      method semantics are implemented by creating dispatch code twice,
     *      the first time for final methods only, the second time for non-final
     *      methods only
     * @return a pair, the first element being a List of Stmt to add as dispatch code,
     *      the second being a Boolean value saying whether the group of dispatch
     *      possibilities will always find a method.
     */
    private Object[] dispatchForList(Patternable p, List formals, List staticTypeParams, Local methChosLocal, ClassType t, boolean finalMode)
    {
        Collection methods;
        if (t instanceof OOMatchClassType)
        {
            methods = ((OOMatchClassType)t).getTopLevelOfType(p);
        }
        else
        {
            methods = OOMatchClassType.spotForSameName(p, t);
        }

        methods = removeAbstract(methods);
        List retVal = new LinkedList();
        List topLevels = new LinkedList();
        for (Iterator i = methods.iterator(); i.hasNext();)
        {
            Patternable instance = (Patternable)i.next();
            
            //Don't dispatch to abstract methods.
            //if (instance.flags().isAbstract()) continue;
            
            //Only try to dispatch to methods that might possibly apply from the
            //dispatcher.
            if (instance.cantBothApply(p))
                continue;
            
            //Find out whether instance overrides anything; if so, don't add it to
            //the top-level methods, if that top-level method will already be
            //added later.
            //If it does, that thing will also get added as a top-level method.
            boolean overridesSomething = false;
            for (Iterator j = methods.iterator(); j.hasNext(); )
            {
                Patternable toCheck = (Patternable)j.next();
                if (instance != toCheck && instance.preferred(toCheck))
                {
                    //if instance is contained somewhere in the children
                    //of toCheck
                    overridesSomething = true;
                    break;
                }
            }
            if (overridesSomething) continue;
            
            topLevels.add(instance);
        }
        
        List switchElements = new LinkedList();  //Elements for the switch statement
            //to call the appropriate method that applied.

        //Build a DAG representing all the methods to possibly dispatch to,
        //where a node A pointing to another node B means that B overrides A.
        List dag = new ArrayList(topLevels.size());
        methodToDAGNode = new HashMap();

        for (Iterator i = topLevels.iterator(); i.hasNext(); )
        {
            dag.add(buildDAGFor((Patternable)i.next()));
        }
        
        //Keep track of the IDs of methods that are 
        //always going to apply.
        Collection alwaysTrueArr = new LinkedList();
        
        while (dag.size() > 0)
        {
            Set leaves = removeLeaves(dag);
            //System.out.println("Bunch of leaves:");
            for (Iterator i = leaves.iterator(); i.hasNext(); )
            //For each leaf node in the DAG 
            {
                Patternable leaf = (Patternable)i.next();
                
                boolean skip = false;  //whether to skip leaf
                
                //check whether one of the children of leaf is always
                //going to apply.  If so, there's no point in checking
                //leaf (and in fact, for correctness of throw clauses, we
                //can't check leaf).
                for (Iterator j = alwaysTrueArr.iterator(); j.hasNext() && !skip; )
                {
                    Integer alwaysTrueID = (Integer)j.next();
                    Collection allChildren = new LinkedList();
                    allChildren.add(leaf);
                    allChildren = OOMatchClassType.allMethods(allChildren);
                    for (Iterator k = allChildren.iterator(); k.hasNext(); )
                    {
                        Patternable child = (Patternable)k.next();
                        if (child.getID() == alwaysTrueID.intValue())
                        {
                            skip = true;
                            break;
                        }
                    }
                }
                
                if (finalMode == leaf.flags().isFinal()  //only create dispatch
                    //code if the method is final and we're doing final methods,
                    //or if it's not and we're not
                    && !skip)
                {
                    Object[] retValFromProc = 
                        dispatchForProc(formals, leaf, staticTypeParams, methChosLocal);
                    retVal.addAll((List)retValFromProc[0]);
                    switchElements.addAll((List)retValFromProc[1]);
                    Boolean alwaysTrueSingle = (Boolean)(retValFromProc[2]);
                    if (alwaysTrueSingle.booleanValue())
                    {
                        alwaysTrueArr.add(new Integer(leaf.getID()));
                    }
                }
            }
            //Now all the leaf nodes have been removed, yielding new leaf nodes;
            //repeat for the new, smaller DAG.
        }
        
        //Add switch statement to check which method applied
        if (switchElements.size() > 0)
        {
            retVal.add(nf.Switch(position(), methChosLocal, 
                    switchElements));
        }
        return new Object[] { nf.Block(position(), retVal), new Boolean(alwaysTrueArr.size() > 0) };
    }
    
    /** The DAG structure.  We can't use the existing structure made available
     * from OOMatchProcedureIntance.children() because we have to modify the DAG
     * and get a smaller one.
     */
    private static class DAGNode {
        public List children;
        public OOMatchProcedureInstance p;
        public DAGNode(List children, OOMatchProcedureInstance p)
        {
            this.children = children;
            this.p = p;
        }
    }
    
    //Map of methods to DAGNodes.  Needed to ensure that a method only appears in the
    //DAG once (e.g. if you had two top-level methods, neither of which is preferred
    //over the other, but a third method which overrides both of them).
    HashMap methodToDAGNode;
    
    /**Remove, and return, all leaves from the DAG with root nodes dagNodes
     * (which is a List of DAGNode).  Returns a Set to prevent returning duplicate
     * copies of the same method (if a diamond structure is present).
     */
    private Set removeLeaves(List dagNodes)
    {
        //We can't remove and return them all at once because of
        //the possibility of a node being reached twice while traversing
        //the DAG and its children having been removed the first time.
        Set leaves = getLeaves(dagNodes);
        removeLeaves(dagNodes, leaves);
        return leaves;
    }
    
    private Set getLeaves(List dagNodes)
    {
        Set retVal = new LinkedHashSet();
        for (Iterator i = dagNodes.iterator(); i.hasNext(); )
        {
            DAGNode n = (DAGNode)i.next();

            if (n.children.size() == 0)
            {
                retVal.add(n.p);
            }
            else
            {
                retVal.addAll(removeLeaves(n.children));
            }
        }
        return retVal;
    }
    private void removeLeaves(List dagNodes, Set leaves)
    {
        List toRemove = new LinkedList();
        for (Iterator i = dagNodes.iterator(); i.hasNext(); )
        {
            DAGNode n = (DAGNode)i.next();
            if (leaves.contains(n.p))
                toRemove.add(n);
            removeLeaves(n.children, leaves);
        }
        dagNodes.removeAll(toRemove);
    }
    
    /**Build the DAG (see above) for procedure p.
     * @return The DAGNode for p.*/
    private DAGNode buildDAGFor(Patternable p)
    {
        Object existingDAGNode = methodToDAGNode.get(p);
        if (existingDAGNode != null)
            return (DAGNode)existingDAGNode;
        
        List newChildren = new LinkedList();
        for (Iterator i = p.children().iterator(); i.hasNext();)
        {
            Patternable child = (Patternable)i.next();
            newChildren.add(buildDAGFor(child));
        }
        DAGNode newDN = new DAGNode(newChildren, p); 
        methodToDAGNode.put(p, newDN);
        return newDN;
    }

    /** Create the switch elements to call child (a single case with a block to
     * go with it).
     * @param args The arguments to pass in the call */
    private List switchElementsFor(OOMatchProcedureInstance child, List args)
    {
        List switchElements = new LinkedList();
        switchElements.add(nf.Case(position(), tnf.IntLit(child.getID())));
        
        List caseBlock = new LinkedList();
        if (child instanceof MethodInstance)
        {
            MethodInstance childAsMi = (MethodInstance)child;
            Call childCall;
            
            String name;  //Name of the method to call
            if (child.realName() == "")
                name = ((MethodInstance)child).name();
            else
                name = child.realName();
            if (child.container().equals(classTypeToTrans))
            {
                childCall = nf.Call(position(), name, args);
            }
            else
            {
                childCall = nf.Call(position(), nf.Super(position()).type(child.container()), 
                        name, args);
                
            }
            
            childCall = (Call)childCall.type(child.typeOf());
            childCall = childCall.methodInstance(childAsMi);
            if (childAsMi.returnType().equals(ts.Void()))
            {
                //If the method returns void, we have to call the child and
                //then return instead of returning the child's result
                caseBlock.add(nf.Eval(position(), childCall));
                caseBlock.add(nf.Return(position()));
            }
            else 
            {
                caseBlock.add(nf.Return(position(), childCall));
            }
        }
        else
        {
            //DEAD CODE
            OOMatchConstructorInstance childAsCi = (OOMatchConstructorInstance)child;
            TypeNode tn = nf.CanonicalTypeNode(position(), childAsCi.container());
            
            //Add junk parameters
            List junkedArgs = new ArrayList(args.size() + childAsCi.junkParams());
            junkedArgs.addAll(args);
            for (int i = 0; i < childAsCi.junkParams(); ++i)
            {
                junkedArgs.add(tnf.BooleanLit(true));
            }
            New childCall = nf.New(position(), tn, junkedArgs);
            childCall = childCall.constructorInstance(childAsCi);
            childCall = (New)childCall.type(childAsCi.container());
            //return to avoid executing the rest of the constructor
            caseBlock.add(nf.Return(position(), childCall));
        }

        switchElements.add(nf.SwitchBlock(position(), caseBlock));
        return switchElements;

    }
    
    private Expr messageForCalls(Expr[] args)
    {
        Binary bin0, bin1, bin2, bin3;
        StringLit strLit1, strLit2, strLit3;
        
        strLit1 = nf.StringLit(position(), "The following 2 methods are ambiguous:\n");
        strLit1 = (StringLit)strLit1.type(ts.String());
        strLit2 = nf.StringLit(position(), " and \n");
        strLit2 = (StringLit)strLit2.type(ts.String());
        String name;  //Name of the class to give in an amibiguity error message.
        if (classTypeToTrans.isAnonymous())
            name = "<Anonymous>";
        else
            name = classTypeToTrans.name();
        strLit3 = nf.StringLit(position(), " in class " + name + ".\n");
        strLit3 = (StringLit)strLit3.type(ts.String());
        
        //Create the two "Call" expressions
        Call[] calls = new Call[2];
        for (int i = 1; i <=2; ++i)
        {
            
            List messageForArgs = new ArrayList(1);
            messageForArgs.add(args[i-1]);
            calls[i-1] = tnf.Call(messageForMI(classTypeToTrans), messageForArgs);
        }
        
        //Create the string
        bin3 = nf.Binary(position(), strLit2, Binary.ADD, calls[1]);
        bin3 = (Binary)bin3.type(ts.String());
        bin2 = nf.Binary(position(), calls[0], Binary.ADD, bin3);
        bin2 = (Binary)bin2.type(ts.String());
        bin1 = nf.Binary(position(), strLit1, Binary.ADD, bin2);
        bin1 = (Binary)bin1.type(ts.String());
        bin0 = nf.Binary(position(), bin1, Binary.ADD, strLit3);
        bin0 = (Binary)bin0.type(ts.String());

        //Create the call
        List ambErrArgs = new ArrayList(1);
        ambErrArgs.add(bin0);
        
        New ambErrorNew = tnf.New(ts.Error(), ambErrArgs);

        return ambErrorNew;

    }
    /**
     * Create the dispatch code to attempt to dispatch to a single user method.
     * @param parentParams The parameters from the dispatcher method.
     * @param child The user method being dispatched to.
     * @param methChosLocal A Local for the methodChosen variable that keeps track
     *      of which method was chosen
     * @param errClass The AmbiguityError class to throw if there's an ambiguity error.
     * @return A triple, the first element being a List of Stmt representing the 
     * dispatch code, the 2nd being a list of switch elements to put in 
     * the switch statement that
     * it dispatches to the correct method, and the third being a Boolean
     * which is true iff the procedure will always be chosen for dispatch.
     */
    private Object[] dispatchForProc(List parentParams, Patternable child,
            List staticTypeParams,
            Local methChosLocal)
    {
        String dollarSigns = "$";
        List stmts = new LinkedList();  //The statements forming the dispatch code

        Expr matchCondition = null;

        Object[] dispatchResult = dispatchForMethod(parentParams, child.paramTypes(), 
                staticTypeParams, dollarSigns, child.getID(), child.isNamedParam());
        
        matchCondition = (Expr)dispatchResult[1];

        List decls = (List)dispatchResult[0];
        
        List args = (List)dispatchResult[2];
        
        List whereArgs = (List)dispatchResult[3];
        
        //Add the code to check the where clause
        if (child instanceof OOMatchMethodInstance)
        {
            OOMatchMethodInstance childAsMI = (OOMatchMethodInstance)child;
            if (childAsMI.hasWhereClause())
            {
                Call whereCall = nf.Call(position(), child.realName() + "$where", whereArgs);
                whereCall = (Call)whereCall.type(ts.Boolean());
                whereCall = whereCall.methodInstance(childAsMI);
                matchCondition = binAnd(matchCondition, whereCall);
            }
        }
        
        boolean alwaysTrue = false;  //whether the dispatch condition will always return
            //true
        
        if (matchCondition == null)
        {
            matchCondition = tnf.BooleanLit(true);
            alwaysTrue = true;
        } else if (!(child.container() instanceof OOMatchClassType))
        {
            //if the child is in a regular Java class, can only call it if it will
            //definitely apply; so ignore this method.
            return new Object[] { new LinkedList(), new LinkedList(), new Boolean(alwaysTrue) };
        }
        
        List methodPickedStmts = new LinkedList();
        
        //Maybe throw an exception.
        //When the exception is thrown, we must give an error message listing
        //the method that was just matched and the one that had been previously
        //matched.
        
        Expr[] ambErrArgs = new Expr[2];
        ambErrArgs[0] = tnf.IntLit(child.getID());
        ambErrArgs[1] = (Local)methChosLocal.copy();
        
        Stmt ifErrBlock = nf.Throw(position(), messageForCalls(ambErrArgs));
        
        Binary ifErrCond = tnf.NE((Local)methChosLocal.copy(), tnf.IntLit(0));
        
        methodPickedStmts.add(nf.If(position(), ifErrCond, ifErrBlock));

        //set that this method was chosen
        methodPickedStmts.add(nf.Eval(position(), tnf.LocalAssign(
                (Local)methChosLocal.copy(), tnf.IntLit(child.getID())))); 

        stmts.add(nf.If(position(), matchCondition, 
                nf.Block(position(), methodPickedStmts)));

        Expr checkCond = checkCondFor(child, methChosLocal);
        Stmt block = nf.Block(position(), stmts);
        if (checkCond != null)
            block = nf.If(position(), checkCond, block);
        
        decls.add(block);
        //Create switch statement
        return new Object[] {decls, switchElementsFor(child, args), new Boolean(alwaysTrue) };
    }
    
    /** Build the condition to check whether we should check p for applicability.
     * We shouldn't check it if one of its children have already applied.
     * @param methChosLocal The integer variable in the output code that keeps 
     *      track of which method was chosen.
     */
    private Expr checkCondFor(Patternable p, Local methChosLocal)
    {
        Expr retVal = null;
        
        Collection allChildren = new LinkedList();
        allChildren.add(p);
        allChildren = OOMatchClassType.allMethods(allChildren);
        for (Iterator i = allChildren.iterator(); i.hasNext(); )
        {
            Patternable child = (Patternable)i.next();
            Expr methID = tnf.IntLit(child.getID());
            Expr checkNotApplied = tnf.NE((Expr)methChosLocal.copy(), methID);
            retVal = binAnd(retVal, checkNotApplied);
        }
        return retVal;
    }
    
    /** Create a completer for m, if it needs one, and add it to newMembers, if
     * not already there. */
    private void maybeCreateCompleterFor(Patternable m, List newMembers, 
            List methods)
    {
        if (m instanceof DeconstructorInstance)
            return;
        
        if (m instanceof ConstructorInstance)
            return;
        
        //don't create dispatchers for abstract methods
        if (m.flags().isAbstract()) return;

        //Prevent dispatchers from being added
        //when there is already the same dispatcher added due to another method.
        List newParams = OOMatchMethodInstance.javaTypes(m.paramTypes());
        for (Iterator i = newMembers.iterator(); i.hasNext();)
        {
            OOMatchProcedureDecl n = (OOMatchProcedureDecl)i.next();
            if (n.oomProcedureInstance().sameName(m) && ((Patternable)n.oomProcedureInstance()).paramTypes().equals(newParams))
                return;
        }
        
        OOMatchProcedureDecl newMember = createCompleterFor(m);
        newMembers.add(newMember);
    }
    
    //Return members, which is a list of class member AST nodes, but with all
    //its renamed procedures final, and it's "inc" flag (if present) removed.
    //Don't return abstract methods.
    //This should make it easier for optimizers to remove dead code and
    //speed up method dispatch.
    //Also, don't include abstract methods - they'll already be added later as
    //dispatchers.
    private List modifyFlags(List members)
    {
        List retVal =  new ArrayList(members.size());
        for (Iterator i = members.iterator(); i.hasNext(); )
        {
            Object o = i.next();
            if (o instanceof OOMatchMethodDecl_c)
            {
                OOMatchMethodDecl_c m = (OOMatchMethodDecl_c)o;
                OOMatchMethodInstance mi = (OOMatchMethodInstance)m.methodInstance();
                if (!m.flags().isAbstract())
                {
                    Flags flags = m.flags();
                    if (mi.shouldBeRenamed())
                        flags = flags.Final();
                    //Methods in the output can't be labelled "inc"
                    flags = flags.clear(OOMFlags.INC);
                    retVal.add(m.flags(flags));
                }
            }
            else retVal.add(o);
        }
        return retVal;
        
    }
    
    /**Get all the abstract methods from members and return them.
     * Add the static type parameters to them too.*/
    private List getAbstract(List members)
    {
        List retVal =  new LinkedList();
        for (Iterator i = members.iterator(); i.hasNext(); )
        {
            Object o = i.next();
            if (o instanceof OOMatchMethodDecl_c)
            {
                OOMatchMethodDecl_c m = (OOMatchMethodDecl_c)o;
                if (m.flags().isAbstract())
                {
                    List staticTypeParams = staticTypeParams(m.params().size(), m.params());
                    List newParams = new ArrayList(staticTypeParams.size() + m.formals().size());
                    
                    newParams.addAll(m.params());
                    newParams.addAll(staticTypeParams);
                    OOMatchMethodDecl_c.formalsIn(newParams, nf);
                    m = (OOMatchMethodDecl_c)m.formals(OOMatchMethodDecl_c.formalsIn(newParams, nf));
                    m = (OOMatchMethodDecl_c)m.params(newParams);
                    retVal.add(m);
                }
            }
        }
        return retVal;
    }
    
    /**Add methods used to evaluate the "where" clauses.
     * 
     * @param body The class body to add where clause methods to
     * @return A new class body with the where clause methods added
     */
    private List addWhere(List members)
    {
        List retVal = new ArrayList(members.size());
        for (Iterator i = members.iterator(); i.hasNext(); )
        {
            Object o = i.next();
            if (o instanceof OOMatchMethodDecl_c)
            {
                OOMatchMethodDecl_c m = (OOMatchMethodDecl_c)o;
                if (m.whereClause() != null)
                {
                    Position pos = m.whereClause().position();
                    //Create a method to evaluate the where clause
                    Stmt retStmt = nf.Return(pos, m.whereClause());
                    MethodDecl whereMethod = nf.MethodDecl(pos, m.flags(), 
                            nf.CanonicalTypeNode(pos, ts.Boolean()), 
                            m.name() + "$where", 
                            m.params(), m.throwTypes(), nf.Block(pos, retStmt));
                    whereMethod = whereMethod.methodInstance(m.methodInstance());
                    retVal.add(whereMethod);
                    
                    m = (OOMatchMethodDecl_c)m.params(removeMadeUpParams(m.params()));
                    m = (OOMatchMethodDecl_c)m.formals(
                            OOMatchMethodDecl_c.formalsIn(m.params(), nf));
                }
                retVal.add(m);
            }
            else retVal.add(o);
        }


        return retVal;
    }
    
    /**Add any dispatchers needed to the class, which determine which method should
     * be called.
     */
    private ClassBody addCompleters()
    {
        List abstractMethods;
        if (classTypeToTrans.flags().isAbstract())
        {
            abstractMethods = new LinkedList(getAbstract(classBodyToTrans.members()));
        }
        else
            abstractMethods = Collections.EMPTY_LIST;
        
        List newMembers = new LinkedList(
                modifyFlags(classBodyToTrans.members()));
        
        List methods;
        List newCompleters = new LinkedList();   //A list of all new completers created
        
        methods = ((OOMatchClassType)classTypeToTrans).getTopLevelOfType(null);
        //for each method m in this class which overrides nothing 
        for (Iterator i = methods.iterator(); i.hasNext();)
        {
            Object o = i.next(); 

            if (!(o instanceof Patternable)) continue;
            Patternable m = (Patternable)o;
            
            //Only need a completer for a function with patterns or children
            if (m.shouldBeRenamed())
            {
                //Create a completer for m
                maybeCreateCompleterFor(m, newCompleters, methods);
            }
            
            Type t = classTypeToTrans.superType();
            
            //Pull down methods from the superclasses
            while (!t.equals(ts.Object()) && t instanceof ClassType)
            {
                List superMethods;
                if (t instanceof OOMatchClassType)
                {
                    superMethods = ((OOMatchClassType)t).getTopLevelOfType(m);
                    for (Iterator j = superMethods.iterator(); j.hasNext();)
                    {
                        Patternable m_prime = (Patternable)j.next();
                        if (m_prime.intersectsWith(m))
                        {
                            //Create a completer for m_prime
                            maybeCreateCompleterFor(m_prime, newCompleters, methods);
                        }
                    }
                    
                }
                else
                {
                    //t is a regular Java class
                    //superMethods = OOMatchClassType.spotFor(m, (ClassType)t);
                }
                
                t = ((ClassType)t).superType();
            } 
            
        }

        //Remove any made-up formals from user methods, to prevent name clashes
        newMembers = addWhere(newMembers);
        
        newMembers.addAll(newCompleters);
        
        //Add messageFor method
        if (!classTypeToTrans.flags().isInterface())
            newMembers.add(messageFor(OOMatchClassType.allMethods(methods)));
        
        //Add all abstract methods, except the ones for which there is now a dispatcher
        //with the same parameters.
        //Adding those would cause a duplicate method definition in the Java output.
        for (Iterator i = abstractMethods.iterator(); i.hasNext(); )
        {
            OOMatchMethodDecl_c absMeth = (OOMatchMethodDecl_c)i.next();
            boolean retainMethod = true;  //whether to retain absMeth in the class 
            for (Iterator j = newCompleters.iterator(); j.hasNext(); )
            {
                Object o = j.next();
                if (o instanceof OOMatchMethodDecl_c)
                {
                    OOMatchMethodDecl_c possibleConflict = (OOMatchMethodDecl_c)o;
                    if (possibleConflict.params().equals(absMeth.params()))
                    {
                        retainMethod = false;
                        break;
                    }
                }
            }
            if (retainMethod)
                newMembers.add(absMeth);
        }
        return classBodyToTrans.members(newMembers);
    }
    //Remove the made up paramters (from parameters that reference a variable)
    //from l (they have to be removed from user methods to avoid a name clash)
    private List removeMadeUpParams(Collection l)
    {
        List retVal = new ArrayList(l.size());
        for (Iterator j = l.iterator(); j.hasNext(); )
        {
            Param param = (Param)j.next();
            if (param instanceof PatternParam)
            {
                PatternParam patParam = (PatternParam)param;
                List newPattern = removeMadeUpParams(
                        patParam.pattern());
                retVal.add(patParam.pattern(newPattern));
            }
            else if (!(param instanceof MadeUpParam))
            {
                retVal.add(param);
            }
        }
        return retVal;
    }

}
