package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ErrorHandlingVisitor;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.OOMatchMethodInstance;
import java.util.*;

/** When the user writes M1 | M2, i.e. a manual specification that M1 overrides M2,
 * this visitor sets that information in the type info (of M1).  
 * @author a5richar
 *
 */

public class AddManualChildren extends ErrorHandlingVisitor
{

    public AddManualChildren(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node n)
        throws SemanticException
    {
        if (n instanceof ClassBody)  //Works for both anonymous
            //classes and normal classes
        {
            return flattenMethods((ClassBody)n);
        }
        else return n;
    }

    /** At first, the AST is such that manually overridden methods are child nodes
     * of their parent method, rather than being in the class.  This flattens all
     * methods in b to be in the class body, and sets the type information
     * of the methods to indicate manual children.  
     * @param b
     * @return
     * @throws SemanticException When incorrect manual override relationships are
     * declared.
     */
    private ClassBody flattenMethods(ClassBody b)
        throws SemanticException
    {
        boolean found;
        List newMembers = new ArrayList(b.members().size());
        newMembers.addAll(b.members());
        do {
            //Keep looping until we've found no children to flatten.
            //After pulling up a method, it might still have had children to flatten.
            found = false;
            List toAdd = new LinkedList(), toRemove = new LinkedList();
            for (Iterator i = newMembers.iterator(); i.hasNext(); )
            {
                Object o = i.next();
                if (o instanceof OOMatchMethodDecl_c)
                {
                    OOMatchMethodDecl_c m = (OOMatchMethodDecl_c)o;
                    OOMatchMethodInstance mi = (OOMatchMethodInstance)m.methodInstance();
                    if (m.getChild() != null)
                    {
                        //Found a manual override relationship
                        found = true;
                        OOMatchMethodInstance childMI = 
                            (OOMatchMethodInstance)m.getChild().methodInstance(); 
                        mi.setChild(childMI);
                        
                        //Error checking
                        if (mi.preferred(childMI))
                        {
                            throw new SemanticException(mi + " overrides " + childMI +
                                    ", but the reverse is declared.", mi.position());
                        }
                        if (mi.cantBothApply(childMI))
                        {
                            throw new SemanticException(childMI + 
                                    " cannot be declared to override " + mi +
                                    " because the methods never apply at the " +
                                    "same time.", mi.position());
                        }

                        //flatten
                        toRemove.add(m);
                        toAdd.add(m.getChild());
                        
                        //set type info
                        m = (OOMatchMethodDecl_c)m.child(null).methodInstance(mi);
                        
                        //add flattened method
                        toAdd.add(m);
                    }
                }
            }
            newMembers.removeAll(toRemove);
            newMembers.addAll(toAdd);
        } while (found);
        return b.members(newMembers);
    }
}
