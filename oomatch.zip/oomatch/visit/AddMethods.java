package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.ext.oomatch.ast.OOMatchMethodDecl_c;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.*;

//Add regular OOMatch methods to classes.
//Has to be done separately from the AddMembersVisitor because of named parameters.
public class AddMethods extends AddMemberVisitor
{

    public AddMethods(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }

    protected NodeVisitor enterCall(Node n) throws SemanticException {
        if (n instanceof New)
        {
            //We should bypass a New the first time
            New nw = (New)n;
            ClassType t = nw.anonType();
            //this will be true the first time through, when anonymous classes
            //haven't been constructed yet
            if (t != null && t.superType() == null) 
                return bypassChildren(n);
        }
        if (n instanceof OOMatchMethodDecl_c)
            return ((OOMatchMethodDecl_c)n).realAddMembersEnter(this);
        else return this;
    }

    protected Node leaveCall(Node old, Node n, NodeVisitor v) throws SemanticException {
        return n;
    }

}
