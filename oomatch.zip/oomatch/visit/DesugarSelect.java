package polyglot.ext.oomatch.visit;

import java.util.*;
import polyglot.ast.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.*;

import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.*;
import polyglot.util.*;

//Convert select statements into an anonymous class with a method for each case,
//and a call using the select arguments.
//Not used because select isn't implemented.

public class DesugarSelect extends ContextVisitor
{

    public DesugarSelect(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }

    protected Node leaveCall(Node old, Node n, NodeVisitor v) throws SemanticException {
        if (n instanceof Select)
        {
            return desugar((Select)n, context(), job, nf, ts);
        }
        else return n;
    }
    
    public static Stmt desugar(Select select, Context context, Job job, 
            NodeFactory nf, TypeSystem ts)
        throws SemanticException
    {
        ClassType classOfSelect = context.currentClass();

        //Type for the anonymous class
        ParsedClassType t = ts.createClassType();
        t.kind(ClassType.ANONYMOUS);
        t.flags(Flags.NONE);
        t.superType(ts.Object());
        t.outer(classOfSelect);

        Position pos = select.position();
        //TypedNodeFactory tnf = new TypedNodeFactory((OOMatchNodeFactory)nf, 
//                (OOMatchTypeSystem)ts, pos);
        OOMatchNodeFactory oomNF = (OOMatchNodeFactory)nf;
        
        //Convert "this" and "super" to be qualified with the current class
        ConvertThisAndSuper converter = new ConvertThisAndSuper(job, ts, nf, 
                classOfSelect);
        converter = (ConvertThisAndSuper)converter.context(context);
        select = (Select)select.visitChildren(converter);
        
        //Construct the "new" expression
        //New newObj = tnf.New(ts.Object(), new LinkedList());
        New newObj = nf.New(pos, nf.CanonicalTypeNode(pos, ts.Object()), new LinkedList());

        List cases = select.cases();
        List selectMembers = new ArrayList(cases.size() + 1);
        
        //Add the methods.
        //Each case becomes a method with parameters being the pattern in the case.

        boolean foundDefault = false;

        //The formals for the method for the most general case, if no "default" case
        //is present.  We have to calculate them here so we can tell if there's
        //already a method with these formals.
        //List defaultFormals = staticTypes(select.args(), oomNF, pos, "$", tnf);
        
        MethodDecl lastMethod = null;
        for (Iterator i = cases.iterator(); i.hasNext(); )
        {
            SelectCase sCase = (SelectCase)i.next();
            
            if (foundDefault) {
                throw new SemanticException("Default case must be the last case "
                        + "in the select block.", sCase.position());
            }
            if (sCase.params().size() != select.args().size())
            {
                throw new SemanticException("Too few parameters in case expression.", 
                        sCase.position());
            }
            
            MethodDecl m = createMethod(sCase.position(), sCase.params(), 
                    nf.Block(sCase.position(), sCase.statements()), nf, ts, t);
            if (sCase.isDefault())
            {
             /*  
                //Calculate dollar signs needed for names
                DollarSignCounter counter = new DollarSignCounter();
                sCase.visitChildren(counter);
                String dollarSigns = counter.getResult() + "$";
*/
                /*
                defaultFormals = 
                    staticTypes(select.args(), oomNF, sCase.position(), 
                            dollarSigns, tnf);
*/
                foundDefault = true;
                //m = m.formals(defaultFormals);
            }
            if (lastMethod != null)
            {
                //Set each method to override the next one
                oomNF.setChild(lastMethod, m);
            }
            lastMethod = m;
        }
        //MethodDecl genMethod = null;
        /*
        if (foundDefault ||
                //Don't need a default method if this next condition is true; 
                //there's already one
                //that's more general than the formal parameters.
                paramsMoreGeneral(((OOMatchMethodDecl_c)lastMethod).params(), 
                        defaultFormals)
        )
        {
            //genMethod = lastMethod;
        }
        else
        {
            //Create the default method
            
            MethodDecl m = createMethod(pos, defaultFormals, nf.Block(pos), nf, ts, t);
            m = oomNF.setChild(lastMethod, m);
            genMethod = m;
        }
        */
        if (foundDefault)
            selectMembers.add(lastMethod);
        else
        {
            //Create the default method
            OOMatchMethodDecl_c m = createMethod(pos, new LinkedList(), nf.Block(pos), nf, ts, t);
            m = (OOMatchMethodDecl_c)oomNF.setChild(lastMethod, m);
            
            //I think this copies the list, or if it doesn't, it doesn't matter
            m = m.setArgs(new ArrayList(select.args()));
            selectMembers.add(m);
        }
        //Set the body
        New classBody = newObj.body(nf.ClassBody(pos, selectMembers));
        classBody = classBody.anonType(t);
        
/*        return nf.Eval(pos, tnf.Call(classBody, genMethod.methodInstance(), 
                select.args()));*/
        return nf.Eval(pos, nf.Call(pos, classBody, "select", 
                select.args()));
        
    }
    
    public static boolean paramsMoreGeneral(List params1, List params2)
    {
        for (Iterator i = params1.iterator(), j = params2.iterator(); i.hasNext(); )
        {
            Param p1 = (Param)i.next();
            NormalParam p2 = (NormalParam)j.next();  //The static type args are always
                //normal params
            if (p1 instanceof NormalParam)
            {
                if (p2.type().isSubtype(p1.type()))
                {}
                else return false;
            }
            else return false;
        }
        return true;
    }
    private static OOMatchMethodDecl_c createMethod(Position pos, List params, Block body,
            NodeFactory nf, TypeSystem ts, ClassType anonClass)
    {
        Flags f = Flags.PUBLIC;
        Type retType = ts.Void();
        String name = "select";
        MethodDecl m = nf.MethodDecl(pos, f,
                nf.CanonicalTypeNode(pos, retType), 
                name, params, new LinkedList(), body);
        
        m = m.methodInstance(ts.methodInstance(pos, anonClass, f, retType, name, 
                OOMatchMethodInstance.typesOf(params),
                new LinkedList()));
                
        return (OOMatchMethodDecl_c)m;
    }
    public static List staticTypes(List args, OOMatchNodeFactory nf, 
            Position pos, String dollarSigns, TypedNodeFactory tnf)
    {
        //Create parameters
        List retVal = new ArrayList(args.size());
        int paramNum = 0;
        for (Iterator i = args.iterator(); i.hasNext();)
        {
            ++paramNum;
            Expr arg = (Expr)i.next();
            NormalParam p = nf.NormalParam(pos, tnf.Formal(Flags.NONE, arg.type(), 
                    "arg" + dollarSigns + paramNum));
            retVal.add(p);
            
        }
        return retVal;
    }

}
