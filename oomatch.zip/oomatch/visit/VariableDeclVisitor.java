package polyglot.ext.oomatch.visit;

import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ext.oomatch.ast.OOMatchConstructorDecl_c;
import polyglot.ext.oomatch.ast.OOMatchMethodDecl_c;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ContextVisitor;

//Find the set of variables declared in a pattern, and set the method's 
//formals to that set.
//For example, the method:
//void f(Point(int x, int y))
//has two formals x and y, each of type int, even though the type of the method
//is Point -> ()
//This does not find the name given to a pattern - that's done later, after
//the pattern has received a type.

public class VariableDeclVisitor extends ContextVisitor
{

    public VariableDeclVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }

    protected Node leaveCall(Node n)
    throws SemanticException 
    {
        if (n instanceof OOMatchConstructorDecl_c)
        {
            OOMatchConstructorDecl_c nAsProc = (OOMatchConstructorDecl_c)n;
            return nAsProc.formals(OOMatchMethodDecl_c.formalsIn(nAsProc.params(), nf));
        }
        else if (n instanceof OOMatchMethodDecl_c)
        {
            //Duplicate code once again for constructors and methods; this time
            //because of a Polyglot design flaw - the "formals" method should have 
            //been in ProcedureDecl instead of each of MethodDecl and ConstructorDecl.
            OOMatchMethodDecl_c nAsProc = (OOMatchMethodDecl_c)n;
            return nAsProc.formals(OOMatchMethodDecl_c.formalsIn(nAsProc.params(), nf));
        }
        else return n;
    }

}
