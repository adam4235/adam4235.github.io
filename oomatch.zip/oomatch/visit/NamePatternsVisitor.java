package polyglot.ext.oomatch.visit;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import polyglot.ast.Formal;
import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ext.oomatch.ast.*;
import polyglot.types.Flags;
import polyglot.visit.NodeVisitor;

//This class is no longer used, because it turns out there's no need
//to give names to unnamed pattern parameters.

/**This visitor sets each method that had a pattern (deconstructor usage)
 * with no name given to it.  It gives a made-up name to it which doesn't
 * conflict with any name declared in the body of the method.
 * 
 * This is necessary so that the method can get a signature, and be called
 * from other methods.  It might seem like all that's necessary is the named
 * parameters, but consider this pair of methods:
 * 
 * f(Point(int x, int y));
 * f(Point(0, 0) p);
 * 
 * The 2nd method overrides the 1st, so the first needs to be able to call the second.
 * But if its real signature becomes f(int, int), then it no longer has the Point to
 * pass on to the 2nd method.  So the only option is for them to both get the signature
 * f(Point) (though at least one of them will be renamed to f$1 or something).
 * 
 */

public class NamePatternsVisitor extends NodeVisitor
{
    NodeFactory nf;
    public NamePatternsVisitor(NodeFactory nf)
    {
        super();
        this.nf = nf;
    }

    public Node leave(Node old, Node n, NodeVisitor v)
    {
        if (n instanceof OOMatchProcedureDecl)
        {
            return namePatterns(((OOMatchProcedureDecl)n));
        }
        else return n;
    }

    //These variables, and the ugliness below, seem necessary because Java lacks
    //nested methods
    static String dollarSigns;  //max # of $ signs in the method body declarations

    //If paramNum exceeds 2^32, there might be an overflow.
    //Though something else probably prevents that from mattering.
    static int paramNum;  //Counter to use to name new parameters; arg1, arg2, etc.
    
    public List namePatterns2(List params, OOMatchProcedureDecl d)
    {
        //Take each parameter, possibly change it, and put it in the new list of
        //parameters
        List retVal = new ArrayList(params.size());  //We know the size in advance, so it's
            //efficient to give it here
        for (Iterator i = params.iterator(); i.hasNext();)
        {
            Object toAdd = (i.next());
            if (toAdd instanceof PatternParam)
            {
                PatternParam p = (PatternParam)toAdd;
                Formal decl = p.formal();
                if (decl == null)
                {
                    //No name; have to make one up
                    
                    if (dollarSigns.equals(""))
                    {
                        //If the dollar signs in this method haven't already been calculated,
                        //calculate them.
                        DollarSignCounter counter = new DollarSignCounter();
                        counter.visitEdge(d, d.body());
                        dollarSigns = counter.getResult() + "$";
                    }
                    ++paramNum;
                    String name = "arg" + dollarSigns + paramNum;
                    
                    //Create the formal for p
                    Formal f = nf.Formal(p.position(), Flags.NONE, 
                            p.decon().toType(),
                            name);
                    
                    //Set the formal, and recursively name the subpatterns of p
                    toAdd = p.formal(f).pattern(namePatterns2(p.pattern(), d));
                }
            }
            retVal.add(toAdd);
        }
        return retVal;
    }
    public Node namePatterns(OOMatchProcedureDecl d)
    {
        paramNum = 0;
        dollarSigns = "";
        return d.params(namePatterns2(d.params(), d));
    }
}
