package polyglot.ext.oomatch.visit;

import java.util.*;

import polyglot.ast.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.frontend.Job;
import polyglot.types.FieldInstance;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.NodeVisitor;

/**Disambiguate methods, and set the types of their parameters.
 * Happens separately from regular disambiguation because for named parameters,
 * we have to be able to look up the field referenced in the class, which happens
 * during add members.
 *
 */
public class DisamMethods extends AmbiguityRemover
{

    public DisamMethods(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf, SIGNATURES);
    }
    protected NodeVisitor enterCall(Node n) throws SemanticException {
        if (n instanceof OOMatchMethodDecl_c)
            return ((OOMatchMethodDecl_c)n).realDisambiguateEnter(this);
        else return this;
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v)
        throws SemanticException 
    {
        if (n instanceof OOMatchMethodDecl_c)
        {
            OOMatchMethodDecl_c d = ((OOMatchMethodDecl_c)n); 
            //Assign types to the parameters
            List newParams = typesToParams(d.params(), new LinkedList());
            d = (OOMatchMethodDecl_c)d.params(newParams);
            d = (OOMatchMethodDecl_c)d.formals(OOMatchMethodDecl_c.formalsIn(newParams, nf));

            return d.realDisambiguate(this);
        }
        else return n;
    }

    public List typesToParams(List params, Collection decls)
        throws SemanticException
    {
        List retVal = new ArrayList(params.size());
        for (Iterator i = params.iterator(); i.hasNext();)
        {
            Param p = (Param)i.next();
            if (p instanceof PatternParam)
            {
                //Give a type to all the components of the pattern, then
                //to the pattern.
                PatternParam pat = (PatternParam)p;
                List newSubpatterns = typesToParams(pat.pattern(), decls);
                pat = pat.pattern(newSubpatterns);
                pat = (PatternParam)pat.assignType(this);
                retVal.add(pat);
                
                if (pat.formal() != null) decls.add(pat.formal());
            }
            else if (p instanceof NamedParam)
            {
                NamedParam np = (NamedParam)p;
                Formal nlFormal = DesugarNamedParams.nonlinearFormal(np.printParam(), decls);
                if (nlFormal != null)
                {
                    //Non-linear pattern matching.
                    np = np.type(nlFormal.type().type());
                }
                else
                {
                    //Reference to a field in the class.
                    
                    //We have to get the type by looking up the field.
                    FieldInstance fi = context.findField(np.printParam()); 
                    np = np.type(fi.type());
               }
               retVal.add(np);

            }
            else if (p instanceof NormalParam)
            {
                NormalParam np = (NormalParam)p;
                decls.add(np.formal());
                retVal.add(np);
            }
            else retVal.add(p);
        }
        return retVal;
    }

}
