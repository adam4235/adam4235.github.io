package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.frontend.*;
import polyglot.types.*;
import polyglot.visit.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.OOMatchTypeSystem;

import java.util.*;

//Not used because select isn't being implemented.
public class CreateDefaultSelect extends ContextVisitor
{

    public CreateDefaultSelect(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }

    protected Node leaveCall(Node n) throws SemanticException {
        if (n instanceof OOMatchMethodDecl_c)
        {
            OOMatchMethodDecl_c ds = (OOMatchMethodDecl_c)n;
            if (ds.args() == null) return n;
            
            //Calculate dollar signs needed for names
            DollarSignCounter counter = new DollarSignCounter();
            ds.visitChild(ds, counter);
            String dollarSigns = counter.getResult() + "$";

            List args = ds.args();
            List params = new ArrayList(args.size());
            int paramNum = 0;

            for (Iterator i = args.iterator(); i.hasNext();)
            {
                ++paramNum;
                Expr arg = (Expr)i.next();
                Job sj = job().spawn(context(), arg,
                        Pass.DISAM, Pass.TYPE_CHECK);

                Expr typedExpr = (Expr)sj.ast();
                OOMatchNodeFactory oomNF = (OOMatchNodeFactory)nf;
                TypedNodeFactory tnf = new TypedNodeFactory((OOMatchNodeFactory)nf, 
                        (OOMatchTypeSystem)ts, ds.position());

                params.add(oomNF.NormalParam(ds.position(), tnf.Formal(Flags.NONE, 
                        typedExpr.type(), 
                        "arg" + dollarSigns + paramNum)));
            }
            OOMatchMethodDecl_c newM = ds;
            newM = (OOMatchMethodDecl_c)newM.params(params);
            newM = (OOMatchMethodDecl_c)newM.formals(OOMatchMethodDecl_c.formalsIn(params, nf));
            return newM;
        }
        else return n;
    }
}
