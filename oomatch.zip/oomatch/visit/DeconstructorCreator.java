package polyglot.ext.oomatch.visit;

/** Creates deconstructor instances for the typesystem.
* Necessary because we have to process deconstructors before methods, since
* knowledge of deconstructors is necessary to find the type of method headers.*/

import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ext.oomatch.ast.DeconstructorDecl;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.NodeVisitor;

public class DeconstructorCreator extends AmbiguityRemover
{
    public DeconstructorCreator(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf, SIGNATURES);
    }
    protected NodeVisitor enterCall(Node n) throws SemanticException {
        if (n instanceof DeconstructorDecl)
            return ((DeconstructorDecl)n).realDisambiguateEnter(this);
        else return this;
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v) throws SemanticException {
        if (n instanceof DeconstructorDecl)
        {
            DeconstructorDecl d = ((DeconstructorDecl)n); 
            return d.realDisambiguate(this);
        }
        else return n;
    }
}
