package polyglot.ext.oomatch.visit;

import java.util.*;
import java.io.*;

import polyglot.ast.*;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.util.ErrorInfo;
import polyglot.util.ErrorQueue;
import polyglot.visit.ContextVisitor;

import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.*;
import polyglot.ext.oomatch.OOMOptions;

/** Do the typechecking required by OOMatch.
 * 
 * Also build the structure of which methods override which in the type system info.
 */
public class OOMatchTypeCheck extends ContextVisitor {

	public OOMatchTypeCheck(Job job, TypeSystem ts, NodeFactory nf) {
		super(job, ts, nf);
        OOMatchMethodInstance.nf = (OOMatchNodeFactory)nf;
	}

    protected Node leaveCall(Node n)
    	throws SemanticException 
    {
    	if (n instanceof OOMatchClassDecl_c)
    	{
            
            OOMatchClassDecl_c nAsClass = (OOMatchClassDecl_c)n;
            classCheckingType = (OOMatchClassType)nAsClass.type();
            checkDeconstructors(classCheckingType.deconstructors());
    	}
        else if (n instanceof New)
        {
            New nAsNew = (New)n;
            if (nAsNew.body() == null) return n;  //no anonymous class present

            classCheckingType = (OOMatchClassType)nAsNew.anonType();
            if (classCheckingType.deconstructors().size() > 0)
                throw new SemanticException("Anonymous classes may not have deconstructors.",
                        nAsNew.body().position());
            //this will be true the first time through, when anonymous classes
            //haven't been constructed yet
            if (classCheckingType.superType() == null) return n;
        }
        else return n;
        buildOverrides(classCheckingType.methods());
        buildOverrides(classCheckingType.constructors());
        checkFinal(OOMatchClassType.allMethods(classCheckingType.methods()));
        checkAbstract();

        checkCompleteness(classCheckingType.methods(), true);
        checkCompleteness(classCheckingType.constructors(), false);
        return n;
    }

    OOMatchClassType classCheckingType = null;
    
    private String className()
    {
        if (classCheckingType.isAnonymous())
            return "<Anonymous>";
        else
            return classCheckingType.name();
    }
    
    // Data structure to group methods that have already been seen into 
    //methods with the same name.
    private class MethodsSeen extends HashMap {
        MethodsSeen() {
            super();
        }

        /**
         * Get a list of methods named methodName. Guaranteed to return a
         * (possibly empty) List and not null.
         */
        public List methodsNamed(String methodName) {
            List listOfMs = (List) (get(methodName));
            if (listOfMs == null) {
                listOfMs = new LinkedList();
                put(methodName, listOfMs);

            }
            return listOfMs;
        }

        public void addToMethodsNamed(String methodName, OOMatchProcedureInstance m)
        {
            List methodsNamedM = methodsNamed(methodName);
            methodsNamedM.add(m);
        }
        
        /** Print the data structure in a format that can be used to create
         * a dot graph (.dot file)
         */
        public void printDAGForDot(int fileNum) {
            final String fileNamePrefix = "/u1/a5richard/thesis/polyglot-1.3.4-src/src/polyglot/ext/oomatch/tests/ex" + classCheckingType.name();

            //if (!classCheckingType.name().equals("RectTest")) return;
            Set nodes = new LinkedHashSet();  //the nodes in the .dot file
            Set edges = new LinkedHashSet();  //the edges in the .dot file; a set of pairs
            for (Iterator i = values().iterator(); i.hasNext(); )
            {
                List listOfMs = (List)i.next();
                Object[] returned = printDAGForDot(listOfMs);
                nodes.addAll((Set)returned[0]);
                edges.addAll((Set)returned[1]);
            }

            try {

                FileWriter writer = new FileWriter(fileNamePrefix + fileNum + ".dot");
                PrintWriter out = new PrintWriter(writer);
                out.println("digraph Ex" + fileNum + "{");
                
                //print nodes, then edges
                for (Iterator i = nodes.iterator(); i.hasNext(); )
                {
                    out.println("\"" + i.next() + "\"");
                }
                for (Iterator i = edges.iterator(); i.hasNext(); )
                {
                    Object[] edge = (Object[])i.next();
                    out.println("\"" + edge[0] + "\"" + " -> " + "\"" + edge[1] + "\"");
                }
                out.println("}");
                writer.close();
            }
            catch(IOException e)
            {
                throw new Error();
            }
        }
        private Object[] printDAGForDot(Collection methods)
        {
            Set nodes = new LinkedHashSet();
            Set edges = new LinkedHashSet();
            for (Iterator i = methods.iterator(); i.hasNext(); )
            {
                Object o = i.next();
                if (o instanceof Patternable)
                {
                    Patternable m = (Patternable)o;
                    nodes.add(m);
                    for (Iterator j = m.children().iterator(); j.hasNext();)
                    {
                        Patternable child = (Patternable)j.next();
                        edges.add(new Object[] {m, child});
                    }
                    Object[] returned = printDAGForDot(m.children());
                    nodes.addAll((Set)returned[0]);
                    edges.addAll((Set)returned[1]);
                }
            }
            return new Object[] { nodes, edges };
        }
        
        private static final long serialVersionUID = 8872357; // since HashMap
        // is Serializable, this is apparantly necessary. I don't fully
        // understand it.
    }
    
    private String name(OOMatchProcedureInstance p)
    {
        String mName;
        if (p instanceof OOMatchMethodInstance)
        {
            mName = ((OOMatchMethodInstance)p).name();
        }
        else
            mName = "constructor";  //just need a junk name; 
            //all constructors can be grouped together
            //for each OOMatchProcedureDecl m
        return mName;
    }

    /**Check that abstract methods don't contain patterns.*/
    private void checkAbstract()
        throws SemanticException
    {
        for (Iterator i = classCheckingType.methods().iterator(); i.hasNext(); ) {
            OOMatchMethodInstance mi = (OOMatchMethodInstance)i.next();
            if (mi.flags().isAbstract())
            {
                if (!mi.hasOnlyFormals())
                {
                    throw new SemanticException("Abstract methods cannot contain patterns.",
                            mi.position());
                }
                checkNoFinalChildren(mi.children(), mi);
            }
        }
    }

    private void checkNoFinalChildren(List methods, OOMatchMethodInstance abstractMethod)
        throws SemanticException
    {
        for (Iterator i = methods.iterator(); i.hasNext(); ) {
            Patternable mi = (Patternable)i.next();
            if (!mi.flags().isFinal())
            {
                throw new SemanticException(mi + " must be final because it overrides " +
                        "the abstract method " + abstractMethod + ".  Otherwise, it " +
                        "can never be called.", mi.position());
            }
        }
    }
    private void checkFinal(Collection methods)
        throws SemanticException
    {
        for (Iterator i = methods.iterator(); i.hasNext(); ) {
            Patternable mi = (Patternable)i.next();
            if (mi.flags().isFinal())
            {
                for (Iterator j = mi.children().iterator(); j.hasNext(); )
                {
                    Patternable overridesFinal = (Patternable)j.next();
                    throw new SemanticException(overridesFinal + " cannot override "
                            + mi + " because it's labelled final.", 
                            overridesFinal.position());
                }
            }
            ProcedureInstance finalOverrider = 
                OOMatchMethodInstance
                .findCompleterInSuperClass(mi, 
                        classCheckingType, 
                        typeSystem(), true);
            if (finalOverrider != null)
            {
                throw new SemanticException(mi + " cannot override "
                        + finalOverrider + " in class " + finalOverrider.container() +
                        " because it's labelled final.",
                        mi.position());
            }
        }
    }
    public void checkDeconstructors(List deconstructors)
        throws SemanticException
    {
        for (Iterator i = deconstructors.iterator(); i.hasNext(); )
        {
            DeconstructorInstance d1 = (DeconstructorInstance)i.next();
            for (Iterator j = deconstructors.iterator(); j.hasNext(); )
            {
                DeconstructorInstance d2 = (DeconstructorInstance)j.next();
                if (d1 != d2 && d1.isSameProc(d2))
                {
                    dupDefn(d1, d2);
                }
            }
            
        }
    }
    /**
     * Build the structure of what overrides what.  Check for ambiguity errors in the
     * process.
     * @param procedures The list of procedures (either methods or constructors)
     *      to build the DAG structures for
     * Check that there are no ambiguities, while rearranging the ClassType
     * so that methods have as their children methods that override them.
     */
    private void buildOverrides(List procedures)
        throws SemanticException
    {
        MethodsSeen newMethods = new MethodsSeen();
        int fileNum = 0;
        for (Iterator i = procedures.iterator(); i.hasNext(); ) {
            Patternable p = (Patternable)i.next();

            checkErrors(p);
            
            List listOfMs = newMethods.methodsNamed(name(p));
            Object[] returned = add(p, listOfMs);
            boolean wasAdded = ((Boolean)returned[1]).booleanValue();
            listOfMs = (List)returned[0];
            if (!wasAdded)
                listOfMs.add(p);
            //listOfMs = add(p, listOfMs);
            //finishChildren(p, listOfMs);
            newMethods.put(name(p), listOfMs);
            
            ++fileNum;
            //if (p instanceof MethodInstance) newMethods.printDAGForDot(fileNum);
        }
        //newMethods.printDAGForDot();
        
        //Remove procedures that can't be called directly to hide them from
        //the class's interface.  (Their AST nodes will remain.)
        List toRemove = new LinkedList();
        for (Iterator i = procedures.iterator(); i.hasNext(); ) {
            Patternable p = (Patternable)i.next();
            /*
            if (p instanceof OOMatchMethodInstance && ((OOMatchMethodInstance)p).name().equals("g2"))
            {
                System.out.println("DEBUG");
            }
*/

            /*
            if (p instanceof MethodInstance && ((MethodInstance)p).name().equals("nullTest"))
            {
                System.out.println("DEBUG");
            }
            */
            List methodsNamedP = newMethods.methodsNamed(name(p));
            boolean hasPatterns = !(p.hasOnlyFormals() && !p.hasWhereClause()); 
            if (hasPatterns && !methodsNamedP.contains(p))
            {
                toRemove.add(p);
            }

        }
        /*
        for (Iterator i = toRemove.iterator(); i.hasNext(); )
        {
            Patternable r = (Patternable)i.next();
            for (Iterator j = procedures.iterator(); j.hasNext(); )
            {
                Patternable a = (Patternable)j.next();
                if (a.equals(r))
                {
                    System.out.println(r + "equals" + a);
                }
            }
            procedures.remove(r);
        }
        */
        procedures.removeAll(toRemove);  //I'm not sure if you can remove something
            //while iterating over it, so I put this outside the loop
        //printOverrides(procedures, new LinkedList());
    }
    
    public void printOverrides(List procedures, List done)
    {
        //DEBUG
        for (Iterator i = procedures.iterator(); i.hasNext(); ) {
            Patternable p = (Patternable)i.next();
            if (done.contains(p)) continue;
            for (Iterator j = p.children().iterator(); j.hasNext(); )
            {
                OOMatchProcedureInstance child = (OOMatchProcedureInstance)j.next();
                System.out.println(child + " overrides " + p);
            }
            done.add(p);
            printOverrides(p.children(), done);
        }
    }
    /** Check that a list of methods are each complete, i.e. can handle any
     * parameter it might be given.
     * @param methods A list of either methods or constructors
     */
    private void checkCompleteness(List methods, boolean doingMethods)
        throws SemanticException
    {
        List toRemove = new LinkedList();
        List toKeep = new LinkedList();
        for (Iterator i = methods.iterator(); i.hasNext();)
        {
            Object o = i.next();
            if (o instanceof Patternable) 
            {
                Patternable p = (Patternable)o;
                
                if (!p.flags().contains(OOMFlags.INC) && (!p.hasOnlyFormals() || p.hasWhereClause()))
                //if (!p.hasOnlyFormals())  
                {
                    if (p instanceof ConstructorInstance  //Constructors must have
                            //a complete version in the class itself, because you can't
                            //substitute a super call for a constructor call
                        || OOMatchMethodInstance
                            .findCompleterInSuperClass(p, 
                                                       classCheckingType, 
                                                       typeSystem(), false) == null )
                    {
                        throw new SemanticException(p
                                + " does not handle any parameter of its argument "
                                + "types.", p.position());
                    }
                    else
                    {
                        //A method in a super class can handle p.  Remove p from being a top-level
                        //method.
                        remove(toRemove, p);
                    }
                }
                else if (containsWithFormalTypes(toKeep, p))
                {
                    remove(toRemove, p);
                }
                else toKeep.add(p);
            }
        }
        if (doingMethods)
            classCheckingType.methods().removeAll(toRemove);
        else
            classCheckingType.constructors().removeAll(toRemove);
    }
    
    private void remove(List toRemove, OOMatchProcedureInstance p)
    {
        toRemove.add(p);
        ((OOMatchClassType)classCheckingType).saveTopLevel(p);
    }
    
    /**@return Whether there is already a procedure with the same formal
     * types as p that we're keeping
     * @param toKeep
     * @param p
     * @return
     */
    private boolean containsWithFormalTypes(List toKeep, OOMatchProcedureInstance p)
    {
        for (Iterator i = toKeep.iterator(); i.hasNext(); )
        {
            OOMatchProcedureInstance other = (OOMatchProcedureInstance)i.next();
            if (other.sameName(p) && other.formalTypes().equals(p.formalTypes()))
                return true;
        }
        return false;
    }
    /** Check whether first and second are ambiguous, given that neither is preferred.
     *  If so, throw an exception; if not, do nothing. */
    private void checkForAmbiguity(Patternable first, 
            Patternable second, 
            List intersection)
        throws SemanticException
    {
        //At this point they have an intersection; that intersection must therefore
        //exist as a method in the same class.
        //The following ugliness is due to lack of covariant return types
        List possibleMethods = OOMatchClassType.spotForSameName(first, classCheckingType);
        for (Iterator i = possibleMethods.iterator(); i.hasNext(); )
        {
            Patternable possibleMethod = (Patternable)i.next();
            if (possibleMethod.paramTypes().equals(intersection))
            {
                return;
            }
        }
        /*
        DEBUG
        StringUntokenizer.printList(intersection);
        for (Iterator i = possibleMethods.iterator(); i.hasNext(); )
        {
            OOMatchProcedureInstance possibleMethod = (OOMatchProcedureInstance)i.next();
            List types = possibleMethod.formalTypes();
            StringUntokenizer.printList(types);
            if (types.size() != intersection.size())
            {
                continue;
            }
            boolean equal = true;
            for (Iterator j = types.iterator(), k = intersection.iterator(); j.hasNext(); )
            {
                if (!(j.next().equals(k.next())))
                    equal = false;
            }
            if (equal)
            {
                return;
            }
        }
        */
        throw new SemanticException(first + "\nis ambiguous with\n"
                + second + " \nin " + className() +
                ".  For example, we wouldn't know how to handle the following arguments:\n"
                + PatternType_c.printParamList(intersection), classCheckingType.position());
    }
    
    private void checkDeconstructorThrows(OOMatchProcedureInstance m, List types)
        throws SemanticException
    {
        //Check that whatever deconstructors that m references throw, m also throws.
        for (Iterator i = types.iterator(); i.hasNext(); )
        {
            Object o = i.next();
            if (o instanceof PatternType)
            {
                PatternType param = (PatternType)o;
                DeconstructorInstance d = param.decon();
                if (!d.throwsSubset(m))
                {
                    //Error: m isn't throwing enough
                    List missingThrows = new LinkedList(d.throwTypes());
                    missingThrows.removeAll(m.throwTypes());

                    throw new SemanticException(m + " must declare to throw these types:\n" +
                            missingThrows + "\n" +
                            "because " + d + " does.");
                }
                checkDeconstructorThrows(m, param.pattern());
            }
        }

    }
    
    private void dupDefn(OOMatchProcedureInstance m, OOMatchProcedureInstance n)
        throws SemanticException
    {
        throw new SemanticException("Duplicate definition: " +
                m + " and " + n + " in class " + 
                className(), 
                classCheckingType.position());
    }
    
    /** Checks for different return types, different throw types, and 
     * duplicate definition errors.
     * Duplicate definitions have to be checked by the OOMatch extension because
     * by the time Polyglot checks for them, some methods will have been removed
     * from the class.  (Also it requires a different check.) 
     * 
     * This method first checks whether m is overriding a regular Java method.
     * If so, we shouldn't do some of the other checks for it.
     * @param m
     * @throws SemanticException
     */
    private void checkErrors(Patternable m)
        throws SemanticException
    {
        if (!(m instanceof MethodInstance)) return;  //don't do constructors for now
        
        ClassType t = (ClassType)m.container();
        
        boolean noDispatcher = false;  //True once m doesn't need a dispatcher
            //(because it overrides a Java method)
        Patternable javaErrorMethod = null;  //Gets set to a method in a Java superclass
            //with the same name as m but different parameters.  Unless there's another
            //one with the same parameters, we then need to give an error.
        do
        {
            if (!(t instanceof OOMatchClassType)) //Java class
            {
                for (Iterator i = OOMatchClassType.spotForSameName(m, t).iterator(); i.hasNext(); )
                {
                    Patternable n = (Patternable)i.next();
                    
                    if (!noDispatcher && m != n)
                    {
                        //Check for overriding a regular Java method
                        if (m.paramTypes().equals(n.paramTypes()))
                        {
                            m.setNoDispatcher();
                            noDispatcher = true;
                            checkThrow(m, n, t);
                            checkReturn(m, n, t);
                        }
                        else
                        {
                            javaErrorMethod = n;
                        }
                    }
                }
            }
            t = (ClassType)t.superType();
        } while (!t.equals(ts.Object()));
        
        if (!noDispatcher)
        {
            if (javaErrorMethod != null)
            {
                throw new SemanticException(m + 
                        " must have the same parameter types as " +
                        javaErrorMethod.container() + "." + javaErrorMethod + 
                        " because an OOMatch class is extending a Java class.",
                        classCheckingType.position());
            }
            else checkErrorsReally(m);
        }
    }
    
    //This method does the real OOMatch error checks, given that m doesn't conflict with
    //a regular Java method.
    private void checkErrorsReally(Patternable m)
    throws SemanticException
    {
        boolean mHasOnlyFormals = m.hasOnlyFormals();
        boolean compatWarnings = ((OOMOptions)job.extensionInfo().getOptions()).compatWarnings();
        checkDeconstructorThrows(m, m.paramTypes());
        ClassType t = (ClassType)m.container();
        
        do
        {
            for (Iterator i = OOMatchClassType.spotForSameName(m, t).iterator(); i.hasNext(); )
            {
                Patternable n = (Patternable)i.next();
                
                if (t == m.container() && m != n)
                    //if m and n are in the same class, but aren't the same method
                {
                    //duplicate definition
                    if (m.isSameProc(n))
                    {
                        dupDefn(m, n);
                    }
                
                    //Give a warning for backwards compatibility
                    if (compatWarnings && mHasOnlyFormals && m.preferred(n) && n.hasOnlyFormals())
                    {
                        ErrorQueue eq = errorQueue();
                        eq.enqueue(ErrorInfo.WARNING, m + " overrides " + n + 
                                ", where in Java they would be overloaded.",
                                   m.position());
    
                    }
                }
                
                if (m != n && !m.cantBothApply(n))  //anytime 2 methods could both apply,
                    //they must have the same return and throw types; otherwise,
                    //you can't tell what type a call to the function has.
                    //In the future, it would be more ideal to add methods overloaded
                    //on their return type, and covariant return types, to lift some
                    //of the restrictiveness of this rule.
                {
                    //Give a warning for backwards compatibility
                    if (compatWarnings && 
                            t != m.container() && 
                            mHasOnlyFormals  && n.hasOnlyFormals())
                    {
                        if (m.paramTypes().equals(n.paramTypes()))
                        {
                            //Java overriding is taking place
                        }
                        else 
                        {
                            ErrorQueue eq = errorQueue();
                            eq.enqueue(ErrorInfo.WARNING, m +
                                    " might simultaneously apply with " + n + 
                                    " in class " + t + ", where it wouldn't in Java.",
                                       m.position());
                        }
    
                    }
                    
                    checkThrow(m, n, t);
                    checkReturn(m, n, t);
                    
                }
                
            }
            t = (ClassType)t.superType();
        } while (!t.equals(ts.Object()));
        
    }

    private void checkThrow(Patternable m, Patternable n, ClassType t)
        throws SemanticException
    {
        //Check for valid "throws" clauses
        boolean bothRegular = m.hasOnlyFormals() && n.hasOnlyFormals();
        boolean mOverridesN = m.preferred(n),
                nOverridesM = n.preferred(m);
        if (n.container() != m.container())
        {
            //Methods in subclasses override those in superclasses,
            //except if the superclass is final and the subclass isn't
            if (n.flags().isFinal() && !m.flags().isFinal())
            {
                nOverridesM = true;
                mOverridesN = false;
            }
            else
            {
                mOverridesN = true;
                nOverridesM = false;
            }
        }
        if (bothRegular && mOverridesN)
        {
            if (!m.throwsSubset(n))
            {
                throw new SemanticException(m + 
                        " must throw a subset of the throw types of " +
                        t.fullName() + "." + n + 
                        " in class " + className(), 
                        classCheckingType.position());

            }
        }
        else if (bothRegular && nOverridesM)
        {
            if (!n.throwsSubset(m))
            {
                throw new SemanticException(n + 
                        " must throw a subset of the throw types of " +
                        t.fullName() + "." + m + 
                        " in class " + className(), 
                        classCheckingType.position());
                
            }
        }
        else if (!m.throwTypes().equals(n.throwTypes()))
        {
            throw new SemanticException(m + 
                    " must have the same throw types as " +
                    t.fullName() + "." + n + 
                    " in class " + className(), 
                    classCheckingType.position());
        }
        
    }
    
    private void checkReturn(Patternable m, Patternable n, ClassType t)
        throws SemanticException
    {
        //Check for valid return types
        MethodInstance mAsMi = (MethodInstance)m, 
            nAsMi = (MethodInstance)n;
        if (!mAsMi.returnType().equals(nAsMi.returnType()))
        {
            throw new SemanticException(m + 
                    " must have the same return type as " +
                    t.fullName() + "." + n + 
                    " in class " + className(), 
                    classCheckingType.position());
        }
        

    }

    /** Take m and put it in the appropriate overriding heirarchy of listOfMs, i.e.
     * if it overrides any methods in listOfMs then make them its child and vice versa.
     * 
     * @param m The method to add
     * @param listOfMs A list of all methods with the same name as m that have been
     *                 encountered so far.
     * @return The new List with m in its proper place.
     */
    private Object[] add(Patternable m, List listOfMs)
            throws SemanticException 
    {
        
        boolean hasAParent = false;  //Keeps track of whether m has gotten stuffed
            //into the children of some other method in listOfMs.
        List retVal = new ArrayList(listOfMs.size() + 1);  //return value
        for (Iterator i = listOfMs.iterator(); i.hasNext(); ) 
        {
            Patternable mostGeneral = (Patternable) (i.next());  //A
                //method with m's name which, so far, is most general
                //(i.e. it overrides nothing)

            /*
            if (intersection == null)
            {
                //If their intersection is null, there can't be overriding
                //DEBUG: don't need to do this check in the final, correct version
                
                if (mostGeneral.preferred(m) || m.preferred(mostGeneral))
                {
                    throw new Error("");
                }
                //retVal.add(mostGeneral);
                //continue;
            }
            */
            
            if (mostGeneral.preferred(m))
            {
                //What was previously thought to be a most general method is actually
                //a child of m.
                //We don't need to add anything to the list to return because m is 
                //getting added later (or indeed, perhaps it's already been added).
                
                //Since the structure is a DAG, mostGeneral might have
                //already been added as a child of m on another path through
                //the DAG.  Don't add it twice.
                if (!m.children().contains(mostGeneral))
                    m.children().add(mostGeneral);
            }
            else
            {
                if (m.preferred(mostGeneral))
                {
                    List children = mostGeneral.children();
                    Object[] returned = add(m, children);
                    boolean wasAdded = ((Boolean)returned[1]).booleanValue();
                    
                    //Set the new children of mostGeneral to the result of 
                    //adding m to them 
                    mostGeneral.children().clear();
                    mostGeneral.children().addAll((List)returned[0]);
                    hasAParent = true;
                    
                    //add m as a child if necessary
                    if (!wasAdded)
                        mostGeneral.children().add(m);
                
                }
                
                else 
                {
                    List intersection = OOMatchMethodInstance.intersection(
                            m.paramTypes(), mostGeneral.paramTypes());

                    if (intersection != null) {
                        //Neither m nor mostGeneral is preferred.  Make sure their 
                        //intersection is either null (which it isn't at this point),
                        //or that it exists as a method.
                        checkForAmbiguity(m, mostGeneral, intersection);
                    }                    
                    
                }
                retVal.add(mostGeneral);  //Keep mostGeneral in the list of 
                    //methods, since it still has no parent.
            }
        }
        return new Object[] {retVal, new Boolean(hasAParent)};
    }

}
