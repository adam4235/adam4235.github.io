package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.ext.oomatch.ast.DeconstructorDecl;
import polyglot.ext.oomatch.ast.NormalParam;
import polyglot.ext.oomatch.ast.OOMatchConstructorDecl_c;
import polyglot.ext.oomatch.ast.OOMatchMethodDecl_c;
import polyglot.ext.oomatch.ast.OOMatchNodeFactory;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.ErrorHandlingVisitor;
import polyglot.visit.NodeVisitor;
import java.util.*;

/** Desugar the private, protected, and public fields for constructor parameters. */
public class DesugarConstructors extends ErrorHandlingVisitor
{

    public DesugarConstructors(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v) throws SemanticException {
        if (n instanceof ClassBody)
        {
            return desugar((ClassBody)n);
        }
        else return n;
    }
    
    protected ClassBody desugar(ClassBody body)
        throws SemanticException 
    {
        List members = new LinkedList(body.members()),
            toRemove = new LinkedList(),
            toAdd = new LinkedList();
        fieldsAdded = new LinkedList();
        for (Iterator i = members.iterator(); i.hasNext();)
        {
            Object o = i.next();
            if (o instanceof OOMatchMethodDecl_c)
            {
                //methods should not have any formals with access specifiers
                OOMatchMethodDecl_c m = (OOMatchMethodDecl_c)o;
                for (Iterator j = m.formals().iterator(); j.hasNext();)
                {
                   
                    Object p = j.next();
                    if (p instanceof Formal)
                    {
                        Formal f = (Formal)p;
                        if (hasAccessSpecs(f.flags()))
                        {
                            throw new SemanticException("Regular methods can't have " +
                                    "formals with access specifiers.", m.position());
                        }
                    }
                }
            }
            else if (o instanceof OOMatchConstructorDecl_c)
            {
                OOMatchConstructorDecl_c constructor = (OOMatchConstructorDecl_c)o;
                boolean hasAccessSpecs = false, hasNoAccessSpecs = false;
                for (Iterator j = constructor.formals().iterator(); j.hasNext();)
                {
                    Object p = j.next();
                    if (p instanceof Formal)
                    {
                        Formal f = (Formal)p;
                        if (hasAccessSpecs(f.flags()))
                            hasAccessSpecs = true;
                        else
                            hasNoAccessSpecs = true;
                    }
                    else hasNoAccessSpecs = true;
                }
                if (hasAccessSpecs && hasNoAccessSpecs)
                {
                    throw new SemanticException("All parameters must be given an " +
                            "access specifier if any have one.", constructor.position());
                }
                if (hasAccessSpecs)
                {
                    toRemove.add(constructor);
                    toAdd.addAll(desugaredMembers(constructor));
                }

            }
        }
        members.removeAll(toRemove);
        members.addAll(toAdd);
        return body.members(members);
    }
    List fieldsAdded = null;   //Keeps track of all the constructor-added fields
        //that have been added to a single class.  Used to allow duplicate instances
        //of the same field in different constructors.
    private boolean hasAccessSpecs(Flags flags)
    {
        return flags.isPrivate() || flags.isPublic() || flags.isProtected();
    }
    private List desugaredMembers(OOMatchConstructorDecl_c c)
        throws SemanticException 
    {
        List retVal = new LinkedList();
        List newConsFormals = new LinkedList(),
            newConsParams = new LinkedList(),
            deconBody = new LinkedList(),
            deconParams = new LinkedList();
        
        Block conBody = c.body();
        for (Iterator i = c.formals().iterator(); i.hasNext(); )
        {
            Formal f = ((Formal)i.next());
            Flags clearedFlags = f.flags().clearPrivate().clearProtected().clearPublic();
            Formal clearedF = f.flags(clearedFlags);
            NormalParam clearedNormal = ((OOMatchNodeFactory)nf).NormalParam(
                    f.position(), clearedF);
            newConsFormals.add(clearedF);
            newConsParams.add(clearedNormal.copy());
            FieldDecl field = nf.FieldDecl(f.position(), f.flags(), 
                    (TypeNode)f.type().copy(), f.name());
            if (!fieldIn(field))
            {
                retVal.add(field);
                fieldsAdded.add(field);
            }
            deconParams.add(clearedNormal);
            Local target = nf.Local(f.position(), f.name());
            Field fieldRef = nf.Field(f.position(), nf.Special(f.position(), Special.THIS),
                    field.name());
                deconBody.add(nf.Eval(f.position(), 
                        nf.LocalAssign(f.position(), target, Assign.ASSIGN, fieldRef)));
            
            //Local conTarget = nf.Local(f.position(), f.name());
            FieldAssign conAssign = nf.FieldAssign(f.position(), 
                    (Field)fieldRef.copy(), 
                    Assign.ASSIGN,
                    (Local)target.copy());
            conBody = conBody.append(nf.Eval(f.position(), conAssign));
            
        }
        
        //add new constructor
        c = (OOMatchConstructorDecl_c)c.formals(newConsFormals);
        c = (OOMatchConstructorDecl_c)c.body(conBody);
        c = (OOMatchConstructorDecl_c)c.params(newConsParams);
        retVal.add(c);
        
        //add new deconstructor
        deconBody.add(nf.Return(c.position(), 
                          nf.BooleanLit(c.position(), true)
                                .type(ts.Boolean()))
        );
        DeconstructorDecl decon = ((OOMatchNodeFactory)nf).DeconstructorDecl(
                 c.position(), nf.CanonicalTypeNode(c.position(), ts.Boolean()),
                 c.name(), deconParams, new LinkedList(), 
                 nf.Block(c.position(), deconBody), c.flags(), null);
        retVal.add(decon);
        return retVal;
    }
    
    private boolean fieldIn(FieldDecl f)
        throws SemanticException
    {
        for (Iterator i = fieldsAdded.iterator(); i.hasNext();)
        {
            FieldDecl other = (FieldDecl)i.next();
            if (other.name().equals(f.name()))
            {
                //Can't compare other.type().type() and f.type().type()
                //because types haven't been built yet.  However, they should
                //be the same if and only if their string representations are the same.
                if (other.toString().equals(f.toString()))
                {
                    return true;
                }
                else 
                    throw new SemanticException(f + " and " + other + " must have " +
                        "the same type and specifiers.", f.position());
                
            }
        }
        return false;
    }
}
