package polyglot.ext.oomatch.visit;

import java.util.Iterator;

import polyglot.ast.*;
import polyglot.ext.oomatch.StringExt;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.*;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.*;

/** Choose output names for the methods of the class.
 * E.g. if you have these two methods:
 * void f(int x) {...}
 * void f(0) {...}
 * they can't both be named f in the output code because they would
 * have duplicate signatures.
 * Also give a unique ID to each method, which is used in the output code
 * to remember that that method applied.
 */

public class NameMethodsVisitor extends ContextVisitor
{

    public NameMethodsVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node n)
    throws SemanticException 
    {
        if (n instanceof OOMatchClassDecl_c)
        {
            OOMatchClassDecl_c nAsClass = (OOMatchClassDecl_c)n;
            classBodyToTrans = nAsClass.body();
            classTypeToTrans = (OOMatchClassType)nAsClass.type();
        }
        else if (n instanceof New)
        {
            New nAsNew = (New)n;
            if (nAsNew.body() == null) return n;  //no anonymous class present
            classBodyToTrans = nAsNew.body();
            classTypeToTrans = (OOMatchClassType)nAsNew.anonType();
            
            //this will be true the first time through, when anonymous classes
            //haven't been constructed yet
            if (classTypeToTrans.superType() == null) return n;
                
        }
        else return n;
        nameMethods();
        return n;
    }
    
    ClassBody classBodyToTrans = null;
    OOMatchClassType classTypeToTrans = null;


    public void nameMethods()
    {
        String dollarSigns = "$" + calculateDollarSignsForMethods();
        int methodNum = classTypeToTrans.startingID();
        classTypeToTrans.setDollarSigns(dollarSigns);
        for (Iterator i = classBodyToTrans.members().iterator(); i.hasNext(); )
        {
            ClassMember m = (ClassMember)(i.next());
            if (m instanceof OOMatchProcedureDecl)
            {
                //This code assumes methods will be in the same order when originally
                //compiled and when partially compiled again when mentioned in other
                //files.  I don't see why this wouldn't hold, and I don't know how
                //to do anything safer.
                OOMatchProcedureDecl p = (OOMatchProcedureDecl)m;
                p.oomProcedureInstance().setID(methodNum);
                if (p.oomProcedureInstance().shouldBeRenamed()) 
                {
                    String newName = p.name() + dollarSigns + methodNum;
                    p.oomProcedureInstance().setRealName(newName);
                }
                else p.oomProcedureInstance().setRealName(p.name());
                ++methodNum;
            }
        }
    }
    
    /**@return The string of dollar signs that is the smallest string not contained
     *      in any methods of the class being transformed or any of its superclasses. 
     */ 
    public String calculateDollarSignsForMethods()
    {
        ClassType t = classTypeToTrans;
        String dollarSigns = "";
        do {
            //Find the greatest number of dollar signs in the methods of the class
            String newDollarSigns = DollarSignCounter.calculateDollarSignsNeeded(
                t.methods(),
                new DollarSignCounter.StringGetter() {
                    public String getString(Object o)
                    {
                        return ((MethodInstance)o).name();
                    }
                }
            );
            
            if (!t.isAnonymous())
            {
                while (StringExt.contains(t.name(), newDollarSigns + "$"))
                    //If the class name also has too many dollar signs
                    newDollarSigns += "$";
            }
            
            //Remember only the greatest # of dollar signs
            if (newDollarSigns.length() > dollarSigns.length())
                dollarSigns = newDollarSigns;
            
            if (t.superType() instanceof ClassType)
                t = (ClassType)t.superType();
            else break;
        } while (!t.equals(ts.Object()));
        return dollarSigns;

    }

}
