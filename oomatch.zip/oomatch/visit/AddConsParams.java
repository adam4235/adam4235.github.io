package polyglot.ext.oomatch.visit;

import polyglot.ast.*;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.*;
import java.util.*;

//Add extra junk parameters to constructors.
//Not used, because constructors can no longer have patterns.
public class AddConsParams extends ContextVisitor
{

    public AddConsParams(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }
    protected Node leaveCall(Node old, Node n, NodeVisitor v)
    throws SemanticException 
    {

        if (n instanceof ClassDecl)
        {
            ClassDecl classToCheck = (ClassDecl)n;
            return addParams(classToCheck);
        }
        return n;
    }
    
    private Node addParams(ClassDecl classToCheck)
    {
        List constructors = new LinkedList();
        List allMembers = new ArrayList(classToCheck.body().members().size());
        for (Iterator i = classToCheck.body().members().iterator(); i.hasNext();)
        {
            Object o = i.next();
            if (o instanceof OOMatchConstructorDecl_c)
            {
                OOMatchConstructorDecl_c constructor = (OOMatchConstructorDecl_c)o;
                boolean foundConflict;
                int extraParams = 0;
                do {
                    foundConflict = false;

                    for (Iterator j = constructors.iterator(); j.hasNext(); )
                    {
                        OOMatchConstructorDecl_c other = (OOMatchConstructorDecl_c)j.next();
                        if (sameFormals(other.formals(), constructor.formals()))
                        {
                            //conflict; add a new formal to constructor
                            constructor = addFormalTo(constructor);
                            ++extraParams;
                            foundConflict = true;
                            break;
                        }
                    }
                } while (foundConflict);
                OOMatchConstructorInstance ci = 
                    (OOMatchConstructorInstance)constructor.constructorInstance();
                ci.setJunkParams(extraParams);
                constructors.add(constructor);
                allMembers.add(constructor);
            }
            else
                allMembers.add(o);
        }
        return classToCheck.body(classToCheck.body().members(allMembers));
    }
    
    private boolean sameFormals(List f1, List f2)
    {
        if (f1.size() != f2.size()) return false;
        for (Iterator i = f1.iterator(), j = f2.iterator(); i.hasNext(); )
        {
            Formal firstForm = (Formal)i.next(), secondForm = (Formal)j.next();
            if (!firstForm.type().type().equals(secondForm.type().type()))
            {
                return false;
            }
        }
        return true;
    }
    private OOMatchConstructorDecl_c addFormalTo(OOMatchConstructorDecl_c constructor)
    {
        //Calculate the number of dollar signs in the constructor body,
        //and add an extra one, to ensure no conflict with things declared
        //therein.
        DollarSignCounter counter = new DollarSignCounter();
        counter.visitEdge(constructor, constructor.body());
        String dollarSigns = counter.getResult() + "$";
        
        int paramNum = 1;
        String formalName; 
        do {
            formalName = "arg" + dollarSigns + paramNum;
        } while (containsFormalNamed(constructor, formalName));
        TypeNode tn = nf.CanonicalTypeNode(constructor.position(), ts.Boolean());
        Formal newFormal = nf.Formal(constructor.position(), Flags.NONE, tn, formalName);
        newFormal = newFormal.localInstance(ts.localInstance(
                constructor.position(), Flags.NONE, ts.Boolean(), formalName
                ));
        List newFormals = new ArrayList(constructor.formals().size() + 1);
        newFormals.addAll(constructor.formals());
        newFormals.add(newFormal);
        return (OOMatchConstructorDecl_c)constructor.formals(newFormals);
    }

    private boolean containsFormalNamed(OOMatchConstructorDecl_c constructor, String name)
    {
        for (Iterator i = constructor.formals().iterator(); i.hasNext(); )
        {
            Formal f = (Formal)i.next();
            if (f.name().equals(name))
                return true;
        }
        return false;
    }
}
