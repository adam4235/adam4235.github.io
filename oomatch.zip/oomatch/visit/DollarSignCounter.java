package polyglot.ext.oomatch.visit;

import java.util.Iterator;
import java.util.List;

import polyglot.ast.*;
import polyglot.ext.oomatch.StringExt;
import polyglot.visit.NodeVisitor;

/**Traverse an AST, in particular the body of a method, and count
 * the maximum number of $ signs in the names declared therein.
 * 
 * The purpose of this is that the compiler can then declare a 
 * made-up name with one more $ in a row, and that name is then
 * guaranteed not to clash with anything in the body of the method 
 * traversed.
 */
public class DollarSignCounter extends NodeVisitor
{
    private int num;

    public DollarSignCounter()
    {
        super();
    }

    public Node leave(Node old, Node n, NodeVisitor v)
    {
        String otherName = "";

        //do the number of $ signs in n's name
        if (n instanceof ClassDecl)  //e.g. local class declared in method body
        {
            ClassDecl nAsClassDecl = (ClassDecl)n;
            otherName = nAsClassDecl.name();
        }
        else if (n instanceof LocalDecl)
        {
            LocalDecl nAsLocal = (LocalDecl)n;
            otherName = nAsLocal.name();            
        }
        else return n;
        
        //if the number of $ signs in n's name is the most
        //we've seen so far, remember it
        int num = StringExt.count(otherName, "$");
        if (num > this.num) this.num = num;
        return n;
    }
    
    public String getResult()
    {
        return StringExt.nCopies("$", num);
    }
    
    //This is the kind of ugliness needed to implement callback methods in Java.
    public abstract static class StringGetter
    {
        public abstract String getString(Object o);
    }

    /**Given a list of things, calculate how many dollar signs are needed
     * to add to a new made-up name to ensure that it won't clash with anything
     * in the list.
     * @param objects The list of things to search.
     * @param sg A means of getting the name or string to check from each element of
     *      objects.
     * @return A string of dollar signs.
     */
    public static String calculateDollarSignsNeeded(List objects, StringGetter sg)
    {
        String dollarSigns = "";
        
        boolean foundConflictingName;
        do
        {
            foundConflictingName = false;

            for (Iterator i = objects.iterator(); i.hasNext(); )
            {
                Object o = i.next();
                //for each method m in the class
                
                if (StringExt.contains(sg.getString(o), dollarSigns + "$"))  //if
                    //dollarSigns is contained in the method's name
                {
                    foundConflictingName = true;
                    dollarSigns += "$";
                    break;
                }
            }
            
        } while (foundConflictingName);
        return dollarSigns;
    }

    /** 
     * @param formals A list of polyglot.ast.Formal
     * @return The smallest string of $ signs that is not contained in the name of
     *      any element of params.
     */
    public static String dollarSignsFromFormals(List formals)
    {
        return calculateDollarSignsNeeded(formals, 
            new StringGetter() {
                public String getString(Object o) { 
                    return ((Formal)o).name();
                }
            }
        );
    }
}
