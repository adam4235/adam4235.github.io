package polyglot.ext.oomatch;

import polyglot.lex.Lexer;
import polyglot.main.Options;
import polyglot.ext.oomatch.parse.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.*;
import polyglot.ext.oomatch.visit.*;

import polyglot.ast.*;
import polyglot.types.*;
import polyglot.util.*;
import polyglot.frontend.*;

import java.util.*;
import java.io.*;
/**
 * Extension information for oomatch extension.
 */
public class ExtensionInfo extends polyglot.ext.jl.ExtensionInfo {
    static {
        // force Topics to load
        new Topics();
    }

    public String defaultFileExtension() {
        return "oom";
    }

    public String compilerName() {
        return "oomatchc";
    }

    protected Options createOptions() {
        return new OOMOptions(this);
    }

    public Parser parser(Reader reader, FileSource source, ErrorQueue eq) {
        Lexer lexer = new OOMatchLexer(reader, source.name(), eq);
        Grm grm = new Grm(lexer, ts, nf, eq);
        return new CupParser(grm, source, eq);
    }

    protected NodeFactory createNodeFactory() {
        return new OOMatchNodeFactory_c();
    }

    protected TypeSystem createTypeSystem() {
        return new OOMatchTypeSystem_c();
    }

    public static final Pass.ID 
        CREATE_DECONSTRUCTOR_TYPE = new Pass.ID("create-dec-type"),
        DESUGAR_CONS = new Pass.ID("desugar-constructors"),
        OOM_TYPE_CHECK = new Pass.ID("oom-type-check"),
        CREATE_DECONSTRUCTORS = new Pass.ID("create-deconstructor"),
        ADD_DECONSTRUCTORS = new Pass.ID("add-deconstructor"),
        PARAM_TYPES = new Pass.ID("param-types"),
        VAR_DECL = new Pass.ID("var-decl"),
        ADD_RETURN = new Pass.ID("add-return"),
        ADD_COMPLETERS = new Pass.ID("completers"),
        DEBUG = new Pass.ID("debug"),
        NAME_PATTERNS = new Pass.ID("name-patterns"),
        NAME_METHODS = new Pass.ID("name-methods"),
        TRANSFORM_CALLS = new Pass.ID("transform-calls"),
        TRANSFORM_PATTERNS = new Pass.ID("transform-patterns"),
        REMOVE_PARAMS = new Pass.ID("remove-params"),
        MISSING_TYPE_INFO = new Pass.ID("missing-type"),
        DEC_ADDED = new Pass.ID("deconstructor-barrier"),
        ADD_CONS_PARAMS = new Pass.ID("add-cons-params"),
        RENAME_METHODS = new Pass.ID("rename-methods"),
        ADD_MANUAL_CHILDREN = new Pass.ID("add-manual-children"),
        DESUGAR_SELECT = new Pass.ID("desugar-select"),
        BODIES_DISAM = new Pass.ID("bodies-disam"),
        DEFAULT_SELECT = new Pass.ID("default-select"),
        LET_DOLLARS = new Pass.ID("let-dollars"),
        DESUGAR_NAMED_PATTERNS = new Pass.ID("desugar-named-patterns"),
        DISAM_METHODS = new Pass.ID("disam-methods"),
        ADD_METHODS = new Pass.ID("add-methods");
    
    public List passes(Job job) {
        
        List passes = super.passes(job);
/*
        beforePass(passes, Pass.BUILD_TYPES,
                new VisitorPass(NAME_PATTERNS, job,
                        new NamePatternsVisitor(nf)));
  */
        beforePass(passes, Pass.BUILD_TYPES, 
                new VisitorPass(DESUGAR_CONS, job,
                    new DesugarConstructors(job, ts, nf)));

        beforePass(passes, Pass.CLEAN_SUPER, 
                new VisitorPass(CREATE_DECONSTRUCTOR_TYPE, job,
                    new DecTypeCreator(job, ts, nf)));

        beforePass(passes, Pass.CLEAN_SIGS, 
                new VisitorPass(CREATE_DECONSTRUCTORS, job,
                    new DeconstructorCreator(job, ts, nf)));
        /*
        beforePass(passes, Pass.CLEAN_SIGS,
                new VisitorPass(DEBUG, job,
                        new DebugVisitor(job, ts, nf)));
         */
        
        beforePass(passes, Pass.CLEAN_SIGS, 
                new VisitorPass(ADD_DECONSTRUCTORS, job, 
                    new AddDeconstructorVisitor(job, ts, nf)));

        /*
        beforePass(passes, Pass.CLEAN_SIGS, 
                new VisitorPass(PARAM_TYPES, job, 
                    new ParamTypesVisitor(job, ts, nf)));
        */
        
        beforePass(passes, Pass.CLEAN_SIGS, 
                new VisitorPass(VAR_DECL, job, 
                    new VariableDeclVisitor(job, ts, nf)));

        //Need a barrier pass to support separate compilation.
        //This ensures that deconstructors have been added to all classes
        //mentioned in the source file being compiled before deconstructors are
        //looked up.
        beforePass(passes, Pass.CLEAN_SIGS, 
                new BarrierPass(DEC_ADDED, job));
        
        //Methods have to be disambiguated and added after other class members,
        //because parameters that reference a field have to be able to look up the
        //field in the class in order to receive a type.
        beforePass(passes, Pass.ADD_MEMBERS_ALL,
                new VisitorPass(DISAM_METHODS, job,
                        new DisamMethods(job, ts, nf)));
        beforePass(passes, Pass.ADD_MEMBERS_ALL,
                new VisitorPass(ADD_METHODS, job,
                        new AddMethods(job, ts, nf)));
        
        beforePass(passes, Pass.DISAM_ALL, 
                new BarrierPass(BODIES_DISAM, job));

        /*
        beforePass(passes, Pass.DISAM_ALL, 
                new VisitorPass(DEFAULT_SELECT, job,
                    new CreateDefaultSelect(job, ts, nf)));
*/
        
        beforePass(passes, Pass.DISAM_ALL,
                new VisitorPass(ADD_MANUAL_CHILDREN, job,
                    new AddManualChildren(job, ts, nf)));
        
        beforePass(passes, Pass.DISAM_ALL,
                new VisitorPass(NAME_METHODS, job,
                        new NameMethodsVisitor(job, ts, nf)));

        beforePass(passes, Pass.DISAM_ALL,
                new VisitorPass(DESUGAR_NAMED_PATTERNS, job,
                        new DesugarNamedParams(job, ts, nf)));

        //do before the barrier pass for anonymous classes.
        beforePass(passes, Pass.DISAM_ALL,
                new VisitorPass(OOM_TYPE_CHECK, job, 
                        new OOMatchTypeCheck(job, ts, nf)));
        
        /*
        beforePass(passes, Pass.TYPE_CHECK,
                new VisitorPass(OOM_TYPE_CHECK, job, 
                        new OOMatchTypeCheck(job, ts, nf)));
                        */
/*
        beforePass(passes, Pass.EXIT_CHECK, 
        //beforePass(passes, Pass.REACH_CHECK,
                new VisitorPass(ADD_RETURN, job, 
                        new AddReturnVisitor(job, ts, nf)));
        */
        
        /*
        beforePass(passes, Pass.PRE_OUTPUT_ALL,
                new VisitorPass(ADD_COMPLETERS, job,
                        new CompleterVisitor(job, ts, nf)));
        */

        beforePass(passes, Pass.REACH_CHECK,
                new VisitorPass(RENAME_METHODS, job,
                        new RenameMethodsVisitor(job, ts, nf)));

/*
        beforePass(passes, Pass.REACH_CHECK,
                new VisitorPass(ADD_CONS_PARAMS, job,
                    new AddConsParams(job, ts, nf)));
  */
        beforePass(passes, Pass.REACH_CHECK,
                new VisitorPass(LET_DOLLARS, job,
                        new DollarSignsForLet()));

        beforePass(passes, Pass.REACH_CHECK,
                new VisitorPass(TRANSFORM_CALLS, job,
                        new TransformCallsVisitor(job, ts, nf)));
        
        beforePass(passes, Pass.REACH_CHECK,
                new VisitorPass(TRANSFORM_PATTERNS, job,
                        new TransformPatternsVisitor(job, ts, nf)));

        //DEBUG
        /*beforePass(passes, Pass.REACH_CHECK,
                new VisitorPass(MISSING_TYPE_INFO, job,
                        new FindMissingTypeInfo()));*/
        
        //Now that the deconstructors have been transformed, check that variables are
        //assigned on all paths, and that they're not used before they're given a
        //value.  This simply uses the existing
        //Polyglot variable-declaration-before-use visitor.
        //Edit: this check is now done in the regular InitChecker pass,
        //and wouldn't work if done here.
        /*
        beforePass(passes, Pass.PRE_OUTPUT_ALL, 
                new VisitorPass(Pass.INIT_CHECK, job, 
                        new InitChecker(job, ts, nf)));
*/
        
        return passes;
    }

}
