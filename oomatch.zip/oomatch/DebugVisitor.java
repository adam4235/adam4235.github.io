package polyglot.ext.oomatch;

import polyglot.ast.*;
import polyglot.ext.oomatch.ast.*;
import polyglot.ext.oomatch.types.*;
import polyglot.frontend.Job;
import polyglot.types.*;
import polyglot.visit.*;
import java.util.*;

public class DebugVisitor extends ContextVisitor
{

    public DebugVisitor(Job job, TypeSystem ts, NodeFactory nf)
    {
        super(job, ts, nf);
    }

    protected Node leaveCall(Node old, Node n, NodeVisitor v) throws SemanticException {
        if (n instanceof PatternParam)
        {
            PatternParam p = (PatternParam)n;
            if (p.decType instanceof AmbTypeNode)
            {
                AmbTypeNode amb = (AmbTypeNode)p.decType;
                if (amb.name().equals("InvokeStmt"))
                {
                    System.out.println("InvokeStmt");
                }
                else if (amb.name().equals("d"))
                {
                    System.out.println("d");
                }
            }
        }
        /*
        if (n instanceof OOMatchClassDecl_c)
        {
            OOMatchClassDecl_c cl = (OOMatchClassDecl_c)n;
            ClassType t = cl.type();
            findEqualChildren(t);
            System.out.println(n);
        }
        */
        return n;
    }

    public static void findEqualChildren(ClassType t)
    {
        for (Iterator i = t.methods().iterator(); i.hasNext(); )
        {
            OOMatchMethodInstance m = (OOMatchMethodInstance)i.next(); 
            for (Iterator j = t.methods().iterator(); j.hasNext(); )
            {
                OOMatchMethodInstance m2 = (OOMatchMethodInstance)j.next(); 
                if (m != m2 && m.children() == m2.children())
                {
                    System.out.println("equal children: " + m + "\nand " + m2);
                }
            }
            
        }
        
    }
}
