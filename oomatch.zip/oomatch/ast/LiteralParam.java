package polyglot.ext.oomatch.ast;

import java.util.List;
import polyglot.ast.*;
import polyglot.visit.*;
import polyglot.util.*;
import polyglot.types.*;
import polyglot.ext.jl.ast.Term_c;
import polyglot.ext.oomatch.types.*;

/** The AST node for a literal (numeric, string, or null) parameter to
 * a method.
 */

public class LiteralParam extends Term_c implements Param {

    /** The literal of the parameter */
	private Lit literal;
    
	private Type type;

    //Needed to create negative literals.  Returns the negative of this literal.
    public LiteralParam negate(OOMatchNodeFactory nf)
    {
        LiteralParam n = (LiteralParam) copy();

        if (literal instanceof IntLit)
        {
            IntLit il = (IntLit)literal;
            n.literal = il.value(-il.value());
        }
        else if (literal instanceof CharLit)
        {
            //A negative char lit is an int lit
            CharLit cl = (CharLit)literal;
            n.literal = nf.IntLit(cl.position(), IntLit.INT, -cl.value());
        }
        else if (literal instanceof FloatLit)
        {
            FloatLit fl = (FloatLit)literal;
            n.literal = fl.value(-fl.value());
        }
        return n;
    }

    public LiteralParam(Position pos, Lit literal)
    {
        super(pos);
        this.literal = literal;
    }
    
    public Node assignType(ContextVisitor tc) throws SemanticException
    {
        LiteralParam n = (LiteralParam) copy();
        n.type = new ValueType_c(tc.typeSystem(), position(), type(tc.typeSystem()), literal);
        return n;
    }

    public Node disambiguate(AmbiguityRemover ar) 
    throws SemanticException 
    {
        return assignType(ar);
    }

    public Type type() { return type; }
    public Type regularType() { return type; }
    
	public Term entry() {
		return literal;
	}

	public List acceptCFG(CFGBuilder v, List succs) {
		v.visitCFG(literal, this);
		return succs;
	}

	public Lit literal() { return literal; }

    public String printParam()
    {
        return literal.toString();
    }

    /** @return The type of the parameter, in the context of the typesystem tc.*/
    public Type type(TypeSystem tc)
    {
        if (literal instanceof CharLit)
            return tc.Char();
        else if (literal instanceof IntLit)
        {
            IntLit.Kind kind = ((IntLit)literal).kind();
            if (kind == IntLit.INT)
            {
                return tc.Int();
            }
            else if (kind == IntLit.LONG)
            {
                return tc.Long();
            }
            else return null;
        }
        else if (literal instanceof FloatLit)
        {
            FloatLit.Kind kind = ((FloatLit)literal).kind();
            if (kind == FloatLit.FLOAT)
            {
                return tc.Float();
            }
            else if (kind == FloatLit.DOUBLE)
            {
                return tc.Double();
            }
            else return null;
        }
        else if (literal instanceof BooleanLit)
            return tc.Boolean();
        else if (literal instanceof StringLit)
            return tc.String();
        else if (literal instanceof NullLit)
            return tc.Null();
        else
            return null;
    }
    
    public Node visitChildren(NodeVisitor v) {
        LiteralParam n = (LiteralParam)copy();
        n.literal = (Lit) visitChild(literal, v);
        return n;
    }
}
