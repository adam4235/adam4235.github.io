package polyglot.ext.oomatch.ast;

import polyglot.ast.*;
import polyglot.ext.jl.parse.Name;
import polyglot.types.Flags;
import polyglot.util.*;

import java.util.*;

/**
 * NodeFactory for oomatch extension.
 */
public interface OOMatchNodeFactory extends NodeFactory {
    public DeconstructorDecl DeconstructorDecl(Position pos, TypeNode returnType, String name, List formals, List throwTypes, Block body, Flags flags, NormalParam p);
    public NormalParam NormalParam(Position pos, Formal formal);
    public PatternParam PatternParam(Position pos, Name decon, List formals, Formal name);
    public PatternParam PatternParam(Position pos, Name decon, List formals);
    public LiteralParam LiteralParam(Position pos, Lit lit);
    public NamedParam NamedParam(Position pos, String name);
    public MadeUpParam MadeUpParam(Position pos, Formal formal);
    public Lit Lit(Position pos, Object literal);

    //Select statement
    public SelectCase SelectCase(Position pos, List params, List statements);
    public Select Select(Position pos, List args, List statements);

    //Let statement
    public Let Let(Position pos, PatternParam lhs, Expr rhs);
    
    /**Set the user-declared child of the first element of l to m*/
    public MethodDecl setChild(MethodDecl m, MethodDecl l);
    
    //Method declaration with a where clause
    public MethodDecl OOMMethodDecl(Position pos, Flags flags, TypeNode returnType, String name, List formals, List throwTypes, Expr whereClause, Block body);

}
