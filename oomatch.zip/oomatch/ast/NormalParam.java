package polyglot.ext.oomatch.ast;

import java.util.List;

import polyglot.ast.Formal;
import polyglot.ast.Node;
import polyglot.ast.Term;
import polyglot.visit.*;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.util.*;
import polyglot.ext.jl.ast.Term_c;

/** The AST node for a normal parameter to a method */
public class NormalParam extends Term_c implements Param {

    /** The Formal that makes up the normal parameter */
    private Formal f;
	
	public NormalParam(Position pos, Formal f)
	{
		super(pos);
		this.f = f;
	}
	public Term entry() {
		return f;
	}

	public List acceptCFG(CFGBuilder v, List succs) {
		v.visitCFG(f, this);
		return succs;
	}

	public Formal formal() { return f; }

    public String printParam()
    {
        return f.toString();
    }
    public Type type() { return f.declType(); }
    public Type regularType() { return f.declType(); }
    
    public Node assignType(ContextVisitor tc) throws SemanticException 
    { 
        return this; 
    }

    public Node visitChildren(NodeVisitor v) {
        NormalParam n = (NormalParam)copy();
        n.f = (Formal) visitChild(f, v);
        return n;
    }

}
