package polyglot.ext.oomatch.ast;

import java.util.*;

import polyglot.ast.*;
import polyglot.ext.jl.ast.*;
import polyglot.types.*;
import polyglot.util.*;

/** An OOMatch class.  Pretty much the same as a Java class, to Polyglot. */

public class OOMatchClassDecl_c extends ClassDecl_c implements ClassDecl {
	public OOMatchClassDecl_c(Position pos, Flags flags, String name,
			TypeNode superClass, List interfaces, ClassBody body) {
		super(pos, flags, name, superClass, interfaces, body);
	}

    //DEBUG
    protected void printMembers()
    {
        List allMembers = body.members();
        Iterator i = allMembers.iterator();
        while (i.hasNext()) {
            Object o = i.next();
            if (o instanceof OOMatchProcedureDecl) {
                System.out.println(((OOMatchProcedureDecl)o).printProc());
                System.out.println(((OOMatchProcedureDecl)o).oomProcedureInstance().toString());
            }
        }
    }
	

}
