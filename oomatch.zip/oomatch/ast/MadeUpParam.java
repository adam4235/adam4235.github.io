package polyglot.ext.oomatch.ast;

import polyglot.ast.Formal;
import polyglot.util.Position;

/** A Param made up by the compiler to replace a NamedParam.
 * There's a special class so we can distinguish made up parameters from
 * regular user parameters, because made up parameters should not be present
 * in the user method (to prevent name clashes).
 *
 */
public class MadeUpParam extends NormalParam
{

    public MadeUpParam(Position pos, Formal f)
    {
        super(pos, f);
    }

}
