package polyglot.ext.oomatch.ast;

import polyglot.ext.jl.ast.*;
import polyglot.util.Position;

import java.util.*;

//A node to hold a list of statements.  Visiting it visits each statement in the
//list.  Used in transforming a Let statement.

/*
public class StmtList extends Stmt_c
{
    public Term entry() {
        return listEntry(stmts, this);
    }

    public List acceptCFG(CFGBuilder v, List succs) {
        v.visitCFGList(stmts, this);
        return succs;
    }

    List stmts;

    public StmtList(Position pos, List stmts)
    {
        super(pos);
        this.stmts = stmts;
    }
    public Node visitChildren(NodeVisitor v) {
        StmtList n = (StmtList)copy();
        n.stmts = visitList(stmts, v);
        return n;
    }

}
*/

public class StmtList extends AbstractBlock_c
{
    public StmtList(Position pos, List stmts)
    {
        super(pos, stmts);
    }

}
