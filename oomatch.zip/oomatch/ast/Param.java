package polyglot.ext.oomatch.ast;

import polyglot.ast.Node;
import polyglot.ast.Term;
import polyglot.types.SemanticException;
import polyglot.visit.ContextVisitor;

import polyglot.types.*;

/** The AST node for a parameter to a method.  Parameters can't be subtypes of
 * the Java Formal AST node, because a Formal has a name and not all parameters
 * have a name in OOMatch.  Rather, normal parameters get parsed as instances of
 * NormalParam.
 */
public interface Param extends Term {
    /**@return The type of this parameter*/
    public Type type();
    
    /** A method called by a visitor to assign a type to this parameter */
    public Node assignType(ContextVisitor tc) throws SemanticException;

    /** Return a String representation of the parameter, for debugging and 
     * error messages. */
    public String printParam();
    
    /**@return A correspond regular Java type for the parameter.  E.g. for
     * patterns, the type before the ".".*/
    public Type regularType();
    
}
