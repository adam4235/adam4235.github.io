package polyglot.ext.oomatch.ast;

import java.util.List;

import polyglot.ext.jl.ast.*;
import polyglot.types.*;
import polyglot.util.*;
import polyglot.visit.CFGBuilder;
import polyglot.visit.ContextVisitor;
import polyglot.visit.NodeVisitor;
import polyglot.ast.*;

/**AST node for a parameter that's a simple name.  This is used for both
 * non-linear pattern matching and to reference other names (such as fields) that are
 * in scope. 
 */
public class NamedParam extends Term_c implements Param
{

    private String name;
    
    public NamedParam(Position pos, String name)
    {
        super(pos);
        this.name = name;
    }

    public Term entry() {
        return null;
    }

    public List acceptCFG(CFGBuilder v, List succs) {
        return null;
    }
    
    private Type t;
    public NamedParam type(Type t)
    {
        NamedParam n = (NamedParam)copy();
        n.t = t;
        return n;
    }
    public Type type() { return t; }
    public Type regularType() { return null; }
    public String printParam() { return name; }
    public String toString() { return name; }

    public Node assignType(ContextVisitor tc) throws SemanticException
    {
        return this;
    }
    public Node visitChildren(NodeVisitor v) {
        NamedParam n = (NamedParam)copy();
        return n;
    }

}
