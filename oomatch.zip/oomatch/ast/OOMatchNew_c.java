package polyglot.ext.oomatch.ast;

import java.util.List;

import polyglot.ast.ClassBody;
import polyglot.ast.Expr;
import polyglot.ast.New;
import polyglot.ast.TypeNode;
import polyglot.ext.jl.ast.New_c;
import polyglot.frontend.Job;
import polyglot.frontend.Pass;
import polyglot.types.ClassType;
import polyglot.types.Context;
import polyglot.types.SemanticException;
import polyglot.util.Position;
import polyglot.visit.TypeChecker;
import polyglot.ext.oomatch.ExtensionInfo;

/**A New expression.  We need to override Polyglot's typechecking of New
 * in case it contains an anonymous class declaration.  In that case special
 * processing must be done for it.
 */
public class OOMatchNew_c extends New_c implements New
{

    public OOMatchNew_c(Position pos, Expr qualifier, TypeNode tn,
            List arguments, ClassBody body)
    {
        super(pos, qualifier, tn, arguments, body);
    }

    //This duplicates the code in New_c but inserts OOMatch typechecking.
    //It's needed to implement anonymous classes.
    protected ClassBody typeCheckBody(TypeChecker tc, ClassType superType)
    throws SemanticException
    {
        Context bodyCtxt = tc.context().pushClass(anonType, anonType);
        Job sj = tc.job().spawn(bodyCtxt, body,
                                Pass.CLEAN_SUPER, Pass.DISAM_ALL);
    
        if (! sj.status()) {
            if (! sj.reportedErrors()) {
                throw new SemanticException("Could not disambiguate body of " +
                                            "anonymous " +
                                            (superType.flags().isInterface() ?
                                             "implementor" : "subclass") +
                                            " of \"" + superType + "\".");
            }
            throw new SemanticException();
        }
    
        ClassBody b = (ClassBody) sj.ast();
    
        //Rename methods in the New's body.
        //Even though the range of passes above includes NAME_METHODS, it isn't
        //sufficient to rename the methods because the above spawn works on the class
        //body, but we need to visit the New itself to get its type info.
        Job oomJob1 = tc.job().spawn(tc.context(), this.body(b),
                 ExtensionInfo.NAME_METHODS,ExtensionInfo.NAME_METHODS);
        b = ((New)oomJob1.ast()).body();
    
        //OOMatch type checking
        Job oomJob = tc.job().spawn(tc.context(), this.body(b),
                 ExtensionInfo.OOM_TYPE_CHECK,ExtensionInfo.OOM_TYPE_CHECK);
        b = ((New)oomJob.ast()).body();
        
        // Now, type-check the body.
        TypeChecker bodyTC = (TypeChecker)tc.context(bodyCtxt);
        b = (ClassBody) visitChild(b, bodyTC.visitChildren());
    
        // check the class implements all abstract methods that it needs to.
        bodyTC.typeSystem().checkClassConformance(anonType());
    
        return b;
    }
    
}
