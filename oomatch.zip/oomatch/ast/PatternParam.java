package polyglot.ext.oomatch.ast;

import java.util.*;

import polyglot.ast.*;
import polyglot.visit.*;
import polyglot.types.*;
import polyglot.util.*;
import polyglot.ext.jl.parse.*;

import polyglot.ext.oomatch.types.*;
import polyglot.ext.jl.ast.*;

/** The AST node for a pattern parameter to a method.*/
public class PatternParam extends Term_c implements Param {

    /** The deconstructor name for the pattern 
     * (e.g. Point in Point(int x, int y) p) */
    private Name decon;
    
    /** The name given to the pattern (null if the user didn't
     * give it a name) */
	protected Formal formal = null;
    protected String name;
    
    /** The pattern's subcomponents (List of Param) */
	private List pattern;
    
    
	protected PatternType type = null;
    public TypeNode decType = null;
    
	public PatternParam(Position pos, Name decon, List pattern, Formal f)
	{
		super(pos);
		this.decon = decon;
		this.pattern = pattern;
        if (f == null || f.name() == null)
            this.name = "";
        else
		  this.name = f.name();
        
        //Change the type of all pattern formals to be Object.  This is because
        //this.formal = f;  //Note that the formal's type will be wrong at this point;
            //it gets set correctly later (in assignType)
	}
    public PatternParam(Position pos, Name decon, List pattern)
    {
        this(pos, decon, pattern, null);
    }

	public Term entry() {
		return listEntry(pattern, this);
	}

	public List acceptCFG(CFGBuilder v, List succs) {
		v.visitCFGList(succs, this);
		return succs;
	}

	public Formal formal() { return formal; }
    public PatternParam formal(Formal f)
    {
        PatternParam retVal = (PatternParam)copy();
        retVal.formal = f;
        return retVal;
    }
	public Name decon() { return decon; }
	public List pattern() { return pattern; }
    public PatternParam pattern(List pattern)
    {
        PatternParam retVal = (PatternParam)copy();
        retVal.pattern = pattern;
        return retVal;
    }
    public Type type() { return type; }
    public Type regularType() { return type.deconstructorType(); }
    
	public Node assignType(ContextVisitor tc)
		throws SemanticException
	{
        PatternParam n = (PatternParam) copy();
        PatternType newType = typeOfPattern(OOMatchMethodInstance.typesOf(pattern), tc);
        n.type = newType;
        
        NodeFactory nf = tc.nodeFactory();
        
        //Now that we know the type, create a formal for the pattern
        //if the user has named it.
        //The formal will be added to its' method's formals during the disambiguation
        //of methods (DisamMethods).
        if (!name.equals(""))
        {
            /*
            n.formal = formal().type(nf.CanonicalTypeNode(
                    position(), newType.deconstructorType()));
                    */
            LocalInstance li = tc.typeSystem().localInstance(position(), Flags.NONE, 
                    newType.deconstructorType(), name); 
            n.formal = nf.Formal(position(), Flags.NONE, 
                    nf.CanonicalTypeNode(position(), newType.deconstructorType()),
                    name).localInstance(li);
            
        }
		return n;
	}
    
    /**create an ambiguous type node for the deconstructor reference*/
    public Node setDecType(ContextVisitor tc)
        throws SemanticException
    {
        PatternParam n = (PatternParam)copy();
        boolean classForm = DeconstructorDecl.classForm(decon, tc);
        if (classForm)
        {
            n.decType = decon.toType();
        }
        else if (decon.prefix == null)
        {
            throw new NoClassException(decon.toString(), 
                    decon.pos);
        }
        else {
            n.decType = decon.prefix.toType();
        }
        return n;
    }

    /** Find the type of pattern, which is a List of Types for this pattern.
     */
    private PatternType typeOfPattern(List pattern, ContextVisitor tc)
        throws SemanticException
    {
        boolean classForm = DeconstructorDecl.classForm(decon, tc);
        OOMatchClassType decClassType = //DeconstructorDecl_c.typeOf(decon, tc);
            (OOMatchClassType)decType.type();
        OOMatchClassType classToSearch = decClassType;
        String deconstructorName = decon.name;
        if (!tc.typeSystem().classAccessible(classToSearch, tc.context()))
            throw new SemanticException("Can't access class " + classToSearch +
                    " from here.", position());

        do {
            if (classForm) deconstructorName = classToSearch.name();
            //Look for all deconstructors with the appropriate name in the
            //class which it's a type of.
            List possibleDeconstructors = new ArrayList();
            for (Iterator i = classToSearch.deconstructors().iterator(); i.hasNext(); )
            {
                Object o = i.next();
                if (o instanceof DeconstructorInstance)
                {
                    DeconstructorInstance d = (DeconstructorInstance)o;
                    if (d.name().equals(deconstructorName) && d.match(pattern))
                    {
                        possibleDeconstructors.add(d);   
                    }
                }
            }
            
            if (possibleDeconstructors.size() == 0)
            {
                //No deconstructor found; search superclasses
                //Get the supertype of the class being checked for the
                //deconstructor
                Type superType = classToSearch.superType();
                
                if (!(superType instanceof OOMatchClassType))
                    break;
                
                classToSearch = (OOMatchClassType)superType;

            }
            else
            {
                OOMatchTypeSystem ts = ((OOMatchTypeSystem)(tc.typeSystem())); 

                //Choose which deconstructor applies; namely, find the most specific one
                //of all the ones that matched.
                DeconstructorInstance retVal = 
                    ts.findMostSpecificDeconstructor(possibleDeconstructors, 
                                                     classToSearch, pattern, 
                                                     tc.context().currentClass());
                if (retVal == null)
                {
                    throw new SemanticException("Reference to deconstructor in " + 
                            printParam() + " is ambiguous.  These deconstructors: " + 
                            possibleDeconstructors + " all match.", position());                  
                }
                else
                {
                    //assign all the parameter types; the types of its sub-AST nodes will have
                    //already been assigned earlier in the traversal
                    DeconstructorInstance first = (DeconstructorInstance)(possibleDeconstructors.get(0));
                    return new PatternType_c(tc.typeSystem(), position(), decClassType, pattern, first, varName());

                }
            }

        } while (!classToSearch.equals(tc.typeSystem().Object())); //loop while it has a supertype
        throw new SemanticException("Can't find a deconstructor that applies to " + printParam(), position());
        
    }

    public String varName()
    {
        return name;
    }
    public String printParam()
    {
        String retVal = decon + "(" + OOMatchMethodDecl_c.printParamList(pattern) + ")";
        if (name != null) retVal += " " + name;
        return retVal;
    }
    
    public Node visitChildren(NodeVisitor v) {
        PatternParam n = (PatternParam)copy();
        n.pattern = visitList(pattern, v);
        if (formal != null) n.formal = (Formal)visitChild(formal, v); 
        if (decType != null) n.decType = (TypeNode)visitChild(decType, v);
        return n;
    }
}
