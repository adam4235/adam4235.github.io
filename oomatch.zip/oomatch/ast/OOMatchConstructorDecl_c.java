package polyglot.ext.oomatch.ast;

import java.util.*;

import polyglot.ast.*;
import polyglot.ext.jl.ast.ConstructorDecl_c;
import polyglot.ext.oomatch.types.*;
import polyglot.types.*;
import polyglot.util.Position;
import polyglot.visit.*;

//I had originally thought to allow patterns in constructors, but it turns out that
//this is almost impossible to implement because of the Java rule that super 
//calls must be the first statement in a constructor.  Hence, there is a lot of code
//to deal with constructors throughout the OOMatch compiler that can never be
//executed, but which would require too much effort to remove (and which may be needed
//someday anyway, if a solution to this problem is ever found).

/** There's a lot of duplication between this class and OOMatchMethodDecl_c, since
 * they're almost the same thing; but because Java lacks multiple inheritance, I
 * don't know how to get rid of it.  So see that class for documentation.
 */
public class OOMatchConstructorDecl_c extends ConstructorDecl_c implements OOMatchProcedureDecl, ConstructorDecl 
{
	
	//Store params as the parameters, and set the formals to the list of things
	//declared in params
	List params;

	public OOMatchConstructorDecl_c(Position pos, Flags flags, String name,
			List params, List throwTypes, Block body, NodeFactory nf) {
		super(pos, flags, name, OOMatchMethodDecl_c.formalsIn(params, nf), throwTypes, body);
		this.params = params;
	}

	public List params() {
		return params;
	}
	
    public OOMatchProcedureInstance oomProcedureInstance()
    {
        return (OOMatchProcedureInstance)ci;  //with covariant return types, this cast
            //wouldn't be necessary
    }

    public String printProc()
    {
        return flags.translate() + " " + name + "(" + OOMatchMethodDecl_c.printParamList(params) + ")";
    }
    //The method instance has to have the formal types set to the types of
    //the params, not the formals declared in the params.
    protected ConstructorInstance makeConstructorInstance(ClassType ct, TypeSystem ts)
    throws SemanticException 
    {
        OOMatchConstructorInstance retVal = (OOMatchConstructorInstance)super.makeConstructorInstance(ct, ts);
        retVal = (OOMatchConstructorInstance)retVal.paramTypes(OOMatchMethodInstance.typesOf(params));
        if (!retVal.hasOnlyFormals())
        {
            throw new SemanticException("Constructors cannot contain patterns", position());
        }

        return retVal;
    }

    //Same as from MethodDecl_c
    //More cloning made necessary by the lack of multiple inheritance, it seems
    public Node visitChildren(NodeVisitor v) {
        OOMatchConstructorDecl_c n = (OOMatchConstructorDecl_c)super.visitChildren(v);
        if (params != null) {
            List p = visitList(params, v);
            return n.params(p);
        }
        return n;
    }
    public OOMatchProcedureDecl params(List params)
    {
        OOMatchConstructorDecl_c n = (OOMatchConstructorDecl_c)copy();
        n.params = params;
        return n;
    }
    
    public void rename(String newName) { this.name = newName; }

}
