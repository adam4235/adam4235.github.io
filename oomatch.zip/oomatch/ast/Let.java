package polyglot.ext.oomatch.ast;

import java.util.List;

import polyglot.ast.*;
import polyglot.ext.jl.ast.Stmt_c;
import polyglot.util.Position;
import polyglot.visit.CFGBuilder;
import polyglot.visit.NodeVisitor;

//A let statement, to allow pattern matching in assignment.

public class Let extends Stmt_c
{

    private String dollarSigns;
    public String dollarSigns() { return dollarSigns; }
    public Node dollarSigns(String dollarSigns) {
        Let l = (Let)copy();
        l.dollarSigns = dollarSigns;
        return l;
    }
    private PatternParam lhs;  //The lvalue (left hand side) of the let assignment
    private Expr rhs;  //The rvalue (right hand side) of the let assignment
    public PatternParam lhs() { return lhs; }
    public Expr rhs() { return rhs; }
    
    public Let(Position pos, PatternParam lhs, Expr rhs)
    {
        super(pos);
        this.lhs = lhs;
        this.rhs = rhs;

    }

    public Term entry() {
        return null;
    }

    public List acceptCFG(CFGBuilder v, List succs) {
        return null;
    }

    public Node visitChildren(NodeVisitor v) {
        Let n = (Let)copy();
        n.lhs = (PatternParam)visitChild(lhs, v);
        n.rhs = (Expr)visitChild(rhs, v);
        return n;
    }

}
