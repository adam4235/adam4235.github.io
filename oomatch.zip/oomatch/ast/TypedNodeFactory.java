package polyglot.ext.oomatch.ast;

import polyglot.ast.*;
import polyglot.ext.oomatch.types.*;
import polyglot.util.*;
import polyglot.types.*;

import java.util.*;

/**Create a bunch of AST nodes and set type info for them more easily
 * than with the use of Polyglot's node factory.
 */
public class TypedNodeFactory
{

    OOMatchNodeFactory nf;
    OOMatchTypeSystem ts;
    Position pos;
    public TypedNodeFactory(OOMatchNodeFactory realFac, OOMatchTypeSystem ts,
            Position pos)
    {
        this.nf = realFac;
        this.ts = ts;
        this.pos = pos;
    }

    public NullLit NullLit()
    {
        return (NullLit)nf.NullLit(pos).type(ts.Null());
    }

    public Position position()
    {
        return pos;
    }

    public LocalDecl LocalDecl(TypeNode type, String name, Expr initVal)
    {
        LocalDecl retVal = nf.LocalDecl(position(), Flags.NONE, type, 
                name, initVal);
        LocalInstance li = ts.localInstance(position(), Flags.NONE, 
                type.type(), name);
        retVal = retVal.localInstance(li);
        return retVal;
    }
    
    public Local Local(LocalDecl ld)
    {
        Local retVal = nf.Local(position(), ld.name());
        retVal = retVal.localInstance(ld.localInstance());
        retVal = (Local)retVal.type(ld.type().type());
        return retVal;
    }
    public Local Local(Formal f)
    {
        Local retVal = nf.Local(position(), f.name());
        retVal = retVal.localInstance(f.localInstance());
        retVal = (Local)retVal.type(f.type().type());
        return retVal;
    }
    public LocalAssign LocalAssign(Local l, Expr init)
    {
        LocalAssign retVal = nf.LocalAssign(position(), l, 
                LocalAssign.ASSIGN, init);
        retVal = (LocalAssign)retVal.type(l.type());
        return retVal;
    }
    
    public Field Field(FieldInstance fi, Receiver receiver)
    {
        Field retVal = nf.Field(position(), receiver, fi.name());
        retVal = retVal.fieldInstance(fi);
        retVal = (Field)retVal.type(fi.type());
        return retVal;
    }

    public IntLit IntLit(int val)
    {
        Expr retVal = nf.IntLit(position(), IntLit.INT, val);
        retVal = retVal.type(ts.Int());
        return (IntLit)retVal;
    }
    
    public Cast Cast(Type t, Expr e)
    {
        TypeNode tn = nf.CanonicalTypeNode(position(), t);
        Cast castExpr = nf.Cast(position(), tn, e);
        castExpr = (Cast)castExpr.type(t);
        return castExpr;
    }
    
    public Call Call(Receiver receiver, MethodInstance method)
    {
        return Call(receiver, method, Collections.EMPTY_LIST);
    }
    public Call Call(Receiver receiver, MethodInstance method, Expr arg)
    {
        List args = new ArrayList(1);
        args.add(arg);
        return Call(receiver, method, args);
    }
    public Call Call(Receiver receiver, MethodInstance method, List args)
    {
        Call c = nf.Call(position(), receiver, method.name(), args);
        c = (Call)c.type(method.returnType());
        c = c.methodInstance(method);
        return c;
    }
    public Call Call(MethodInstance method, List args)
    {
        return Call(null, method, args);
    }
    public ClassLit ClassLit(Type theClass)
    {
        TypeNode tn = nf.CanonicalTypeNode(position(), theClass);
        ClassLit classLit = nf.ClassLit(position(), tn);
        classLit = (ClassLit)classLit.type(ts.Class());
        return classLit;
    }
    protected Binary RelOp(Expr e1, Binary.Operator op, Expr e2)
    {
        Binary retVal = nf.Binary(position(), e1, op, e2);
        retVal = (Binary)retVal.type(ts.Boolean());
        return retVal;
    }
    public Binary EQ(Expr e1, Expr e2)
    {
        return RelOp(e1, Binary.EQ, e2);
    }
    public Binary NE(Expr e1, Expr e2)
    {
        return RelOp(e1, Binary.NE, e2);
    }
    public Instanceof Instanceof(Expr e, Type t)
    {
        TypeNode tn = nf.CanonicalTypeNode(position(), t);

        Instanceof retVal = nf.Instanceof(position(), e, tn);
        retVal = (Instanceof)retVal.type(ts.Boolean());
        return retVal;

    }
    public BooleanLit BooleanLit(boolean val)
    {
        BooleanLit retVal = nf.BooleanLit(position(), val);
        retVal = (BooleanLit)retVal.type(ts.Boolean());
        return retVal;
    }
    public Formal Formal(Flags theFlags, Type t, String name)
    {
        TypeNode typeAsNode = nf.CanonicalTypeNode(pos, t);
        Formal f = nf.Formal(position(),theFlags, typeAsNode, name);
        f = f.localInstance(ts.localInstance(
                position(), theFlags, t, name));
        return f;
    }
    
    public New New(ClassType t, List args)
    {
        TypeNode tn = nf.CanonicalTypeNode(pos, t);
        List types = new ArrayList(args.size());
        for (Iterator i = args.iterator(); i.hasNext(); )
        {
            Expr arg = (Expr)i.next();
            types.add(arg.type());
        }
        New retVal = nf.New(position(), tn, args);
        retVal = retVal.constructorInstance(
                ts.constructorInstance(pos, 
                        t, Flags.PUBLIC, 
                        types, new LinkedList()));
        retVal = (New)retVal.type(t);
        return retVal;

    }
    public StringLit StringLit(String s)
    {
        StringLit retVal = nf.StringLit(position(), s);
        retVal = (StringLit)retVal.type(ts.String());
        return retVal;
    }
}
