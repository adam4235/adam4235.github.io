package polyglot.ext.oomatch.ast;

import java.util.*;

import polyglot.ast.*;
import polyglot.ext.jl.ast.MethodDecl_c;
import polyglot.types.*;
import polyglot.util.*;
import polyglot.visit.*;
import polyglot.ext.oomatch.types.*;

/**AST node for an OOMatch method
 * (a method which possibly contains patterns for parameters)
 */

public class OOMatchMethodDecl_c extends MethodDecl_c implements OOMatchProcedureDecl, MethodDecl 
{
    public OOMatchMethodDecl_c(Position pos, Flags flags, TypeNode returnType,
            String name, List params, List throwTypes, Block body, NodeFactory nf) {
        this(pos, flags, returnType, name, params, throwTypes, null, body, nf);
    }
    public OOMatchMethodDecl_c(Position pos, Flags flags, TypeNode returnType,
            String name, List params, List throwTypes, Expr whereClause, Block body, NodeFactory nf) {
        super(pos, flags, returnType, name, OOMatchMethodDecl_c.formalsIn(params, nf),
                 
                throwTypes, body);
        this.params = params;
        this.whereClause = whereClause;
    }

    //where clause
    private Expr whereClause;
    public Expr whereClause() { return whereClause; }
    public OOMatchMethodDecl_c whereClause(Expr whereClause) {
        OOMatchMethodDecl_c n = (OOMatchMethodDecl_c)copy();
        n.whereClause = whereClause;
        return n;
    }
    private OOMatchMethodDecl_c child;
    public MethodDecl child(OOMatchMethodDecl_c child)
    {
        OOMatchMethodDecl_c n = (OOMatchMethodDecl_c)copy();
        n.child = child;
        return n;
    }
    public OOMatchMethodDecl_c getChild() { return child; }
	//Store params as the parameters, and set the formals to the list of things
	//declared in params
	protected List params;
	
	public List params() { return params; }
	public OOMatchProcedureDecl params(List params)
    {
        OOMatchMethodDecl_c n = (OOMatchMethodDecl_c)copy();
        n.params = params;
        return n;
    }
    public String printProc()
    {
        return flags.translate() + returnType + " " + name + "(" + printParamList(params) + ")";
    }
    public OOMatchProcedureInstance oomProcedureInstance()
    {
        return (OOMatchProcedureInstance)procedureInstance();  //with 
            //covariant return types, this cast wouldn't be necessary
    }
    public static String printParamList(List params)
    {
        String retVal = "";
        Iterator i = params.iterator();
        while (i.hasNext())
        {
            Param p = (Param)(i.next());
            retVal += p.printParam();
            if (i.hasNext()) retVal += ", ";
        }
        return retVal;
    }
    
    //The method instance has to have the formal types set to the types of
    //the params, not the formals declared in the params.
    protected MethodInstance makeMethodInstance(ClassType ct, TypeSystem ts)
    throws SemanticException 
    {
        OOMatchMethodInstance retVal = (OOMatchMethodInstance)((OOMatchMethodInstance)(super.makeMethodInstance(ct, ts)));
        retVal = (OOMatchMethodInstance)retVal.paramTypes(OOMatchMethodInstance.typesOf(params));
        retVal.setIsNamedParam(new boolean[retVal.paramTypes().size()]);
        if (whereClause != null || hasNamedParam(params()))
        {
            retVal = (OOMatchMethodInstance)retVal.hasWhereClause(true);
        }
        return retVal;
    }
    public boolean hasNamedParam(List params)
    {
        for (Iterator i = params.iterator(); i.hasNext(); )
        {
            Param p = (Param)i.next();
            if (p instanceof PatternParam)
            {
                PatternParam pat = (PatternParam)p; 
                if (hasNamedParam(pat.pattern()))
                    return true;
            }
            else if (p instanceof NamedParam)
                return true;
        }
        return false;
    }

    public Node visitChildren(NodeVisitor v) {
        //FIXME: If I try to fix up this method to be
        //like the other visitChildren methods, it causes manual 
        //overriding to not
        //work properly.  I don't know why.
        //There's apparently a difference between calling n.visitChild and visitChild.
        OOMatchMethodDecl_c n = (OOMatchMethodDecl_c)super.visitChildren(v);
        if (whereClause != null)
        {
            Expr newWhere = (Expr)visitChild(whereClause, v);
            n.whereClause = newWhere;
        }
        if (params != null) {
            List newParams = visitList(params, v);
            n = (OOMatchMethodDecl_c)n.params(newParams);
        }
        if (child != null)
        {
            OOMatchMethodDecl_c newChild = (OOMatchMethodDecl_c)n.visitChild(child, v);
            
            /* DEBUG:
            OOMatchMethodDecl_c newOtherChild = (OOMatchMethodDecl_c)visitChild(child, v);
            if (!newChild.equals(newOtherChild))
            {
                System.out.println("DEBUG");
                System.out.println(v);
                System.out.println(newChild);
                System.out.println(newOtherChild);
            }
            */
            
            n = (OOMatchMethodDecl_c)n.child(newChild);
        }

        if (args != null)
        {
            n.args = visitList(args, v);
        }
        return n;
    }
    
    public void rename(String newName) { this.name = newName; }

    private List args;  //Copies of the arguments to a select statement, if the
        //method is in a select statement.
    public List args() { return args; }
    public OOMatchMethodDecl_c setArgs(List args) { 
        OOMatchMethodDecl_c n = (OOMatchMethodDecl_c)copy();
        n.args = args;
        return n;
    }
    
    public Node typeCheck(TypeChecker tc) throws SemanticException {
        if (whereClause != null && !whereClause.type().equals(tc.typeSystem().Boolean()))
        {
            throw new SemanticException("A where clause must have type boolean.", whereClause.position());
        }
        return super.typeCheck(tc);
    }
    
    //Add the method on a different visitor pass than usual
    public NodeVisitor addMembersEnter(AddMemberVisitor am) {
        return am.bypassChildren(this);
    }
    public NodeVisitor realAddMembersEnter(AddMemberVisitor am) {
        return super.addMembersEnter(am);
    }

    //Disambiguate the method on a different visitor pass than usual
    public NodeVisitor realDisambiguateEnter(AmbiguityRemover ar) 
    throws SemanticException
    {
        return super.disambiguateEnter(ar);
    }

    public Node realDisambiguate(AmbiguityRemover ar) 
        throws SemanticException 
    {
        return super.disambiguate(ar);
    }
    /*
     * We want to do disambiguateEnter normally, because we still want the
     * children of the method to be disambiguated during the regular signatures
     * disambiguation phase.
     * 
    public NodeVisitor disambiguateEnter(AmbiguityRemover ar) 
    throws SemanticException 
    {
        return ar.bypassChildren(this);
    }
    */
    public Node disambiguate(AmbiguityRemover ar) 
        throws SemanticException 
    {
        return this;
    }


    /** Get a list of formals declared within a list of Params.
     * This method is called during creation of methods but will
     * have the wrong types for the formals at that point.
     * It's then called again from the VariableDeclVisitor to
     * give them the correct types. */
    public static List formalsIn(List params, NodeFactory nf)
    {
        if (params.size() > 0 && params.get(0) instanceof Formal)
        {
            //This lets methods be created with Formals instead of Params
            return new LinkedList(params);
        }
        
        List retVal = new TypedList(new LinkedList(), Formal.class, false);
        Iterator i = params.iterator();
        while (i.hasNext())
        {
            Object o = i.next();
            if (o instanceof NormalParam)
            {
                NormalParam p = (NormalParam)o;
                retVal.add(p.formal());
            }
            else if (o instanceof PatternParam)
            {
                PatternParam p = (PatternParam)o;
                
                //Add the formal for the pattern itself
                if (p.formal() != null)
                    retVal.add(p.formal());
                
                //Add any formals declared in the pattern
                retVal.addAll(formalsIn(p.pattern(), nf));
            }
        }
        return retVal;
    }

}
