package polyglot.ext.oomatch.ast;

import java.util.List;

import polyglot.ext.jl.ast.AbstractBlock_c;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.PrettyPrinter;

/**This class is not used in the compiler.  It was from when
 * I was trying to make the compiler work with multiple threads by
 * translating to Atomos instead of Java.
 * @author a5richar
 *
 */
public class Atomic extends AbstractBlock_c
{

    public Atomic(Position pos, List statements)
    {
        super(pos, statements);
    }

    /** Write the block to an output file. */
    public void prettyPrint(CodeWriter w, PrettyPrinter tr) {
    w.write("atomic");
    w.allowBreak(4," ");
    w.write("{");
    w.allowBreak(4," ");
    super.prettyPrint(w, tr);
    w.allowBreak(0, " ");
    w.write("}");

    }

}
