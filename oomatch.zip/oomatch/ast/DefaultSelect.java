package polyglot.ext.oomatch.ast;

import polyglot.ext.jl.ast.*;
import polyglot.ast.*;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;

import java.util.*;

//The method for a default select statement.
//This isn't actually used in the compiler because select isn't implemented, due
//to difficulties translating it.
public class DefaultSelect extends Node_c
{

    private List args;  //Copies of the arguments to the select statement.
    private OOMatchMethodDecl_c method;
    
    public List args() { return args; }
    public OOMatchMethodDecl_c method() { return method; }
    
    public DefaultSelect(Position pos, List args, OOMatchMethodDecl_c method)
    {
        super(pos);
        this.args = args;
        this.method = method;
    }

    public Node visitChildren(NodeVisitor v) {
        DefaultSelect n = (DefaultSelect)copy();
        n.args = visitList(args, v);
        n.method = (OOMatchMethodDecl_c)visitChild(method, v);
        return n;
    }

}
