package polyglot.ext.oomatch.ast;

import java.util.List;

import polyglot.ast.*;
import polyglot.ext.jl.ast.Stmt_c;
import polyglot.util.Position;
import polyglot.visit.*;

//A select statement
//Not used, because not implemented yet.
public class Select extends Stmt_c
{

    private List args;  //The arguments (in brackets at the start of the select
        //statement)
    private List cases;  //The cases in the select statement
    
    public List args() { return args; }
    public List cases() { return cases; }
    
    public Select(Position pos, List args, List statements)
    {
        super(pos);
        this.args = args;
        this.cases = statements;
    }

    public Term entry() {
        return null;
    }

    public List acceptCFG(CFGBuilder v, List succs) {
        return null;
    }

    public Node visitChildren(NodeVisitor v) {
        Select n = (Select)copy();
        n.args = visitList(args, v);
        n.cases = visitList(cases, v);
        return n;
    }

    /*
    public Node typeCheck(TypeChecker tc)
    throws SemanticException
    {
        Stmt s = DesugarSelect.desugar(this, tc.context(), tc.job(), tc.nodeFactory(), tc.typeSystem());
        //Job sj = tc.job().spawn(tc.context(), this, ExtensionInfo.DESUGAR_SELECT, ExtensionInfo.DESUGAR_SELECT);
        /*
        //Now we have to run the passes on the generated AST
        Job sj = tc.job().spawn(tc.context(), s, Pass.BUILD_TYPES, Pass.DISAM_ALL);
        return sj.ast();
        */
    /*
        Eval e = (Eval)s;
        Call c = (Call)e.expr();
        New n = (New)c.target();
        n = (New)n.typeCheck(tc);
        return e.expr(c.target(n));
    }
    */
    
    public NodeVisitor addMembersEnter(AddMemberVisitor am) {
        return am.bypassChildren(this);
    }

}
