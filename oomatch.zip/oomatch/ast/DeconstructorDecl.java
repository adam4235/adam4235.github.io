package polyglot.ext.oomatch.ast;

import java.util.*;

import polyglot.ext.jl.parse.Name;

import polyglot.util.*;
import polyglot.visit.*;
import polyglot.ast.*;
import polyglot.ext.jl.ast.*;
import polyglot.types.*;
import polyglot.ext.oomatch.types.*;
import polyglot.frontend.Job;
import polyglot.frontend.Pass;

/**The AST node for the declaration of a deconstructor.*/

public class DeconstructorDecl extends MethodDecl_c implements OOMatchProcedureDecl
{
    public DeconstructorDecl(Position pos, TypeNode returnType, String name, List params, 
            List throwTypes, Block body, NodeFactory nf, Flags flags, NormalParam onClause)
    {
        //Deconstructors should always be public so they can be accessed.
        //Note that a check is done elsewhere that prevents users from declaring
        //deconstructors private or protected.
    	super(pos, flags.Public(), returnType, name, OOMatchMethodDecl_c.formalsIn(addOn(params, onClause), nf), throwTypes, body);
        this.params = params;
        this.onClause = onClause;
    }
    
    //Add the "on" clause to the list of formals.  This way the body of the deconstructor
    //can be typechecked.
    private static List addOn(List formals, NormalParam onClause)
    {
        if (onClause != null)
            formals.add(onClause);
        return formals;
    }
    
    //The parameter declared in the "on" clause.  Null for a normal deconstructor,
    //non-null for a static deconstructor (one with an "on" clause).
    private NormalParam onClause;
    public NormalParam onClause() { return onClause; }
    
    //Deconstructors get disambiguated in a special pass before other methods,
    //because other methods need deconstructor definitions to be disambiguated.
    //Hence, the following 2 overrides.
    public NodeVisitor disambiguateEnter(AmbiguityRemover ar) 
        throws SemanticException 
    {
        return ar.bypass(this);
    }
    //For some reason we still need to override disambiguate; the call to bypass above
    //doesn't prevent it from being called.
    public Node disambiguate(AmbiguityRemover ar) 
        throws SemanticException 
    {
        return this;
    }
    
    //These next two are called by the visitor that disambiguates deconstructors
    public NodeVisitor realDisambiguateEnter(AmbiguityRemover ar) 
        throws SemanticException
    {
        return super.disambiguateEnter(ar);
    }
    
    public Node realDisambiguate(AmbiguityRemover ar) 
        throws SemanticException 
    {
        //Disambiguate the deconstructors parameters before creating type info
        //for it.
        Job sj = ar.job().spawn(ar.context(), this,
                Pass.CLEAN_SIGS, Pass.CLEAN_SIGS);

        DeconstructorDecl n = (DeconstructorDecl)sj.ast();
        
        n = (DeconstructorDecl)n.superDisam(ar);
        
        if (mi.container() instanceof ClassType)
        {
            if (flags.isAbstract() ||
                    ((ClassType)n.mi.container()).flags().isInterface())
            {
                throw new SemanticException("Deconstructors may not be abstract.  (Yet.)");
            }
        }
        else throw new Error("Containers must be classes or interfaces.");
        n.di = new DeconstructorInstance(n.mi, removeOn(n.params()), n.onClause);

        return n;
    }
    
    //Return the parameters without the "on" parameter
    private List removeOn(List params)
    {
        if (onClause == null)
            return params;
        else
        {
            List retVal = new ArrayList(params);
            retVal.remove(retVal.size() - 1);
            return retVal;
        }
    }
    //Ugly hack because Java doesn't let you call a super method on a type
    public Node superDisam(AmbiguityRemover ar)
        throws SemanticException 
    {
        return super.disambiguate(ar);
    }
    
    //Again, we need to add deconstructors to classes before regular methods.
    public NodeVisitor addMembersEnter(AddMemberVisitor am) {
        return am.bypassChildren(this);
    }
    public NodeVisitor realAddMembersEnter(AddMemberVisitor am) {
        OOMatchClassType ct = (OOMatchClassType)am.context().currentClassScope();
        ct.addDeconstructor(di);
        return am.bypassChildren(this);
    }
    
    //We have to make sure deconstructors have a special type, DeconstructorInstance,
    //so we can tell them apart from regular methods.
    public Node buildTypes(TypeBuilder tb) throws SemanticException {
        if (!flags.clearAbstract().clearPublic().equals(Flags.NONE))
        {
            throw new SemanticException("Deconstructors can only be abstract " +
                    " and/or public; other flags aren't allowed.", position());
        }
        DeconstructorDecl newNode = (DeconstructorDecl)(super.buildTypes(tb));
        newNode.di = new DeconstructorInstance(newNode.mi, removeOn(newNode.params()), null);
        return newNode;
    }
    
    private DeconstructorInstance di;
    public DeconstructorDecl decInstance(DeconstructorInstance di)
    {
        DeconstructorDecl n = (DeconstructorDecl) copy();
        n.di = di;
        return n;
    }
    public DeconstructorInstance decInstance() { return di; }
    
    /*
    protected MethodInstance makeMethodInstance(ClassType ct, TypeSystem ts)
        throws SemanticException 
    {
        /*
        if (throwTypes.size() > 0) 
            throw new SemanticException("Deconstructors may not throw.");
        */
    /*
        if (ct.isAnonymous())
            throw new SemanticException("Anonymous classes may not have deconstructors.");

        MethodInstance mi = super.makeMethodInstance(ct, ts);
        return new DeconstructorInstance(mi, params());
    }
    */
    /** Find the type of decon, i.e. the class it is expected to be found in, 
     * or null if there is no such deconstructor.
     * For example, if a pattern ScreenCoordinate(0, 0) is found, returns 
     * ScreenCoordinate if it can find such a class, even though the deconstructor
     * might be in a superclass (such as Point).  When encountering A.B, it first
     * checks whether B is a class; if not, it might be the name of a deconstructor
     * in the class A, so it checks whether A is a class. */
    public static ClassType typeOf(Name decon, ContextVisitor tc)
    	throws SemanticException
    {
        //This strategy based on what was done in CanonicalTypeNode_c.typeCheck
        
        if (classForm(decon, tc))
        {
            return lookUpClass(tc, decon.toString());
        }
        else
        {
            if (decon.prefix == null) 
                throw new NoClassException(decon.toString(), 
                        decon.pos);;
            
            ClassType deconstructorAsType;
            deconstructorAsType = lookUpClass(tc, decon.prefix.toString());
            if (deconstructorAsType == null) 
                throw new NoClassException(decon.prefix.toString(), 
                        decon.pos);;
            
            return deconstructorAsType;
        }
    }
    
    /** @return true iff decon uses the shorthand of omitting the ".deconstructor"
     * and is simply using a deconstructor with the same name as the class
     * @param tc The context in which decon appears (we need to know if there's
     *      a class visible from tc)
     */
    public static boolean classForm(Name decon, ContextVisitor tc)
        throws SemanticException
    {
        try {
            if (lookUpClass(tc, decon.toString()) == null)
                return false;
            else return true;
        }
        catch(NoClassException e)
        {
            return false;
        }
    }
    private static ClassType lookUpClass(ContextVisitor tc, String maybeClassName)
        throws SemanticException
    {
        Context c = tc.context();
        
        Named deconstructorAsType = c.find(maybeClassName);
        if (deconstructorAsType instanceof ClassType)
            //Check later whether it's accessible
            return (ClassType)deconstructorAsType;
        else
            return null;
    }
    public ProcedureInstance procedureInstance()
    {
        return di;
    }

    public Node visitChildren(NodeVisitor v) {
        DeconstructorDecl n = (DeconstructorDecl)super.visitChildren(v);
        if (onClause != null)
        {
            n.onClause = (NormalParam)visitChild(onClause, v);
        }
        if (params != null) {
            List newParams = visitList(params, v);
            n = (DeconstructorDecl)n.params(newParams);
        }
        return n;
    }
    
    protected List params;
    public List params() { return params; }
    public OOMatchProcedureDecl params(List params)
    {
        DeconstructorDecl n = (DeconstructorDecl)copy();
        n.params = params;
        return n;
    }
    public String printProc()
    {
        return "deconstructor " + name + "(" + OOMatchMethodDecl_c.printParamList(params) + ")";
    }
    public OOMatchProcedureInstance oomProcedureInstance()
    {
        return di;
    }
    public void rename(String newName) { this.name = newName; }

    /*
    protected MethodInstance makeMethodInstance(ClassType ct, TypeSystem ts)
    throws SemanticException 
    {
        DeconstructorInstance retVal = ((DeconstructorInstance)
                (super.makeMethodInstance(ct, ts)));
        retVal = (DeconstructorInstance)retVal.paramTypes(OOMatchMethodInstance.typesOf(params));
        retVal.setIsNamedParam(new boolean[retVal.paramTypes().size()]);
        return retVal;
    }
*/
}
