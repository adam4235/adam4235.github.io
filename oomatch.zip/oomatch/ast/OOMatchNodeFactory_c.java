package polyglot.ext.oomatch.ast;

import polyglot.ast.*;
import polyglot.ext.jl.ast.*;
import polyglot.types.Flags;
import polyglot.util.*;

import java.util.*;

import polyglot.ext.jl.parse.*;

/**
 * NodeFactory for oomatch extension.
 */
public class OOMatchNodeFactory_c extends NodeFactory_c implements OOMatchNodeFactory {
	
    public OOMatchNodeFactory_c() {
    	super();
    }
    public OOMatchNodeFactory_c(ExtFactory extFactory) {
    	super(extFactory);
    }
    public OOMatchNodeFactory_c(ExtFactory extFactory,
                           DelFactory delFactory ) {
    	super(extFactory, delFactory);
    }

    //Based on the version in NodeFactory_c.java, but to return an OOMatchClassDecl_c
    public ClassDecl ClassDecl(Position pos, Flags flags, String name, TypeNode superClass, List interfaces, ClassBody body) {
        ClassDecl n = new OOMatchClassDecl_c(pos, flags, name, superClass, interfaces, body);
        n = (ClassDecl)n.ext(extFactory().extClassDecl());
        n = (ClassDecl)n.del(delFactory().delClassDecl());
        return n;
    }
    //Likewise
    public MethodDecl MethodDecl(Position pos, Flags flags, TypeNode returnType, String name, List formals, List throwTypes, Block body) {
        MethodDecl n = new OOMatchMethodDecl_c(pos, flags, returnType, name, formals, throwTypes, body, this);
        n = (MethodDecl)n.ext(extFactory().extMethodDecl());
        n = (MethodDecl)n.del(delFactory().delMethodDecl());
        return n;
    }
    public MethodDecl OOMMethodDecl(Position pos, Flags flags, TypeNode returnType, String name, List formals, List throwTypes, Expr whereClause, Block body) {
        MethodDecl n = new OOMatchMethodDecl_c(pos, flags, returnType, name, formals, throwTypes, whereClause, body, this);
        n = (MethodDecl)n.ext(extFactory().extMethodDecl());
        n = (MethodDecl)n.del(delFactory().delMethodDecl());
        return n;
    }

    //Likewise
    public ConstructorDecl ConstructorDecl(Position pos, Flags flags, String name, List formals, List throwTypes, Block body) {
        ConstructorDecl n = new OOMatchConstructorDecl_c(pos, flags, name, formals, throwTypes, body, this);
        n = (ConstructorDecl)n.ext(extFactory().extConstructorDecl());
        n = (ConstructorDecl)n.del(delFactory().delConstructorDecl());
        return n;
    }
    /*
    //Likewise
    public Call Call(Position pos, Receiver target, String name, List args) {
        Call n = new OOMatchCall_c(pos, target, name, args);
        n = (Call)n.ext(extFactory().extCall());
        n = (Call)n.del(delFactory().delCall());
        return n;
    }
    */
    //Likewise
    public New New(Position pos, Expr outer, TypeNode objectType, List args, ClassBody body) {
        New n = new OOMatchNew_c(pos, outer, objectType, args, body);
        n = (New)n.ext(extFactory().extNew());
        n = (New)n.del(delFactory().delNew());
        return n;
    }

    public DeconstructorDecl DeconstructorDecl(Position pos, TypeNode returnType, String name, List formals, List throwTypes, Block body, Flags flags, NormalParam p) {
    	DeconstructorDecl n = new DeconstructorDecl(pos, returnType, name, formals, throwTypes, body, this, flags, p);
        n = (DeconstructorDecl)n.ext(extFactory().extMethodDecl());
        n = (DeconstructorDecl)n.del(delFactory().delMethodDecl());
        return n;
    }
    public NormalParam NormalParam(Position pos, Formal formal)
    {
    	NormalParam n = new NormalParam(pos, formal);
        n = (NormalParam)n.ext(extFactory().extTerm());
        n = (NormalParam)n.del(delFactory().delTerm());
    	return n;
    }
    public MadeUpParam MadeUpParam(Position pos, Formal formal)
    {
        MadeUpParam n = new MadeUpParam(pos, formal);
        n = (MadeUpParam)n.ext(extFactory().extTerm());
        n = (MadeUpParam)n.del(delFactory().delTerm());
        return n;
    }
    public PatternParam PatternParam(Position pos, Name decon, List formals, Formal name)
    {
    	PatternParam n = new PatternParam(pos, decon, formals, name);
        n = (PatternParam)n.ext(extFactory().extTerm());
        n = (PatternParam)n.del(delFactory().delTerm());
    	return n;
    }
    public PatternParam PatternParam(Position pos, Name decon, List formals)
    {
        return PatternParam(pos, decon, formals, null);
    }

    public LiteralParam LiteralParam(Position pos, Lit lit)
    {
    	LiteralParam n = new LiteralParam(pos, lit);
        n = (LiteralParam)n.ext(extFactory().extTerm());
        n = (LiteralParam)n.del(delFactory().delTerm());
    	return n;
    }
    public NamedParam NamedParam(Position pos, String name)
    {
        NamedParam n = new NamedParam(pos, name);
        n = (NamedParam)n.ext(extFactory().extTerm());
        n = (NamedParam)n.del(delFactory().delTerm());
        return n;
    }
    //Select statement
    public SelectCase SelectCase(Position pos, List params, List statements)
    {
        SelectCase n = new SelectCase(pos, params, statements);
        n = (SelectCase)n.ext(extFactory().extTerm());
        n = (SelectCase)n.del(delFactory().delTerm());
        return n;
    }
    
    public Select Select(Position pos, List args, List statements)
    {
        Select n = new Select(pos, args, statements);
        n = (Select)n.ext(extFactory().extTerm());
        n = (Select)n.del(delFactory().delTerm());
        return n;
        
    }
    
    public Let Let(Position pos, PatternParam lhs, Expr rhs)
    {
        Let n = new Let(pos, lhs, rhs);
        n = (Let)n.ext(extFactory().extTerm());
        n = (Let)n.del(delFactory().delTerm());
        return n;
    }
    
    /** Construct a new literal with the type and value of literal */
    public Lit Lit(Position pos, Object literal)
    {
        if (literal == null)
            return NullLit(pos);
        else if (literal instanceof Character)
            return CharLit(pos, ((Character)literal).charValue());
        else if (literal instanceof Integer)
            return IntLit(pos,  IntLit.INT, ((Integer)literal).intValue());
        else if (literal instanceof Long)
            return IntLit(pos,  IntLit.LONG, ((Long)literal).longValue());
        else if (literal instanceof Float)
            return FloatLit(pos, FloatLit.FLOAT, ((Float)literal).floatValue());
        else if (literal instanceof Double)
            return FloatLit(pos, FloatLit.DOUBLE, ((Double)literal).doubleValue());
        else if (literal instanceof Boolean)
            return BooleanLit(pos, ((Boolean)literal).booleanValue());
        else if (literal instanceof String)
            return StringLit(pos, ((String)literal));
        else throw new Error("Invalid object");
    }
    
    /** For manual overriding. 
     *  Set the manual child at the bottom of the tree of l to be m.  Don't
     *  modify l, but return a copy of it with m as its child. */
    public MethodDecl setChild(MethodDecl m, MethodDecl l)
    {
        OOMatchMethodDecl_c parent = ((OOMatchMethodDecl_c)l);
        //add the child to the bottom of the tree of parent
        while (parent.getChild() != null)
            parent = parent.getChild();
        return parent.child((OOMatchMethodDecl_c)m);
    }

}
