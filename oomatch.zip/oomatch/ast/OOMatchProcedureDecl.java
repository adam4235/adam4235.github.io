package polyglot.ext.oomatch.ast;

import java.util.List;

import polyglot.ast.*;
import polyglot.ext.oomatch.types.*;

/**An OOMatch procedure (method, constructor, deconstructor, etc.) - any block
 * of code that can be called somehow*/
public interface OOMatchProcedureDecl extends ProcedureDecl {
    /**@return The List of parameters (instances of Param) for this procedure*/
	public List params();
    public OOMatchProcedureDecl params(List params);
	
    /**@return The procedure instance as an OOMatchProcedureInstance*/
    public OOMatchProcedureInstance oomProcedureInstance();
    
    /**Print the procedure, for debugging and error messages*/
    public String printProc();
    
    /**Change the name of the procedure to newName - done towards the end during
     * the transformation phase.*/
    public void rename(String newName);
}
