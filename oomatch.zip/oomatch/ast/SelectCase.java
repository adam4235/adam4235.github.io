package polyglot.ext.oomatch.ast;

import java.util.*;

import polyglot.ast.Node;
import polyglot.ext.jl.ast.Node_c;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;

//A case for a select statement.
//Not used, because select is not implemented yet.
public class SelectCase extends Node_c
{
    private List params;
    private List statements;
    
    public List params() { return params; }
    public List statements() { return statements; }
    
    public boolean isDefault() { return params.size() == 0; }
    public SelectCase(Position pos, List params, List statements)
    {
        super(pos);
        this.params = params;
        this.statements = statements;
    }
    public Node visitChildren(NodeVisitor v) {
        SelectCase n = (SelectCase)copy();
        n.params = visitList(params, v);
        n.statements = visitList(statements, v);
        return n;
    }

}
