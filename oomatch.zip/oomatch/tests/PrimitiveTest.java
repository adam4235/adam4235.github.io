public class PrimitiveTest {
    final void g$1(int x) { System.out.println("g(int)"); }
    
    final void g$2() { System.out.println("g(0.0)"); }
    
    final void g$3() { System.out.println("g(0)"); }
    
    final void g$4(double x) { System.out.println("g(double)"); }
    
    final void g$5(float x) { System.out.println("g(float)"); }
    
    final void g$6() { System.out.println("g(0.1f)"); }
    
    final void g$7(char x) { System.out.println("g(char)"); }
    
    final void g$8() { System.out.println("g(\'c\')"); }
    
    final void g$9(boolean x) { System.out.println("g(boolean)"); }
    
    final void g$10() { System.out.println("g(true)"); }
    
    final void g$11(String x) { System.out.println("g(String)"); }
    
    final void g$12() { System.out.println("null string"); }
    
    final void g$13(short x) { System.out.println("g(short)"); }
    
    final void g$14(byte x) { System.out.println("g(byte)"); }
    
    public static void main(String[] args) { new PrimitiveTest().f(); }
    
    final void f$16() {
        g(1.0, double.class);
        g(1, int.class);
        g(2.0, double.class);
        g(3.0F, float.class);
        g(5, int.class);
        g((short) 5, short.class);
        g('5', char.class);
        g((byte) 5, byte.class);
        g(true, boolean.class);
        g(false, boolean.class);
        g("Hello world", String.class);
    }
    
    public PrimitiveTest() { super(); }
    
    void g(int arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 3) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 3;
                }
            }
            if (methodChosen != 8) {
                if (arg1 == 'c') {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(8) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 8;
                }
            }
            if (methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(14) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 14;
                }
            }
            if (methodChosen != 6) {
                if (arg1 == 0.1F) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(6) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 6;
                }
            }
            if (methodChosen != 2 && methodChosen != 3) {
                if (arg1 == 0.0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 13 && methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2) || (arg2 == null || short.class.equals(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(13) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 13;
                }
            }
            if (methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8) {
                if (arg2 == null || char.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(7) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 7;
                }
            }
            if (methodChosen != 1 && methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8 &&
                  methodChosen != 13 &&
                  methodChosen != 14) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(1) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 1;
                }
            }
            switch (methodChosen) {
                case 3:
                    g$3();
                    return;
                case 8:
                    g$8();
                    return;
                case 14:
                    g$14((byte) arg1);
                    return;
                case 6:
                    g$6();
                    return;
                case 2:
                    g$2();
                    return;
                case 13:
                    g$13((short) arg1);
                    return;
                case 7:
                    g$7((char) arg1);
                    return;
                case 1:
                    g$1(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(double arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 3) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 3;
                }
            }
            if (methodChosen != 8) {
                if (arg1 == 'c') {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(8) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 8;
                }
            }
            if (methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(14) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 14;
                }
            }
            if (methodChosen != 6) {
                if (arg1 == 0.1F) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(6) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 6;
                }
            }
            if (methodChosen != 2 && methodChosen != 3) {
                if (arg1 == 0.0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 13 && methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2) || (arg2 == null || short.class.equals(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(13) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 13;
                }
            }
            if (methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8) {
                if (arg2 == null || char.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(7) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 7;
                }
            }
            if (methodChosen != 1 && methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8 &&
                  methodChosen != 13 &&
                  methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2) || (arg2 == null || char.class.equals(arg2)) ||
                      (arg2 == null || int.class.equals(arg2)) ||
                      (arg2 == null || short.class.equals(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(1) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 1;
                }
            }
            if (methodChosen != 5 && methodChosen != 1 && methodChosen != 7 && methodChosen != 2 && methodChosen != 3 &&
                  methodChosen != 8 &&
                  methodChosen != 13 &&
                  methodChosen != 14 &&
                  methodChosen != 6) {
                if (arg2 == null || byte.class.equals(arg2) || (arg2 == null || char.class.equals(arg2)) ||
                      (arg2 == null || float.class.equals(arg2)) ||
                      (arg2 == null || int.class.equals(arg2)) ||
                      (arg2 == null || long.class.equals(arg2)) ||
                      (arg2 == null || short.class.equals(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(5) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 5;
                }
            }
            if (methodChosen != 4 && methodChosen != 5 && methodChosen != 1 && methodChosen != 7 && methodChosen != 2 &&
                  methodChosen != 3 &&
                  methodChosen != 8 &&
                  methodChosen != 13 &&
                  methodChosen != 14 &&
                  methodChosen != 6) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(4) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 4;
                }
            }
            switch (methodChosen) {
                case 3:
                    g$3();
                    return;
                case 8:
                    g$8();
                    return;
                case 14:
                    g$14((byte) arg1);
                    return;
                case 6:
                    g$6();
                    return;
                case 2:
                    g$2();
                    return;
                case 13:
                    g$13((short) arg1);
                    return;
                case 7:
                    g$7((char) arg1);
                    return;
                case 1:
                    g$1((int) arg1);
                    return;
                case 5:
                    g$5((float) arg1);
                    return;
                case 4:
                    g$4(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(float arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 3) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 3;
                }
            }
            if (methodChosen != 8) {
                if (arg1 == 'c') {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(8) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 8;
                }
            }
            if (methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(14) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 14;
                }
            }
            if (methodChosen != 6) {
                if (arg1 == 0.1F) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(6) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 6;
                }
            }
            if (methodChosen != 2 && methodChosen != 3) {
                if (arg1 == 0.0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 13 && methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2) || (arg2 == null || short.class.equals(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(13) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 13;
                }
            }
            if (methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8) {
                if (arg2 == null || char.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(7) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 7;
                }
            }
            if (methodChosen != 1 && methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8 &&
                  methodChosen != 13 &&
                  methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2) || (arg2 == null || char.class.equals(arg2)) ||
                      (arg2 == null || int.class.equals(arg2)) ||
                      (arg2 == null || short.class.equals(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(1) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 1;
                }
            }
            if (methodChosen != 5 && methodChosen != 1 && methodChosen != 7 && methodChosen != 2 && methodChosen != 3 &&
                  methodChosen != 8 &&
                  methodChosen != 13 &&
                  methodChosen != 14 &&
                  methodChosen != 6) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(5) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 5;
                }
            }
            switch (methodChosen) {
                case 3:
                    g$3();
                    return;
                case 8:
                    g$8();
                    return;
                case 14:
                    g$14((byte) arg1);
                    return;
                case 6:
                    g$6();
                    return;
                case 2:
                    g$2();
                    return;
                case 13:
                    g$13((short) arg1);
                    return;
                case 7:
                    g$7((char) arg1);
                    return;
                case 1:
                    g$1((int) arg1);
                    return;
                case 5:
                    g$5(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(char arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 3) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 3;
                }
            }
            if (methodChosen != 8) {
                if (arg1 == 'c') {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(8) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 8;
                }
            }
            if (methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(14) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 14;
                }
            }
            if (methodChosen != 6) {
                if (arg1 == 0.1F) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(6) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 6;
                }
            }
            if (methodChosen != 2 && methodChosen != 3) {
                if (arg1 == 0.0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 13 && methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2) || (arg2 == null || short.class.equals(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(13) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 13;
                }
            }
            if (methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(7) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 7;
                }
            }
            switch (methodChosen) {
                case 3:
                    g$3();
                    return;
                case 8:
                    g$8();
                    return;
                case 14:
                    g$14((byte) arg1);
                    return;
                case 6:
                    g$6();
                    return;
                case 2:
                    g$2();
                    return;
                case 13:
                    g$13((short) arg1);
                    return;
                case 7:
                    g$7(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(boolean arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 10) {
                if (arg1 == true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(10) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 10;
                }
            }
            if (methodChosen != 9 && methodChosen != 10) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(9) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 9;
                }
            }
            switch (methodChosen) {
                case 10:
                    g$10();
                    return;
                case 9:
                    g$9(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(String arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 12) {
                if ("".equals(arg1)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(12) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 12;
                }
            }
            if (methodChosen != 11 && methodChosen != 12) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(11) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 11;
                }
            }
            switch (methodChosen) {
                case 12:
                    g$12();
                    return;
                case 11:
                    g$11(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(short arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 3) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 3;
                }
            }
            if (methodChosen != 8) {
                if (arg1 == 'c') {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(8) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 8;
                }
            }
            if (methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(14) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 14;
                }
            }
            if (methodChosen != 6) {
                if (arg1 == 0.1F) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(6) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 6;
                }
            }
            if (methodChosen != 2 && methodChosen != 3) {
                if (arg1 == 0.0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 13 && methodChosen != 14) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(13) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 13;
                }
            }
            if (methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8) {
                if (arg2 == null || char.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(7) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 7;
                }
            }
            switch (methodChosen) {
                case 3:
                    g$3();
                    return;
                case 8:
                    g$8();
                    return;
                case 14:
                    g$14((byte) arg1);
                    return;
                case 6:
                    g$6();
                    return;
                case 2:
                    g$2();
                    return;
                case 13:
                    g$13(arg1);
                    return;
                case 7:
                    g$7((char) arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(byte arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 3) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 3;
                }
            }
            if (methodChosen != 8) {
                if (arg1 == 'c') {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(8) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 8;
                }
            }
            if (methodChosen != 14) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(14) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 14;
                }
            }
            if (methodChosen != 6) {
                if (arg1 == 0.1F) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(6) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 6;
                }
            }
            if (methodChosen != 2 && methodChosen != 3) {
                if (arg1 == 0.0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 7 && methodChosen != 2 && methodChosen != 3 && methodChosen != 8) {
                if (arg2 == null || char.class.equals(arg2)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(7) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 7;
                }
            }
            switch (methodChosen) {
                case 3:
                    g$3();
                    return;
                case 8:
                    g$8();
                    return;
                case 14:
                    g$14(arg1);
                    return;
                case 6:
                    g$6();
                    return;
                case 2:
                    g$2();
                    return;
                case 7:
                    g$7((char) arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void f() {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 16) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(16) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PrimitiveTest.\n");
                    methodChosen = 16;
                }
            }
            switch (methodChosen) {
                case 16:
                    f$16();
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 1: return "method  void g(int)"; case 7: return "method  void g(char)"; case 2:
                return "method  void g(0.0)"; case 3: return "method  void g(0)"; case 8:
                return "method  void g(\'c\')"; case 13: return "method  void g(short)"; case 14:
                return "method  void g(byte)"; case 4: return "method  void g(double)"; case 5:
                return "method  void g(float)"; case 6: return "method  void g(0.1)"; case 9:
                return "method  void g(boolean)"; case 10: return "method  void g(true)"; case 11:
                return "method  void g(java.lang.String)"; case 12: return "method  void g(\"\")"; case 15:
                return "method public static void main(java.lang.String[])"; case 16: return "method  void f()";
            case 17: return "constructor public PrimitiveTest()";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1177595167000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAABwAAAAEAAABBAAAAAXQAEVBy\naW1pdGl2ZVRlc3Qub29teHQADVByaW" +
       "1pdGl2ZVRlc3RweABzcgAXcG9seWdsb3QudXRpbC5UeXBl\nZExpc3TssjsQ" +
       "ji1ztgIAA1oACWltbXV0YWJsZUwADGFsbG93ZWRfdHlwZXQAEUxqYXZhL2xh" +
       "bmcv\nQ2xhc3M7TAAMYmFja2luZ19saXN0cQB+AAF4cAB2cgAicG9seWdsb3" +
       "QudHlwZXMuQ29uc3RydWN0\nb3JJbnN0YW5jZRdnPqC4bpcjAgAAeHBzcgAU" +
       "amF2YS51dGlsLkxpbmtlZExpc3QMKVNdSmCIIgMA\nAHhwdwQAAAABc3IANX" +
       "BvbHlnbG90LmV4dC5vb21hdGNoLnR5cGVzLk9PTWF0Y2hDb25zdHJ1Y3Rv\n" +
       "ckluc3RhbmNlAAAAABRAZLYCAAdJAAJpZEkACmp1bmtQYXJhbXNaAAxub0Rp" +
       "c3BhdGNoZXJMAAhj\naGlsZHJlbnEAfgABWwAMaXNOYW1lZFBhcmFtdAACW1" +
       "pMAApwYXJhbVR5cGVzcQB+AAFMAAhyZWFs\nTmFtZXEAfgACeHIAK3BvbHln" +
       "bG90LmV4dC5qbC50eXBlcy5Db25zdHJ1Y3Rvckluc3RhbmNlX2PA\noSsMA7" +
       "LT6AIAAHhyAClwb2x5Z2xvdC5leHQuamwudHlwZXMuUHJvY2VkdXJlSW5zdG" +
       "FuY2VfY8UG\newKJhuVrAgAETAAJY29udGFpbmVydAAeTHBvbHlnbG90L3R5" +
       "cGVzL1JlZmVyZW5jZVR5cGU7TAAI\nZXhjVHlwZXNxAH4AAUwABWZsYWdzcQ" +
       "B+AARMAAtmb3JtYWxUeXBlc3EAfgABeHEAfgAMcQB+ABB4\ncQB+AA5zcQB+" +
       "ABMBdnIAE3BvbHlnbG90LnR5cGVzLlR5cGX1UdGqdcwmTwIAAHhwc3IAE2ph" +
       "dmEu\ndXRpbC5BcnJheUxpc3R4gdIdmcdhnQMAAUkABHNpemV4cAAAAAB3BA" +
       "AAAAB4c3IAFHBvbHlnbG90\nLnR5cGVzLkZsYWdz2v+28N3GIAMCAAFKAARi" +
       "aXRzeHAAAAAAAAAAAXNxAH4AEwFxAH4AInNxAH4A\nIwAAAAB3BAAAAAB4AA" +
       "AAEQAAAAAAc3EAfgAYdwQAAAAAeHBzcgAfamF2YS51dGlsLkNvbGxlY3Rp\n" +
       "b25zJEVtcHR5TGlzdHq4F7Q8p57eAgAAeHB0ABBQcmltaXRpdmVUZXN0JDE3" +
       "eHNxAH4AEwB2cgAc\ncG9seWdsb3QudHlwZXMuRmllbGRJbnN0YW5jZdRnvi" +
       "DT7YphAgAAeHBzcQB+ABh3BAAAAAB4c3EA\nfgAlAAAAAAAAAAFzcQB+ABMA" +
       "cQB+ACJzcQB+ABh3BAAAAAB4c3IAHXBvbHlnbG90LnR5cGVzLkNs\nYXNzVH" +
       "lwZSRLaW5kh1jxDIZhxF0CAAB4cgAScG9seWdsb3QudXRpbC5FbnVtsOTezC" +
       "dsygkCAAFM\nAARuYW1lcQB+AAJ4cHQACXRvcC1sZXZlbHNxAH4AEwBxAH4A" +
       "InNxAH4AGHcEAAAAAHhzcQB+ABMA\ndnIAHXBvbHlnbG90LnR5cGVzLk1ldG" +
       "hvZEluc3RhbmNlXGSFCAkpfOkCAAB4cHNxAH4AGHcEAAAA\nCnNyADBwb2x5" +
       "Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoTWV0aG9kSW5zdGFuY2UA" +
       "AAAA\nLB2kfwIACFoADmhhc1doZXJlQ2xhdXNlSQACaWRaAAxub0Rpc3BhdG" +
       "NoZXJMAAVjaGlsZHQAH0xw\nb2x5Z2xvdC90eXBlcy9NZXRob2RJbnN0YW5j" +
       "ZTtMAAhjaGlsZHJlbnEAfgABWwAMaXNOYW1lZFBh\ncmFtcQB+ABtMAApwYX" +
       "JhbVR5cGVzcQB+AAFMAAhyZWFsTmFtZXEAfgACeHIAJnBvbHlnbG90LmV4\n" +
       "dC5qbC50eXBlcy5NZXRob2RJbnN0YW5jZV9jjFcIyQELZfsCAAJMAARuYW1l" +
       "cQB+AAJMAApyZXR1\ncm5UeXBlcQB+AAh4cQB+AB1zcQB+AA8AAAAEAAAAEQ" +
       "AAAAQAAAAEcQB+ABF4cQB+AA5zcQB+ABMB\ncQB+ACJzcQB+ACMAAAAAdwQA" +
       "AAAAeHNxAH4AJQAAAAAAAAAAc3EAfgAjAAAAAXcEAAAAAXNyACVw\nb2x5Z2" +
       "xvdC5leHQuamwudHlwZXMuUHJpbWl0aXZlVHlwZV9j71PrGvcKEsQCAAFMAA" +
       "RraW5kdAAj\nTHBvbHlnbG90L3R5cGVzL1ByaW1pdGl2ZVR5cGUkS2luZDt4" +
       "cQB+AAtweHQAA2ludHB4c3IAIXBv\nbHlnbG90LnR5cGVzLlByaW1pdGl2ZV" +
       "R5cGUkS2luZMQrIax+Ut5iAgAAeHEAfgA1cQB+AEp4dAAB\nZ3NxAH4AR3B4" +
       "dAAEdm9pZHB4c3EAfgBLcQB+AE8AAAAAAQBwc3EAfgAYdwQAAAACc3EAfgA+" +
       "c3EA\nfgAPAAAABAAAABIAAAAWAAAAFnEAfgAReHEAfgAOc3EAfgATAXEAfg" +
       "Aic3EAfgAjAAAAAHcEAAAA\nAHhxAH4ARXNxAH4AIwAAAAF3BAAAAAFzcQB+" +
       "AEdweHQABGNoYXJweHNxAH4AS3EAfgBYeHQAAWdx\nAH4ATgAAAAAHAHBzcQ" +
       "B+ABh3BAAAAAJzcQB+AD5zcQB+AA8AAAAEAAAADwAAAAcAAAAHcQB+ABF4\n" +
       "cQB+AA5zcQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeHEAfgBFc3EAfgAj" +
       "AAAAAXcEAAAAAXNx\nAH4AR3B4dAAGZG91YmxlcHhzcQB+AEtxAH4AYnh0AA" +
       "FncQB+AE4AAAAAAgBwc3EAfgAYdwQAAAAB\nc3EAfgA+c3EAfgAPAAAABAAA" +
       "AA0AAAAKAAAACnEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAj\nAAAAAH" +
       "cEAAAAAHhxAH4ARXNxAH4AIwAAAAF3BAAAAAFxAH4ASXh0AAFncQB+AE4AAA" +
       "AAAwBwc3EA\nfgAYdwQAAAAAeHVyAAJbWlePIDkUuF3iAgAAeHAAAAABAHNx" +
       "AH4AGHcEAAAAAXNyACZwb2x5Z2xv\ndC5leHQub29tYXRjaC50eXBlcy5WYW" +
       "x1ZVR5cGVfYwAAAAAEB4wPAgACTAANY29uc3RhbnRWYWx1\nZXQAEkxqYXZh" +
       "L2xhbmcvT2JqZWN0O0wAC3R5cGVPZlZhbHVlcQB+AAh4cQB+AAtzcQB+AA8A" +
       "AAAL\nAAAADAAAAAoAAAAKcQB+ABF4eHNyABFqYXZhLmxhbmcuSW50ZWdlch" +
       "LioKT3gYc4AgABSQAFdmFs\ndWV4cgAQamF2YS5sYW5nLk51bWJlcoaslR0L" +
       "lOCLAgAAeHAAAAAAcQB+AEl4dAADZyQzeHVxAH4A\nbQAAAAEAc3EAfgAYdw" +
       "QAAAABc3EAfgBwc3EAfgAPAAAACwAAAA4AAAAHAAAAB3EAfgAReHhzcgAQ\n" +
       "amF2YS5sYW5nLkRvdWJsZYCzwkopa/sEAgABRAAFdmFsdWV4cQB+AHUAAAAA" +
       "AAAAAHEAfgBheHQA\nA2ckMnNxAH4APnNxAH4ADwAAAAQAAAAPAAAAGQAAAB" +
       "lxAH4AEXhxAH4ADnNxAH4AEwFxAH4AInNx\nAH4AIwAAAAB3BAAAAAB4cQB+" +
       "AEVzcQB+ACMAAAABdwQAAAABcQB+AFd4dAABZ3EAfgBOAAAAAAgA\ncHNxAH" +
       "4AGHcEAAAAAHh1cQB+AG0AAAABAHNxAH4AGHcEAAAAAXNxAH4AcHNxAH4ADw" +
       "AAAA0AAAAO\nAAAAGQAAABlxAH4AEXh4c3IAE2phdmEubGFuZy5DaGFyYWN0" +
       "ZXI0i0fZaxomeAIAAUMABXZhbHVl\neHAAY3EAfgBXeHQAA2ckOHh1cQB+AG" +
       "0AAAABAHNxAH4AGHcEAAAAAXEAfgBXeHQAA2ckN3NxAH4A\nPnNxAH4ADwAA" +
       "AAQAAAATAAAAKAAAAChxAH4AEXhxAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAA" +
       "AAB3\nBAAAAAB4cQB+AEVzcQB+ACMAAAABdwQAAAABc3EAfgBHcHh0AAVzaG" +
       "9ydHB4c3EAfgBLcQB+AJZ4\ndAABZ3EAfgBOAAAAAA0AcHNxAH4AGHcEAAAA" +
       "AXNxAH4APnNxAH4ADwAAAAQAAAASAAAAKwAAACtx\nAH4AEXhxAH4ADnNxAH" +
       "4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4cQB+AEVzcQB+ACMAAAABdwQA\n" +
       "AAABc3EAfgBHcHh0AARieXRlcHhzcQB+AEtxAH4AoHh0AAFncQB+AE4AAAAA" +
       "DgBwc3EAfgAYdwQA\nAAAAeHVxAH4AbQAAAAEAc3EAfgAYdwQAAAABcQB+AJ" +
       "94dAAEZyQxNHh1cQB+AG0AAAABAHNxAH4A\nGHcEAAAAAXEAfgCVeHQABGck" +
       "MTN4dXEAfgBtAAAAAQBzcQB+ABh3BAAAAAFxAH4ASXh0AANnJDFz\ncQB+AD" +
       "5zcQB+AA8AAAAEAAAAFAAAAA0AAAANcQB+ABF4cQB+AA5zcQB+ABMBcQB+AC" +
       "JzcQB+ACMA\nAAAAdwQAAAAAeHEAfgBFc3EAfgAjAAAAAXcEAAAAAXEAfgBh" +
       "eHQAAWdxAH4ATgAAAAAEAHBzcQB+\nABh3BAAAAAFzcQB+AD5zcQB+AA8AAA" +
       "AEAAAAEwAAABAAAAAQcQB+ABF4cQB+AA5zcQB+ABMBcQB+\nACJzcQB+ACMA" +
       "AAAAdwQAAAAAeHEAfgBFc3EAfgAjAAAAAXcEAAAAAXNxAH4AR3B4dAAFZmxv" +
       "YXRw\neHNxAH4AS3EAfgC6eHQAAWdxAH4ATgAAAAAFAHBzcQB+ABh3BAAAAA" +
       "JxAH4AQXNxAH4APnNxAH4A\nDwAAAAQAAAAQAAAAEwAAABNxAH4AEXhxAH4A" +
       "DnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4\ncQB+AEVzcQB+ACMAAA" +
       "ABdwQAAAABcQB+ALl4dAABZ3EAfgBOAAAAAAYAcHNxAH4AGHcEAAAAAHh1\n" +
       "cQB+AG0AAAABAHNxAH4AGHcEAAAAAXNxAH4AcHNxAH4ADwAAAAsAAAAPAAAA" +
       "EwAAABNxAH4AEXh4\nc3IAD2phdmEubGFuZy5GbG9hdNrtyaLbPPDsAgABRg" +
       "AFdmFsdWV4cQB+AHU9zMzNcQB+ALl4dAAD\nZyQ2eHVxAH4AbQAAAAEAc3EA" +
       "fgAYdwQAAAABcQB+ALl4dAADZyQ1eHVxAH4AbQAAAAEAc3EAfgAY\ndwQAAA" +
       "ABcQB+AGF4dAADZyQ0cQB+ALRxAH4AUnNxAH4APnNxAH4ADwAAAAQAAAAVAA" +
       "AAHAAAABxx\nAH4AEXhxAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3BAAA" +
       "AAB4cQB+AEVzcQB+ACMAAAABdwQA\nAAABc3EAfgBHcHh0AAdib29sZWFucH" +
       "hzcQB+AEtxAH4A2Hh0AAFncQB+AE4AAAAACQBwc3EAfgAY\ndwQAAAABc3EA" +
       "fgA+c3EAfgAPAAAABAAAABAAAAAfAAAAH3EAfgAReHEAfgAOc3EAfgATAXEA" +
       "fgAi\nc3EAfgAjAAAAAHcEAAAAAHhxAH4ARXNxAH4AIwAAAAF3BAAAAAFxAH" +
       "4A13h0AAFncQB+AE4AAAAA\nCgBwc3EAfgAYdwQAAAAAeHVxAH4AbQAAAAEA" +
       "c3EAfgAYdwQAAAABc3EAfgBwc3EAfgAPAAAACwAA\nAA8AAAAfAAAAH3EAfg" +
       "AReHhzcgARamF2YS5sYW5nLkJvb2xlYW7NIHKA1Zz67gIAAVoABXZhbHVl\n" +
       "eHABcQB+ANd4dAAEZyQxMHh1cQB+AG0AAAABAHNxAH4AGHcEAAAAAXEAfgDX" +
       "eHQAA2ckOXNxAH4A\nPnNxAH4ADwAAAAQAAAAUAAAAIgAAACJxAH4AEXhxAH" +
       "4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3\nBAAAAAB4cQB+AEVzcQB+ACMA" +
       "AAABdwQAAAABc3IAI3BvbHlnbG90LmV4dC5qbC50eXBlcy5QbGFj\nZUhvbG" +
       "Rlcl9jSvTWWjbIvHQCAAFMAARuYW1lcQB+AAJ4cHQAEGphdmEubGFuZy5TdH" +
       "Jpbmd4dAAB\nZ3EAfgBOAAAAAAsAcHNxAH4AGHcEAAAAAXNxAH4APnNxAH4A" +
       "DwAAAAQAAAAOAAAAJQAAACVxAH4A\nEXhxAH4ADnNxAH4AEwFxAH4AInNxAH" +
       "4AIwAAAAB3BAAAAAB4cQB+AEVzcQB+ACMAAAABdwQAAAAB\ncQB+APN4dAAB" +
       "Z3EAfgBOAAAAAAwAcHNxAH4AGHcEAAAAAHh1cQB+AG0AAAABAHNxAH4AGHcE" +
       "AAAA\nAXNxAH4AcHNxAH4ADwAAAAsAAAANAAAAJQAAACVxAH4AEXh4dAAAcQ" +
       "B+APN4dAAEZyQxMnh1cQB+\nAG0AAAABAHNxAH4AGHcEAAAAAXEAfgDzeHQA" +
       "BGckMTFxAH4AkHEAfgCac3EAfgA+c3EAfgAPAAAA\nEgAAACoAAAAvAAAAL3" +
       "EAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHhzcQB+\n" +
       "ACUAAAAAAAAACXNxAH4AIwAAAAF3BAAAAAFzcgAhcG9seWdsb3QuZXh0Lmps" +
       "LnR5cGVzLkFycmF5\nVHlwZV9jPcvH1IatQB0CAARMAARiYXNlcQB+AAhMAA" +
       "ZmaWVsZHNxAH4AAUwACmludGVyZmFjZXNx\nAH4AAUwAB21ldGhvZHNxAH4A" +
       "AXhxAH4ACnNxAH4ADwAAABwAAAAiAAAALwAAAC9xAH4AEXh4cQB+\nAPNwcH" +
       "B4dAAEbWFpbnEAfgBOAAAAAA8AcHNxAH4AGHcEAAAAAHh1cQB+AG0AAAABAH" +
       "NxAH4AGHcE\nAAAAAXEAfgEOeHEAfgEQc3EAfgA+c3EAfgAPAAAABAAAAAwA" +
       "AAAzAAAAM3EAfgAReHEAfgAOc3EA\nfgATAXEAfgAic3EAfgAjAAAAAHcEAA" +
       "AAAHhxAH4ARXNxAH4AIwAAAAB3BAAAAAB4dAABZnEAfgBO\nAAAAABAAcHNx" +
       "AH4AGHcEAAAAAHh1cQB+AG0AAAAAc3EAfgAYdwQAAAAAeHQABGYkMTZ4cQB+" +
       "ABJw\ncHNxAH4A8nQAEGphdmEubGFuZy5PYmplY3RzcQB+ABh3BAAAAAB4dA" +
       "ABJHNxAH4AGHcEAAAAAHg=");
}
