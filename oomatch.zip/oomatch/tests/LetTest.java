class LetTest {
    public static void main(String[] args) {
        Point p = new Point(0,0);
        int x;
        int y;
        {
            Object[] retVal$ = null;
            if (p != null) retVal$ = p.Point$2();
            if (p != null && retVal$ != null) {
                x = ((Integer) retVal$[0]).intValue();
                y = ((Integer) retVal$[1]).intValue(); } else {
                throw new Error("Let assignment failed."); }
        }
        System.out.println(x);
    }
    
    public LetTest() { super(); }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 1: return "method public static void main(java.lang.String[])"; case 2: return "constructor LetTest()";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1180538885000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAHAAAAAXQAC0xl\ndFRlc3Qub29teHQAB0xldFRlc3RweA" +
       "BzcgAXcG9seWdsb3QudXRpbC5UeXBlZExpc3TssjsQji1z\ntgIAA1oACWlt" +
       "bXV0YWJsZUwADGFsbG93ZWRfdHlwZXQAEUxqYXZhL2xhbmcvQ2xhc3M7TAAM" +
       "YmFj\na2luZ19saXN0cQB+AAF4cAB2cgAicG9seWdsb3QudHlwZXMuQ29uc3" +
       "RydWN0b3JJbnN0YW5jZRdn\nPqC4bpcjAgAAeHBzcgAUamF2YS51dGlsLkxp" +
       "bmtlZExpc3QMKVNdSmCIIgMAAHhwdwQAAAABc3IA\nNXBvbHlnbG90LmV4dC" +
       "5vb21hdGNoLnR5cGVzLk9PTWF0Y2hDb25zdHJ1Y3Rvckluc3RhbmNlAAAA\n" +
       "ABRAZLYCAAZJAAJpZEkACmp1bmtQYXJhbXNMAAhjaGlsZHJlbnEAfgABWwAM" +
       "aXNOYW1lZFBhcmFt\ndAACW1pMAApwYXJhbVR5cGVzcQB+AAFMAAhyZWFsTm" +
       "FtZXEAfgACeHIAK3BvbHlnbG90LmV4dC5q\nbC50eXBlcy5Db25zdHJ1Y3Rv" +
       "ckluc3RhbmNlX2PAoSsMA7LT6AIAAHhyAClwb2x5Z2xvdC5leHQu\namwudH" +
       "lwZXMuUHJvY2VkdXJlSW5zdGFuY2VfY8UGewKJhuVrAgAETAAJY29udGFpbm" +
       "VydAAeTHBv\nbHlnbG90L3R5cGVzL1JlZmVyZW5jZVR5cGU7TAAIZXhjVHlw" +
       "ZXNxAH4AAUwABWZsYWdzcQB+AARM\nAAtmb3JtYWxUeXBlc3EAfgABeHEAfg" +
       "AMcQB+ABB4cQB+AA5zcQB+ABMBdnIAE3BvbHlnbG90LnR5\ncGVzLlR5cGX1" +
       "UdGqdcwmTwIAAHhwc3IAE2phdmEudXRpbC5BcnJheUxpc3R4gdIdmcdhnQMA" +
       "AUkA\nBHNpemV4cAAAAAB3BAAAAAB4c3IAFHBvbHlnbG90LnR5cGVzLkZsYW" +
       "dz2v+28N3GIAMCAAFKAARi\naXRzeHAAAAAAAAAAAHNxAH4AEwFxAH4AInNx" +
       "AH4AIwAAAAB3BAAAAAB4AAAAAgAAAABzcQB+ABh3\nBAAAAAB4cHNyAB9qYX" +
       "ZhLnV0aWwuQ29sbGVjdGlvbnMkRW1wdHlMaXN0ergXtDynnt4CAAB4cHQA\n" +
       "CUxldFRlc3QkMnhzcQB+ABMAdnIAHHBvbHlnbG90LnR5cGVzLkZpZWxkSW5z" +
       "dGFuY2XUZ74g0+2K\nYQIAAHhwc3EAfgAYdwQAAAAAeHEAfgAmc3EAfgATAH" +
       "EAfgAic3EAfgAYdwQAAAAAeHNyAB1wb2x5\nZ2xvdC50eXBlcy5DbGFzc1R5" +
       "cGUkS2luZIdY8QyGYcRdAgAAeHIAEnBvbHlnbG90LnV0aWwuRW51\nbbDk3s" +
       "wnbMoJAgABTAAEbmFtZXEAfgACeHB0AAl0b3AtbGV2ZWxzcQB+ABMAcQB+AC" +
       "JzcQB+ABh3\nBAAAAAB4c3EAfgATAHZyAB1wb2x5Z2xvdC50eXBlcy5NZXRo" +
       "b2RJbnN0YW5jZVxkhQgJKXzpAgAA\neHBzcQB+ABh3BAAAAAFzcgAwcG9seW" +
       "dsb3QuZXh0Lm9vbWF0Y2gudHlwZXMuT09NYXRjaE1ldGhv\nZEluc3RhbmNl" +
       "AAAAACwdpH8CAAdaAA5oYXNXaGVyZUNsYXVzZUkAAmlkTAAFY2hpbGR0AB9M" +
       "cG9s\neWdsb3QvdHlwZXMvTWV0aG9kSW5zdGFuY2U7TAAIY2hpbGRyZW5xAH" +
       "4AAVsADGlzTmFtZWRQYXJh\nbXEAfgAbTAAKcGFyYW1UeXBlc3EAfgABTAAI" +
       "cmVhbE5hbWVxAH4AAnhyACZwb2x5Z2xvdC5leHQu\namwudHlwZXMuTWV0aG" +
       "9kSW5zdGFuY2VfY4xXCMkBC2X7AgACTAAEbmFtZXEAfgACTAAKcmV0dXJu\n" +
       "VHlwZXEAfgAIeHEAfgAdc3EAfgAPAAAAEgAAACoAAAACAAAAAnEAfgAReHEA" +
       "fgAOc3EAfgATAXEA\nfgAic3EAfgAjAAAAAHcEAAAAAHhzcQB+ACUAAAAAAA" +
       "AACXNxAH4AIwAAAAF3BAAAAAFzcgAhcG9s\neWdsb3QuZXh0LmpsLnR5cGVz" +
       "LkFycmF5VHlwZV9jPcvH1IatQB0CAARMAARiYXNlcQB+AAhMAAZm\naWVsZH" +
       "NxAH4AAUwACmludGVyZmFjZXNxAH4AAUwAB21ldGhvZHNxAH4AAXhxAH4ACn" +
       "NxAH4ADwAA\nABwAAAAiAAAAAgAAAAJxAH4AEXh4c3IAI3BvbHlnbG90LmV4" +
       "dC5qbC50eXBlcy5QbGFjZUhvbGRl\ncl9jSvTWWjbIvHQCAAFMAARuYW1lcQ" +
       "B+AAJ4cHQAEGphdmEubGFuZy5TdHJpbmdwcHB4dAAEbWFp\nbnNyACVwb2x5" +
       "Z2xvdC5leHQuamwudHlwZXMuUHJpbWl0aXZlVHlwZV9j71PrGvcKEsQCAAFM" +
       "AARr\naW5kdAAjTHBvbHlnbG90L3R5cGVzL1ByaW1pdGl2ZVR5cGUkS2luZD" +
       "t4cQB+AAtweHQABHZvaWRw\neHNyACFwb2x5Z2xvdC50eXBlcy5QcmltaXRp" +
       "dmVUeXBlJEtpbmTEKyGsflLeYgIAAHhxAH4ANHEA\nfgBQAAAAAAFwc3EAfg" +
       "AYdwQAAAAAeHVyAAJbWlePIDkUuF3iAgAAeHAAAAABAHNxAH4AGHcEAAAA\n" +
       "AXEAfgBHeHEAfgBMeHEAfgAScHBzcQB+AEl0ABBqYXZhLmxhbmcuT2JqZWN0" +
       "c3EAfgAYdwQAAAAA\neHQAASRzcQB+ABh3BAAAAAB4");
}
