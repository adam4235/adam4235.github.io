class BankTransaction {
    Point q;
    
    final void f$1(Point p) { System.out.println("f(Point p)"); }
    
    final boolean f$2$where(Point arg$0) { return this.q == arg$0 || this.q != null && this.q.equals(arg$0); }
    
    final void f$2() { System.out.println("f(q)"); }
    
    public BankTransaction() { super(); }
    
    void f(Point arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            {
                if (f$2$where(arg1)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class BankTransaction.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 2) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(1) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class BankTransaction.\n");
                    methodChosen = 1;
                }
            }
            switch (methodChosen) {
                case 2:
                    f$2();
                    return;
                case 1:
                    f$1(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 1: return "method  void f(Point)"; case 2: return "method  void f(Point) where (...)"; case 3:
                return "constructor BankTransaction()";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1181835605000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAJAAAAAXQAFkVy\ncm9yTmFtZWRQYXR0ZXJucy5vb214dA" +
       "APQmFua1RyYW5zYWN0aW9ucHgAc3IAF3BvbHlnbG90LnV0\naWwuVHlwZWRM" +
       "aXN07LI7EI4tc7YCAANaAAlpbW11dGFibGVMAAxhbGxvd2VkX3R5cGV0ABFM" +
       "amF2\nYS9sYW5nL0NsYXNzO0wADGJhY2tpbmdfbGlzdHEAfgABeHAAdnIAIn" +
       "BvbHlnbG90LnR5cGVzLkNv\nbnN0cnVjdG9ySW5zdGFuY2UXZz6guG6XIwIA" +
       "AHhwc3IAFGphdmEudXRpbC5MaW5rZWRMaXN0DClT\nXUpgiCIDAAB4cHcEAA" +
       "AAAXNyADVwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ29u\n" +
       "c3RydWN0b3JJbnN0YW5jZQAAAAAUQGS2AgAGSQACaWRJAApqdW5rUGFyYW1z" +
       "TAAIY2hpbGRyZW5x\nAH4AAVsADGlzTmFtZWRQYXJhbXQAAltaTAAKcGFyYW" +
       "1UeXBlc3EAfgABTAAIcmVhbE5hbWVxAH4A\nAnhyACtwb2x5Z2xvdC5leHQu" +
       "amwudHlwZXMuQ29uc3RydWN0b3JJbnN0YW5jZV9jwKErDAOy0+gC\nAAB4cg" +
       "ApcG9seWdsb3QuZXh0LmpsLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBn" +
       "sCiYblawIA\nBEwACWNvbnRhaW5lcnQAHkxwb2x5Z2xvdC90eXBlcy9SZWZl" +
       "cmVuY2VUeXBlO0wACGV4Y1R5cGVz\ncQB+AAFMAAVmbGFnc3EAfgAETAALZm" +
       "9ybWFsVHlwZXNxAH4AAXhxAH4ADHEAfgAQeHEAfgAOc3EA\nfgATAXZyABNw" +
       "b2x5Z2xvdC50eXBlcy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwu" +
       "QXJy\nYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyAB" +
       "Rwb2x5Z2xvdC50eXBlcy5G\nbGFnc9r/tvDdxiADAgABSgAEYml0c3hwAAAA" +
       "AAAAAABzcQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQA\nAAAAeAAAAAMAAAAAc3" +
       "EAfgAYdwQAAAAAeHBzcgAfamF2YS51dGlsLkNvbGxlY3Rpb25zJEVtcHR5\n" +
       "TGlzdHq4F7Q8p57eAgAAeHB0ABFCYW5rVHJhbnNhY3Rpb24kM3hzcQB+ABMA" +
       "dnIAHHBvbHlnbG90\nLnR5cGVzLkZpZWxkSW5zdGFuY2XUZ74g0+2KYQIAAH" +
       "hwc3EAfgAYdwQAAAABc3IAJXBvbHlnbG90\nLmV4dC5qbC50eXBlcy5GaWVs" +
       "ZEluc3RhbmNlX2ORwPlzqvuJ+wIAAUwACWNvbnRhaW5lcnEAfgAe\neHIAI3" +
       "BvbHlnbG90LmV4dC5qbC50eXBlcy5WYXJJbnN0YW5jZV9jnwNblT1G3McCAA" +
       "VaAAppc0Nv\nbnN0YW50TAANY29uc3RhbnRWYWx1ZXQAEkxqYXZhL2xhbmcv" +
       "T2JqZWN0O0wABWZsYWdzcQB+AARM\nAARuYW1lcQB+AAJMAAR0eXBlcQB+AA" +
       "h4cQB+AAxzcQB+AA8AAAAEAAAADAAAAAIAAAACcQB+ABF4\nAHBxAH4AJnQA" +
       "AXFzcgAjcG9seWdsb3QuZXh0LmpsLnR5cGVzLlBsYWNlSG9sZGVyX2NK9NZa" +
       "Nsi8\ndAIAAUwABG5hbWVxAH4AAnhwdAAFUG9pbnRxAH4ADnhxAH4AJnNxAH" +
       "4AEwBxAH4AInNxAH4AGHcE\nAAAAAHhzcgAdcG9seWdsb3QudHlwZXMuQ2xh" +
       "c3NUeXBlJEtpbmSHWPEMhmHEXQIAAHhyABJwb2x5\nZ2xvdC51dGlsLkVudW" +
       "2w5N7MJ2zKCQIAAUwABG5hbWVxAH4AAnhwdAAJdG9wLWxldmVsc3EAfgAT\n" +
       "AHEAfgAic3EAfgAYdwQAAAAAeHNxAH4AEwB2cgAdcG9seWdsb3QudHlwZXMu" +
       "TWV0aG9kSW5zdGFu\nY2VcZIUICSl86QIAAHhwc3EAfgAYdwQAAAABc3IAMH" +
       "BvbHlnbG90LmV4dC5vb21hdGNoLnR5cGVz\nLk9PTWF0Y2hNZXRob2RJbnN0" +
       "YW5jZQAAAAAsHaR/AgAHWgAOaGFzV2hlcmVDbGF1c2VJAAJpZEwA\nBWNoaW" +
       "xkdAAfTHBvbHlnbG90L3R5cGVzL01ldGhvZEluc3RhbmNlO0wACGNoaWxkcm" +
       "VucQB+AAFb\nAAxpc05hbWVkUGFyYW1xAH4AG0wACnBhcmFtVHlwZXNxAH4A" +
       "AUwACHJlYWxOYW1lcQB+AAJ4cgAm\ncG9seWdsb3QuZXh0LmpsLnR5cGVzLk" +
       "1ldGhvZEluc3RhbmNlX2OMVwjJAQtl+wIAAkwABG5hbWVx\nAH4AAkwACnJl" +
       "dHVyblR5cGVxAH4ACHhxAH4AHXNxAH4ADwAAAAQAAAATAAAAAwAAAANxAH4A" +
       "EXhx\nAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4cQB+ACZzcQ" +
       "B+ACMAAAABdwQAAAABcQB+\nADh4dAABZnNyACVwb2x5Z2xvdC5leHQuamwu" +
       "dHlwZXMuUHJpbWl0aXZlVHlwZV9j71PrGvcKEsQC\nAAFMAARraW5kdAAjTH" +
       "BvbHlnbG90L3R5cGVzL1ByaW1pdGl2ZVR5cGUkS2luZDt4cQB+AAtweHQA\n" +
       "BHZvaWRweHNyACFwb2x5Z2xvdC50eXBlcy5QcmltaXRpdmVUeXBlJEtpbmTE" +
       "KyGsflLeYgIAAHhx\nAH4APXEAfgBSAAAAAAFwc3EAfgAYdwQAAAABc3EAfg" +
       "BGc3EAfgAPAAAABAAAAA0AAAAGAAAABnEA\nfgAReHEAfgAOc3EAfgATAXEA" +
       "fgAic3EAfgAjAAAAAHcEAAAAAHhxAH4AJnNxAH4AIwAAAAF3BAAA\nAAFxAH" +
       "4AOHh0AAFmcQB+AFEBAAAAAnBzcQB+ABh3BAAAAAB4dXIAAltaV48gORS4Xe" +
       "ICAAB4cAAA\nAAEBc3EAfgAjAAAAAXcEAAAAAXEAfgA4eHQAA2YkMnh1cQB+" +
       "AF0AAAABAHNxAH4AGHcEAAAAAXEA\nfgA4eHQAA2YkMXhxAH4AEnBwc3EAfg" +
       "A3dAAQamF2YS5sYW5nLk9iamVjdHNxAH4AGHcEAAAAAHh0\nAAEkc3EAfgAY" +
       "dwQAAAAAeA==");
}
