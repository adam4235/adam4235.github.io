class Widget {
    public Widget() { super(); }
    
    public static String messageFor1$(int m) {
        switch (m) { case 1: return "constructor Widget()"; }
        return ""; }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1182288731000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAACAAAAAXQADVBv\nc3RlckVnMy5vb214dAAGV2lkZ2V0cH" +
       "gAc3IAF3BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7EI4t\nc7YCAANaAAlp" +
       "bW11dGFibGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNzO0wA" +
       "DGJh\nY2tpbmdfbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLkNvbn" +
       "N0cnVjdG9ySW5zdGFuY2UX\nZz6guG6XIwIAAHhwc3IAFGphdmEudXRpbC5M" +
       "aW5rZWRMaXN0DClTXUpgiCIDAAB4cHcEAAAAAXNy\nADVwb2x5Z2xvdC5leH" +
       "Qub29tYXRjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5jZQAA\n" +
       "AAAUQGS2AgAGSQACaWRJAApqdW5rUGFyYW1zTAAIY2hpbGRyZW5xAH4AAVsA" +
       "DGlzTmFtZWRQYXJh\nbXQAAltaTAAKcGFyYW1UeXBlc3EAfgABTAAIcmVhbE" +
       "5hbWVxAH4AAnhyACtwb2x5Z2xvdC5leHQu\namwudHlwZXMuQ29uc3RydWN0" +
       "b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgApcG9seWdsb3QuZXh0\nLmpsLn" +
       "R5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblawIABEwACWNvbnRhaW" +
       "5lcnQAHkxw\nb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VUeXBlO0wACGV4Y1R5" +
       "cGVzcQB+AAFMAAVmbGFnc3EAfgAE\nTAALZm9ybWFsVHlwZXNxAH4AAXhxAH" +
       "4ADHEAfgAQeHEAfgAOc3EAfgATAXZyABNwb2x5Z2xvdC50\neXBlcy5UeXBl" +
       "9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0D" +
       "AAFJ\nAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2x5Z2xvdC50eXBlcy5GbG" +
       "Fnc9r/tvDdxiADAgABSgAE\nYml0c3hwAAAAAAAAAABzcQB+ABMBcQB+ACJz" +
       "cQB+ACMAAAAAdwQAAAAAeAAAAAEAAAAAc3EAfgAY\ndwQAAAAAeHBzcgAfam" +
       "F2YS51dGlsLkNvbGxlY3Rpb25zJEVtcHR5TGlzdHq4F7Q8p57eAgAAeHB0\n" +
       "AAhXaWRnZXQkMXhzcQB+ABMAdnIAHHBvbHlnbG90LnR5cGVzLkZpZWxkSW5z" +
       "dGFuY2XUZ74g0+2K\nYQIAAHhwc3EAfgAYdwQAAAAAeHEAfgAmc3EAfgATAH" +
       "EAfgAic3EAfgAYdwQAAAAAeHNyAB1wb2x5\nZ2xvdC50eXBlcy5DbGFzc1R5" +
       "cGUkS2luZIdY8QyGYcRdAgAAeHIAEnBvbHlnbG90LnV0aWwuRW51\nbbDk3s" +
       "wnbMoJAgABTAAEbmFtZXEAfgACeHB0AAl0b3AtbGV2ZWxzcQB+ABMAcQB+AC" +
       "JzcQB+ABh3\nBAAAAAB4c3EAfgATAHZyAB1wb2x5Z2xvdC50eXBlcy5NZXRo" +
       "b2RJbnN0YW5jZVxkhQgJKXzpAgAA\neHBzcQB+ABh3BAAAAAB4cQB+ABJwcH" +
       "NyACNwb2x5Z2xvdC5leHQuamwudHlwZXMuUGxhY2VIb2xk\nZXJfY0r01lo2" +
       "yLx0AgABTAAEbmFtZXEAfgACeHB0ABBqYXZhLmxhbmcuT2JqZWN0c3EAfgAY" +
       "dwQA\nAAAAeHQAASRzcQB+ABh3BAAAAAB4");
}

class Button extends Widget {
    public String name;
    
    public Button(String name) {
        super();
        this.name = name; }
    
    public Object[] Button$3() {
        String name;
        name = this.name;
        if (true) return new Object[] { name }; else return null;
    }
    
    public static String messageFor2$(int m) {
        switch (m) { case 2: return "constructor public Button(java.lang.String)"; }
        return Widget.messageFor1$(m); }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1182288731000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAHAAAABHQADVBv\nc3RlckVnMy5vb214dAAGQnV0dG9ucH" +
       "gAc3IAF3BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7EI4t\nc7YCAANaAAlp" +
       "bW11dGFibGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNzO0wA" +
       "DGJh\nY2tpbmdfbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLkNvbn" +
       "N0cnVjdG9ySW5zdGFuY2UX\nZz6guG6XIwIAAHhwc3IAFGphdmEudXRpbC5M" +
       "aW5rZWRMaXN0DClTXUpgiCIDAAB4cHcEAAAAAXNy\nADVwb2x5Z2xvdC5leH" +
       "Qub29tYXRjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5jZQAA\n" +
       "AAAUQGS2AgAGSQACaWRJAApqdW5rUGFyYW1zTAAIY2hpbGRyZW5xAH4AAVsA" +
       "DGlzTmFtZWRQYXJh\nbXQAAltaTAAKcGFyYW1UeXBlc3EAfgABTAAIcmVhbE" +
       "5hbWVxAH4AAnhyACtwb2x5Z2xvdC5leHQu\namwudHlwZXMuQ29uc3RydWN0" +
       "b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgApcG9seWdsb3QuZXh0\nLmpsLn" +
       "R5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblawIABEwACWNvbnRhaW" +
       "5lcnQAHkxw\nb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VUeXBlO0wACGV4Y1R5" +
       "cGVzcQB+AAFMAAVmbGFnc3EAfgAE\nTAALZm9ybWFsVHlwZXNxAH4AAXhxAH" +
       "4ADHNxAH4ADwAAAAsAAAAFAAAABgAAAAVxAH4AEXhxAH4A\nDnNxAH4AEwF2" +
       "cgATcG9seWdsb3QudHlwZXMuVHlwZfVR0ap1zCZPAgAAeHBzcgATamF2YS51" +
       "dGls\nLkFycmF5TGlzdHiB0h2Zx2GdAwABSQAEc2l6ZXhwAAAAAHcEAAAAAH" +
       "hzcgAUcG9seWdsb3QudHlw\nZXMuRmxhZ3Pa/7bw3cYgAwIAAUoABGJpdHN4" +
       "cAAAAAAAAAABc3EAfgAkAAAAAXcEAAAAAXNyACNw\nb2x5Z2xvdC5leHQuam" +
       "wudHlwZXMuUGxhY2VIb2xkZXJfY0r01lo2yLx0AgABTAAEbmFtZXEAfgAC\n" +
       "eHB0ABBqYXZhLmxhbmcuU3RyaW5neAAAAAIAAAAAc3EAfgAYdwQAAAAAeHBz" +
       "cQB+ABh3BAAAAAFx\nAH4AKnh0AAhCdXR0b24kMnhzcQB+ABMAdnIAHHBvbH" +
       "lnbG90LnR5cGVzLkZpZWxkSW5zdGFuY2XU\nZ74g0+2KYQIAAHhwc3EAfgAY" +
       "dwQAAAABc3IAJXBvbHlnbG90LmV4dC5qbC50eXBlcy5GaWVsZElu\nc3Rhbm" +
       "NlX2ORwPlzqvuJ+wIAAUwACWNvbnRhaW5lcnEAfgAeeHIAI3BvbHlnbG90Lm" +
       "V4dC5qbC50\neXBlcy5WYXJJbnN0YW5jZV9jnwNblT1G3McCAAVaAAppc0Nv" +
       "bnN0YW50TAANY29uc3RhbnRWYWx1\nZXQAEkxqYXZhL2xhbmcvT2JqZWN0O0" +
       "wABWZsYWdzcQB+AARMAARuYW1lcQB+AAJMAAR0eXBlcQB+\nAAh4cQB+AAxw" +
       "eABwcQB+ACd0AARuYW1lcQB+ACpxAH4ADnhzcQB+ACYAAAAAAAAAAHNxAH4A" +
       "EwBx\nAH4AI3NxAH4AGHcEAAAAAHhzcgAdcG9seWdsb3QudHlwZXMuQ2xhc3" +
       "NUeXBlJEtpbmSHWPEMhmHE\nXQIAAHhyABJwb2x5Z2xvdC51dGlsLkVudW2w" +
       "5N7MJ2zKCQIAAUwABG5hbWVxAH4AAnhwdAAJdG9w\nLWxldmVsc3EAfgATAH" +
       "EAfgAjc3EAfgAYdwQAAAAAeHNxAH4AEwB2cgAdcG9seWdsb3QudHlwZXMu\n" +
       "TWV0aG9kSW5zdGFuY2VcZIUICSl86QIAAHhwc3EAfgAYdwQAAAAAeHEAfgAS" +
       "cHBzcQB+ACl0AAZX\naWRnZXRzcQB+ABh3BAAAAAFzcgAwcG9seWdsb3QuZX" +
       "h0Lm9vbWF0Y2gudHlwZXMuRGVjb25zdHJ1\nY3Rvckluc3RhbmNlAAAAAAWx" +
       "fjQCAAVJAAJpZEwABG5hbWVxAH4AAkwABm9uVHlwZXEAfgAGTAAK\ncGFyYW" +
       "1OYW1lc3EAfgABTAAIcmVhbE5hbWVxAH4AAnhxAH4AHXEAfgAgeHEAfgAOc3" +
       "EAfgATAXEA\nfgAjc3EAfgAkAAAAAHcEAAAAAHhzcQB+ACYAAAAAAAAAAXNx" +
       "AH4AEwFxAH4AI3NxAH4AJAAAAAF3\nBAAAAAFxAH4AKngAAAADdAAGQnV0dG" +
       "9ucHNxAH4AJAAAAAF3BAAAAAFxAH4AN3h0AAhCdXR0b24k\nM3h0AAEkc3EA" +
       "fgAYdwQAAAAAeA==");
}

class Textbox extends Widget {
    public String text;
    
    public Textbox(String text) {
        super();
        this.text = text; }
    
    public Object[] Textbox$3() {
        String text;
        text = this.text;
        if (true) return new Object[] { text }; else return null;
    }
    
    public static String messageFor2$(int m) {
        switch (m) { case 2: return "constructor public Textbox(java.lang.String)"; }
        return Widget.messageFor1$(m); }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1182288731000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAMAAAACXQADVBv\nc3RlckVnMy5vb214dAAHVGV4dGJveH" +
       "B4AHNyABdwb2x5Z2xvdC51dGlsLlR5cGVkTGlzdOyyOxCO\nLXO2AgADWgAJ" +
       "aW1tdXRhYmxlTAAMYWxsb3dlZF90eXBldAARTGphdmEvbGFuZy9DbGFzcztM" +
       "AAxi\nYWNraW5nX2xpc3RxAH4AAXhwAHZyACJwb2x5Z2xvdC50eXBlcy5Db2" +
       "5zdHJ1Y3Rvckluc3RhbmNl\nF2c+oLhulyMCAAB4cHNyABRqYXZhLnV0aWwu" +
       "TGlua2VkTGlzdAwpU11KYIgiAwAAeHB3BAAAAAFz\ncgA1cG9seWdsb3QuZX" +
       "h0Lm9vbWF0Y2gudHlwZXMuT09NYXRjaENvbnN0cnVjdG9ySW5zdGFuY2UA\n" +
       "AAAAFEBktgIABkkAAmlkSQAKanVua1BhcmFtc0wACGNoaWxkcmVucQB+AAFb" +
       "AAxpc05hbWVkUGFy\nYW10AAJbWkwACnBhcmFtVHlwZXNxAH4AAUwACHJlYW" +
       "xOYW1lcQB+AAJ4cgArcG9seWdsb3QuZXh0\nLmpsLnR5cGVzLkNvbnN0cnVj" +
       "dG9ySW5zdGFuY2VfY8ChKwwDstPoAgAAeHIAKXBvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5Qcm9jZWR1cmVJbnN0YW5jZV9jxQZ7AomG5WsCAARMAAljb250YW" +
       "luZXJ0AB5M\ncG9seWdsb3QvdHlwZXMvUmVmZXJlbmNlVHlwZTtMAAhleGNU" +
       "eXBlc3EAfgABTAAFZmxhZ3NxAH4A\nBEwAC2Zvcm1hbFR5cGVzcQB+AAF4cQ" +
       "B+AAxzcQB+AA8AAAALAAAABQAAAAsAAAAKcQB+ABF4cQB+\nAA5zcQB+ABMB" +
       "dnIAE3BvbHlnbG90LnR5cGVzLlR5cGX1UdGqdcwmTwIAAHhwc3IAE2phdmEu" +
       "dXRp\nbC5BcnJheUxpc3R4gdIdmcdhnQMAAUkABHNpemV4cAAAAAB3BAAAAA" +
       "B4c3IAFHBvbHlnbG90LnR5\ncGVzLkZsYWdz2v+28N3GIAMCAAFKAARiaXRz" +
       "eHAAAAAAAAAAAXNxAH4AJAAAAAF3BAAAAAFzcgAj\ncG9seWdsb3QuZXh0Lm" +
       "psLnR5cGVzLlBsYWNlSG9sZGVyX2NK9NZaNsi8dAIAAUwABG5hbWVxAH4A\n" +
       "AnhwdAAQamF2YS5sYW5nLlN0cmluZ3gAAAACAAAAAHNxAH4AGHcEAAAAAHhw" +
       "c3EAfgAYdwQAAAAB\ncQB+ACp4dAAJVGV4dGJveCQyeHNxAH4AEwB2cgAccG" +
       "9seWdsb3QudHlwZXMuRmllbGRJbnN0YW5j\nZdRnviDT7YphAgAAeHBzcQB+" +
       "ABh3BAAAAAFzcgAlcG9seWdsb3QuZXh0LmpsLnR5cGVzLkZpZWxk\nSW5zdG" +
       "FuY2VfY5HA+XOq+4n7AgABTAAJY29udGFpbmVycQB+AB54cgAjcG9seWdsb3" +
       "QuZXh0Lmps\nLnR5cGVzLlZhckluc3RhbmNlX2OfA1uVPUbcxwIABVoACmlz" +
       "Q29uc3RhbnRMAA1jb25zdGFudFZh\nbHVldAASTGphdmEvbGFuZy9PYmplY3" +
       "Q7TAAFZmxhZ3NxAH4ABEwABG5hbWVxAH4AAkwABHR5cGVx\nAH4ACHhxAH4A" +
       "DHB4AHBxAH4AJ3QABHRleHRxAH4AKnEAfgAOeHNxAH4AJgAAAAAAAAAAc3EA" +
       "fgAT\nAHEAfgAjc3EAfgAYdwQAAAAAeHNyAB1wb2x5Z2xvdC50eXBlcy5DbG" +
       "Fzc1R5cGUkS2luZIdY8QyG\nYcRdAgAAeHIAEnBvbHlnbG90LnV0aWwuRW51" +
       "bbDk3swnbMoJAgABTAAEbmFtZXEAfgACeHB0AAl0\nb3AtbGV2ZWxzcQB+AB" +
       "MAcQB+ACNzcQB+ABh3BAAAAAB4c3EAfgATAHZyAB1wb2x5Z2xvdC50eXBl\n" +
       "cy5NZXRob2RJbnN0YW5jZVxkhQgJKXzpAgAAeHBzcQB+ABh3BAAAAAB4cQB+" +
       "ABJwcHNxAH4AKXQA\nBldpZGdldHNxAH4AGHcEAAAAAXNyADBwb2x5Z2xvdC" +
       "5leHQub29tYXRjaC50eXBlcy5EZWNvbnN0\ncnVjdG9ySW5zdGFuY2UAAAAA" +
       "BbF+NAIABUkAAmlkTAAEbmFtZXEAfgACTAAGb25UeXBlcQB+AAZM\nAApwYX" +
       "JhbU5hbWVzcQB+AAFMAAhyZWFsTmFtZXEAfgACeHEAfgAdcQB+ACB4cQB+AA" +
       "5zcQB+ABMB\ncQB+ACNzcQB+ACQAAAAAdwQAAAAAeHNxAH4AJgAAAAAAAAAB" +
       "c3EAfgATAXEAfgAjc3EAfgAkAAAA\nAXcEAAAAAXEAfgAqeAAAAAN0AAdUZX" +
       "h0Ym94cHNxAH4AJAAAAAF3BAAAAAFxAH4AN3h0AAlUZXh0\nYm94JDN4dAAB" +
       "JHNxAH4AGHcEAAAAAHg=");
}

class PosterEg3 {
    final void doEvent$1(Widget w) {  }
    
    final void doEvent$2() {  }
    
    final void doEvent$3(String name) {  }
    
    final void doEvent$4(String text) {  }
    
    public PosterEg3() { super(); }
    
    void doEvent(Widget arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$2$1 = null;
            if (arg1 instanceof Button &&
                  (arg2 == null || Button.class.isAssignableFrom(arg2) || arg2.isAssignableFrom(Button.class)) &&
                  arg1 != null)
                retVal$2$1 = ((Button) arg1).Button$3();
            {
                if (arg1 instanceof Button &&
                      (arg2 == null || Button.class.isAssignableFrom(arg2) || arg2.isAssignableFrom(Button.class)) &&
                      arg1 != null &&
                      retVal$2$1 != null &&
                      "OK".equals(retVal$2$1[0])) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PosterEg3.\n");
                    methodChosen = 2;
                }
            }
            Object[] retVal$4$1 = null;
            if (arg1 instanceof Textbox &&
                  (arg2 == null || Textbox.class.isAssignableFrom(arg2) || arg2.isAssignableFrom(Textbox.class)) &&
                  arg1 != null)
                retVal$4$1 = ((Textbox) arg1).Textbox$3();
            {
                if (arg1 instanceof Textbox &&
                      (arg2 == null || Textbox.class.isAssignableFrom(arg2) || arg2.isAssignableFrom(Textbox.class)) &&
                      arg1 != null &&
                      retVal$4$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(4) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PosterEg3.\n");
                    methodChosen = 4;
                }
            }
            Object[] retVal$3$1 = null;
            if (arg1 instanceof Button &&
                  (arg2 == null || Button.class.isAssignableFrom(arg2) || arg2.isAssignableFrom(Button.class)) &&
                  arg1 != null)
                retVal$3$1 = ((Button) arg1).Button$3();
            if (methodChosen != 2) {
                if (arg1 instanceof Button &&
                      (arg2 == null || Button.class.isAssignableFrom(arg2) || arg2.isAssignableFrom(Button.class)) &&
                      arg1 != null &&
                      retVal$3$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PosterEg3.\n");
                    methodChosen = 3;
                }
            }
            if (methodChosen != 2 && methodChosen != 3 && methodChosen != 4) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(1) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class PosterEg3.\n");
                    methodChosen = 1;
                }
            }
            switch (methodChosen) {
                case 2:
                    doEvent$2();
                    return;
                case 4:
                    doEvent$4((String) retVal$4$1[0]);
                    return;
                case 3:
                    doEvent$3((String) retVal$3$1[0]);
                    return;
                case 1:
                    doEvent$1(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 1: return "method  void doEvent(Widget)"; case 3:
                return "method  void doEvent(Button.Button(java.lang.String))"; case 2:
                return "method  void doEvent(Button.Button(\"OK\"))"; case 4:
                return "method  void doEvent(Textbox.Textbox(java.lang.String))"; case 5:
                return "constructor PosterEg3()";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1182288731000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAaAAAADnQADVBv\nc3RlckVnMy5vb214dAAJUG9zdGVyRW" +
       "czcHgAc3IAF3BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7\nEI4tc7YCAANa" +
       "AAlpbW11dGFibGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNz" +
       "O0wA\nDGJhY2tpbmdfbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLk" +
       "NvbnN0cnVjdG9ySW5zdGFu\nY2UXZz6guG6XIwIAAHhwc3IAFGphdmEudXRp" +
       "bC5MaW5rZWRMaXN0DClTXUpgiCIDAAB4cHcEAAAA\nAXNyADVwb2x5Z2xvdC" +
       "5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5j\n" +
       "ZQAAAAAUQGS2AgAGSQACaWRJAApqdW5rUGFyYW1zTAAIY2hpbGRyZW5xAH4A" +
       "AVsADGlzTmFtZWRQ\nYXJhbXQAAltaTAAKcGFyYW1UeXBlc3EAfgABTAAIcm" +
       "VhbE5hbWVxAH4AAnhyACtwb2x5Z2xvdC5l\neHQuamwudHlwZXMuQ29uc3Ry" +
       "dWN0b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgApcG9seWdsb3Qu\nZXh0Lm" +
       "psLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblawIABEwACWNvbn" +
       "RhaW5lcnQA\nHkxwb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VUeXBlO0wACGV4" +
       "Y1R5cGVzcQB+AAFMAAVmbGFnc3EA\nfgAETAALZm9ybWFsVHlwZXNxAH4AAX" +
       "hxAH4ADHEAfgAQeHEAfgAOc3EAfgATAXZyABNwb2x5Z2xv\ndC50eXBlcy5U" +
       "eXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnH" +
       "YZ0D\nAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2x5Z2xvdC50eXBlcy" +
       "5GbGFnc9r/tvDdxiADAgAB\nSgAEYml0c3hwAAAAAAAAAABzcQB+ABMBcQB+" +
       "ACJzcQB+ACMAAAAAdwQAAAAAeAAAAAUAAAAAc3EA\nfgAYdwQAAAAAeHBzcg" +
       "AfamF2YS51dGlsLkNvbGxlY3Rpb25zJEVtcHR5TGlzdHq4F7Q8p57eAgAA\n" +
       "eHB0AAtQb3N0ZXJFZzMkNXhzcQB+ABMAdnIAHHBvbHlnbG90LnR5cGVzLkZp" +
       "ZWxkSW5zdGFuY2XU\nZ74g0+2KYQIAAHhwc3EAfgAYdwQAAAAAeHEAfgAmc3" +
       "EAfgATAHEAfgAic3EAfgAYdwQAAAAAeHNy\nAB1wb2x5Z2xvdC50eXBlcy5D" +
       "bGFzc1R5cGUkS2luZIdY8QyGYcRdAgAAeHIAEnBvbHlnbG90LnV0\naWwuRW" +
       "51bbDk3swnbMoJAgABTAAEbmFtZXEAfgACeHB0AAl0b3AtbGV2ZWxzcQB+AB" +
       "MAcQB+ACJz\ncQB+ABh3BAAAAAB4c3EAfgATAHZyAB1wb2x5Z2xvdC50eXBl" +
       "cy5NZXRob2RJbnN0YW5jZVxkhQgJ\nKXzpAgAAeHBzcQB+ABh3BAAAAAFzcg" +
       "AwcG9seWdsb3QuZXh0Lm9vbWF0Y2gudHlwZXMuT09NYXRj\naE1ldGhvZElu" +
       "c3RhbmNlAAAAACwdpH8CAAdaAA5oYXNXaGVyZUNsYXVzZUkAAmlkTAAFY2hp" +
       "bGR0\nAB9McG9seWdsb3QvdHlwZXMvTWV0aG9kSW5zdGFuY2U7TAAIY2hpbG" +
       "RyZW5xAH4AAVsADGlzTmFt\nZWRQYXJhbXEAfgAbTAAKcGFyYW1UeXBlc3EA" +
       "fgABTAAIcmVhbE5hbWVxAH4AAnhyACZwb2x5Z2xv\ndC5leHQuamwudHlwZX" +
       "MuTWV0aG9kSW5zdGFuY2VfY4xXCMkBC2X7AgACTAAEbmFtZXEAfgACTAAK\n" +
       "cmV0dXJuVHlwZXEAfgAIeHEAfgAdc3EAfgAPAAAABAAAABoAAAAPAAAAD3EA" +
       "fgAReHEAfgAOc3EA\nfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHhxAH4AJn" +
       "NxAH4AIwAAAAF3BAAAAAFzcgAjcG9seWds\nb3QuZXh0LmpsLnR5cGVzLlBs" +
       "YWNlSG9sZGVyX2NK9NZaNsi8dAIAAUwABG5hbWVxAH4AAnhwdAAG\nV2lkZ2" +
       "V0eHQAB2RvRXZlbnRzcgAlcG9seWdsb3QuZXh0LmpsLnR5cGVzLlByaW1pdG" +
       "l2ZVR5cGVf\nY+9T6xr3ChLEAgABTAAEa2luZHQAI0xwb2x5Z2xvdC90eXBl" +
       "cy9QcmltaXRpdmVUeXBlJEtpbmQ7\neHEAfgALcHh0AAR2b2lkcHhzcgAhcG" +
       "9seWdsb3QudHlwZXMuUHJpbWl0aXZlVHlwZSRLaW5kxCsh\nrH5S3mICAAB4" +
       "cQB+ADRxAH4ATAAAAAABcHNxAH4AGHcEAAAAAnNxAH4APXNxAH4ADwAAAAQA" +
       "AAAl\nAAAAEwAAABNxAH4AEXhxAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAA" +
       "B3BAAAAAB4cQB+ACZzcQB+\nACMAAAABdwQAAAABc3EAfgBFdAAGQnV0dG9u" +
       "eHQAB2RvRXZlbnRxAH4ASwAAAAADcHNxAH4AGHcE\nAAAAAXNxAH4APXNxAH" +
       "4ADwAAAAQAAAAeAAAAEAAAABBxAH4AEXhxAH4ADnNxAH4AEwFxAH4AInNx\n" +
       "AH4AIwAAAAB3BAAAAAB4cQB+ACZzcQB+ACMAAAABdwQAAAABcQB+AFV4dAAH" +
       "ZG9FdmVudHEAfgBL\nAAAAAAJwc3EAfgAYdwQAAAAAeHVyAAJbWlePIDkUuF" +
       "3iAgAAeHAAAAABAHNxAH4AGHcEAAAAAXNy\nAChwb2x5Z2xvdC5leHQub29t" +
       "YXRjaC50eXBlcy5QYXR0ZXJuVHlwZV9jAAAAACoCxDgCAAVMAA1k\nZWNvbn" +
       "N0cnVjdG9ydAAyTHBvbHlnbG90L2V4dC9vb21hdGNoL3R5cGVzL0RlY29uc3" +
       "RydWN0b3JJ\nbnN0YW5jZTtMABFkZWNvbnN0cnVjdG9yVHlwZXEAfgAGWwAM" +
       "aXNOYW1lZFBhcmFtcQB+ABtMAAdw\nYXR0ZXJucQB+AAFMAAd2YXJOYW1lcQ" +
       "B+AAJ4cQB+AAtzcQB+AA8AAAARAAAAHQAAABAAAAAQcQB+\nABF4eHNyADBw" +
       "b2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5EZWNvbnN0cnVjdG9ySW5zdGFu" +
       "Y2UA\nAAAABbF+NAIABUkAAmlkTAAEbmFtZXEAfgACTAAGb25UeXBlcQB+AA" +
       "ZMAApwYXJhbU5hbWVzcQB+\nAAFMAAhyZWFsTmFtZXEAfgACeHEAfgAdc3EA" +
       "fgAPAAAACwAAAAUAAAAGAAAABXEAfgAReHEAfgBV\nc3EAfgATAXEAfgAic3" +
       "EAfgAjAAAAAHcEAAAAAHhzcQB+ACUAAAAAAAAAAXNxAH4AEwFxAH4AInNx\n" +
       "AH4AIwAAAAF3BAAAAAFzcQB+AEV0ABBqYXZhLmxhbmcuU3RyaW5neAAAAAN0" +
       "AAZCdXR0b25wc3EA\nfgAjAAAAAXcEAAAAAXQABG5hbWV4dAAIQnV0dG9uJD" +
       "NxAH4AVXVxAH4AYAAAAAEAc3EAfgAYdwQA\nAAABc3IAJnBvbHlnbG90LmV4" +
       "dC5vb21hdGNoLnR5cGVzLlZhbHVlVHlwZV9jAAAAAAQHjA8CAAJM\nAA1jb2" +
       "5zdGFudFZhbHVldAASTGphdmEvbGFuZy9PYmplY3Q7TAALdHlwZU9mVmFsdW" +
       "VxAH4ACHhx\nAH4AC3NxAH4ADwAAABgAAAAcAAAAEAAAABBxAH4AEXh4dAAC" +
       "T0txAH4Ab3h0AAB4dAAJZG9FdmVu\ndCQyeHVxAH4AYAAAAAEAc3EAfgAYdw" +
       "QAAAABc3EAfgBjc3EAfgAPAAAAEQAAACQAAAATAAAAE3EA\nfgAReHhxAH4A" +
       "aHEAfgBVdXEAfgBgAAAAAQBzcQB+ABh3BAAAAAFxAH4Ab3hxAH4AfHh0AAlk" +
       "b0V2\nZW50JDNzcQB+AD1zcQB+AA8AAAAEAAAAJgAAABcAAAAXcQB+ABF4cQ" +
       "B+AA5zcQB+ABMBcQB+ACJz\ncQB+ACMAAAAAdwQAAAAAeHEAfgAmc3EAfgAj" +
       "AAAAAXcEAAAAAXNxAH4ARXQAB1RleHRib3h4dAAH\nZG9FdmVudHEAfgBLAA" +
       "AAAARwc3EAfgAYdwQAAAAAeHVxAH4AYAAAAAEAc3EAfgAYdwQAAAABc3EA\n" +
       "fgBjc3EAfgAPAAAAEQAAACUAAAAXAAAAF3EAfgAReHhzcQB+AGdzcQB+AA8A" +
       "AAALAAAABQAAAAsA\nAAAKcQB+ABF4cQB+AIpzcQB+ABMBcQB+ACJzcQB+AC" +
       "MAAAAAdwQAAAAAeHNxAH4AJQAAAAAAAAAB\nc3EAfgATAXEAfgAic3EAfgAj" +
       "AAAAAXcEAAAAAXEAfgBveAAAAAN0AAdUZXh0Ym94cHNxAH4AIwAA\nAAF3BA" +
       "AAAAF0AAR0ZXh0eHQACVRleHRib3gkM3EAfgCKdXEAfgBgAAAAAQBzcQB+AB" +
       "h3BAAAAAFx\nAH4Ab3hxAH4AfHh0AAlkb0V2ZW50JDR4dXEAfgBgAAAAAQBz" +
       "cQB+ABh3BAAAAAFxAH4ARnh0AAlk\nb0V2ZW50JDF4cQB+ABJwcHNxAH4ARX" +
       "QAEGphdmEubGFuZy5PYmplY3RzcQB+ABh3BAAAAAB4dAAB\nJHNxAH4AGHcE" +
       "AAAAAHg=");
}
