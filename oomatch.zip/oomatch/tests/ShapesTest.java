abstract class Shape {
    public Object[] Shape$1() { if (true) return new Object[] {  }; else return null; }
    
    public Object[] Shape$2() {
        boolean b;
        b = true;
        if (true) return new Object[] { new Boolean(b) }; else return null;
    }
    
    public Shape() { super(); }
    
    public static String messageFor1$(int m) {
        switch (m) { case 3: return "constructor Shape()"; }
        return ""; }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1179255800000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAACQAAAAEAAAAUAAAADXQADlNo\nYXBlc1Rlc3Qub29teHQABVNoYXBlcH" +
       "gAc3IAF3BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7EI4t\nc7YCAANaAAlp" +
       "bW11dGFibGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNzO0wA" +
       "DGJh\nY2tpbmdfbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLkNvbn" +
       "N0cnVjdG9ySW5zdGFuY2UX\nZz6guG6XIwIAAHhwc3IAFGphdmEudXRpbC5M" +
       "aW5rZWRMaXN0DClTXUpgiCIDAAB4cHcEAAAAAXNy\nADVwb2x5Z2xvdC5leH" +
       "Qub29tYXRjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5jZQAA\n" +
       "AAAUQGS2AgAHSQACaWRJAApqdW5rUGFyYW1zWgAMbm9EaXNwYXRjaGVyTAAI" +
       "Y2hpbGRyZW5xAH4A\nAVsADGlzTmFtZWRQYXJhbXQAAltaTAAKcGFyYW1UeX" +
       "Blc3EAfgABTAAIcmVhbE5hbWVxAH4AAnhy\nACtwb2x5Z2xvdC5leHQuamwu" +
       "dHlwZXMuQ29uc3RydWN0b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4\ncgApcG" +
       "9seWdsb3QuZXh0LmpsLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiY" +
       "blawIABEwA\nCWNvbnRhaW5lcnQAHkxwb2x5Z2xvdC90eXBlcy9SZWZlcmVu" +
       "Y2VUeXBlO0wACGV4Y1R5cGVzcQB+\nAAFMAAVmbGFnc3EAfgAETAALZm9ybW" +
       "FsVHlwZXNxAH4AAXhxAH4ADHEAfgAQeHEAfgAOc3EAfgAT\nAXZyABNwb2x5" +
       "Z2xvdC50eXBlcy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJy" +
       "YXlM\naXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2" +
       "x5Z2xvdC50eXBlcy5GbGFn\nc9r/tvDdxiADAgABSgAEYml0c3hwAAAAAAAA" +
       "AABzcQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAA\neAAAAAMAAAAAAHNxAH" +
       "4AGHcEAAAAAHhwc3IAH2phdmEudXRpbC5Db2xsZWN0aW9ucyRFbXB0eUxp\n" +
       "c3R6uBe0PKee3gIAAHhwdAAHU2hhcGUkM3hzcQB+ABMAdnIAHHBvbHlnbG90" +
       "LnR5cGVzLkZpZWxk\nSW5zdGFuY2XUZ74g0+2KYQIAAHhwc3EAfgAYdwQAAA" +
       "AAeHNxAH4AJQAAAAAAAAIAc3EAfgATAHEA\nfgAic3EAfgAYdwQAAAAAeHNy" +
       "AB1wb2x5Z2xvdC50eXBlcy5DbGFzc1R5cGUkS2luZIdY8QyGYcRd\nAgAAeH" +
       "IAEnBvbHlnbG90LnV0aWwuRW51bbDk3swnbMoJAgABTAAEbmFtZXEAfgACeH" +
       "B0AAl0b3At\nbGV2ZWxzcQB+ABMAcQB+ACJzcQB+ABh3BAAAAAB4c3EAfgAT" +
       "AHZyAB1wb2x5Z2xvdC50eXBlcy5N\nZXRob2RJbnN0YW5jZVxkhQgJKXzpAg" +
       "AAeHBzcQB+ABh3BAAAAAB4cQB+ABJwcHNyACNwb2x5Z2xv\ndC5leHQuamwu" +
       "dHlwZXMuUGxhY2VIb2xkZXJfY0r01lo2yLx0AgABTAAEbmFtZXEAfgACeHB0" +
       "ABBq\nYXZhLmxhbmcuT2JqZWN0c3EAfgAYdwQAAAACc3IAMHBvbHlnbG90Lm" +
       "V4dC5vb21hdGNoLnR5cGVz\nLkRlY29uc3RydWN0b3JJbnN0YW5jZQAAAAAF" +
       "sX40AgAFSQACaWRMAARuYW1lcQB+AAJMAAZvblR5\ncGVxAH4ABkwACnBhcm" +
       "FtTmFtZXNxAH4AAUwACHJlYWxOYW1lcQB+AAJ4cQB+AB1zcQB+AA8AAAAE\n" +
       "AAAAGQAAAA8AAAAPcQB+ABF4cQB+AA5zcQB+ABMBcQB+ACJzcQB+ACMAAAAA" +
       "dwQAAAAAeHNxAH4A\nJQAAAAAAAAABc3EAfgATAXEAfgAic3EAfgAjAAAAAH" +
       "cEAAAAAHgAAAABdAAFU2hhcGVwc3EAfgAj\nAAAAAHcEAAAAAHh0AAdTaGFw" +
       "ZSQxc3EAfgBCc3EAfgAPAAAABAAAACIAAAAQAAAAEHEAfgAReHEA\nfgAOc3" +
       "EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHhzcQB+ACUAAAAAAAAAAXNxAH" +
       "4AEwFxAH4A\nInNxAH4AIwAAAAF3BAAAAAFzcgAlcG9seWdsb3QuZXh0Lmps" +
       "LnR5cGVzLlByaW1pdGl2ZVR5cGVf\nY+9T6xr3ChLEAgABTAAEa2luZHQAI0" +
       "xwb2x5Z2xvdC90eXBlcy9QcmltaXRpdmVUeXBlJEtpbmQ7\neHEAfgALcHh0" +
       "AAdib29sZWFucHhzcgAhcG9seWdsb3QudHlwZXMuUHJpbWl0aXZlVHlwZSRL" +
       "aW5k\nxCshrH5S3mICAAB4cQB+ADVxAH4AV3gAAAACdAAFU2hhcGVwc3EAfg" +
       "AjAAAAAXcEAAAAAXQAAWJ4\ndAAHU2hhcGUkMnh0AAEkc3EAfgAYdwQAAAAA" +
       "eA==");
}

class Circle extends Shape {
    Point centre;
    
    public Circle(Point centre) {
        super();
        this.centre = centre; }
    
    public Object[] Shape$3() { if (true) return new Object[] {  }; else return null; }
    
    public Object[] Circle$4() {
        Point centre;
        centre = this.centre;
        if (true) return new Object[] { centre }; else return null;
    }
    
    public Object[] Circle$5() {
        CoorPoint centre;
        centre = new CoorPoint(this.centre.x + 1,this.centre.y + 1);
        if (true) return new Object[] { centre }; else return null;
    }
    
    public static String messageFor2$(int m) {
        switch (m) { case 2: return "constructor public Circle(Point)"; }
        return Shape.messageFor1$(m); }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1179255800000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAlAAAAFnQADlNo\nYXBlc1Rlc3Qub29teHQABkNpcmNsZX" +
       "B4AHNyABdwb2x5Z2xvdC51dGlsLlR5cGVkTGlzdOyyOxCO\nLXO2AgADWgAJ" +
       "aW1tdXRhYmxlTAAMYWxsb3dlZF90eXBldAARTGphdmEvbGFuZy9DbGFzcztM" +
       "AAxi\nYWNraW5nX2xpc3RxAH4AAXhwAHZyACJwb2x5Z2xvdC50eXBlcy5Db2" +
       "5zdHJ1Y3Rvckluc3RhbmNl\nF2c+oLhulyMCAAB4cHNyABRqYXZhLnV0aWwu" +
       "TGlua2VkTGlzdAwpU11KYIgiAwAAeHB3BAAAAAFz\ncgA1cG9seWdsb3QuZX" +
       "h0Lm9vbWF0Y2gudHlwZXMuT09NYXRjaENvbnN0cnVjdG9ySW5zdGFuY2UA\n" +
       "AAAAFEBktgIAB0kAAmlkSQAKanVua1BhcmFtc1oADG5vRGlzcGF0Y2hlckwA" +
       "CGNoaWxkcmVucQB+\nAAFbAAxpc05hbWVkUGFyYW10AAJbWkwACnBhcmFtVH" +
       "lwZXNxAH4AAUwACHJlYWxOYW1lcQB+AAJ4\ncgArcG9seWdsb3QuZXh0Lmps" +
       "LnR5cGVzLkNvbnN0cnVjdG9ySW5zdGFuY2VfY8ChKwwDstPoAgAA\neHIAKX" +
       "BvbHlnbG90LmV4dC5qbC50eXBlcy5Qcm9jZWR1cmVJbnN0YW5jZV9jxQZ7Ao" +
       "mG5WsCAARM\nAAljb250YWluZXJ0AB5McG9seWdsb3QvdHlwZXMvUmVmZXJl" +
       "bmNlVHlwZTtMAAhleGNUeXBlc3EA\nfgABTAAFZmxhZ3NxAH4ABEwAC2Zvcm" +
       "1hbFR5cGVzcQB+AAF4cQB+AAxzcQB+AA8AAAALAAAABQAA\nABoAAAAYcQB+" +
       "ABF4cQB+AA5zcQB+ABMBdnIAE3BvbHlnbG90LnR5cGVzLlR5cGX1UdGqdcwm" +
       "TwIA\nAHhwc3IAE2phdmEudXRpbC5BcnJheUxpc3R4gdIdmcdhnQMAAUkABH" +
       "NpemV4cAAAAAB3BAAAAAB4\nc3IAFHBvbHlnbG90LnR5cGVzLkZsYWdz2v+2" +
       "8N3GIAMCAAFKAARiaXRzeHAAAAAAAAAAAXNxAH4A\nJAAAAAF3BAAAAAFzcg" +
       "AjcG9seWdsb3QuZXh0LmpsLnR5cGVzLlBsYWNlSG9sZGVyX2NK9NZaNsi8\n" +
       "dAIAAUwABG5hbWVxAH4AAnhwdAAFUG9pbnR4AAAAAgAAAAAAc3EAfgAYdwQA" +
       "AAAAeHBzcQB+ABh3\nBAAAAAFxAH4AKnh0AAhDaXJjbGUkMnhzcQB+ABMAdn" +
       "IAHHBvbHlnbG90LnR5cGVzLkZpZWxkSW5z\ndGFuY2XUZ74g0+2KYQIAAHhw" +
       "c3EAfgAYdwQAAAABc3IAJXBvbHlnbG90LmV4dC5qbC50eXBlcy5G\naWVsZE" +
       "luc3RhbmNlX2ORwPlzqvuJ+wIAAUwACWNvbnRhaW5lcnEAfgAeeHIAI3BvbH" +
       "lnbG90LmV4\ndC5qbC50eXBlcy5WYXJJbnN0YW5jZV9jnwNblT1G3McCAAVa" +
       "AAppc0NvbnN0YW50TAANY29uc3Rh\nbnRWYWx1ZXQAEkxqYXZhL2xhbmcvT2" +
       "JqZWN0O0wABWZsYWdzcQB+AARMAARuYW1lcQB+AAJMAAR0\neXBlcQB+AAh4" +
       "cQB+AAxzcQB+AA8AAAAEAAAAEQAAABcAAAAXcQB+ABF4AHBzcQB+ACYAAAAA" +
       "AAAA\nAHQABmNlbnRyZXEAfgAqcQB+AA54cQB+ADhzcQB+ABMAcQB+ACNzcQ" +
       "B+ABh3BAAAAAB4c3IAHXBv\nbHlnbG90LnR5cGVzLkNsYXNzVHlwZSRLaW5k" +
       "h1jxDIZhxF0CAAB4cgAScG9seWdsb3QudXRpbC5F\nbnVtsOTezCdsygkCAA" +
       "FMAARuYW1lcQB+AAJ4cHQACXRvcC1sZXZlbHNxAH4AEwBxAH4AI3NxAH4A\n" +
       "GHcEAAAAAHhzcQB+ABMAdnIAHXBvbHlnbG90LnR5cGVzLk1ldGhvZEluc3Rh" +
       "bmNlXGSFCAkpfOkC\nAAB4cHNxAH4AGHcEAAAAAHhxAH4AEnBwc3EAfgApdA" +
       "AFU2hhcGVzcQB+ABh3BAAAAANzcgAwcG9s\neWdsb3QuZXh0Lm9vbWF0Y2gu" +
       "dHlwZXMuRGVjb25zdHJ1Y3Rvckluc3RhbmNlAAAAAAWxfjQCAAVJ\nAAJpZE" +
       "wABG5hbWVxAH4AAkwABm9uVHlwZXEAfgAGTAAKcGFyYW1OYW1lc3EAfgABTA" +
       "AIcmVhbE5h\nbWVxAH4AAnhxAH4AHXNxAH4ADwAAAAQAAAAZAAAAGwAAABtx" +
       "AH4AEXhxAH4ADnNxAH4AEwFxAH4A\nI3NxAH4AJAAAAAB3BAAAAAB4c3EAfg" +
       "AmAAAAAAAAAAFzcQB+ABMBcQB+ACNzcQB+ACQAAAAAdwQA\nAAAAeAAAAAN0" +
       "AAVTaGFwZXBzcQB+ACQAAAAAdwQAAAAAeHQAB1NoYXBlJDNzcQB+AElzcQB+" +
       "AA8A\nAAAEAAAAJgAAABwAAAAccQB+ABF4cQB+AA5zcQB+ABMBcQB+ACNzcQ" +
       "B+ACQAAAAAdwQAAAAAeHNx\nAH4AJgAAAAAAAAABc3EAfgATAXEAfgAjc3EA" +
       "fgAkAAAAAXcEAAAAAXEAfgAqeAAAAAR0AAZDaXJj\nbGVwc3EAfgAkAAAAAX" +
       "cEAAAAAXQABmNlbnRyZXh0AAhDaXJjbGUkNHNxAH4ASXNxAH4ADwAAAAQA\n" +
       "AAAqAAAAIQAAACFxAH4AEXhxAH4ADnNxAH4AEwFxAH4AI3NxAH4AJAAAAAB3" +
       "BAAAAAB4c3EAfgAm\nAAAAAAAAAAFzcQB+ABMBcQB+ACNzcQB+ACQAAAABdw" +
       "QAAAABc3EAfgApdAAJQ29vclBvaW50eAAA\nAAV0AAZDaXJjbGVwc3EAfgAk" +
       "AAAAAXcEAAAAAXQABmNlbnRyZXh0AAhDaXJjbGUkNXh0AAEkc3EA\nfgAYdw" +
       "QAAAAAeA==");
}

class Rectangle extends Shape {
    public Point p1;
    
    public Point p2;
    
    public Rectangle(Point p, Point p2) {
        super();
        this.p1 = p;
        this.p2 = p2;
    }
    
    public Rectangle() { super(); }
    
    public static String messageFor2$(int m) {
        switch (m) {
            case 2: return "constructor public Rectangle(Point, Point)"; case 3:
                return "constructor public Rectangle()";
        }
        return Shape.messageFor1$(m);
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1179255800000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAvAAAAJ3QADlNo\nYXBlc1Rlc3Qub29teHQACVJlY3Rhbm" +
       "dsZXB4AHNyABdwb2x5Z2xvdC51dGlsLlR5cGVkTGlzdOyy\nOxCOLXO2AgAD" +
       "WgAJaW1tdXRhYmxlTAAMYWxsb3dlZF90eXBldAARTGphdmEvbGFuZy9DbGFz" +
       "cztM\nAAxiYWNraW5nX2xpc3RxAH4AAXhwAHZyACJwb2x5Z2xvdC50eXBlcy" +
       "5Db25zdHJ1Y3Rvckluc3Rh\nbmNlF2c+oLhulyMCAAB4cHNyABRqYXZhLnV0" +
       "aWwuTGlua2VkTGlzdAwpU11KYIgiAwAAeHB3BAAA\nAAJzcgA1cG9seWdsb3" +
       "QuZXh0Lm9vbWF0Y2gudHlwZXMuT09NYXRjaENvbnN0cnVjdG9ySW5zdGFu\n" +
       "Y2UAAAAAFEBktgIAB0kAAmlkSQAKanVua1BhcmFtc1oADG5vRGlzcGF0Y2hl" +
       "ckwACGNoaWxkcmVu\ncQB+AAFbAAxpc05hbWVkUGFyYW10AAJbWkwACnBhcm" +
       "FtVHlwZXNxAH4AAUwACHJlYWxOYW1lcQB+\nAAJ4cgArcG9seWdsb3QuZXh0" +
       "LmpsLnR5cGVzLkNvbnN0cnVjdG9ySW5zdGFuY2VfY8ChKwwDstPo\nAgAAeH" +
       "IAKXBvbHlnbG90LmV4dC5qbC50eXBlcy5Qcm9jZWR1cmVJbnN0YW5jZV9jxQ" +
       "Z7AomG5WsC\nAARMAAljb250YWluZXJ0AB5McG9seWdsb3QvdHlwZXMvUmVm" +
       "ZXJlbmNlVHlwZTtMAAhleGNUeXBl\nc3EAfgABTAAFZmxhZ3NxAH4ABEwAC2" +
       "Zvcm1hbFR5cGVzcQB+AAF4cQB+AAxzcQB+AA8AAAALAAAA\nBQAAAC0AAAAp" +
       "cQB+ABF4cQB+AA5zcQB+ABMBdnIAE3BvbHlnbG90LnR5cGVzLlR5cGX1UdGq" +
       "dcwm\nTwIAAHhwc3IAE2phdmEudXRpbC5BcnJheUxpc3R4gdIdmcdhnQMAAU" +
       "kABHNpemV4cAAAAAB3BAAA\nAAB4c3IAFHBvbHlnbG90LnR5cGVzLkZsYWdz" +
       "2v+28N3GIAMCAAFKAARiaXRzeHAAAAAAAAAAAXNx\nAH4AJAAAAAJ3BAAAAA" +
       "JzcgAjcG9seWdsb3QuZXh0LmpsLnR5cGVzLlBsYWNlSG9sZGVyX2NK9NZa\n" +
       "Nsi8dAIAAUwABG5hbWVxAH4AAnhwdAAFUG9pbnRxAH4AKngAAAACAAAAAABz" +
       "cQB+ABh3BAAAAAB4\ncHNxAH4AGHcEAAAAAnEAfgAqcQB+ACp4dAALUmVjdG" +
       "FuZ2xlJDJzcQB+ABpzcQB+AA8AAAALAAAA\nGQAAAC4AAAAucQB+ABF4cQB+" +
       "AA5zcQB+ABMBcQB+ACNzcQB+ACQAAAAAdwQAAAAAeHEAfgAnc3EA\nfgAkAA" +
       "AAAHcEAAAAAHgAAAADAAAAAABzcQB+ABh3BAAAAAB4cHNxAH4AGHcEAAAAAH" +
       "h0AAtSZWN0\nYW5nbGUkM3hzcQB+ABMAdnIAHHBvbHlnbG90LnR5cGVzLkZp" +
       "ZWxkSW5zdGFuY2XUZ74g0+2KYQIA\nAHhwc3EAfgAYdwQAAAACc3IAJXBvbH" +
       "lnbG90LmV4dC5qbC50eXBlcy5GaWVsZEluc3RhbmNlX2OR\nwPlzqvuJ+wIA" +
       "AUwACWNvbnRhaW5lcnEAfgAeeHIAI3BvbHlnbG90LmV4dC5qbC50eXBlcy5W" +
       "YXJJ\nbnN0YW5jZV9jnwNblT1G3McCAAVaAAppc0NvbnN0YW50TAANY29uc3" +
       "RhbnRWYWx1ZXQAEkxqYXZh\nL2xhbmcvT2JqZWN0O0wABWZsYWdzcQB+AARM" +
       "AARuYW1lcQB+AAJMAAR0eXBlcQB+AAh4cQB+AAxz\ncQB+AA8AAAALAAAAGA" +
       "AAACgAAAAocQB+ABF4AHBxAH4AJ3QAAnAxcQB+ACpxAH4ADnNxAH4AO3Nx\n" +
       "AH4ADwAAAAsAAAAYAAAAKAAAAChxAH4AEXgAcHEAfgAndAACcDJxAH4AKnEA" +
       "fgAOeHNxAH4AJgAA\nAAAAAAAAc3EAfgATAHEAfgAjc3EAfgAYdwQAAAAAeH" +
       "NyAB1wb2x5Z2xvdC50eXBlcy5DbGFzc1R5\ncGUkS2luZIdY8QyGYcRdAgAA" +
       "eHIAEnBvbHlnbG90LnV0aWwuRW51bbDk3swnbMoJAgABTAAEbmFt\nZXEAfg" +
       "ACeHB0AAl0b3AtbGV2ZWxzcQB+ABMAcQB+ACNzcQB+ABh3BAAAAAB4c3EAfg" +
       "ATAHZyAB1w\nb2x5Z2xvdC50eXBlcy5NZXRob2RJbnN0YW5jZVxkhQgJKXzp" +
       "AgAAeHBzcQB+ABh3BAAAAAB4cQB+\nABJwcHNxAH4AKXQABVNoYXBlc3EAfg" +
       "AYdwQAAAAAeHQAASRzcQB+ABh3BAAAAAB4");
}

public class ShapesTest {
    public static void main(String[] args) { new ShapesTest().doMain(); }
    
    final void doMain$2() {
        Point p = new Point(5,4);
        CoorPoint cp = new CoorPoint(2,3);
        Circle c = new Circle(p);
        Rectangle r = new Rectangle(p,cp);
        linepack.Line line = new linepack.Line(0,0,1,1);
        nullTest((Point) null, Point.class);
        nullTest(p, Point.class);
        nullTest(cp, CoorPoint.class);
        Shape s = new Rectangle();
        testShape(s, Shape.class);
        testNamedDec(line, linepack.Line.class);
        testOverloadDec(c, Circle.class);
    }
    
    final void testNamedDec$3(linepack.Line l) {  }
    
    final void testNamedDec$4(double x, double y) { System.out.println("testNamedDec: x = " + x + "y = " + y); }
    
    final void testOverloadDec$5(Circle c) {  }
    
    final void testOverloadDec$6(Point p) {  }
    
    final void testOverloadDec$7() {  }
    
    final void testShape$8() {  }
    
    final void testShape$9(Shape s) { System.out.println("testShape(Shape)"); }
    
    final void nullTest$10() { System.out.println("nullTest(null)"); }
    
    final void nullTest$11(Point p) { System.out.println("nullTest(Point)"); }
    
    final void nullTest$12(CoorPoint q) { System.out.println("nullTest(CoorPoint)"); }
    
    final void nullTest$13(Rectangle p) { System.out.println("nullTest(Rectangle)"); }
    
    public ShapesTest() { super(); }
    
    void doMain() {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 2) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 2;
                }
            }
            switch (methodChosen) {
                case 2:
                    doMain$2();
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void testNamedDec(linepack.Line arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$4$1 = null;
            if (arg1 != null) retVal$4$1 = arg1.rightEndPoint$1();
            if (methodChosen != 4) {
                if (arg1 != null && retVal$4$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(4) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 4;
                }
            }
            if (methodChosen != 3 && methodChosen != 4) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 3;
                }
            }
            switch (methodChosen) {
                case 4:
                    testNamedDec$4(((Double) retVal$4$1[0]).doubleValue(), ((Double) retVal$4$1[1]).doubleValue());
                    return;
                case 3:
                    testNamedDec$3(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void testOverloadDec(Circle arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$6$1 = null;
            if (arg1 != null) retVal$6$1 = arg1.Circle$4();
            if (methodChosen != 6) {
                if (arg1 != null && retVal$6$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(6) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 6;
                }
            }
            Object[] retVal$7$1 = null;
            if (arg1 != null) retVal$7$1 = arg1.Shape$3();
            if (methodChosen != 7) {
                if (arg1 != null && retVal$7$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(7) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 7;
                }
            }
            if (methodChosen != 5 && methodChosen != 6 && methodChosen != 7) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(5) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 5;
                }
            }
            switch (methodChosen) {
                case 6:
                    testOverloadDec$6((Point) retVal$6$1[0]);
                    return;
                case 7:
                    testOverloadDec$7();
                    return;
                case 5:
                    testOverloadDec$5(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void testShape(Shape arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$8$1 = null;
            if (arg1 != null) retVal$8$1 = arg1.Shape$1();
            if (methodChosen != 8) {
                if (arg1 != null && retVal$8$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(8) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 8;
                }
            }
            if (methodChosen != 9 && methodChosen != 8) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(9) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 9;
                }
            }
            switch (methodChosen) {
                case 8:
                    testShape$8();
                    return;
                case 9:
                    testShape$9(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void nullTest(Point arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 10) {
                if (arg1 == null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(10) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 10;
                }
            }
            if (methodChosen != 12 && methodChosen != 10) {
                if (arg1 instanceof CoorPoint &&
                      (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                         arg2.isAssignableFrom(CoorPoint.class)) ||
                      arg1 == null && (arg2 == null || CoorPoint.class.isAssignableFrom(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(12) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 12;
                }
            }
            if (methodChosen != 11 && methodChosen != 12 && methodChosen != 10) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(11) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 11;
                }
            }
            switch (methodChosen) {
                case 10:
                    nullTest$10();
                    return;
                case 12:
                    nullTest$12((CoorPoint) arg1);
                    return;
                case 11:
                    nullTest$11(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void nullTest(CoorPoint arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 10) {
                if (arg1 == null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(10) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 10;
                }
            }
            if (methodChosen != 12 && methodChosen != 10) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(12) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 12;
                }
            }
            switch (methodChosen) {
                case 10:
                    nullTest$10();
                    return;
                case 12:
                    nullTest$12(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void nullTest(Rectangle arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 13) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(13) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class ShapesTest.\n");
                    methodChosen = 13;
                }
            }
            switch (methodChosen) {
                case 13:
                    nullTest$13(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 1: return "method public static void main(java.lang.String[])"; case 2: return "method  void doMain()";
            case 3: return "method  void testNamedDec(linepack.Line)"; case 4:
                return ("method  void testNamedDec(linepack.Line.rightEndPoint(double" + ", double))"); case 5:
                return "method  void testOverloadDec(Circle)"; case 6:
                return "method  void testOverloadDec(Circle.Circle(Point))"; case 7:
                return "method  void testOverloadDec(Circle.Shape())"; case 9: return "method  void testShape(Shape)";
            case 8: return "method  void testShape(Shape.Shape())"; case 11: return "method  void nullTest(Point)";
            case 12: return "method  void nullTest(CoorPoint)"; case 10: return "method  void nullTest(null)"; case 13:
                return "method  void nullTest(Rectangle)"; case 14: return "constructor public ShapesTest()";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1179255800000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAABwAAAAEAAABXAAAAMXQADlNo\nYXBlc1Rlc3Qub29teHQAClNoYXBlc1" +
       "Rlc3RweABzcgAXcG9seWdsb3QudXRpbC5UeXBlZExpc3Ts\nsjsQji1ztgIA" +
       "A1oACWltbXV0YWJsZUwADGFsbG93ZWRfdHlwZXQAEUxqYXZhL2xhbmcvQ2xh" +
       "c3M7\nTAAMYmFja2luZ19saXN0cQB+AAF4cAB2cgAicG9seWdsb3QudHlwZX" +
       "MuQ29uc3RydWN0b3JJbnN0\nYW5jZRdnPqC4bpcjAgAAeHBzcgAUamF2YS51" +
       "dGlsLkxpbmtlZExpc3QMKVNdSmCIIgMAAHhwdwQA\nAAABc3IANXBvbHlnbG" +
       "90LmV4dC5vb21hdGNoLnR5cGVzLk9PTWF0Y2hDb25zdHJ1Y3Rvckluc3Rh\n" +
       "bmNlAAAAABRAZLYCAAdJAAJpZEkACmp1bmtQYXJhbXNaAAxub0Rpc3BhdGNo" +
       "ZXJMAAhjaGlsZHJl\nbnEAfgABWwAMaXNOYW1lZFBhcmFtdAACW1pMAApwYX" +
       "JhbVR5cGVzcQB+AAFMAAhyZWFsTmFtZXEA\nfgACeHIAK3BvbHlnbG90LmV4" +
       "dC5qbC50eXBlcy5Db25zdHJ1Y3Rvckluc3RhbmNlX2PAoSsMA7LT\n6AIAAH" +
       "hyAClwb2x5Z2xvdC5leHQuamwudHlwZXMuUHJvY2VkdXJlSW5zdGFuY2VfY8" +
       "UGewKJhuVr\nAgAETAAJY29udGFpbmVydAAeTHBvbHlnbG90L3R5cGVzL1Jl" +
       "ZmVyZW5jZVR5cGU7TAAIZXhjVHlw\nZXNxAH4AAUwABWZsYWdzcQB+AARMAA" +
       "tmb3JtYWxUeXBlc3EAfgABeHEAfgAMcQB+ABB4cQB+AA5z\ncQB+ABMBdnIA" +
       "E3BvbHlnbG90LnR5cGVzLlR5cGX1UdGqdcwmTwIAAHhwc3IAE2phdmEudXRp" +
       "bC5B\ncnJheUxpc3R4gdIdmcdhnQMAAUkABHNpemV4cAAAAAB3BAAAAAB4c3" +
       "IAFHBvbHlnbG90LnR5cGVz\nLkZsYWdz2v+28N3GIAMCAAFKAARiaXRzeHAA" +
       "AAAAAAAAAXNxAH4AEwFxAH4AInNxAH4AIwAAAAB3\nBAAAAAB4AAAADgAAAA" +
       "AAc3EAfgAYdwQAAAAAeHBzcgAfamF2YS51dGlsLkNvbGxlY3Rpb25zJEVt\n" +
       "cHR5TGlzdHq4F7Q8p57eAgAAeHB0AA1TaGFwZXNUZXN0JDE0eHNxAH4AEwB2" +
       "cgAccG9seWdsb3Qu\ndHlwZXMuRmllbGRJbnN0YW5jZdRnviDT7YphAgAAeH" +
       "BzcQB+ABh3BAAAAAB4c3EAfgAlAAAAAAAA\nAAFzcQB+ABMAcQB+ACJzcQB+" +
       "ABh3BAAAAAB4c3IAHXBvbHlnbG90LnR5cGVzLkNsYXNzVHlwZSRL\naW5kh1" +
       "jxDIZhxF0CAAB4cgAScG9seWdsb3QudXRpbC5FbnVtsOTezCdsygkCAAFMAA" +
       "RuYW1lcQB+\nAAJ4cHQACXRvcC1sZXZlbHNxAH4AEwBxAH4AInNxAH4AGHcE" +
       "AAAAAHhzcQB+ABMAdnIAHXBvbHln\nbG90LnR5cGVzLk1ldGhvZEluc3Rhbm" +
       "NlXGSFCAkpfOkCAAB4cHNxAH4AGHcEAAAACHNyADBwb2x5\nZ2xvdC5leHQu" +
       "b29tYXRjaC50eXBlcy5PT01hdGNoTWV0aG9kSW5zdGFuY2UAAAAALB2kfwIA" +
       "CFoA\nDmhhc1doZXJlQ2xhdXNlSQACaWRaAAxub0Rpc3BhdGNoZXJMAAVjaG" +
       "lsZHQAH0xwb2x5Z2xvdC90\neXBlcy9NZXRob2RJbnN0YW5jZTtMAAhjaGls" +
       "ZHJlbnEAfgABWwAMaXNOYW1lZFBhcmFtcQB+ABtM\nAApwYXJhbVR5cGVzcQ" +
       "B+AAFMAAhyZWFsTmFtZXEAfgACeHIAJnBvbHlnbG90LmV4dC5qbC50eXBl\n" +
       "cy5NZXRob2RJbnN0YW5jZV9jjFcIyQELZfsCAAJMAARuYW1lcQB+AAJMAApy" +
       "ZXR1cm5UeXBlcQB+\nAAh4cQB+AB1zcQB+AA8AAAASAAAAKgAAADIAAAAycQ" +
       "B+ABF4cQB+AA5zcQB+ABMBcQB+ACJzcQB+\nACMAAAAAdwQAAAAAeHNxAH4A" +
       "JQAAAAAAAAAJc3EAfgAjAAAAAXcEAAAAAXNyACFwb2x5Z2xvdC5l\neHQuam" +
       "wudHlwZXMuQXJyYXlUeXBlX2M9y8fUhq1AHQIABEwABGJhc2VxAH4ACEwABm" +
       "ZpZWxkc3EA\nfgABTAAKaW50ZXJmYWNlc3EAfgABTAAHbWV0aG9kc3EAfgAB" +
       "eHEAfgAKc3EAfgAPAAAAHAAAACIA\nAAAyAAAAMnEAfgAReHhzcgAjcG9seW" +
       "dsb3QuZXh0LmpsLnR5cGVzLlBsYWNlSG9sZGVyX2NK9NZa\nNsi8dAIAAUwA" +
       "BG5hbWVxAH4AAnhwdAAQamF2YS5sYW5nLlN0cmluZ3BwcHh0AARtYWluc3IA" +
       "JXBv\nbHlnbG90LmV4dC5qbC50eXBlcy5QcmltaXRpdmVUeXBlX2PvU+sa9w" +
       "oSxAIAAUwABGtpbmR0ACNM\ncG9seWdsb3QvdHlwZXMvUHJpbWl0aXZlVHlw" +
       "ZSRLaW5kO3hxAH4AC3B4dAAEdm9pZHB4c3IAIXBv\nbHlnbG90LnR5cGVzLl" +
       "ByaW1pdGl2ZVR5cGUkS2luZMQrIax+Ut5iAgAAeHEAfgA1cQB+AFEAAAAA\n" +
       "AQBwc3EAfgAYdwQAAAAAeHVyAAJbWlePIDkUuF3iAgAAeHAAAAABAHNxAH4A" +
       "GHcEAAAAAXEAfgBI\neHEAfgBNc3EAfgA+c3EAfgAPAAAABAAAABEAAAA1AA" +
       "AANXEAfgAReHEAfgAOc3EAfgATAXEAfgAi\nc3EAfgAjAAAAAHcEAAAAAHhz" +
       "cQB+ACUAAAAAAAAAAHNxAH4AIwAAAAB3BAAAAAB4dAAGZG9NYWlu\ncQB+AF" +
       "AAAAAAAgBwc3EAfgAYdwQAAAAAeHVxAH4AVQAAAABzcQB+ABh3BAAAAAB4dA" +
       "AIZG9NYWlu\nJDJzcQB+AD5zcQB+AA8AAAAEAAAAJgAAAEQAAABEcQB+ABF4" +
       "cQB+AA5zcQB+ABMBcQB+ACJzcQB+\nACMAAAAAdwQAAAAAeHEAfgBcc3EAfg" +
       "AjAAAAAXcEAAAAAXNxAH4ASnQADWxpbmVwYWNrLkxpbmV4\ndAAMdGVzdE5h" +
       "bWVkRGVjcQB+AFAAAAAAAwBwc3EAfgAYdwQAAAABc3EAfgA+c3EAfgAPAAAA" +
       "BAAA\nAEYAAABFAAAARXEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAjAA" +
       "AAAHcEAAAAAHhxAH4AXHNx\nAH4AIwAAAAF3BAAAAAFxAH4AaHh0AAx0ZXN0" +
       "TmFtZWREZWNxAH4AUAAAAAAEAHBzcQB+ABh3BAAA\nAAB4dXEAfgBVAAAAAQ" +
       "BzcQB+ABh3BAAAAAFzcgAocG9seWdsb3QuZXh0Lm9vbWF0Y2gudHlwZXMu\n" +
       "UGF0dGVyblR5cGVfYwAAAAAqAsQ4AgAFTAAFZGVjb250ADJMcG9seWdsb3Qv" +
       "ZXh0L29vbWF0Y2gv\ndHlwZXMvRGVjb25zdHJ1Y3Rvckluc3RhbmNlO0wAEW" +
       "RlY29uc3RydWN0b3JUeXBlcQB+AAZbAAxp\nc05hbWVkUGFyYW1xAH4AG0wA" +
       "B3BhdHRlcm5xAH4AAUwAB3Zhck5hbWVxAH4AAnhxAH4AC3NxAH4A\nDwAAAB" +
       "YAAABFAAAARQAAAEVxAH4AEXh4c3IAMHBvbHlnbG90LmV4dC5vb21hdGNoLn" +
       "R5cGVzLkRl\nY29uc3RydWN0b3JJbnN0YW5jZQAAAAAFsX40AgAFSQACaWRM" +
       "AARuYW1lcQB+AAJMAAZvblR5cGVx\nAH4ABkwACnBhcmFtTmFtZXNxAH4AAU" +
       "wACHJlYWxOYW1lcQB+AAJ4cQB+AB1zcQB+AA8AAAAEAAAA\nNQAAAAcAAAAH" +
       "dAAITGluZS5vb214cQB+AGhzcQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAA" +
       "eHNx\nAH4AJQAAAAAAAAABc3EAfgATAXEAfgAic3EAfgAjAAAAAncEAAAAAn" +
       "NxAH4ATnB4dAAGZG91Ymxl\ncHhzcQB+AFJxAH4Ag3EAfgCCeAAAAAF0AA1y" +
       "aWdodEVuZFBvaW50cHNxAH4AIwAAAAJ3BAAAAAJ0\nAAJ4MnQAAnkyeHQAD3" +
       "JpZ2h0RW5kUG9pbnQkMXEAfgBodXEAfgBVAAAAAgAAc3EAfgAYdwQAAAAC\n" +
       "c3EAfgBOcHhxAH4Ag3B4cQB+AIRxAH4AjHh0AAB4dAAOdGVzdE5hbWVkRGVj" +
       "JDR4dXEAfgBVAAAA\nAQBzcQB+ABh3BAAAAAFxAH4AaHh0AA50ZXN0TmFtZW" +
       "REZWMkM3NxAH4APnNxAH4ADwAAAAQAAAAi\nAAAASAAAAEhxAH4AEXhxAH4A" +
       "DnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4cQB+AFxzcQB+\nACMAAA" +
       "ABdwQAAAABc3EAfgBKdAAGQ2lyY2xleHQAD3Rlc3RPdmVybG9hZERlY3EAfg" +
       "BQAAAAAAUA\ncHNxAH4AGHcEAAAAAnNxAH4APnNxAH4ADwAAAAQAAAApAAAA" +
       "SQAAAElxAH4AEXhxAH4ADnNxAH4A\nEwFxAH4AInNxAH4AIwAAAAB3BAAAAA" +
       "B4cQB+AFxzcQB+ACMAAAABdwQAAAABcQB+AJd4dAAPdGVz\ndE92ZXJsb2Fk" +
       "RGVjcQB+AFAAAAAABgBwc3EAfgAYdwQAAAAAeHVxAH4AVQAAAAEAc3EAfgAY" +
       "dwQA\nAAABc3EAfgB1c3EAfgAPAAAAGQAAACgAAABJAAAASXEAfgAReHhzcQ" +
       "B+AHlzcQB+AA8AAAAEAAAA\nJgAAABwAAAAccQB+ABF4cQB+AJdzcQB+ABMB" +
       "cQB+ACJzcQB+ACMAAAAAdwQAAAAAeHNxAH4AJQAA\nAAAAAAABc3EAfgATAX" +
       "EAfgAic3EAfgAjAAAAAXcEAAAAAXNxAH4ASnQABVBvaW50eAAAAAR0AAZD\n" +
       "aXJjbGVwc3EAfgAjAAAAAXcEAAAAAXQABmNlbnRyZXh0AAhDaXJjbGUkNHEA" +
       "fgCXdXEAfgBVAAAA\nAQBzcQB+ABh3BAAAAAFxAH4ArXhxAH4AjXh0ABF0ZX" +
       "N0T3ZlcmxvYWREZWMkNnNxAH4APnNxAH4A\nDwAAAAQAAAAoAAAATAAAAExx" +
       "AH4AEXhxAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4\ncQB+AF" +
       "xzcQB+ACMAAAABdwQAAAABcQB+AJd4dAAPdGVzdE92ZXJsb2FkRGVjcQB+AF" +
       "AAAAAABwBw\nc3EAfgAYdwQAAAAAeHVxAH4AVQAAAAEAc3EAfgAYdwQAAAAB" +
       "c3EAfgB1c3EAfgAPAAAAGQAAACcA\nAABMAAAATHEAfgAReHhzcQB+AHlzcQ" +
       "B+AA8AAAAEAAAAGQAAABsAAAAbcQB+ABF4cQB+AJdzcQB+\nABMBcQB+ACJz" +
       "cQB+ACMAAAAAdwQAAAAAeHNxAH4AJQAAAAAAAAABc3EAfgATAXEAfgAic3EA" +
       "fgAj\nAAAAAHcEAAAAAHgAAAADdAAFU2hhcGVwc3EAfgAjAAAAAHcEAAAAAH" +
       "h0AAdTaGFwZSQzcQB+AJd1\ncQB+AFUAAAAAc3EAfgAYdwQAAAAAeHEAfgCN" +
       "eHQAEXRlc3RPdmVybG9hZERlYyQ3eHVxAH4AVQAA\nAAEAc3EAfgAYdwQAAA" +
       "ABcQB+AJd4dAARdGVzdE92ZXJsb2FkRGVjJDVzcQB+AD5zcQB+AA8AAAAE\n" +
       "AAAAGwAAAFAAAABQcQB+ABF4cQB+AA5zcQB+ABMBcQB+ACJzcQB+ACMAAAAA" +
       "dwQAAAAAeHEAfgBc\nc3EAfgAjAAAAAXcEAAAAAXNxAH4ASnQABVNoYXBleH" +
       "QACXRlc3RTaGFwZXEAfgBQAAAAAAkAcHNx\nAH4AGHcEAAAAAXNxAH4APnNx" +
       "AH4ADwAAAAQAAAAbAAAATwAAAE9xAH4AEXhxAH4ADnNxAH4AEwFx\nAH4AIn" +
       "NxAH4AIwAAAAB3BAAAAAB4cQB+AFxzcQB+ACMAAAABdwQAAAABcQB+ANZ4dA" +
       "AJdGVzdFNo\nYXBlcQB+AFAAAAAACABwc3EAfgAYdwQAAAAAeHVxAH4AVQAA" +
       "AAEAc3EAfgAYdwQAAAABc3EAfgB1\nc3EAfgAPAAAAEwAAABoAAABPAAAAT3" +
       "EAfgAReHhzcQB+AHlzcQB+AA8AAAAEAAAAGQAAAA8AAAAP\ncQB+ABF4cQB+" +
       "ANZzcQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeHNxAH4AJQAAAAAAAAAB" +
       "c3EA\nfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHgAAAABdAAFU2hhcGVwc3" +
       "EAfgAjAAAAAHcEAAAAAHh0\nAAdTaGFwZSQxcQB+ANZ1cQB+AFUAAAAAc3EA" +
       "fgAYdwQAAAAAeHEAfgCNeHQAC3Rlc3RTaGFwZSQ4\neHVxAH4AVQAAAAEAc3" +
       "EAfgAYdwQAAAABcQB+ANZ4dAALdGVzdFNoYXBlJDlzcQB+AD5zcQB+AA8A\n" +
       "AAAEAAAAGgAAAFMAAABTcQB+ABF4cQB+AA5zcQB+ABMBcQB+ACJzcQB+ACMA" +
       "AAAAdwQAAAAAeHEA\nfgBcc3EAfgAjAAAAAXcEAAAAAXEAfgCteHQACG51bG" +
       "xUZXN0cQB+AFAAAAAACwBwc3EAfgAYdwQA\nAAABc3EAfgA+c3EAfgAPAAAA" +
       "BAAAAB4AAABUAAAAVHEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EA\nfgAjAA" +
       "AAAHcEAAAAAHhxAH4AXHNxAH4AIwAAAAF3BAAAAAFzcQB+AEp0AAlDb29yUG" +
       "9pbnR4dAAI\nbnVsbFRlc3RxAH4AUAAAAAAMAHBzcQB+ABh3BAAAAAFzcQB+" +
       "AD5zcQB+AA8AAAAEAAAAFwAAAFIA\nAABScQB+ABF4cQB+AA5zcQB+ABMBcQ" +
       "B+ACJzcQB+ACMAAAAAdwQAAAAAeHEAfgBcc3EAfgAjAAAA\nAXcEAAAAAXNy" +
       "ACBwb2x5Z2xvdC5leHQuamwudHlwZXMuTnVsbFR5cGVfY6ZUaPan5s1BAgAA" +
       "eHEA\nfgALcHh4eHQACG51bGxUZXN0cQB+AFAAAAAACgBwc3EAfgAYdwQAAA" +
       "AAeHVxAH4AVQAAAAEAc3EA\nfgAYdwQAAAABc3IAJnBvbHlnbG90LmV4dC5v" +
       "b21hdGNoLnR5cGVzLlZhbHVlVHlwZV9jAAAAAAQH\njA8CAAJMAA1jb25zdG" +
       "FudFZhbHVldAASTGphdmEvbGFuZy9PYmplY3Q7TAALdHlwZU9mVmFsdWVx\n" +
       "AH4ACHhxAH4AC3NxAH4ADwAAABIAAAAWAAAAUgAAAFJxAH4AEXh4cHEAfgEL" +
       "eHQAC251bGxUZXN0\nJDEweHVxAH4AVQAAAAEAc3EAfgAYdwQAAAABcQB+AQ" +
       "F4dAALbnVsbFRlc3QkMTJ4dXEAfgBVAAAA\nAQBzcQB+ABh3BAAAAAFxAH4A" +
       "rXh0AAtudWxsVGVzdCQxMXEAfgD8c3EAfgA+c3EAfgAPAAAABAAA\nAB4AAA" +
       "BVAAAAVXEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAH" +
       "hxAH4AXHNx\nAH4AIwAAAAF3BAAAAAFzcQB+AEp0AAlSZWN0YW5nbGV4dAAI" +
       "bnVsbFRlc3RxAH4AUAAAAAANAHBz\ncQB+ABh3BAAAAAB4dXEAfgBVAAAAAQ" +
       "BzcQB+ABh3BAAAAAFxAH4BIHh0AAtudWxsVGVzdCQxM3hx\nAH4AEnBwc3EA" +
       "fgBKdAAQamF2YS5sYW5nLk9iamVjdHNxAH4AGHcEAAAAAHh0AAEkc3EAfgAY" +
       "dwQA\nAAAAeA==");
}
