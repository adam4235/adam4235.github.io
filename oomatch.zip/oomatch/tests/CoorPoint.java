class CoorPoint extends Point {
    public CoorPoint(int x, int y) { super(x,y); }
    
    public static String messageFor4$(int m) {
        switch (m) { case 4: return "constructor public CoorPoint(int, int)"; }
        return Point.messageFor1$(m); }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1177598730000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAHAAAAAXQADUNv\nb3JQb2ludC5vb214dAAJQ29vclBvaW" +
       "50cHgAc3IAF3BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7\nEI4tc7YCAANa" +
       "AAlpbW11dGFibGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNz" +
       "O0wA\nDGJhY2tpbmdfbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLk" +
       "NvbnN0cnVjdG9ySW5zdGFu\nY2UXZz6guG6XIwIAAHhwc3IAFGphdmEudXRp" +
       "bC5MaW5rZWRMaXN0DClTXUpgiCIDAAB4cHcEAAAA\nAXNyADVwb2x5Z2xvdC" +
       "5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5j\n" +
       "ZQAAAAAUQGS2AgAGSQACaWRJAApqdW5rUGFyYW1zTAAIY2hpbGRyZW5xAH4A" +
       "AVsADGlzTmFtZWRQ\nYXJhbXQAAltaTAAKcGFyYW1UeXBlc3EAfgABTAAIcm" +
       "VhbE5hbWVxAH4AAnhyACtwb2x5Z2xvdC5l\neHQuamwudHlwZXMuQ29uc3Ry" +
       "dWN0b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgApcG9seWdsb3Qu\nZXh0Lm" +
       "psLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblawIABEwACWNvbn" +
       "RhaW5lcnQA\nHkxwb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VUeXBlO0wACGV4" +
       "Y1R5cGVzcQB+AAFMAAVmbGFnc3EA\nfgAETAALZm9ybWFsVHlwZXNxAH4AAX" +
       "hxAH4ADHNxAH4ADwAAAAgAAAACAAAABgAAAANxAH4AEXhx\nAH4ADnNxAH4A" +
       "EwF2cgATcG9seWdsb3QudHlwZXMuVHlwZfVR0ap1zCZPAgAAeHBzcgATamF2" +
       "YS51\ndGlsLkFycmF5TGlzdHiB0h2Zx2GdAwABSQAEc2l6ZXhwAAAAAHcEAA" +
       "AAAHhzcgAUcG9seWdsb3Qu\ndHlwZXMuRmxhZ3Pa/7bw3cYgAwIAAUoABGJp" +
       "dHN4cAAAAAAAAAABc3EAfgAkAAAAAncEAAAAAnNy\nACVwb2x5Z2xvdC5leH" +
       "QuamwudHlwZXMuUHJpbWl0aXZlVHlwZV9j71PrGvcKEsQCAAFMAARraW5k\n" +
       "dAAjTHBvbHlnbG90L3R5cGVzL1ByaW1pdGl2ZVR5cGUkS2luZDt4cQB+AAtw" +
       "eHQAA2ludHB4c3IA\nIXBvbHlnbG90LnR5cGVzLlByaW1pdGl2ZVR5cGUkS2" +
       "luZMQrIax+Ut5iAgAAeHIAEnBvbHlnbG90\nLnV0aWwuRW51bbDk3swnbMoJ" +
       "AgABTAAEbmFtZXEAfgACeHBxAH4ALHEAfgAreAAAAAQAAAAAc3EA\nfgAYdw" +
       "QAAAAAeHBzcQB+ABh3BAAAAAJxAH4AK3EAfgAreHQAC0Nvb3JQb2ludCQ0eH" +
       "NxAH4AEwB2\ncgAccG9seWdsb3QudHlwZXMuRmllbGRJbnN0YW5jZdRnviDT" +
       "7YphAgAAeHBzcQB+ABh3BAAAAAB4\nc3EAfgAmAAAAAAAAAABzcQB+ABMAcQ" +
       "B+ACNzcQB+ABh3BAAAAAB4c3IAHXBvbHlnbG90LnR5cGVz\nLkNsYXNzVHlw" +
       "ZSRLaW5kh1jxDIZhxF0CAAB4cQB+AC50AAl0b3AtbGV2ZWxzcQB+ABMAcQB+" +
       "ACNz\ncQB+ABh3BAAAAAB4c3EAfgATAHZyAB1wb2x5Z2xvdC50eXBlcy5NZX" +
       "Rob2RJbnN0YW5jZVxkhQgJ\nKXzpAgAAeHBzcQB+ABh3BAAAAAB4cQB+ABJw" +
       "cHNyACNwb2x5Z2xvdC5leHQuamwudHlwZXMuUGxh\nY2VIb2xkZXJfY0r01l" +
       "o2yLx0AgABTAAEbmFtZXEAfgACeHB0AAVQb2ludHNxAH4AGHcEAAAAAHh0\n" +
       "AAEkc3EAfgAYdwQAAAAAeA==");
}
