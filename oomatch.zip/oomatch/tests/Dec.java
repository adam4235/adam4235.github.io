public class Dec {
    public static Object[] DD$1(D d) {
        int x;
        x = d.x;
        if (true) return new Object[] { new Integer(x), d }; else return null;
    }
    
    public Dec() { super(); }
    
    public static String messageFor1$(int m) {
        switch (m) { case 2: return "constructor public Dec()"; }
        return ""; }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1184694835000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAABwAAAAEAAAAGAAAAAXQAB0Rl\nYy5vb214dAADRGVjcHgAc3IAF3BvbH" +
       "lnbG90LnV0aWwuVHlwZWRMaXN07LI7EI4tc7YCAANaAAlp\nbW11dGFibGVM" +
       "AAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNzO0wADGJhY2tpbmdf" +
       "bGlz\ndHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLkNvbnN0cnVjdG9ySW" +
       "5zdGFuY2UXZz6guG6XIwIA\nAHhwc3IAFGphdmEudXRpbC5MaW5rZWRMaXN0" +
       "DClTXUpgiCIDAAB4cHcEAAAAAXNyADVwb2x5Z2xv\ndC5leHQub29tYXRjaC" +
       "50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5jZQAAAAAUQGS2AgAH\n" +
       "SQACaWRJAApqdW5rUGFyYW1zWgAMbm9EaXNwYXRjaGVyTAAIY2hpbGRyZW5x" +
       "AH4AAVsADGlzTmFt\nZWRQYXJhbXQAAltaTAAKcGFyYW1UeXBlc3EAfgABTA" +
       "AIcmVhbE5hbWVxAH4AAnhyACtwb2x5Z2xv\ndC5leHQuamwudHlwZXMuQ29u" +
       "c3RydWN0b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgApcG9seWds\nb3QuZX" +
       "h0LmpsLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblawIABEwACW" +
       "NvbnRhaW5l\ncnQAHkxwb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VUeXBlO0wA" +
       "CGV4Y1R5cGVzcQB+AAFMAAVmbGFn\nc3EAfgAETAALZm9ybWFsVHlwZXNxAH" +
       "4AAXhxAH4ADHEAfgAQeHEAfgAOc3EAfgATAXZyABNwb2x5\nZ2xvdC50eXBl" +
       "cy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHS" +
       "HZnH\nYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2x5Z2xvdC50eX" +
       "Blcy5GbGFnc9r/tvDdxiAD\nAgABSgAEYml0c3hwAAAAAAAAAAFzcQB+ABMB" +
       "cQB+ACJzcQB+ACMAAAAAdwQAAAAAeAAAAAIAAAAA\nAHNxAH4AGHcEAAAAAH" +
       "hwc3IAH2phdmEudXRpbC5Db2xsZWN0aW9ucyRFbXB0eUxpc3R6uBe0PKee\n" +
       "3gIAAHhwdAAFRGVjJDJ4c3EAfgATAHZyABxwb2x5Z2xvdC50eXBlcy5GaWVs" +
       "ZEluc3RhbmNl1Ge+\nINPtimECAAB4cHNxAH4AGHcEAAAAAHhzcQB+ACUAAA" +
       "AAAAAAAXNxAH4AEwBxAH4AInNxAH4AGHcE\nAAAAAHhzcgAdcG9seWdsb3Qu" +
       "dHlwZXMuQ2xhc3NUeXBlJEtpbmSHWPEMhmHEXQIAAHhyABJwb2x5\nZ2xvdC" +
       "51dGlsLkVudW2w5N7MJ2zKCQIAAUwABG5hbWVxAH4AAnhwdAAJdG9wLWxldm" +
       "Vsc3EAfgAT\nAHEAfgAic3EAfgAYdwQAAAAAeHNxAH4AEwB2cgAdcG9seWds" +
       "b3QudHlwZXMuTWV0aG9kSW5zdGFu\nY2VcZIUICSl86QIAAHhwc3EAfgAYdw" +
       "QAAAAAeHEAfgAScHBzcgAjcG9seWdsb3QuZXh0LmpsLnR5\ncGVzLlBsYWNl" +
       "SG9sZGVyX2NK9NZaNsi8dAIAAUwABG5hbWVxAH4AAnhwdAAQamF2YS5sYW5n" +
       "Lk9i\namVjdHNxAH4AGHcEAAAAAXNyADBwb2x5Z2xvdC5leHQub29tYXRjaC" +
       "50eXBlcy5EZWNvbnN0cnVj\ndG9ySW5zdGFuY2UAAAAABbF+NAIABUkAAmlk" +
       "TAAEbmFtZXEAfgACTAAGb25UeXBlcQB+AAZMAApw\nYXJhbU5hbWVzcQB+AA" +
       "FMAAhyZWFsTmFtZXEAfgACeHEAfgAdc3EAfgAPAAAABAAAABsAAAACAAAA\n" +
       "AnEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHhzcQB+" +
       "ACUAAAAAAAAAAXNx\nAH4AEwFxAH4AInNxAH4AIwAAAAF3BAAAAAFzcgAlcG" +
       "9seWdsb3QuZXh0LmpsLnR5cGVzLlByaW1p\ndGl2ZVR5cGVfY+9T6xr3ChLE" +
       "AgABTAAEa2luZHQAI0xwb2x5Z2xvdC90eXBlcy9QcmltaXRpdmVU\neXBlJE" +
       "tpbmQ7eHEAfgALcHh0AANpbnRweHNyACFwb2x5Z2xvdC50eXBlcy5QcmltaX" +
       "RpdmVUeXBl\nJEtpbmTEKyGsflLeYgIAAHhxAH4ANXEAfgBNeAAAAAF0AAJE" +
       "RHNxAH4APnQAAURzcQB+ACMAAAAB\ndwQAAAABdAABeHh0AARERCQxeHQAAS" +
       "RzcQB+ABh3BAAAAAB4");
}
