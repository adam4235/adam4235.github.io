public class Point {
    public int x;
    
    public int y;
    
    public Point(int x, int y) {
        super();
        this.x = x;
        this.y = y;
    }
    
    public Object[] Point$2() {
        int y;
        int x;
        x = this.x;
        y = this.y;
        if (true) return new Object[] { new Integer(x), new Integer(y) }; else return null;
    }
    
    public Point(int x) {
        super();
        this.x = x;
        y = 0;
    }
    
    public Object[] Point$4() {
        int x;
        x = this.x;
        if (true) return new Object[] { new Integer(x) }; else return null;
    }
    
    public static final void f$5() {  }
    
    public static void f() {
        int methodChosen = 0;
        {  }
        {
            {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(5) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class Point.\n");
                    methodChosen = 5;
                }
            }
            switch (methodChosen) {
                case 5:
                    f$5();
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 5: return "method public static void f()"; case 1: return "constructor public Point(int, int)"; case 3:
                return "constructor public Point(int)";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1177681932000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAABwAAAAEAAAATAAAAAXQACVBv\naW50Lm9vbXh0AAVQb2ludHB4AHNyAB" +
       "dwb2x5Z2xvdC51dGlsLlR5cGVkTGlzdOyyOxCOLXO2AgAD\nWgAJaW1tdXRh" +
       "YmxlTAAMYWxsb3dlZF90eXBldAARTGphdmEvbGFuZy9DbGFzcztMAAxiYWNr" +
       "aW5n\nX2xpc3RxAH4AAXhwAHZyACJwb2x5Z2xvdC50eXBlcy5Db25zdHJ1Y3" +
       "Rvckluc3RhbmNlF2c+oLhu\nlyMCAAB4cHNyABRqYXZhLnV0aWwuTGlua2Vk" +
       "TGlzdAwpU11KYIgiAwAAeHB3BAAAAAJzcgA1cG9s\neWdsb3QuZXh0Lm9vbW" +
       "F0Y2gudHlwZXMuT09NYXRjaENvbnN0cnVjdG9ySW5zdGFuY2UAAAAAFEBk\n" +
       "tgIABkkAAmlkSQAKanVua1BhcmFtc0wACGNoaWxkcmVucQB+AAFbAAxpc05h" +
       "bWVkUGFyYW10AAJb\nWkwACnBhcmFtVHlwZXNxAH4AAUwACHJlYWxOYW1lcQ" +
       "B+AAJ4cgArcG9seWdsb3QuZXh0LmpsLnR5\ncGVzLkNvbnN0cnVjdG9ySW5z" +
       "dGFuY2VfY8ChKwwDstPoAgAAeHIAKXBvbHlnbG90LmV4dC5qbC50\neXBlcy" +
       "5Qcm9jZWR1cmVJbnN0YW5jZV9jxQZ7AomG5WsCAARMAAljb250YWluZXJ0AB" +
       "5McG9seWds\nb3QvdHlwZXMvUmVmZXJlbmNlVHlwZTtMAAhleGNUeXBlc3EA" +
       "fgABTAAFZmxhZ3NxAH4ABEwAC2Zv\ncm1hbFR5cGVzcQB+AAF4cQB+AAxzcQ" +
       "B+AA8AAAALAAAAHwAAAAUAAAAEcQB+ABF4cQB+AA5zcQB+\nABMBdnIAE3Bv" +
       "bHlnbG90LnR5cGVzLlR5cGX1UdGqdcwmTwIAAHhwc3IAE2phdmEudXRpbC5B" +
       "cnJh\neUxpc3R4gdIdmcdhnQMAAUkABHNpemV4cAAAAAB3BAAAAAB4c3IAFH" +
       "BvbHlnbG90LnR5cGVzLkZs\nYWdz2v+28N3GIAMCAAFKAARiaXRzeHAAAAAA" +
       "AAAAAXNxAH4AJAAAAAJ3BAAAAAJzcgAlcG9seWds\nb3QuZXh0LmpsLnR5cG" +
       "VzLlByaW1pdGl2ZVR5cGVfY+9T6xr3ChLEAgABTAAEa2luZHQAI0xwb2x5\n" +
       "Z2xvdC90eXBlcy9QcmltaXRpdmVUeXBlJEtpbmQ7eHEAfgALcHh0AANpbnRw" +
       "eHNyACFwb2x5Z2xv\ndC50eXBlcy5QcmltaXRpdmVUeXBlJEtpbmTEKyGsfl" +
       "LeYgIAAHhyABJwb2x5Z2xvdC51dGlsLkVu\ndW2w5N7MJ2zKCQIAAUwABG5h" +
       "bWVxAH4AAnhwcQB+ACxxAH4AK3gAAAABAAAAAHNxAH4AGHcEAAAA\nAHhwc3" +
       "EAfgAYdwQAAAACcQB+ACtxAH4AK3h0AAdQb2ludCQxc3EAfgAac3EAfgAPAA" +
       "AACwAAAC4A\nAAAMAAAADHEAfgAReHEAfgAOc3EAfgATAXEAfgAjc3EAfgAk" +
       "AAAAAHcEAAAAAHhxAH4AJ3NxAH4A\nJAAAAAF3BAAAAAFxAH4AK3gAAAADAA" +
       "AAAHNxAH4AGHcEAAAAAHhwc3EAfgAYdwQAAAABcQB+ACt4\ndAAHUG9pbnQk" +
       "M3hzcQB+ABMAdnIAHHBvbHlnbG90LnR5cGVzLkZpZWxkSW5zdGFuY2XUZ74g" +
       "0+2K\nYQIAAHhwc3EAfgAYdwQAAAACc3IAJXBvbHlnbG90LmV4dC5qbC50eX" +
       "Blcy5GaWVsZEluc3RhbmNl\nX2ORwPlzqvuJ+wIAAUwACWNvbnRhaW5lcnEA" +
       "fgAeeHIAI3BvbHlnbG90LmV4dC5qbC50eXBlcy5W\nYXJJbnN0YW5jZV9jnw" +
       "NblT1G3McCAAVaAAppc0NvbnN0YW50TAANY29uc3RhbnRWYWx1ZXQAEkxq\n" +
       "YXZhL2xhbmcvT2JqZWN0O0wABWZsYWdzcQB+AARMAARuYW1lcQB+AAJMAAR0" +
       "eXBlcQB+AAh4cQB+\nAAxzcQB+AA8AAAALAAAAFAAAAAMAAAADcQB+ABF4AH" +
       "BxAH4AJ3QAAXhxAH4AK3EAfgAOc3EAfgA/\nc3EAfgAPAAAACwAAABQAAAAD" +
       "AAAAA3EAfgAReABwcQB+ACd0AAF5cQB+ACtxAH4ADnhxAH4AJ3Nx\nAH4AEw" +
       "BxAH4AI3NxAH4AGHcEAAAAAHhzcgAdcG9seWdsb3QudHlwZXMuQ2xhc3NUeX" +
       "BlJEtpbmSH\nWPEMhmHEXQIAAHhxAH4ALnQACXRvcC1sZXZlbHNxAH4AEwBx" +
       "AH4AI3NxAH4AGHcEAAAAAHhzcQB+\nABMAdnIAHXBvbHlnbG90LnR5cGVzLk" +
       "1ldGhvZEluc3RhbmNlXGSFCAkpfOkCAAB4cHNxAH4AGHcE\nAAAAAXNyADBw" +
       "b2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoTWV0aG9kSW5zdGFu" +
       "Y2UA\nAAAALB2kfwIAB1oADmhhc1doZXJlQ2xhdXNlSQACaWRMAAVjaGlsZH" +
       "QAH0xwb2x5Z2xvdC90eXBl\ncy9NZXRob2RJbnN0YW5jZTtMAAhjaGlsZHJl" +
       "bnEAfgABWwAMaXNOYW1lZFBhcmFtcQB+ABtMAApw\nYXJhbVR5cGVzcQB+AA" +
       "FMAAhyZWFsTmFtZXEAfgACeHIAJnBvbHlnbG90LmV4dC5qbC50eXBlcy5N\n" +
       "ZXRob2RJbnN0YW5jZV9jjFcIyQELZfsCAAJMAARuYW1lcQB+AAJMAApyZXR1" +
       "cm5UeXBlcQB+AAh4\ncQB+AB1zcQB+AA8AAAASAAAAGgAAABIAAAAScQB+AB" +
       "F4cQB+AA5zcQB+ABMBcQB+ACNzcQB+ACQA\nAAAAdwQAAAAAeHNxAH4AJgAA" +
       "AAAAAAAJc3EAfgAkAAAAAHcEAAAAAHh0AAFmc3EAfgApcHh0AAR2\nb2lkcH" +
       "hzcQB+AC1xAH4AXgAAAAAFcHNxAH4AGHcEAAAAAHh1cgACW1pXjyA5FLhd4g" +
       "IAAHhwAAAA\nAHNxAH4AGHcEAAAAAHh0AANmJDV4cQB+ABJwcHNyACNwb2x5" +
       "Z2xvdC5leHQuamwudHlwZXMuUGxh\nY2VIb2xkZXJfY0r01lo2yLx0AgABTA" +
       "AEbmFtZXEAfgACeHB0ABBqYXZhLmxhbmcuT2JqZWN0c3EA\nfgAYdwQAAAAC" +
       "c3IAMHBvbHlnbG90LmV4dC5vb21hdGNoLnR5cGVzLkRlY29uc3RydWN0b3JJ" +
       "bnN0\nYW5jZQAAAAAFsX40AgAFSQACaWRMAARuYW1lcQB+AAJMAAZvblR5cG" +
       "VxAH4ABkwACnBhcmFtTmFt\nZXNxAH4AAUwACHJlYWxOYW1lcQB+AAJ4cQB+" +
       "AB1zcQB+AA8AAAAEAAAAJQAAAAYAAAAGcQB+ABF4\ncQB+AA5zcQB+ABMBcQ" +
       "B+ACNzcQB+ACQAAAAAdwQAAAAAeHNxAH4AJgAAAAAAAAABc3EAfgATAXEA\n" +
       "fgAjc3EAfgAkAAAAAncEAAAAAnEAfgArcQB+ACt4AAAAAnQABVBvaW50cHNx" +
       "AH4AJAAAAAJ3BAAA\nAAJ0AAF4dAABeXh0AAdQb2ludCQyc3EAfgBpc3EAfg" +
       "APAAAABAAAAB4AAAANAAAADXEAfgAReHEA\nfgAOc3EAfgATAXEAfgAjc3EA" +
       "fgAkAAAAAHcEAAAAAHhzcQB+ACYAAAAAAAAAAXNxAH4AEwFxAH4A\nI3NxAH" +
       "4AJAAAAAF3BAAAAAFxAH4AK3gAAAAEdAAFUG9pbnRwc3EAfgAkAAAAAXcEAA" +
       "AAAXQAAXh4\ndAAHUG9pbnQkNHh0AAEkc3EAfgAYdwQAAAAAeA==");
}
