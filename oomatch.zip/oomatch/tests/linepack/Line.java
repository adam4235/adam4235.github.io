package linepack;

public class Line {
    public Object[] rightEndPoint$1() {
        double y2;
        double x2;
        x2 = this.x2;
        y2 = this.y2;
        if (true) return new Object[] { new Double(x2), new Double(y2) }; else return null;
    }
    
    public Object[] rightEndPoint$2() {
        double y2;
        float x2;
        x2 = (float) this.x2;
        y2 = this.y2;
        if (true) return new Object[] { new Float(x2), new Double(y2) }; else return null;
    }
    
    public Object[] rightEndPoint$3() {
        float y2;
        double x2;
        x2 = this.x2;
        y2 = (float) this.y2;
        if (true) return new Object[] { new Double(x2), new Float(y2) }; else return null;
    }
    
    protected double x1;
    
    protected double y1;
    
    protected double x2;
    
    protected double y2;
    
    public Line(double x1, double y1, double x2, double y2) {
        super();
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }
    
    public Object[] Line$5() {
        double y2;
        double x2;
        double y1;
        double x1;
        x1 = this.x1;
        y1 = this.y1;
        x2 = this.x2;
        y2 = this.y2;
        if (true) return new Object[] { new Double(x1), new Double(y1), new Double(x2), new Double(y2) }; else
            return null;
    }
    
    public static String messageFor1$(int m) {
        switch (m) { case 4: return ("constructor public linepack.Line(double, double, double, dou" + "ble)"); }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1177697310000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAABwAAAAEAAAAZAAAAA3QACExp\nbmUub29teHQADWxpbmVwYWNrLkxpbm" +
       "VweABzcgAXcG9seWdsb3QudXRpbC5UeXBlZExpc3TssjsQ\nji1ztgIAA1oA" +
       "CWltbXV0YWJsZUwADGFsbG93ZWRfdHlwZXQAEUxqYXZhL2xhbmcvQ2xhc3M7" +
       "TAAM\nYmFja2luZ19saXN0cQB+AAF4cAB2cgAicG9seWdsb3QudHlwZXMuQ2" +
       "9uc3RydWN0b3JJbnN0YW5j\nZRdnPqC4bpcjAgAAeHBzcgAUamF2YS51dGls" +
       "LkxpbmtlZExpc3QMKVNdSmCIIgMAAHhwdwQAAAAB\nc3IANXBvbHlnbG90Lm" +
       "V4dC5vb21hdGNoLnR5cGVzLk9PTWF0Y2hDb25zdHJ1Y3Rvckluc3RhbmNl\n" +
       "AAAAABRAZLYCAAZJAAJpZEkACmp1bmtQYXJhbXNMAAhjaGlsZHJlbnEAfgAB" +
       "WwAMaXNOYW1lZFBh\ncmFtdAACW1pMAApwYXJhbVR5cGVzcQB+AAFMAAhyZW" +
       "FsTmFtZXEAfgACeHIAK3BvbHlnbG90LmV4\ndC5qbC50eXBlcy5Db25zdHJ1" +
       "Y3Rvckluc3RhbmNlX2PAoSsMA7LT6AIAAHhyAClwb2x5Z2xvdC5l\neHQuam" +
       "wudHlwZXMuUHJvY2VkdXJlSW5zdGFuY2VfY8UGewKJhuVrAgAETAAJY29udG" +
       "FpbmVydAAe\nTHBvbHlnbG90L3R5cGVzL1JlZmVyZW5jZVR5cGU7TAAIZXhj" +
       "VHlwZXNxAH4AAUwABWZsYWdzcQB+\nAARMAAtmb3JtYWxUeXBlc3EAfgABeH" +
       "EAfgAMc3EAfgAPAAAACwAAAAUAAAAGAAAABHEAfgAReHEA\nfgAOc3EAfgAT" +
       "AXZyABNwb2x5Z2xvdC50eXBlcy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZh" +
       "LnV0\naWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAA" +
       "AAeHNyABRwb2x5Z2xvdC50\neXBlcy5GbGFnc9r/tvDdxiADAgABSgAEYml0" +
       "c3hwAAAAAAAAAAFzcQB+ACQAAAAEdwQAAAAEc3IA\nJXBvbHlnbG90LmV4dC" +
       "5qbC50eXBlcy5QcmltaXRpdmVUeXBlX2PvU+sa9woSxAIAAUwABGtpbmR0\n" +
       "ACNMcG9seWdsb3QvdHlwZXMvUHJpbWl0aXZlVHlwZSRLaW5kO3hxAH4AC3B4" +
       "dAAGZG91YmxlcHhz\ncgAhcG9seWdsb3QudHlwZXMuUHJpbWl0aXZlVHlwZS" +
       "RLaW5kxCshrH5S3mICAAB4cgAScG9seWds\nb3QudXRpbC5FbnVtsOTezCds" +
       "ygkCAAFMAARuYW1lcQB+AAJ4cHEAfgAscQB+ACtxAH4AK3EAfgAr\neAAAAA" +
       "QAAAAAc3EAfgAYdwQAAAAAeHBzcQB+ABh3BAAAAARxAH4AK3EAfgArcQB+AC" +
       "txAH4AK3h0\nAAZMaW5lJDR4c3EAfgATAHZyABxwb2x5Z2xvdC50eXBlcy5G" +
       "aWVsZEluc3RhbmNl1Ge+INPtimEC\nAAB4cHNxAH4AGHcEAAAABHNyACVwb2" +
       "x5Z2xvdC5leHQuamwudHlwZXMuRmllbGRJbnN0YW5jZV9j\nkcD5c6r7ifsC" +
       "AAFMAAljb250YWluZXJxAH4AHnhyACNwb2x5Z2xvdC5leHQuamwudHlwZXMu" +
       "VmFy\nSW5zdGFuY2VfY58DW5U9RtzHAgAFWgAKaXNDb25zdGFudEwADWNvbn" +
       "N0YW50VmFsdWV0ABJMamF2\nYS9sYW5nL09iamVjdDtMAAVmbGFnc3EAfgAE" +
       "TAAEbmFtZXEAfgACTAAEdHlwZXEAfgAIeHEAfgAM\ncHgAcHNxAH4AJgAAAA" +
       "AAAAAEdAACeDFxAH4AK3EAfgAOc3EAfgA3cHgAcHEAfgA7dAACeTFxAH4A\n" +
       "K3EAfgAOc3EAfgA3cHgAcHEAfgA7dAACeDJxAH4AK3EAfgAOc3EAfgA3cHgA" +
       "cHEAfgA7dAACeTJx\nAH4AK3EAfgAOeHEAfgAnc3EAfgATAHEAfgAjc3EAfg" +
       "AYdwQAAAAAeHNyAB1wb2x5Z2xvdC50eXBl\ncy5DbGFzc1R5cGUkS2luZIdY" +
       "8QyGYcRdAgAAeHEAfgAudAAJdG9wLWxldmVsc3EAfgATAHEAfgAj\nc3EAfg" +
       "AYdwQAAAAAeHNxAH4AEwB2cgAdcG9seWdsb3QudHlwZXMuTWV0aG9kSW5zdG" +
       "FuY2VcZIUI\nCSl86QIAAHhwc3EAfgAYdwQAAAAAeHQABExpbmVwc3IAH3Bv" +
       "bHlnbG90LmV4dC5qbC50eXBlcy5Q\nYWNrYWdlX2MbClxptmMf0wIAA0wACG" +
       "Z1bGxuYW1lcQB+AAJMAARuYW1lcQB+AAJMAAZwcmVmaXhx\nAH4AB3hxAH4A" +
       "DHB4dAAIbGluZXBhY2txAH4AUXBzcgAjcG9seWdsb3QuZXh0LmpsLnR5cGVz" +
       "LlBs\nYWNlSG9sZGVyX2NK9NZaNsi8dAIAAUwABG5hbWVxAH4AAnhwdAAQam" +
       "F2YS5sYW5nLk9iamVjdHNx\nAH4AGHcEAAAABHNyADBwb2x5Z2xvdC5leHQu" +
       "b29tYXRjaC50eXBlcy5EZWNvbnN0cnVjdG9ySW5z\ndGFuY2UAAAAABbF+NA" +
       "IABUkAAmlkTAAEbmFtZXEAfgACTAAGb25UeXBlcQB+AAZMAApwYXJhbU5h\n" +
       "bWVzcQB+AAFMAAhyZWFsTmFtZXEAfgACeHEAfgAdc3EAfgAPAAAABAAAADUA" +
       "AAAHAAAAB3EAfgAR\neHEAfgAOc3EAfgATAXEAfgAjc3EAfgAkAAAAAHcEAA" +
       "AAAHhzcQB+ACYAAAAAAAAAAXNxAH4AEwFx\nAH4AI3NxAH4AJAAAAAJ3BAAA" +
       "AAJxAH4AK3EAfgAreAAAAAF0AA1yaWdodEVuZFBvaW50cHNxAH4A\nJAAAAA" +
       "J3BAAAAAJ0AAJ4MnQAAnkyeHQAD3JpZ2h0RW5kUG9pbnQkMXNxAH4AVnNxAH" +
       "4ADwAAAAQA\nAAA0AAAADQAAAA1xAH4AEXhxAH4ADnNxAH4AEwFxAH4AI3Nx" +
       "AH4AJAAAAAB3BAAAAAB4c3EAfgAm\nAAAAAAAAAAFzcQB+ABMBcQB+ACNzcQ" +
       "B+ACQAAAACdwQAAAACc3EAfgApcHh0AAVmbG9hdHB4c3EA\nfgAtcQB+AGtx" +
       "AH4AK3gAAAACdAANcmlnaHRFbmRQb2ludHBzcQB+ACQAAAACdwQAAAACdAAC" +
       "eDJ0\nAAJ5Mnh0AA9yaWdodEVuZFBvaW50JDJzcQB+AFZzcQB+AA8AAAAEAA" +
       "AANAAAABMAAAATcQB+ABF4\ncQB+AA5zcQB+ABMBcQB+ACNzcQB+ACQAAAAA" +
       "dwQAAAAAeHNxAH4AJgAAAAAAAAABc3EAfgATAXEA\nfgAjc3EAfgAkAAAAAn" +
       "cEAAAAAnEAfgArcQB+AGp4AAAAA3QADXJpZ2h0RW5kUG9pbnRwc3EAfgAk\n" +
       "AAAAAncEAAAAAnQAAngydAACeTJ4dAAPcmlnaHRFbmRQb2ludCQzc3EAfgBW" +
       "cQB+ACB4cQB+AA5z\ncQB+ABMBcQB+ACNzcQB+ACQAAAAAdwQAAAAAeHNxAH" +
       "4AJgAAAAAAAAABc3EAfgATAXEAfgAjc3EA\nfgAkAAAABHcEAAAABHEAfgAr" +
       "cQB+ACtxAH4AK3EAfgAreAAAAAV0AARMaW5lcHNxAH4AJAAAAAR3\nBAAAAA" +
       "RxAH4APHEAfgA+cQB+AEBxAH4AQnh0AAZMaW5lJDV4dAABJHNxAH4AGHcEAA" +
       "AAAHg=");
}
