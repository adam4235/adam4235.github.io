public class Rect {
    private Point topLeft;
    
    private Point bottomRight;
    
    public Rect(Point topLeft, Point bottomRight) {
        super();
        this.topLeft = topLeft;
        this.bottomRight = bottomRight;
    }
    
    public Object[] Rect$2() {
        Point bottomRight;
        Point topLeft;
        topLeft = this.topLeft;
        bottomRight = this.bottomRight;
        if (true) return new Object[] { topLeft, bottomRight }; else return null;
    }
    
    public static String messageFor1$(int m) {
        switch (m) { case 1: return "constructor public Rect(Point, Point)"; }
        return ""; }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1177681950000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAABwAAAAEAAAANAAAAAXQACFJl\nY3Qub29teHQABFJlY3RweABzcgAXcG" +
       "9seWdsb3QudXRpbC5UeXBlZExpc3TssjsQji1ztgIAA1oA\nCWltbXV0YWJs" +
       "ZUwADGFsbG93ZWRfdHlwZXQAEUxqYXZhL2xhbmcvQ2xhc3M7TAAMYmFja2lu" +
       "Z19s\naXN0cQB+AAF4cAB2cgAicG9seWdsb3QudHlwZXMuQ29uc3RydWN0b3" +
       "JJbnN0YW5jZRdnPqC4bpcj\nAgAAeHBzcgAUamF2YS51dGlsLkxpbmtlZExp" +
       "c3QMKVNdSmCIIgMAAHhwdwQAAAABc3IANXBvbHln\nbG90LmV4dC5vb21hdG" +
       "NoLnR5cGVzLk9PTWF0Y2hDb25zdHJ1Y3Rvckluc3RhbmNlAAAAABRAZLYC\n" +
       "AAZJAAJpZEkACmp1bmtQYXJhbXNMAAhjaGlsZHJlbnEAfgABWwAMaXNOYW1l" +
       "ZFBhcmFtdAACW1pM\nAApwYXJhbVR5cGVzcQB+AAFMAAhyZWFsTmFtZXEAfg" +
       "ACeHIAK3BvbHlnbG90LmV4dC5qbC50eXBl\ncy5Db25zdHJ1Y3Rvckluc3Rh" +
       "bmNlX2PAoSsMA7LT6AIAAHhyAClwb2x5Z2xvdC5leHQuamwudHlw\nZXMuUH" +
       "JvY2VkdXJlSW5zdGFuY2VfY8UGewKJhuVrAgAETAAJY29udGFpbmVydAAeTH" +
       "BvbHlnbG90\nL3R5cGVzL1JlZmVyZW5jZVR5cGU7TAAIZXhjVHlwZXNxAH4A" +
       "AUwABWZsYWdzcQB+AARMAAtmb3Jt\nYWxUeXBlc3EAfgABeHEAfgAMc3EAfg" +
       "APAAAACwAAAAUAAAAGAAAAA3EAfgAReHEAfgAOc3EAfgAT\nAXZyABNwb2x5" +
       "Z2xvdC50eXBlcy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJy" +
       "YXlM\naXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2" +
       "x5Z2xvdC50eXBlcy5GbGFn\nc9r/tvDdxiADAgABSgAEYml0c3hwAAAAAAAA" +
       "AAFzcQB+ACQAAAACdwQAAAACc3IAI3BvbHlnbG90\nLmV4dC5qbC50eXBlcy" +
       "5QbGFjZUhvbGRlcl9jSvTWWjbIvHQCAAFMAARuYW1lcQB+AAJ4cHQABVBv\n" +
       "aW50cQB+ACp4AAAAAQAAAABzcQB+ABh3BAAAAAB4cHNxAH4AGHcEAAAAAnEA" +
       "fgAqcQB+ACp4dAAG\nUmVjdCQxeHNxAH4AEwB2cgAccG9seWdsb3QudHlwZX" +
       "MuRmllbGRJbnN0YW5jZdRnviDT7YphAgAA\neHBzcQB+ABh3BAAAAAJzcgAl" +
       "cG9seWdsb3QuZXh0LmpsLnR5cGVzLkZpZWxkSW5zdGFuY2VfY5HA\n+XOq+4" +
       "n7AgABTAAJY29udGFpbmVycQB+AB54cgAjcG9seWdsb3QuZXh0LmpsLnR5cG" +
       "VzLlZhcklu\nc3RhbmNlX2OfA1uVPUbcxwIABVoACmlzQ29uc3RhbnRMAA1j" +
       "b25zdGFudFZhbHVldAASTGphdmEv\nbGFuZy9PYmplY3Q7TAAFZmxhZ3NxAH" +
       "4ABEwABG5hbWVxAH4AAkwABHR5cGVxAH4ACHhxAH4ADHNx\nAH4ADwAAAAwA" +
       "AAAnAAAAAgAAAAJxAH4AEXgAcHNxAH4AJgAAAAAAAAACdAAHdG9wTGVmdHEA" +
       "fgAq\ncQB+AA5zcQB+ADNzcQB+AA8AAAAMAAAAJwAAAAIAAAACcQB+ABF4AH" +
       "BxAH4AOHQAC2JvdHRvbVJp\nZ2h0cQB+ACpxAH4ADnhxAH4AJ3NxAH4AEwBx" +
       "AH4AI3NxAH4AGHcEAAAAAHhzcgAdcG9seWdsb3Qu\ndHlwZXMuQ2xhc3NUeX" +
       "BlJEtpbmSHWPEMhmHEXQIAAHhyABJwb2x5Z2xvdC51dGlsLkVudW2w5N7M\n" +
       "J2zKCQIAAUwABG5hbWVxAH4AAnhwdAAJdG9wLWxldmVsc3EAfgATAHEAfgAj" +
       "c3EAfgAYdwQAAAAA\neHNxAH4AEwB2cgAdcG9seWdsb3QudHlwZXMuTWV0aG" +
       "9kSW5zdGFuY2VcZIUICSl86QIAAHhwc3EA\nfgAYdwQAAAAAeHEAfgAScHBz" +
       "cQB+ACl0ABBqYXZhLmxhbmcuT2JqZWN0c3EAfgAYdwQAAAABc3IA\nMHBvbH" +
       "lnbG90LmV4dC5vb21hdGNoLnR5cGVzLkRlY29uc3RydWN0b3JJbnN0YW5jZQ" +
       "AAAAAFsX40\nAgAFSQACaWRMAARuYW1lcQB+AAJMAAZvblR5cGVxAH4ABkwA" +
       "CnBhcmFtTmFtZXNxAH4AAUwACHJl\nYWxOYW1lcQB+AAJ4cQB+AB1zcQB+AA" +
       "8AAAAEAAAAOAAAAAcAAAAHcQB+ABF4cQB+AA5zcQB+ABMB\ncQB+ACNzcQB+" +
       "ACQAAAAAdwQAAAAAeHNxAH4AJgAAAAAAAAABc3EAfgATAXEAfgAjc3EAfgAk" +
       "AAAA\nAncEAAAAAnEAfgAqcQB+ACp4AAAAAnQABFJlY3Rwc3EAfgAkAAAAAn" +
       "cEAAAAAnQAB3RvcExlZnR0\nAAtib3R0b21SaWdodHh0AAZSZWN0JDJ4dAAB" +
       "JHNxAH4AGHcEAAAAAHg=");
}
