class D {
    public int x;
    
    public D() { super(); }
    
    public static String messageFor1$(int m) {
        switch (m) { case 1: return "constructor D()"; }
        return ""; }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1184693284000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAADAAAAAXQACk9u\nVGVzdC5vb214dAABRHB4AHNyABdwb2" +
       "x5Z2xvdC51dGlsLlR5cGVkTGlzdOyyOxCOLXO2AgADWgAJ\naW1tdXRhYmxl" +
       "TAAMYWxsb3dlZF90eXBldAARTGphdmEvbGFuZy9DbGFzcztMAAxiYWNraW5n" +
       "X2xp\nc3RxAH4AAXhwAHZyACJwb2x5Z2xvdC50eXBlcy5Db25zdHJ1Y3Rvck" +
       "luc3RhbmNlF2c+oLhulyMC\nAAB4cHNyABRqYXZhLnV0aWwuTGlua2VkTGlz" +
       "dAwpU11KYIgiAwAAeHB3BAAAAAFzcgA1cG9seWds\nb3QuZXh0Lm9vbWF0Y2" +
       "gudHlwZXMuT09NYXRjaENvbnN0cnVjdG9ySW5zdGFuY2UAAAAAFEBktgIA\n" +
       "B0kAAmlkSQAKanVua1BhcmFtc1oADG5vRGlzcGF0Y2hlckwACGNoaWxkcmVu" +
       "cQB+AAFbAAxpc05h\nbWVkUGFyYW10AAJbWkwACnBhcmFtVHlwZXNxAH4AAU" +
       "wACHJlYWxOYW1lcQB+AAJ4cgArcG9seWds\nb3QuZXh0LmpsLnR5cGVzLkNv" +
       "bnN0cnVjdG9ySW5zdGFuY2VfY8ChKwwDstPoAgAAeHIAKXBvbHln\nbG90Lm" +
       "V4dC5qbC50eXBlcy5Qcm9jZWR1cmVJbnN0YW5jZV9jxQZ7AomG5WsCAARMAA" +
       "ljb250YWlu\nZXJ0AB5McG9seWdsb3QvdHlwZXMvUmVmZXJlbmNlVHlwZTtM" +
       "AAhleGNUeXBlc3EAfgABTAAFZmxh\nZ3NxAH4ABEwAC2Zvcm1hbFR5cGVzcQ" +
       "B+AAF4cQB+AAxxAH4AEHhxAH4ADnNxAH4AEwF2cgATcG9s\neWdsb3QudHlw" +
       "ZXMuVHlwZfVR0ap1zCZPAgAAeHBzcgATamF2YS51dGlsLkFycmF5TGlzdHiB" +
       "0h2Z\nx2GdAwABSQAEc2l6ZXhwAAAAAHcEAAAAAHhzcgAUcG9seWdsb3QudH" +
       "lwZXMuRmxhZ3Pa/7bw3cYg\nAwIAAUoABGJpdHN4cAAAAAAAAAAAc3EAfgAT" +
       "AXEAfgAic3EAfgAjAAAAAHcEAAAAAHgAAAABAAAA\nAABzcQB+ABh3BAAAAA" +
       "B4cHNyAB9qYXZhLnV0aWwuQ29sbGVjdGlvbnMkRW1wdHlMaXN0ergXtDyn\n" +
       "nt4CAAB4cHQAA0QkMXhzcQB+ABMAdnIAHHBvbHlnbG90LnR5cGVzLkZpZWxk" +
       "SW5zdGFuY2XUZ74g\n0+2KYQIAAHhwc3EAfgAYdwQAAAABc3IAJXBvbHlnbG" +
       "90LmV4dC5qbC50eXBlcy5GaWVsZEluc3Rh\nbmNlX2ORwPlzqvuJ+wIAAUwA" +
       "CWNvbnRhaW5lcnEAfgAeeHIAI3BvbHlnbG90LmV4dC5qbC50eXBl\ncy5WYX" +
       "JJbnN0YW5jZV9jnwNblT1G3McCAAVaAAppc0NvbnN0YW50TAANY29uc3Rhbn" +
       "RWYWx1ZXQA\nEkxqYXZhL2xhbmcvT2JqZWN0O0wABWZsYWdzcQB+AARMAARu" +
       "YW1lcQB+AAJMAAR0eXBlcQB+AAh4\ncQB+AAxzcQB+AA8AAAALAAAAEQAAAA" +
       "IAAAACcQB+ABF4AHBzcQB+ACUAAAAAAAAAAXQAAXhzcgAl\ncG9seWdsb3Qu" +
       "ZXh0LmpsLnR5cGVzLlByaW1pdGl2ZVR5cGVfY+9T6xr3ChLEAgABTAAEa2lu" +
       "ZHQA\nI0xwb2x5Z2xvdC90eXBlcy9QcmltaXRpdmVUeXBlJEtpbmQ7eHEAfg" +
       "ALcHh0AANpbnRweHNyACFw\nb2x5Z2xvdC50eXBlcy5QcmltaXRpdmVUeXBl" +
       "JEtpbmTEKyGsflLeYgIAAHhyABJwb2x5Z2xvdC51\ndGlsLkVudW2w5N7MJ2" +
       "zKCQIAAUwABG5hbWVxAH4AAnhwcQB+ADtxAH4ADnhxAH4AJnNxAH4AEwBx\n" +
       "AH4AInNxAH4AGHcEAAAAAHhzcgAdcG9seWdsb3QudHlwZXMuQ2xhc3NUeXBl" +
       "JEtpbmSHWPEMhmHE\nXQIAAHhxAH4APXQACXRvcC1sZXZlbHNxAH4AEwBxAH" +
       "4AInNxAH4AGHcEAAAAAHhzcQB+ABMAdnIA\nHXBvbHlnbG90LnR5cGVzLk1l" +
       "dGhvZEluc3RhbmNlXGSFCAkpfOkCAAB4cHNxAH4AGHcEAAAAAHhx\nAH4AEn" +
       "Bwc3IAI3BvbHlnbG90LmV4dC5qbC50eXBlcy5QbGFjZUhvbGRlcl9jSvTWWj" +
       "bIvHQCAAFM\nAARuYW1lcQB+AAJ4cHQAEGphdmEubGFuZy5PYmplY3RzcQB+" +
       "ABh3BAAAAAB4dAABJHNxAH4AGHcE\nAAAAAHg=");
}

public class OnTest {
    final void f$1(D d) {  }
    
    final void f$2(D stmt) {  }
    
    public OnTest() { super(); }
    
    void f(D arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$2$1 = null;
            if (arg1 != null) retVal$2$1 = Dec.DD$1(arg1);
            if (methodChosen != 2) {
                if (arg1 != null && retVal$2$1 != null && ((Integer) retVal$2$1[0]).intValue() == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class OnTest.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 1 && methodChosen != 2) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(1) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class OnTest.\n");
                    methodChosen = 1;
                }
            }
            switch (methodChosen) {
                case 2:
                    f$2(arg1);
                    return;
                case 1:
                    f$1(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 1: return "method  void f(D)"; case 2: return "method  void f(Dec.DD(0))"; case 3:
                return "constructor public OnTest()";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1184693284000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAABwAAAAEAAAAIAAAABXQACk9u\nVGVzdC5vb214dAAGT25UZXN0cHgAc3" +
       "IAF3BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7EI4tc7YC\nAANaAAlpbW11" +
       "dGFibGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNzO0wADGJh" +
       "Y2tp\nbmdfbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLkNvbnN0cn" +
       "VjdG9ySW5zdGFuY2UXZz6g\nuG6XIwIAAHhwc3IAFGphdmEudXRpbC5MaW5r" +
       "ZWRMaXN0DClTXUpgiCIDAAB4cHcEAAAAAXNyADVw\nb2x5Z2xvdC5leHQub2" +
       "9tYXRjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5jZQAAAAAU\n" +
       "QGS2AgAHSQACaWRJAApqdW5rUGFyYW1zWgAMbm9EaXNwYXRjaGVyTAAIY2hp" +
       "bGRyZW5xAH4AAVsA\nDGlzTmFtZWRQYXJhbXQAAltaTAAKcGFyYW1UeXBlc3" +
       "EAfgABTAAIcmVhbE5hbWVxAH4AAnhyACtw\nb2x5Z2xvdC5leHQuamwudHlw" +
       "ZXMuQ29uc3RydWN0b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgAp\ncG9seW" +
       "dsb3QuZXh0LmpsLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblaw" +
       "IABEwACWNv\nbnRhaW5lcnQAHkxwb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VU" +
       "eXBlO0wACGV4Y1R5cGVzcQB+AAFM\nAAVmbGFnc3EAfgAETAALZm9ybWFsVH" +
       "lwZXNxAH4AAXhxAH4ADHEAfgAQeHEAfgAOc3EAfgATAXZy\nABNwb2x5Z2xv" +
       "dC50eXBlcy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJyYXlM" +
       "aXN0\neIHSHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2x5Z2" +
       "xvdC50eXBlcy5GbGFnc9r/\ntvDdxiADAgABSgAEYml0c3hwAAAAAAAAAAFz" +
       "cQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeAAA\nAAMAAAAAAHNxAH4AGH" +
       "cEAAAAAHhwc3IAH2phdmEudXRpbC5Db2xsZWN0aW9ucyRFbXB0eUxpc3R6\n" +
       "uBe0PKee3gIAAHhwdAAIT25UZXN0JDN4c3EAfgATAHZyABxwb2x5Z2xvdC50" +
       "eXBlcy5GaWVsZElu\nc3RhbmNl1Ge+INPtimECAAB4cHNxAH4AGHcEAAAAAH" +
       "hzcQB+ACUAAAAAAAAAAXNxAH4AEwBxAH4A\nInNxAH4AGHcEAAAAAHhzcgAd" +
       "cG9seWdsb3QudHlwZXMuQ2xhc3NUeXBlJEtpbmSHWPEMhmHEXQIA\nAHhyAB" +
       "Jwb2x5Z2xvdC51dGlsLkVudW2w5N7MJ2zKCQIAAUwABG5hbWVxAH4AAnhwdA" +
       "AJdG9wLWxl\ndmVsc3EAfgATAHEAfgAic3EAfgAYdwQAAAAAeHNxAH4AEwB2" +
       "cgAdcG9seWdsb3QudHlwZXMuTWV0\naG9kSW5zdGFuY2VcZIUICSl86QIAAH" +
       "hwc3EAfgAYdwQAAAABc3IAMHBvbHlnbG90LmV4dC5vb21h\ndGNoLnR5cGVz" +
       "Lk9PTWF0Y2hNZXRob2RJbnN0YW5jZQAAAAAsHaR/AgAIWgAOaGFzV2hlcmVD" +
       "bGF1\nc2VJAAJpZFoADG5vRGlzcGF0Y2hlckwABWNoaWxkdAAfTHBvbHlnbG" +
       "90L3R5cGVzL01ldGhvZElu\nc3RhbmNlO0wACGNoaWxkcmVucQB+AAFbAAxp" +
       "c05hbWVkUGFyYW1xAH4AG0wACnBhcmFtVHlwZXNx\nAH4AAUwACHJlYWxOYW" +
       "1lcQB+AAJ4cgAmcG9seWdsb3QuZXh0LmpsLnR5cGVzLk1ldGhvZEluc3Rh\n" +
       "bmNlX2OMVwjJAQtl+wIAAkwABG5hbWVxAH4AAkwACnJldHVyblR5cGVxAH4A" +
       "CHhxAH4AHXNxAH4A\nDwAAAAQAAAAPAAAABgAAAAZxAH4AEXhxAH4ADnNxAH" +
       "4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4\nc3EAfgAlAAAAAAAAAABzcQB+" +
       "ACMAAAABdwQAAAABc3IAI3BvbHlnbG90LmV4dC5qbC50eXBlcy5Q\nbGFjZU" +
       "hvbGRlcl9jSvTWWjbIvHQCAAFMAARuYW1lcQB+AAJ4cHQAAUR4dAABZnNyAC" +
       "Vwb2x5Z2xv\ndC5leHQuamwudHlwZXMuUHJpbWl0aXZlVHlwZV9j71PrGvcK" +
       "EsQCAAFMAARraW5kdAAjTHBvbHln\nbG90L3R5cGVzL1ByaW1pdGl2ZVR5cG" +
       "UkS2luZDt4cQB+AAtweHQABHZvaWRweHNyACFwb2x5Z2xv\ndC50eXBlcy5Q" +
       "cmltaXRpdmVUeXBlJEtpbmTEKyGsflLeYgIAAHhxAH4ANXEAfgBOAAAAAAEA" +
       "cHNx\nAH4AGHcEAAAAAXNxAH4APnNxAH4ADwAAAAQAAAAaAAAABwAAAAdxAH" +
       "4AEXhxAH4ADnNxAH4AEwFx\nAH4AInNxAH4AIwAAAAB3BAAAAAB4cQB+AEVz" +
       "cQB+ACMAAAABdwQAAAABcQB+AEh4dAABZnEAfgBN\nAAAAAAIAcHNxAH4AGH" +
       "cEAAAAAHh1cgACW1pXjyA5FLhd4gIAAHhwAAAAAQBzcQB+ABh3BAAAAAFz\n" +
       "cgAocG9seWdsb3QuZXh0Lm9vbWF0Y2gudHlwZXMuUGF0dGVyblR5cGVfYwAA" +
       "AAAqAsQ4AgAFTAAF\nZGVjb250ADJMcG9seWdsb3QvZXh0L29vbWF0Y2gvdH" +
       "lwZXMvRGVjb25zdHJ1Y3Rvckluc3RhbmNl\nO0wAEWRlY29uc3RydWN0b3JU" +
       "eXBlcQB+AAZbAAxpc05hbWVkUGFyYW1xAH4AG0wAB3BhdHRlcm5x\nAH4AAU" +
       "wAB3Zhck5hbWVxAH4AAnhxAH4AC3NxAH4ADwAAAAsAAAAZAAAABwAAAAdxAH" +
       "4AEXh4c3IA\nMHBvbHlnbG90LmV4dC5vb21hdGNoLnR5cGVzLkRlY29uc3Ry" +
       "dWN0b3JJbnN0YW5jZQAAAAAFsX40\nAgAFSQACaWRMAARuYW1lcQB+AAJMAA" +
       "ZvblR5cGVxAH4ABkwACnBhcmFtTmFtZXNxAH4AAUwACHJl\nYWxOYW1lcQB+" +
       "AAJ4cQB+AB1zcQB+AA8AAAAEAAAAGwAAAAIAAAACdAAHRGVjLm9vbXhzcQB+" +
       "AEd0\nAANEZWNzcQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeHNxAH4AJQ" +
       "AAAAAAAAABc3EAfgATAXEA\nfgAic3EAfgAjAAAAAXcEAAAAAXNxAH4AS3B4" +
       "dAADaW50cHhzcQB+AE9xAH4AbHgAAAABdAACRERx\nAH4ASHNxAH4AIwAAAA" +
       "F3BAAAAAF0AAF4eHQABEREJDFxAH4AZHVxAH4AWQAAAAEAc3EAfgAYdwQA\n" +
       "AAABc3IAJnBvbHlnbG90LmV4dC5vb21hdGNoLnR5cGVzLlZhbHVlVHlwZV9j" +
       "AAAAAAQHjA8CAAJM\nAA1jb25zdGFudFZhbHVldAASTGphdmEvbGFuZy9PYm" +
       "plY3Q7TAALdHlwZU9mVmFsdWVxAH4ACHhx\nAH4AC3NxAH4ADwAAABIAAAAT" +
       "AAAABwAAAAdxAH4AEXh4c3IAEWphdmEubGFuZy5JbnRlZ2VyEuKg\npPeBhz" +
       "gCAAFJAAV2YWx1ZXhyABBqYXZhLmxhbmcuTnVtYmVyhqyVHQuU4IsCAAB4cA" +
       "AAAABxAH4A\na3h0AARzdG10eHQAA2YkMnh1cQB+AFkAAAABAHNxAH4AGHcE" +
       "AAAAAXEAfgBIeHQAA2YkMXhxAH4A\nEnBwc3EAfgBHdAAQamF2YS5sYW5nLk" +
       "9iamVjdHNxAH4AGHcEAAAAAHh0AAEkc3EAfgAYdwQAAAAA\neA==");
}
