class TestInterface implements I {
    public final void f$1(int x) {  }
    
    public TestInterface() { super(); }
    
    public void f(int arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 1) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(1) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class TestInterface.\n");
                    methodChosen = 1;
                }
            }
            switch (methodChosen) {
                case 1:
                    f$1(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) { case 1: return "method public void f(int)"; case 2: return "constructor TestInterface()"; }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1183044453000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAADAAAAAXQAEVRl\nc3RJbnRlcmZhY2Uub29teHQADVRlc3" +
       "RJbnRlcmZhY2VweABzcgAXcG9seWdsb3QudXRpbC5UeXBl\nZExpc3TssjsQ" +
       "ji1ztgIAA1oACWltbXV0YWJsZUwADGFsbG93ZWRfdHlwZXQAEUxqYXZhL2xh" +
       "bmcv\nQ2xhc3M7TAAMYmFja2luZ19saXN0cQB+AAF4cAB2cgAicG9seWdsb3" +
       "QudHlwZXMuQ29uc3RydWN0\nb3JJbnN0YW5jZRdnPqC4bpcjAgAAeHBzcgAU" +
       "amF2YS51dGlsLkxpbmtlZExpc3QMKVNdSmCIIgMA\nAHhwdwQAAAABc3IANX" +
       "BvbHlnbG90LmV4dC5vb21hdGNoLnR5cGVzLk9PTWF0Y2hDb25zdHJ1Y3Rv\n" +
       "ckluc3RhbmNlAAAAABRAZLYCAAZJAAJpZEkACmp1bmtQYXJhbXNMAAhjaGls" +
       "ZHJlbnEAfgABWwAM\naXNOYW1lZFBhcmFtdAACW1pMAApwYXJhbVR5cGVzcQ" +
       "B+AAFMAAhyZWFsTmFtZXEAfgACeHIAK3Bv\nbHlnbG90LmV4dC5qbC50eXBl" +
       "cy5Db25zdHJ1Y3Rvckluc3RhbmNlX2PAoSsMA7LT6AIAAHhyAClw\nb2x5Z2" +
       "xvdC5leHQuamwudHlwZXMuUHJvY2VkdXJlSW5zdGFuY2VfY8UGewKJhuVrAg" +
       "AETAAJY29u\ndGFpbmVydAAeTHBvbHlnbG90L3R5cGVzL1JlZmVyZW5jZVR5" +
       "cGU7TAAIZXhjVHlwZXNxAH4AAUwA\nBWZsYWdzcQB+AARMAAtmb3JtYWxUeX" +
       "Blc3EAfgABeHEAfgAMcQB+ABB4cQB+AA5zcQB+ABMBdnIA\nE3BvbHlnbG90" +
       "LnR5cGVzLlR5cGX1UdGqdcwmTwIAAHhwc3IAE2phdmEudXRpbC5BcnJheUxp" +
       "c3R4\ngdIdmcdhnQMAAUkABHNpemV4cAAAAAB3BAAAAAB4c3IAFHBvbHlnbG" +
       "90LnR5cGVzLkZsYWdz2v+2\n8N3GIAMCAAFKAARiaXRzeHAAAAAAAAAAAHNx" +
       "AH4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4AAAA\nAgAAAABzcQB+ABh3BA" +
       "AAAAB4cHNyAB9qYXZhLnV0aWwuQ29sbGVjdGlvbnMkRW1wdHlMaXN0ergX\n" +
       "tDynnt4CAAB4cHQAD1Rlc3RJbnRlcmZhY2UkMnhzcQB+ABMAdnIAHHBvbHln" +
       "bG90LnR5cGVzLkZp\nZWxkSW5zdGFuY2XUZ74g0+2KYQIAAHhwc3EAfgAYdw" +
       "QAAAAAeHEAfgAmc3EAfgATAHEAfgAic3EA\nfgAYdwQAAAABc3IAI3BvbHln" +
       "bG90LmV4dC5qbC50eXBlcy5QbGFjZUhvbGRlcl9jSvTWWjbIvHQC\nAAFMAA" +
       "RuYW1lcQB+AAJ4cHQAAUl4c3IAHXBvbHlnbG90LnR5cGVzLkNsYXNzVHlwZS" +
       "RLaW5kh1jx\nDIZhxF0CAAB4cgAScG9seWdsb3QudXRpbC5FbnVtsOTezCds" +
       "ygkCAAFMAARuYW1lcQB+AAJ4cHQA\nCXRvcC1sZXZlbHNxAH4AEwBxAH4AIn" +
       "NxAH4AGHcEAAAAAHhzcQB+ABMAdnIAHXBvbHlnbG90LnR5\ncGVzLk1ldGhv" +
       "ZEluc3RhbmNlXGSFCAkpfOkCAAB4cHNxAH4AGHcEAAAAAXNyADBwb2x5Z2xv" +
       "dC5l\neHQub29tYXRjaC50eXBlcy5PT01hdGNoTWV0aG9kSW5zdGFuY2UAAA" +
       "AALB2kfwIAB1oADmhhc1do\nZXJlQ2xhdXNlSQACaWRMAAVjaGlsZHQAH0xw" +
       "b2x5Z2xvdC90eXBlcy9NZXRob2RJbnN0YW5jZTtM\nAAhjaGlsZHJlbnEAfg" +
       "ABWwAMaXNOYW1lZFBhcmFtcQB+ABtMAApwYXJhbVR5cGVzcQB+AAFMAAhy\n" +
       "ZWFsTmFtZXEAfgACeHIAJnBvbHlnbG90LmV4dC5qbC50eXBlcy5NZXRob2RJ" +
       "bnN0YW5jZV9jjFcI\nyQELZfsCAAJMAARuYW1lcQB+AAJMAApyZXR1cm5UeX" +
       "BlcQB+AAh4cQB+AB1zcQB+AA8AAAALAAAA\nGAAAAAIAAAACcQB+ABF4cQB+" +
       "AA5zcQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeHNxAH4AJQAA\nAAAAAA" +
       "ABc3EAfgAjAAAAAXcEAAAAAXNyACVwb2x5Z2xvdC5leHQuamwudHlwZXMuUH" +
       "JpbWl0aXZl\nVHlwZV9j71PrGvcKEsQCAAFMAARraW5kdAAjTHBvbHlnbG90" +
       "L3R5cGVzL1ByaW1pdGl2ZVR5cGUk\nS2luZDt4cQB+AAtweHQAA2ludHB4c3" +
       "IAIXBvbHlnbG90LnR5cGVzLlByaW1pdGl2ZVR5cGUkS2lu\nZMQrIax+Ut5i" +
       "AgAAeHEAfgA3cQB+AEx4dAABZnNxAH4ASXB4dAAEdm9pZHB4c3EAfgBNcQB+" +
       "AFEA\nAAAAAXBzcQB+ABh3BAAAAAB4dXIAAltaV48gORS4XeICAAB4cAAAAA" +
       "EAc3EAfgAYdwQAAAABcQB+\nAEt4dAADZiQxeHEAfgAScHBzcQB+ADN0ABBq" +
       "YXZhLmxhbmcuT2JqZWN0c3EAfgAYdwQAAAAAeHQA\nASRzcQB+ABh3BAAAAA" +
       "B4");
}
