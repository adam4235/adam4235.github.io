interface I {
    void f(int x);
}

