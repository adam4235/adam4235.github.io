class ScreenArea extends Rect {
    public ScreenArea(Point topLeft, Point bottomRight) { super(topLeft,bottomRight); }
    
    public static String messageFor2$(int m) {
        switch (m) { case 2: return "constructor public ScreenArea(Point, Point)"; }
        return Rect.messageFor1$(m); }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1181668214000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAJAAAABXQADFJl\nY3RUZXN0Lm9vbXh0AApTY3JlZW5Bcm" +
       "VhcHgAc3IAF3BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7\nEI4tc7YCAANa" +
       "AAlpbW11dGFibGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNz" +
       "O0wA\nDGJhY2tpbmdfbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLk" +
       "NvbnN0cnVjdG9ySW5zdGFu\nY2UXZz6guG6XIwIAAHhwc3IAFGphdmEudXRp" +
       "bC5MaW5rZWRMaXN0DClTXUpgiCIDAAB4cHcEAAAA\nAXNyADVwb2x5Z2xvdC" +
       "5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5j\n" +
       "ZQAAAAAUQGS2AgAHSQACaWRJAApqdW5rUGFyYW1zWgAMbm9EaXNwYXRjaGVy" +
       "TAAIY2hpbGRyZW5x\nAH4AAVsADGlzTmFtZWRQYXJhbXQAAltaTAAKcGFyYW" +
       "1UeXBlc3EAfgABTAAIcmVhbE5hbWVxAH4A\nAnhyACtwb2x5Z2xvdC5leHQu" +
       "amwudHlwZXMuQ29uc3RydWN0b3JJbnN0YW5jZV9jwKErDAOy0+gC\nAAB4cg" +
       "ApcG9seWdsb3QuZXh0LmpsLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBn" +
       "sCiYblawIA\nBEwACWNvbnRhaW5lcnQAHkxwb2x5Z2xvdC90eXBlcy9SZWZl" +
       "cmVuY2VUeXBlO0wACGV4Y1R5cGVz\ncQB+AAFMAAVmbGFnc3EAfgAETAALZm" +
       "9ybWFsVHlwZXNxAH4AAXhxAH4ADHNxAH4ADwAAAAsAAAAF\nAAAACAAAAAZx" +
       "AH4AEXhxAH4ADnNxAH4AEwF2cgATcG9seWdsb3QudHlwZXMuVHlwZfVR0ap1" +
       "zCZP\nAgAAeHBzcgATamF2YS51dGlsLkFycmF5TGlzdHiB0h2Zx2GdAwABSQ" +
       "AEc2l6ZXhwAAAAAHcEAAAA\nAHhzcgAUcG9seWdsb3QudHlwZXMuRmxhZ3Pa" +
       "/7bw3cYgAwIAAUoABGJpdHN4cAAAAAAAAAABc3EA\nfgAkAAAAAncEAAAAAn" +
       "NyACNwb2x5Z2xvdC5leHQuamwudHlwZXMuUGxhY2VIb2xkZXJfY0r01lo2\n" +
       "yLx0AgABTAAEbmFtZXEAfgACeHB0AAVQb2ludHEAfgAqeAAAAAIAAAAAAHNx" +
       "AH4AGHcEAAAAAHhw\nc3EAfgAYdwQAAAACcQB+ACpxAH4AKnh0AAxTY3JlZW" +
       "5BcmVhJDJ4c3EAfgATAHZyABxwb2x5Z2xv\ndC50eXBlcy5GaWVsZEluc3Rh" +
       "bmNl1Ge+INPtimECAAB4cHNxAH4AGHcEAAAAAHhzcQB+ACYAAAAA\nAAAAAH" +
       "NxAH4AEwBxAH4AI3NxAH4AGHcEAAAAAHhzcgAdcG9seWdsb3QudHlwZXMuQ2" +
       "xhc3NUeXBl\nJEtpbmSHWPEMhmHEXQIAAHhyABJwb2x5Z2xvdC51dGlsLkVu" +
       "dW2w5N7MJ2zKCQIAAUwABG5hbWVx\nAH4AAnhwdAAJdG9wLWxldmVsc3EAfg" +
       "ATAHEAfgAjc3EAfgAYdwQAAAAAeHNxAH4AEwB2cgAdcG9s\neWdsb3QudHlw" +
       "ZXMuTWV0aG9kSW5zdGFuY2VcZIUICSl86QIAAHhwc3EAfgAYdwQAAAAAeHEA" +
       "fgAS\ncHBzcQB+ACl0AARSZWN0c3EAfgAYdwQAAAAAeHQAASRzcQB+ABh3BA" +
       "AAAAB4");
}

class A {
    public Object[] A$1()throws Exception {
        int x;
        x = 0;
        if (true) return new Object[] { new Integer(x) }; else return null;
    }
    
    final void f$2(CoorPoint p) { System.out.println("In A.f"); }
    
    final void h$3(CoorPoint x) {  }
    
    final void h$4() { System.out.println("In A.h(CoorPoint(1, 1))"); }
    
    public A() { super(); }
    
    void f(CoorPoint arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 2) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class A.\n");
                    methodChosen = 2;
                }
            }
            switch (methodChosen) {
                case 2:
                    f$2(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void h(CoorPoint arg1, Class arg2) {
        int methodChosen = 0;
        {
            Object[] retVal$4$1 = null;
            if (arg1 != null) retVal$4$1 = arg1.Point$2();
            if (methodChosen != 4) {
                if (arg1 != null && retVal$4$1 != null && ((Integer) retVal$4$1[0]).intValue() == 1 &&
                      ((Integer) retVal$4$1[1]).intValue() == 1) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(4) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class A.\n");
                    methodChosen = 4;
                }
            }
            switch (methodChosen) {
                case 4:
                    h$4();
                    return;
            }
        }
        {
            if (methodChosen != 3 && methodChosen != 4) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class A.\n");
                    methodChosen = 3;
                }
            }
            switch (methodChosen) {
                case 3:
                    h$3(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 2: return "method  void f(CoorPoint)"; case 3: return "method  void h(CoorPoint)"; case 4:
                return "method final void h(CoorPoint.Point(1, 1))"; case 5: return "constructor A()";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1181668214000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAiAAAAFHQADFJl\nY3RUZXN0Lm9vbXh0AAFBcHgAc3IAF3" +
       "BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7EI4tc7YCAANa\nAAlpbW11dGFi" +
       "bGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNzO0wADGJhY2tp" +
       "bmdf\nbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLkNvbnN0cnVjdG" +
       "9ySW5zdGFuY2UXZz6guG6X\nIwIAAHhwc3IAFGphdmEudXRpbC5MaW5rZWRM" +
       "aXN0DClTXUpgiCIDAAB4cHcEAAAAAXNyADVwb2x5\nZ2xvdC5leHQub29tYX" +
       "RjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5jZQAAAAAUQGS2\n" +
       "AgAHSQACaWRJAApqdW5rUGFyYW1zWgAMbm9EaXNwYXRjaGVyTAAIY2hpbGRy" +
       "ZW5xAH4AAVsADGlz\nTmFtZWRQYXJhbXQAAltaTAAKcGFyYW1UeXBlc3EAfg" +
       "ABTAAIcmVhbE5hbWVxAH4AAnhyACtwb2x5\nZ2xvdC5leHQuamwudHlwZXMu" +
       "Q29uc3RydWN0b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgApcG9s\neWdsb3" +
       "QuZXh0LmpsLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblawIABE" +
       "wACWNvbnRh\naW5lcnQAHkxwb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VUeXBl" +
       "O0wACGV4Y1R5cGVzcQB+AAFMAAVm\nbGFnc3EAfgAETAALZm9ybWFsVHlwZX" +
       "NxAH4AAXhxAH4ADHEAfgAQeHEAfgAOc3EAfgATAXZyABNw\nb2x5Z2xvdC50" +
       "eXBlcy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJyYXlMaXN0" +
       "eIHS\nHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2x5Z2xvdC" +
       "50eXBlcy5GbGFnc9r/tvDd\nxiADAgABSgAEYml0c3hwAAAAAAAAAABzcQB+" +
       "ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeAAAAAUA\nAAAAAHNxAH4AGHcEAA" +
       "AAAHhwc3IAH2phdmEudXRpbC5Db2xsZWN0aW9ucyRFbXB0eUxpc3R6uBe0\n" +
       "PKee3gIAAHhwdAADQSQ1eHNxAH4AEwB2cgAccG9seWdsb3QudHlwZXMuRmll" +
       "bGRJbnN0YW5jZdRn\nviDT7YphAgAAeHBzcQB+ABh3BAAAAAB4cQB+ACZzcQ" +
       "B+ABMAcQB+ACJzcQB+ABh3BAAAAAB4c3IA\nHXBvbHlnbG90LnR5cGVzLkNs" +
       "YXNzVHlwZSRLaW5kh1jxDIZhxF0CAAB4cgAScG9seWdsb3QudXRp\nbC5Fbn" +
       "VtsOTezCdsygkCAAFMAARuYW1lcQB+AAJ4cHQACXRvcC1sZXZlbHNxAH4AEw" +
       "BxAH4AInNx\nAH4AGHcEAAAAAHhzcQB+ABMAdnIAHXBvbHlnbG90LnR5cGVz" +
       "Lk1ldGhvZEluc3RhbmNlXGSFCAkp\nfOkCAAB4cHNxAH4AGHcEAAAAAnNyAD" +
       "Bwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNo\nTWV0aG9kSW5z" +
       "dGFuY2UAAAAALB2kfwIACFoADmhhc1doZXJlQ2xhdXNlSQACaWRaAAxub0Rp" +
       "c3Bh\ndGNoZXJMAAVjaGlsZHQAH0xwb2x5Z2xvdC90eXBlcy9NZXRob2RJbn" +
       "N0YW5jZTtMAAhjaGlsZHJl\nbnEAfgABWwAMaXNOYW1lZFBhcmFtcQB+ABtM" +
       "AApwYXJhbVR5cGVzcQB+AAFMAAhyZWFsTmFtZXEA\nfgACeHIAJnBvbHlnbG" +
       "90LmV4dC5qbC50eXBlcy5NZXRob2RJbnN0YW5jZV9jjFcIyQELZfsCAAJM\n" +
       "AARuYW1lcQB+AAJMAApyZXR1cm5UeXBlcQB+AAh4cQB+AB1zcQB+AA8AAAAE" +
       "AAAAFwAAABsAAAAb\ncQB+ABF4cQB+AA5zcQB+ABMBcQB+ACJzcQB+ACMAAA" +
       "AAdwQAAAAAeHEAfgAmc3EAfgAjAAAAAXcE\nAAAAAXNyACNwb2x5Z2xvdC5l" +
       "eHQuamwudHlwZXMuUGxhY2VIb2xkZXJfY0r01lo2yLx0AgABTAAE\nbmFtZX" +
       "EAfgACeHB0AAlDb29yUG9pbnR4dAABZnNyACVwb2x5Z2xvdC5leHQuamwudH" +
       "lwZXMuUHJp\nbWl0aXZlVHlwZV9j71PrGvcKEsQCAAFMAARraW5kdAAjTHBv" +
       "bHlnbG90L3R5cGVzL1ByaW1pdGl2\nZVR5cGUkS2luZDt4cQB+AAtweHQABH" +
       "ZvaWRweHNyACFwb2x5Z2xvdC50eXBlcy5QcmltaXRpdmVU\neXBlJEtpbmTE" +
       "KyGsflLeYgIAAHhxAH4ANHEAfgBMAAAAAAIAcHNxAH4AGHcEAAAAAHh1cgAC" +
       "W1pX\njyA5FLhd4gIAAHhwAAAAAQBzcQB+ABh3BAAAAAFxAH4ARnh0AANmJD" +
       "JzcQB+AD1zcQB+AA8AAAAE\nAAAAFwAAAB4AAAAecQB+ABF4cQB+AA5zcQB+" +
       "ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeHEAfgAm\nc3EAfgAjAAAAAXcEAA" +
       "AAAXEAfgBGeHQAAWhxAH4ASwAAAAADAHBzcQB+ABh3BAAAAAFzcQB+AD1z\n" +
       "cQB+AA8AAAAKAAAAIQAAAB8AAAAfcQB+ABF4cQB+AA5zcQB+ABMBcQB+ACJz" +
       "cQB+ACMAAAAAdwQA\nAAAAeHNxAH4AJQAAAAAAAAAQc3EAfgAjAAAAAXcEAA" +
       "AAAXEAfgBGeHQAAWhxAH4ASwAAAAAEAHBz\ncQB+ABh3BAAAAAB4dXEAfgBQ" +
       "AAAAAQBzcQB+ABh3BAAAAAFzcgAocG9seWdsb3QuZXh0Lm9vbWF0\nY2gudH" +
       "lwZXMuUGF0dGVyblR5cGVfYwAAAAAqAsQ4AgAFTAAFZGVjb250ADJMcG9seW" +
       "dsb3QvZXh0\nL29vbWF0Y2gvdHlwZXMvRGVjb25zdHJ1Y3Rvckluc3RhbmNl" +
       "O0wAEWRlY29uc3RydWN0b3JUeXBl\ncQB+AAZbAAxpc05hbWVkUGFyYW1xAH" +
       "4AG0wAB3BhdHRlcm5xAH4AAUwAB3Zhck5hbWVxAH4AAnhx\nAH4AC3NxAH4A" +
       "DwAAABEAAAAgAAAAHwAAAB9xAH4AEXh4c3IAMHBvbHlnbG90LmV4dC5vb21h" +
       "dGNo\nLnR5cGVzLkRlY29uc3RydWN0b3JJbnN0YW5jZQAAAAAFsX40AgAFSQ" +
       "ACaWRMAARuYW1lcQB+AAJM\nAAZvblR5cGVxAH4ABkwACnBhcmFtTmFtZXNx" +
       "AH4AAUwACHJlYWxOYW1lcQB+AAJ4cQB+AB1zcQB+\nAA8AAAAEAAAAJQAAAA" +
       "YAAAAGdAAJUG9pbnQub29teHNxAH4ARXQABVBvaW50c3EAfgATAXEAfgAi\n" +
       "c3EAfgAjAAAAAHcEAAAAAHhzcQB+ACUAAAAAAAAAAXNxAH4AEwFxAH4AInNx" +
       "AH4AIwAAAAJ3BAAA\nAAJzcQB+AElweHQAA2ludHB4c3EAfgBNcQB+AHVxAH" +
       "4AdHgAAAACdAAFUG9pbnRwc3EAfgAjAAAA\nAncEAAAAAnQAAXh0AAF5eHQA" +
       "B1BvaW50JDJxAH4ARnVxAH4AUAAAAAIAAHNxAH4AGHcEAAAAAnNy\nACZwb2" +
       "x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5WYWx1ZVR5cGVfYwAAAAAEB4wPAg" +
       "ACTAANY29u\nc3RhbnRWYWx1ZXQAEkxqYXZhL2xhbmcvT2JqZWN0O0wAC3R5" +
       "cGVPZlZhbHVlcQB+AAh4cQB+AAtz\ncQB+AA8AAAAbAAAAHAAAAB8AAAAfcQ" +
       "B+ABF4eHNyABFqYXZhLmxhbmcuSW50ZWdlchLioKT3gYc4\nAgABSQAFdmFs" +
       "dWV4cgAQamF2YS5sYW5nLk51bWJlcoaslR0LlOCLAgAAeHAAAAABc3EAfgBJ" +
       "cHhx\nAH4AdXB4cQB+AHZzcQB+AH5zcQB+AA8AAAAeAAAAHwAAAB8AAAAfcQ" +
       "B+ABF4eHNxAH4AggAAAAFx\nAH4AhXh0AAB4dAADaCQ0eHVxAH4AUAAAAAEA" +
       "c3EAfgAYdwQAAAABcQB+AEZ4dAADaCQzeHEAfgAS\ncHBzcQB+AEV0ABBqYX" +
       "ZhLmxhbmcuT2JqZWN0c3EAfgAYdwQAAAABc3EAfgBpc3EAfgAPAAAABAAA\n" +
       "ABoAAAAVAAAAFXEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAjAAAAAXcE" +
       "AAAAAXNxAH4ARXQA\nE2phdmEubGFuZy5FeGNlcHRpb254c3EAfgAlAAAAAA" +
       "AAAAFzcQB+ABMBcQB+ACJzcQB+ACMAAAAB\ndwQAAAABcQB+AIV4AAAAAXQA" +
       "AUFwc3EAfgAjAAAAAXcEAAAAAXQAAXh4dAADQSQxeHQAASRzcQB+\nABh3BA" +
       "AAAAB4");
}

class B extends A {
    final void f$5(Point p, int x, int y) { System.out.println("In B.f"); }
    
    final void g$6(Point p) {  }
    
    final void h$7(CoorPoint x) { System.out.println("In B.h(CoorPoint)"); }
    
    public B() { super(); }
    
    void f(Point arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {  }
        {
            Object[] retVal$5$1 = null;
            if (arg1 != null) retVal$5$1 = arg1.Point$2();
            if (methodChosen != 5) {
                if (arg1 != null && retVal$5$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor5$(5) + (" and \n" + messageFor5$(methodChosen))) +
                                        " in class B.\n");
                    methodChosen = 5;
                }
            }
            switch (methodChosen) {
                case 5:
                    f$5(arg1, ((Integer) retVal$5$1[0]).intValue(), ((Integer) retVal$5$1[1]).intValue());
                    return;
            }
        }
        {
            if (methodChosen != 2) {
                if (arg1 instanceof CoorPoint &&
                      (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                         arg2.isAssignableFrom(CoorPoint.class)) ||
                      arg1 == null && (arg2 == null || CoorPoint.class.isAssignableFrom(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor5$(2) + (" and \n" + messageFor5$(methodChosen))) +
                                        " in class B.\n");
                    methodChosen = 2;
                }
            }
            switch (methodChosen) {
                case 2:
                    super.f$2((CoorPoint) arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void f(CoorPoint arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {  }
        {
            Object[] retVal$5$1 = null;
            if (arg1 != null) retVal$5$1 = arg1.Point$2();
            if (methodChosen != 5) {
                if (arg1 != null && retVal$5$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor5$(5) + (" and \n" + messageFor5$(methodChosen))) +
                                        " in class B.\n");
                    methodChosen = 5;
                }
            }
            switch (methodChosen) {
                case 5:
                    f$5(arg1, ((Integer) retVal$5$1[0]).intValue(), ((Integer) retVal$5$1[1]).intValue());
                    return;
            }
        }
        {
            if (methodChosen != 2) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor5$(2) + (" and \n" + messageFor5$(methodChosen))) +
                                        " in class B.\n");
                    methodChosen = 2;
                }
            }
            switch (methodChosen) {
                case 2:
                    super.f$2(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(Point arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {  }
        {
            if (methodChosen != 6) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor5$(6) + (" and \n" + messageFor5$(methodChosen))) +
                                        " in class B.\n");
                    methodChosen = 6;
                }
            }
            switch (methodChosen) {
                case 6:
                    g$6(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void h(CoorPoint arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$4$1 = null;
            if (arg1 != null) retVal$4$1 = arg1.Point$2();
            if (methodChosen != 4) {
                if (arg1 != null && retVal$4$1 != null && ((Integer) retVal$4$1[0]).intValue() == 1 &&
                      ((Integer) retVal$4$1[1]).intValue() == 1) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor5$(4) + (" and \n" + messageFor5$(methodChosen))) +
                                        " in class B.\n");
                    methodChosen = 4;
                }
            }
            switch (methodChosen) {
                case 4:
                    super.h$4();
                    return;
            }
        }
        {
            if (methodChosen != 7) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor5$(7) + (" and \n" + messageFor5$(methodChosen))) +
                                        " in class B.\n");
                    methodChosen = 7;
                }
            }
            switch (methodChosen) {
                case 7:
                    h$7(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor5$(int m) {
        switch (m) {
            case 5: return "method inc void f(Point.Point(int, int))"; case 6: return "method  void g(Point)"; case 7:
                return "method  void h(CoorPoint)"; case 8: return "constructor B()";
        }
        return A.messageFor1$(m);
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1181668214000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAAsAAAAJHQADFJl\nY3RUZXN0Lm9vbXh0AAFCcHgAc3IAF3" +
       "BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7EI4tc7YCAANa\nAAlpbW11dGFi" +
       "bGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNzO0wADGJhY2tp" +
       "bmdf\nbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLkNvbnN0cnVjdG" +
       "9ySW5zdGFuY2UXZz6guG6X\nIwIAAHhwc3IAFGphdmEudXRpbC5MaW5rZWRM" +
       "aXN0DClTXUpgiCIDAAB4cHcEAAAAAXNyADVwb2x5\nZ2xvdC5leHQub29tYX" +
       "RjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5jZQAAAAAUQGS2\n" +
       "AgAHSQACaWRJAApqdW5rUGFyYW1zWgAMbm9EaXNwYXRjaGVyTAAIY2hpbGRy" +
       "ZW5xAH4AAVsADGlz\nTmFtZWRQYXJhbXQAAltaTAAKcGFyYW1UeXBlc3EAfg" +
       "ABTAAIcmVhbE5hbWVxAH4AAnhyACtwb2x5\nZ2xvdC5leHQuamwudHlwZXMu" +
       "Q29uc3RydWN0b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgApcG9s\neWdsb3" +
       "QuZXh0LmpsLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblawIABE" +
       "wACWNvbnRh\naW5lcnQAHkxwb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VUeXBl" +
       "O0wACGV4Y1R5cGVzcQB+AAFMAAVm\nbGFnc3EAfgAETAALZm9ybWFsVHlwZX" +
       "NxAH4AAXhxAH4ADHEAfgAQeHEAfgAOc3EAfgATAXZyABNw\nb2x5Z2xvdC50" +
       "eXBlcy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJyYXlMaXN0" +
       "eIHS\nHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2x5Z2xvdC" +
       "50eXBlcy5GbGFnc9r/tvDd\nxiADAgABSgAEYml0c3hwAAAAAAAAAABzcQB+" +
       "ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeAAAAAgA\nAAAAAHNxAH4AGHcEAA" +
       "AAAHhwc3IAH2phdmEudXRpbC5Db2xsZWN0aW9ucyRFbXB0eUxpc3R6uBe0\n" +
       "PKee3gIAAHhwdAADQiQ4eHNxAH4AEwB2cgAccG9seWdsb3QudHlwZXMuRmll" +
       "bGRJbnN0YW5jZdRn\nviDT7YphAgAAeHBzcQB+ABh3BAAAAAB4cQB+ACZzcQ" +
       "B+ABMAcQB+ACJzcQB+ABh3BAAAAAB4c3IA\nHXBvbHlnbG90LnR5cGVzLkNs" +
       "YXNzVHlwZSRLaW5kh1jxDIZhxF0CAAB4cgAScG9seWdsb3QudXRp\nbC5Fbn" +
       "VtsOTezCdsygkCAAFMAARuYW1lcQB+AAJ4cHQACXRvcC1sZXZlbHNxAH4AEw" +
       "BxAH4AInNx\nAH4AGHcEAAAAAHhzcQB+ABMAdnIAHXBvbHlnbG90LnR5cGVz" +
       "Lk1ldGhvZEluc3RhbmNlXGSFCAkp\nfOkCAAB4cHNxAH4AGHcEAAAAA3NyAD" +
       "Bwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNo\nTWV0aG9kSW5z" +
       "dGFuY2UAAAAALB2kfwIACFoADmhhc1doZXJlQ2xhdXNlSQACaWRaAAxub0Rp" +
       "c3Bh\ndGNoZXJMAAVjaGlsZHQAH0xwb2x5Z2xvdC90eXBlcy9NZXRob2RJbn" +
       "N0YW5jZTtMAAhjaGlsZHJl\nbnEAfgABWwAMaXNOYW1lZFBhcmFtcQB+ABtM" +
       "AApwYXJhbVR5cGVzcQB+AAFMAAhyZWFsTmFtZXEA\nfgACeHIAJnBvbHlnbG" +
       "90LmV4dC5qbC50eXBlcy5NZXRob2RJbnN0YW5jZV9jjFcIyQELZfsCAAJM\n" +
       "AARuYW1lcQB+AAJMAApyZXR1cm5UeXBlcQB+AAh4cQB+AB1zcQB+AA8AAAAI" +
       "AAAAKwAAACUAAAAl\ncQB+ABF4cQB+AA5zcQB+ABMBcQB+ACJzcQB+ACMAAA" +
       "AAdwQAAAAAeHNxAH4AJQAAAAAAABAAc3EA\nfgAjAAAAAXcEAAAAAXNyACNw" +
       "b2x5Z2xvdC5leHQuamwudHlwZXMuUGxhY2VIb2xkZXJfY0r01lo2\nyLx0Ag" +
       "ABTAAEbmFtZXEAfgACeHB0AAVQb2ludHh0AAFmc3IAJXBvbHlnbG90LmV4dC" +
       "5qbC50eXBl\ncy5QcmltaXRpdmVUeXBlX2PvU+sa9woSxAIAAUwABGtpbmR0" +
       "ACNMcG9seWdsb3QvdHlwZXMvUHJp\nbWl0aXZlVHlwZSRLaW5kO3hxAH4AC3" +
       "B4dAAEdm9pZHB4c3IAIXBvbHlnbG90LnR5cGVzLlByaW1p\ndGl2ZVR5cGUk" +
       "S2luZMQrIax+Ut5iAgAAeHEAfgA0cQB+AE0AAAAABQBwc3EAfgAYdwQAAAAA" +
       "eHVy\nAAJbWlePIDkUuF3iAgAAeHAAAAABAHNxAH4AGHcEAAAAAXNyAChwb2" +
       "x5Z2xvdC5leHQub29tYXRj\naC50eXBlcy5QYXR0ZXJuVHlwZV9jAAAAACoC" +
       "xDgCAAVMAAVkZWNvbnQAMkxwb2x5Z2xvdC9leHQv\nb29tYXRjaC90eXBlcy" +
       "9EZWNvbnN0cnVjdG9ySW5zdGFuY2U7TAARZGVjb25zdHJ1Y3RvclR5cGVx\n" +
       "AH4ABlsADGlzTmFtZWRQYXJhbXEAfgAbTAAHcGF0dGVybnEAfgABTAAHdmFy" +
       "TmFtZXEAfgACeHEA\nfgALc3EAfgAPAAAAFQAAACoAAAAlAAAAJXEAfgAReH" +
       "hzcgAwcG9seWdsb3QuZXh0Lm9vbWF0Y2gu\ndHlwZXMuRGVjb25zdHJ1Y3Rv" +
       "ckluc3RhbmNlAAAAAAWxfjQCAAVJAAJpZEwABG5hbWVxAH4AAkwA\nBm9uVH" +
       "lwZXEAfgAGTAAKcGFyYW1OYW1lc3EAfgABTAAIcmVhbE5hbWVxAH4AAnhxAH" +
       "4AHXNxAH4A\nDwAAAAQAAAAlAAAABgAAAAZ0AAlQb2ludC5vb214cQB+AEdz" +
       "cQB+ABMBcQB+ACJzcQB+ACMAAAAA\ndwQAAAAAeHNxAH4AJQAAAAAAAAABc3" +
       "EAfgATAXEAfgAic3EAfgAjAAAAAncEAAAAAnNxAH4ASnB4\ndAADaW50cHhz" +
       "cQB+AE5xAH4AYnEAfgBheAAAAAJ0AAVQb2ludHBzcQB+ACMAAAACdwQAAAAC" +
       "dAAB\neHQAAXl4dAAHUG9pbnQkMnEAfgBHdXEAfgBRAAAAAgAAc3EAfgAYdw" +
       "QAAAACc3EAfgBKcHhxAH4A\nYnB4cQB+AGNxAH4Aa3h0AAFweHQAA2YkNXNx" +
       "AH4APXNxAH4ADwAAAAQAAAATAAAAKAAAAChxAH4A\nEXhxAH4ADnNxAH4AEw" +
       "FxAH4AInNxAH4AIwAAAAB3BAAAAAB4cQB+ACZzcQB+ACMAAAABdwQAAAAB\n" +
       "cQB+AEd4dAABZ3EAfgBMAAAAAAYAcHNxAH4AGHcEAAAAAHh1cQB+AFEAAAAB" +
       "AHNxAH4AGHcEAAAA\nAXEAfgBHeHQAA2ckNnNxAH4APXNxAH4ADwAAAAQAAA" +
       "AXAAAAKQAAAClxAH4AEXhxAH4ADnNxAH4A\nEwFxAH4AInNxAH4AIwAAAAB3" +
       "BAAAAAB4cQB+ACZzcQB+ACMAAAABdwQAAAABc3EAfgBGdAAJQ29v\nclBvaW" +
       "50eHQAAWhxAH4ATAAAAAAHAHBzcQB+ABh3BAAAAAB4dXEAfgBRAAAAAQBzcQ" +
       "B+ABh3BAAA\nAAFxAH4AfXh0AANoJDd4cQB+ABJwcHNxAH4ARnQAAUFzcQB+" +
       "ABh3BAAAAAB4dAABJHNxAH4AGHcE\nAAAAAHg=");
}

class C extends B {
    final void f$9() {
        super.f(new Point(0,0), Point.class);
        System.out.println("In C.f"); }
    
    final void g$10(CoorPoint p) {  }
    
    public C() { super(); }
    
    void g(CoorPoint arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {  }
        {  }
        {
            if (methodChosen != 10) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(10) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 10;
                }
            }
            switch (methodChosen) {
                case 10:
                    g$10(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(Point arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {  }
        {  }
        {
            if (methodChosen != 10) {
                if (arg1 instanceof CoorPoint &&
                      (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                         arg2.isAssignableFrom(CoorPoint.class)) ||
                      arg1 == null && (arg2 == null || CoorPoint.class.isAssignableFrom(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(10) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 10;
                }
            }
            switch (methodChosen) {
                case 10:
                    g$10((CoorPoint) arg1);
                    return;
            }
        }
        {
            if (methodChosen != 6) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(6) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 6;
                }
            }
            switch (methodChosen) {
                case 6:
                    super.g$6(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void f(CoorPoint arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {  }
        {  }
        {
            Object[] retVal$9$1 = null;
            if (arg1 != null) retVal$9$1 = arg1.Point$2();
            if (methodChosen != 9) {
                if (arg1 != null && retVal$9$1 != null && ((Integer) retVal$9$1[0]).intValue() == 0 &&
                      ((Integer) retVal$9$1[1]).intValue() == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(9) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 9;
                }
            }
            switch (methodChosen) {
                case 9:
                    f$9();
                    return;
            }
        }
        {
            Object[] retVal$5$1 = null;
            if (arg1 != null) retVal$5$1 = arg1.Point$2();
            if (methodChosen != 5) {
                if (arg1 != null && retVal$5$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(5) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 5;
                }
            }
            switch (methodChosen) {
                case 5:
                    super.f$5(arg1, ((Integer) retVal$5$1[0]).intValue(), ((Integer) retVal$5$1[1]).intValue());
                    return;
            }
        }
        {
            if (methodChosen != 2) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(2) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 2;
                }
            }
            switch (methodChosen) {
                case 2:
                    super.f$2(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void f(Point arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {  }
        {  }
        {
            Object[] retVal$9$1 = null;
            if (arg1 instanceof CoorPoint &&
                  (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) || arg2.isAssignableFrom(CoorPoint.class)) &&
                  arg1 != null)
                retVal$9$1 = ((CoorPoint) arg1).Point$2();
            if (methodChosen != 9) {
                if (arg1 instanceof CoorPoint &&
                      (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                         arg2.isAssignableFrom(CoorPoint.class)) &&
                      arg1 != null &&
                      retVal$9$1 != null &&
                      ((Integer) retVal$9$1[0]).intValue() == 0 &&
                      ((Integer) retVal$9$1[1]).intValue() == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(9) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 9;
                }
            }
            switch (methodChosen) {
                case 9:
                    f$9();
                    return;
            }
        }
        {
            Object[] retVal$5$1 = null;
            if (arg1 != null) retVal$5$1 = arg1.Point$2();
            if (methodChosen != 5) {
                if (arg1 != null && retVal$5$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(5) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 5;
                }
            }
            switch (methodChosen) {
                case 5:
                    super.f$5(arg1, ((Integer) retVal$5$1[0]).intValue(), ((Integer) retVal$5$1[1]).intValue());
                    return;
            }
        }
        {
            if (methodChosen != 2) {
                if (arg1 instanceof CoorPoint &&
                      (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                         arg2.isAssignableFrom(CoorPoint.class)) ||
                      arg1 == null && (arg2 == null || CoorPoint.class.isAssignableFrom(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor9$(2) + (" and \n" + messageFor9$(methodChosen))) +
                                        " in class C.\n");
                    methodChosen = 2;
                }
            }
            switch (methodChosen) {
                case 2:
                    super.f$2((CoorPoint) arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor9$(int m) {
        switch (m) {
            case 10: return "method  void g(CoorPoint)"; case 11: return "constructor C()"; case 9:
                return "method  void f(CoorPoint.Point(0, 0))";
        }
        return B.messageFor5$(m);
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1181668214000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAAAAAAAAEAAAA1AAAALnQADFJl\nY3RUZXN0Lm9vbXh0AAFDcHgAc3IAF3" +
       "BvbHlnbG90LnV0aWwuVHlwZWRMaXN07LI7EI4tc7YCAANa\nAAlpbW11dGFi" +
       "bGVMAAxhbGxvd2VkX3R5cGV0ABFMamF2YS9sYW5nL0NsYXNzO0wADGJhY2tp" +
       "bmdf\nbGlzdHEAfgABeHAAdnIAInBvbHlnbG90LnR5cGVzLkNvbnN0cnVjdG" +
       "9ySW5zdGFuY2UXZz6guG6X\nIwIAAHhwc3IAFGphdmEudXRpbC5MaW5rZWRM" +
       "aXN0DClTXUpgiCIDAAB4cHcEAAAAAXNyADVwb2x5\nZ2xvdC5leHQub29tYX" +
       "RjaC50eXBlcy5PT01hdGNoQ29uc3RydWN0b3JJbnN0YW5jZQAAAAAUQGS2\n" +
       "AgAHSQACaWRJAApqdW5rUGFyYW1zWgAMbm9EaXNwYXRjaGVyTAAIY2hpbGRy" +
       "ZW5xAH4AAVsADGlz\nTmFtZWRQYXJhbXQAAltaTAAKcGFyYW1UeXBlc3EAfg" +
       "ABTAAIcmVhbE5hbWVxAH4AAnhyACtwb2x5\nZ2xvdC5leHQuamwudHlwZXMu" +
       "Q29uc3RydWN0b3JJbnN0YW5jZV9jwKErDAOy0+gCAAB4cgApcG9s\neWdsb3" +
       "QuZXh0LmpsLnR5cGVzLlByb2NlZHVyZUluc3RhbmNlX2PFBnsCiYblawIABE" +
       "wACWNvbnRh\naW5lcnQAHkxwb2x5Z2xvdC90eXBlcy9SZWZlcmVuY2VUeXBl" +
       "O0wACGV4Y1R5cGVzcQB+AAFMAAVm\nbGFnc3EAfgAETAALZm9ybWFsVHlwZX" +
       "NxAH4AAXhxAH4ADHEAfgAQeHEAfgAOc3EAfgATAXZyABNw\nb2x5Z2xvdC50" +
       "eXBlcy5UeXBl9VHRqnXMJk8CAAB4cHNyABNqYXZhLnV0aWwuQXJyYXlMaXN0" +
       "eIHS\nHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAAeHNyABRwb2x5Z2xvdC" +
       "50eXBlcy5GbGFnc9r/tvDd\nxiADAgABSgAEYml0c3hwAAAAAAAAAABzcQB+" +
       "ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeAAAAAsA\nAAAAAHNxAH4AGHcEAA" +
       "AAAHhwc3IAH2phdmEudXRpbC5Db2xsZWN0aW9ucyRFbXB0eUxpc3R6uBe0\n" +
       "PKee3gIAAHhwdAAEQyQxMXhzcQB+ABMAdnIAHHBvbHlnbG90LnR5cGVzLkZp" +
       "ZWxkSW5zdGFuY2XU\nZ74g0+2KYQIAAHhwc3EAfgAYdwQAAAAAeHEAfgAmc3" +
       "EAfgATAHEAfgAic3EAfgAYdwQAAAAAeHNy\nAB1wb2x5Z2xvdC50eXBlcy5D" +
       "bGFzc1R5cGUkS2luZIdY8QyGYcRdAgAAeHIAEnBvbHlnbG90LnV0\naWwuRW" +
       "51bbDk3swnbMoJAgABTAAEbmFtZXEAfgACeHB0AAl0b3AtbGV2ZWxzcQB+AB" +
       "MAcQB+ACJz\ncQB+ABh3BAAAAAB4c3EAfgATAHZyAB1wb2x5Z2xvdC50eXBl" +
       "cy5NZXRob2RJbnN0YW5jZVxkhQgJ\nKXzpAgAAeHBzcQB+ABh3BAAAAAFzcg" +
       "AwcG9seWdsb3QuZXh0Lm9vbWF0Y2gudHlwZXMuT09NYXRj\naE1ldGhvZElu" +
       "c3RhbmNlAAAAACwdpH8CAAhaAA5oYXNXaGVyZUNsYXVzZUkAAmlkWgAMbm9E" +
       "aXNw\nYXRjaGVyTAAFY2hpbGR0AB9McG9seWdsb3QvdHlwZXMvTWV0aG9kSW" +
       "5zdGFuY2U7TAAIY2hpbGRy\nZW5xAH4AAVsADGlzTmFtZWRQYXJhbXEAfgAb" +
       "TAAKcGFyYW1UeXBlc3EAfgABTAAIcmVhbE5hbWVx\nAH4AAnhyACZwb2x5Z2" +
       "xvdC5leHQuamwudHlwZXMuTWV0aG9kSW5zdGFuY2VfY4xXCMkBC2X7AgAC\n" +
       "TAAEbmFtZXEAfgACTAAKcmV0dXJuVHlwZXEAfgAIeHEAfgAdc3EAfgAPAAAA" +
       "BAAAABcAAAA0AAAA\nNHEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAjAA" +
       "AAAHcEAAAAAHhxAH4AJnNxAH4AIwAAAAF3\nBAAAAAFzcgAjcG9seWdsb3Qu" +
       "ZXh0LmpsLnR5cGVzLlBsYWNlSG9sZGVyX2NK9NZaNsi8dAIAAUwA\nBG5hbW" +
       "VxAH4AAnhwdAAJQ29vclBvaW50eHQAAWdzcgAlcG9seWdsb3QuZXh0LmpsLn" +
       "R5cGVzLlBy\naW1pdGl2ZVR5cGVfY+9T6xr3ChLEAgABTAAEa2luZHQAI0xw" +
       "b2x5Z2xvdC90eXBlcy9QcmltaXRp\ndmVUeXBlJEtpbmQ7eHEAfgALcHh0AA" +
       "R2b2lkcHhzcgAhcG9seWdsb3QudHlwZXMuUHJpbWl0aXZl\nVHlwZSRLaW5k" +
       "xCshrH5S3mICAAB4cQB+ADRxAH4ATAAAAAAKAHBzcQB+ABh3BAAAAAB4dXIA" +
       "Alta\nV48gORS4XeICAAB4cAAAAAEAc3EAfgAYdwQAAAABcQB+AEZ4dAAEZy" +
       "QxMHhxAH4AEnBwc3EAfgBF\ndAABQnNxAH4AGHcEAAAAAHh0AAEkc3EAfgAY" +
       "dwQAAAABc3EAfgA9c3EAfgAPAAAABAAAABsAAAAv\nAAAAL3EAfgAReHEAfg" +
       "AOc3EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHhxAH4AJnNxAH4AIwAA\n" +
       "AAF3BAAAAAFxAH4ARnh0AAFmcQB+AEsAAAAACQBwc3EAfgAYdwQAAAAAeHVx" +
       "AH4AUAAAAAEAc3EA\nfgAYdwQAAAABc3IAKHBvbHlnbG90LmV4dC5vb21hdG" +
       "NoLnR5cGVzLlBhdHRlcm5UeXBlX2MAAAAA\nKgLEOAIABUwABWRlY29udAAy" +
       "THBvbHlnbG90L2V4dC9vb21hdGNoL3R5cGVzL0RlY29uc3RydWN0\nb3JJbn" +
       "N0YW5jZTtMABFkZWNvbnN0cnVjdG9yVHlwZXEAfgAGWwAMaXNOYW1lZFBhcm" +
       "FtcQB+ABtM\nAAdwYXR0ZXJucQB+AAFMAAd2YXJOYW1lcQB+AAJ4cQB+AAtz" +
       "cQB+AA8AAAALAAAAGgAAAC8AAAAv\ncQB+ABF4eHNyADBwb2x5Z2xvdC5leH" +
       "Qub29tYXRjaC50eXBlcy5EZWNvbnN0cnVjdG9ySW5zdGFu\nY2UAAAAABbF+" +
       "NAIABUkAAmlkTAAEbmFtZXEAfgACTAAGb25UeXBlcQB+AAZMAApwYXJhbU5h" +
       "bWVz\ncQB+AAFMAAhyZWFsTmFtZXEAfgACeHEAfgAdc3EAfgAPAAAABAAAAC" +
       "UAAAAGAAAABnQACVBvaW50\nLm9vbXhzcQB+AEV0AAVQb2ludHNxAH4AEwFx" +
       "AH4AInNxAH4AIwAAAAB3BAAAAAB4c3EAfgAlAAAA\nAAAAAAFzcQB+ABMBcQ" +
       "B+ACJzcQB+ACMAAAACdwQAAAACc3EAfgBJcHh0AANpbnRweHNxAH4ATXEA\n" +
       "fgBycQB+AHF4AAAAAnQABVBvaW50cHNxAH4AIwAAAAJ3BAAAAAJ0AAF4dAAB" +
       "eXh0AAdQb2ludCQy\ncQB+AEZ1cQB+AFAAAAACAABzcQB+ABh3BAAAAAJzcg" +
       "AmcG9seWdsb3QuZXh0Lm9vbWF0Y2gudHlw\nZXMuVmFsdWVUeXBlX2MAAAAA" +
       "BAeMDwIAAkwADWNvbnN0YW50VmFsdWV0ABJMamF2YS9sYW5nL09i\namVjdD" +
       "tMAAt0eXBlT2ZWYWx1ZXEAfgAIeHEAfgALc3EAfgAPAAAAFQAAABYAAAAvAA" +
       "AAL3EAfgAR\neHhzcgARamF2YS5sYW5nLkludGVnZXIS4qCk94GHOAIAAUkA" +
       "BXZhbHVleHIAEGphdmEubGFuZy5O\ndW1iZXKGrJUdC5TgiwIAAHhwAAAAAH" +
       "NxAH4ASXB4cQB+AHJweHEAfgBzc3EAfgB7c3EAfgAPAAAA\nGAAAABkAAAAv" +
       "AAAAL3EAfgAReHhzcQB+AH8AAAAAcQB+AIJ4dAAAeHQAA2YkOXg=");
}

abstract class Abstract {
    public Abstract() { super(); }
    
    public Point p;
    
    public Abstract(Point p) {
        super();
        this.p = p; }
    
    public Object[] Abstract$4() {
        Point p;
        p = this.p;
        if (true) return new Object[] { p }; else return null;
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 1: return "method abstract void abst(Point)"; case 2: return "constructor public Abstract()"; case 3:
                return "constructor public Abstract(Point)";
        }
        return "";
    }
    
    abstract void abst(Point p, Class arg2);
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1181668214000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAACQAAAAEAAAA8AAAAN3QADFJl\nY3RUZXN0Lm9vbXh0AAhBYnN0cmFjdH" +
       "B4AHNyABdwb2x5Z2xvdC51dGlsLlR5cGVkTGlzdOyyOxCO\nLXO2AgADWgAJ" +
       "aW1tdXRhYmxlTAAMYWxsb3dlZF90eXBldAARTGphdmEvbGFuZy9DbGFzcztM" +
       "AAxi\nYWNraW5nX2xpc3RxAH4AAXhwAHZyACJwb2x5Z2xvdC50eXBlcy5Db2" +
       "5zdHJ1Y3Rvckluc3RhbmNl\nF2c+oLhulyMCAAB4cHNyABRqYXZhLnV0aWwu" +
       "TGlua2VkTGlzdAwpU11KYIgiAwAAeHB3BAAAAAJz\ncgA1cG9seWdsb3QuZX" +
       "h0Lm9vbWF0Y2gudHlwZXMuT09NYXRjaENvbnN0cnVjdG9ySW5zdGFuY2UA\n" +
       "AAAAFEBktgIAB0kAAmlkSQAKanVua1BhcmFtc1oADG5vRGlzcGF0Y2hlckwA" +
       "CGNoaWxkcmVucQB+\nAAFbAAxpc05hbWVkUGFyYW10AAJbWkwACnBhcmFtVH" +
       "lwZXNxAH4AAUwACHJlYWxOYW1lcQB+AAJ4\ncgArcG9seWdsb3QuZXh0Lmps" +
       "LnR5cGVzLkNvbnN0cnVjdG9ySW5zdGFuY2VfY8ChKwwDstPoAgAA\neHIAKX" +
       "BvbHlnbG90LmV4dC5qbC50eXBlcy5Qcm9jZWR1cmVJbnN0YW5jZV9jxQZ7Ao" +
       "mG5WsCAARM\nAAljb250YWluZXJ0AB5McG9seWdsb3QvdHlwZXMvUmVmZXJl" +
       "bmNlVHlwZTtMAAhleGNUeXBlc3EA\nfgABTAAFZmxhZ3NxAH4ABEwAC2Zvcm" +
       "1hbFR5cGVzcQB+AAF4cQB+AAxzcQB+AA8AAAALAAAAGAAA\nADoAAAA6cQB+" +
       "ABF4cQB+AA5zcQB+ABMBdnIAE3BvbHlnbG90LnR5cGVzLlR5cGX1UdGqdcwm" +
       "TwIA\nAHhwc3IAE2phdmEudXRpbC5BcnJheUxpc3R4gdIdmcdhnQMAAUkABH" +
       "NpemV4cAAAAAB3BAAAAAB4\nc3IAFHBvbHlnbG90LnR5cGVzLkZsYWdz2v+2" +
       "8N3GIAMCAAFKAARiaXRzeHAAAAAAAAAAAXNxAH4A\nJAAAAAB3BAAAAAB4AA" +
       "AAAgAAAAAAc3EAfgAYdwQAAAAAeHBzcQB+ABh3BAAAAAB4dAAKQWJzdHJh\n" +
       "Y3QkMnNxAH4AGnNxAH4ADwAAAAsAAAAmAAAAOQAAADlxAH4AEXhxAH4ADnNx" +
       "AH4AEwFxAH4AI3Nx\nAH4AJAAAAAB3BAAAAAB4cQB+ACdzcQB+ACQAAAABdw" +
       "QAAAABc3IAI3BvbHlnbG90LmV4dC5qbC50\neXBlcy5QbGFjZUhvbGRlcl9j" +
       "SvTWWjbIvHQCAAFMAARuYW1lcQB+AAJ4cHQABVBvaW50eAAAAAMA\nAAAAAH" +
       "NxAH4AGHcEAAAAAHhwc3EAfgAYdwQAAAABcQB+ADJ4dAAKQWJzdHJhY3QkM3" +
       "hzcQB+ABMA\ndnIAHHBvbHlnbG90LnR5cGVzLkZpZWxkSW5zdGFuY2XUZ74g" +
       "0+2KYQIAAHhwc3EAfgAYdwQAAAAB\nc3IAJXBvbHlnbG90LmV4dC5qbC50eX" +
       "Blcy5GaWVsZEluc3RhbmNlX2ORwPlzqvuJ+wIAAUwACWNv\nbnRhaW5lcnEA" +
       "fgAeeHIAI3BvbHlnbG90LmV4dC5qbC50eXBlcy5WYXJJbnN0YW5jZV9jnwNb" +
       "lT1G\n3McCAAVaAAppc0NvbnN0YW50TAANY29uc3RhbnRWYWx1ZXQAEkxqYX" +
       "ZhL2xhbmcvT2JqZWN0O0wA\nBWZsYWdzcQB+AARMAARuYW1lcQB+AAJMAAR0" +
       "eXBlcQB+AAh4cQB+AAxweABwcQB+ACd0AAFwcQB+\nADJxAH4ADnhzcQB+AC" +
       "YAAAAAAAACAHNxAH4AEwBxAH4AI3NxAH4AGHcEAAAAAHhzcgAdcG9seWds\n" +
       "b3QudHlwZXMuQ2xhc3NUeXBlJEtpbmSHWPEMhmHEXQIAAHhyABJwb2x5Z2xv" +
       "dC51dGlsLkVudW2w\n5N7MJ2zKCQIAAUwABG5hbWVxAH4AAnhwdAAJdG9wLW" +
       "xldmVsc3EAfgATAHEAfgAjc3EAfgAYdwQA\nAAAAeHNxAH4AEwB2cgAdcG9s" +
       "eWdsb3QudHlwZXMuTWV0aG9kSW5zdGFuY2VcZIUICSl86QIAAHhw\nc3EAfg" +
       "AYdwQAAAABc3IAMHBvbHlnbG90LmV4dC5vb21hdGNoLnR5cGVzLk9PTWF0Y2" +
       "hNZXRob2RJ\nbnN0YW5jZQAAAAAsHaR/AgAIWgAOaGFzV2hlcmVDbGF1c2VJ" +
       "AAJpZFoADG5vRGlzcGF0Y2hlckwA\nBWNoaWxkdAAfTHBvbHlnbG90L3R5cG" +
       "VzL01ldGhvZEluc3RhbmNlO0wACGNoaWxkcmVucQB+AAFb\nAAxpc05hbWVk" +
       "UGFyYW1xAH4AG0wACnBhcmFtVHlwZXNxAH4AAUwACHJlYWxOYW1lcQB+AAJ4" +
       "cgAm\ncG9seWdsb3QuZXh0LmpsLnR5cGVzLk1ldGhvZEluc3RhbmNlX2OMVw" +
       "jJAQtl+wIAAkwABG5hbWVx\nAH4AAkwACnJldHVyblR5cGVxAH4ACHhxAH4A" +
       "HXNxAH4ADwAAAA0AAAAfAAAAOAAAADhxAH4AEXhx\nAH4ADnNxAH4AEwFxAH" +
       "4AI3NxAH4AJAAAAAB3BAAAAAB4cQB+AEBzcQB+ACQAAAABdwQAAAABcQB+\n" +
       "ADJ4dAAEYWJzdHNyACVwb2x5Z2xvdC5leHQuamwudHlwZXMuUHJpbWl0aXZl" +
       "VHlwZV9j71PrGvcK\nEsQCAAFMAARraW5kdAAjTHBvbHlnbG90L3R5cGVzL1" +
       "ByaW1pdGl2ZVR5cGUkS2luZDt4cQB+AAtw\neHQABHZvaWRweHNyACFwb2x5" +
       "Z2xvdC50eXBlcy5QcmltaXRpdmVUeXBlJEtpbmTEKyGsflLeYgIA\nAHhxAH" +
       "4ARHEAfgBZAAAAAAEAcHNxAH4AGHcEAAAAAHh1cgACW1pXjyA5FLhd4gIAAH" +
       "hwAAAAAQBz\ncQB+ABh3BAAAAAFxAH4AMnhxAH4AVXhxAH4AEnBwc3EAfgAx" +
       "dAAQamF2YS5sYW5nLk9iamVjdHNx\nAH4AGHcEAAAAAXNyADBwb2x5Z2xvdC" +
       "5leHQub29tYXRjaC50eXBlcy5EZWNvbnN0cnVjdG9ySW5z\ndGFuY2UAAAAA" +
       "BbF+NAIABUkAAmlkTAAEbmFtZXEAfgACTAAGb25UeXBlcQB+AAZMAApwYXJh" +
       "bU5h\nbWVzcQB+AAFMAAhyZWFsTmFtZXEAfgACeHEAfgAdcQB+AC14cQB+AA" +
       "5zcQB+ABMBcQB+ACNzcQB+\nACQAAAAAdwQAAAAAeHNxAH4AJgAAAAAAAAAB" +
       "c3EAfgATAXEAfgAjc3EAfgAkAAAAAXcEAAAAAXEA\nfgAyeAAAAAR0AAhBYn" +
       "N0cmFjdHBzcQB+ACQAAAABdwQAAAABcQB+AD94dAAKQWJzdHJhY3QkNHh0\n" +
       "AAEkc3EAfgAYdwQAAAAAeA==");
}

public class RectTest {
    static int x;
    
    static Point a;
    
    static {
               x = 1;
               a =
                 new Point(0,0) {
                     final void abst$4(int p) {  }
                     
                     void abst(int arg1, Class arg2) {
                         int methodChosen = 0;
                         {  }
                         {  }
                         {
                             if (methodChosen != 4) {
                                 if (true) {
                                     if (methodChosen != 0)
                                         throw new Error("The following 2 methods are ambiguous:\n" +
                                                         (messageFor4$(4) + (" and \n" + messageFor4$(methodChosen))) +
                                                         " in class <Anonymous>.\n");
                                     methodChosen = 4;
                                 }
                             }
                             switch (methodChosen) {
                                 case 4:
                                     abst$4(arg1);
                                     return;
                             }
                         }
                         throw new Error("No method found for call.");
                     }
                     
                     public String messageFor4$(int m) {
                         switch (m) { case 4: return "method  void abst(int)"; }
                         return Point.messageFor1$(m); }
                 };
           }
    
    static final int f$1() { return 0; }
    
    static final int f$2(Point p, int x, int y) {
        System.out.println("p.x=" + p.x);
        return x + y; }
    
    static final int f$3(Point p) { return 4; }
    
    static final int f$4() { return 1; }
    
    static final int f$5() { return 2; }
    
    final void h$6(int a, int b) {  }
    
    final void h$7(int a) {  }
    
    final void h$8(int a) {  }
    
    final void h$9() {  }
    
    final void h2$10(int a, int b) {  }
    
    final void g$11(int x) {  }
    
    final void g$12(short x) {  }
    
    final void g$13() { System.out.println("g(0.0)"); }
    
    final void g$14() { System.out.println("g(0)"); }
    
    static final void i$15(A a)throws Exception {  }
    
    final void testNestedPat$16(Rect r) { System.out.println("In testNestedPat(Rect)"); }
    
    final void testNestedPat$17(Point p) { System.out.println("In testNestedPat: x = " + p.x + ", y = " + p.y); }
    
    final void testNullSem$18(A a1, A a2)throws Exception { System.out.println("testNullSem(A, A)"); }
    
    final void testNullSem$19(B b)throws Exception { System.out.println("testNullSem(B, A(0))"); }
    
    final void testMethSem$20(int a1, A a2)throws Exception { System.out.println("testMethSem(int, A)"); }
    
    final void testMethSem$21(short b)throws Exception { System.out.println("testMethSem(short, A)"); }
    
    public static void main(String[] args)throws Exception {
        Point.f();
        int x = f(new Point(0,0), Point.class);
        int y = f(new Point(1,2), Point.class);
        Point p = new Point(0,0);
        System.out.println("x=" + x);
        System.out.println("y=" + y);
        i(new C(), C.class);
        Abstract a =
          new Abstract() {
            final void abst$4(Point p) {  }
            
            final void abst$5(CoorPoint q) {  }
            
            final void abst$6() {  }
            
            void abst(Point arg1, Class arg2) {
                int methodChosen = 0;
                {  }
                {  }
                {
                    Object[] retVal$6$1 = null;
                    if (arg1 instanceof CoorPoint &&
                          (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                             arg2.isAssignableFrom(CoorPoint.class)) &&
                          arg1 != null)
                        retVal$6$1 = ((CoorPoint) arg1).Point$2();
                    if (methodChosen != 6) {
                        if (arg1 instanceof CoorPoint &&
                              (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                                 arg2.isAssignableFrom(CoorPoint.class)) &&
                              arg1 != null &&
                              retVal$6$1 != null &&
                              ((Integer) retVal$6$1[0]).intValue() == 0 &&
                              ((Integer) retVal$6$1[1]).intValue() == 0) {
                            if (methodChosen != 0)
                                throw new Error("The following 2 methods are ambiguous:\n" +
                                                (messageFor4$(6) + (" and \n" + messageFor4$(methodChosen))) +
                                                " in class <Anonymous>.\n");
                            methodChosen = 6;
                        }
                    }
                    if (methodChosen != 5 && methodChosen != 6) {
                        if (arg1 instanceof CoorPoint &&
                              (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                                 arg2.isAssignableFrom(CoorPoint.class)) ||
                              arg1 == null && (arg2 == null || CoorPoint.class.isAssignableFrom(arg2))) {
                            if (methodChosen != 0)
                                throw new Error("The following 2 methods are ambiguous:\n" +
                                                (messageFor4$(5) + (" and \n" + messageFor4$(methodChosen))) +
                                                " in class <Anonymous>.\n");
                            methodChosen = 5;
                        }
                    }
                    if (methodChosen != 4 && methodChosen != 5 && methodChosen != 6) {
                        if (true) {
                            if (methodChosen != 0)
                                throw new Error("The following 2 methods are ambiguous:\n" +
                                                (messageFor4$(4) + (" and \n" + messageFor4$(methodChosen))) +
                                                " in class <Anonymous>.\n");
                            methodChosen = 4;
                        }
                    }
                    switch (methodChosen) {
                        case 6:
                            abst$6();
                            return;
                        case 5:
                            abst$5((CoorPoint) arg1);
                            return;
                        case 4:
                            abst$4(arg1);
                            return;
                    }
                }
                throw new Error("No method found for call.");
            }
            
            void abst(CoorPoint arg1, Class arg2) {
                int methodChosen = 0;
                {  }
                {  }
                {
                    Object[] retVal$6$1 = null;
                    if (arg1 != null) retVal$6$1 = arg1.Point$2();
                    if (methodChosen != 6) {
                        if (arg1 != null && retVal$6$1 != null && ((Integer) retVal$6$1[0]).intValue() == 0 &&
                              ((Integer) retVal$6$1[1]).intValue() == 0) {
                            if (methodChosen != 0)
                                throw new Error("The following 2 methods are ambiguous:\n" +
                                                (messageFor4$(6) + (" and \n" + messageFor4$(methodChosen))) +
                                                " in class <Anonymous>.\n");
                            methodChosen = 6;
                        }
                    }
                    if (methodChosen != 5 && methodChosen != 6) {
                        if (true) {
                            if (methodChosen != 0)
                                throw new Error("The following 2 methods are ambiguous:\n" +
                                                (messageFor4$(5) + (" and \n" + messageFor4$(methodChosen))) +
                                                " in class <Anonymous>.\n");
                            methodChosen = 5;
                        }
                    }
                    switch (methodChosen) {
                        case 6:
                            abst$6();
                            return;
                        case 5:
                            abst$5(arg1);
                            return;
                    }
                }
                throw new Error("No method found for call.");
            }
            
            public String messageFor4$(int m) {
                switch (m) {
                    case 4: return "method  void abst(Point)"; case 5: return "method  void abst(CoorPoint)"; case 6:
                        return "method  void abst(CoorPoint.Point(0, 0))";
                }
                return Abstract.messageFor1$(m);
            }
        };
        new RectTest().doMain();
    }
    
    final void doMain$23()throws Exception {
        testNullSem(null, new A(), null, A.class);
        testNullSem((B) null, new A(), B.class, A.class);
        A a = null;
        testNullSem(a, new A(), A.class, A.class);
        testMethSem(0, new A(), int.class, A.class);
        testMethSem((short) 0, new A(), short.class, A.class);
        A aa = new A();
        B b = new B();
        C c = new C();
        c.h(new CoorPoint(1,1), CoorPoint.class);
        aa.f(new CoorPoint(0,0), CoorPoint.class);
        aa = c;
        aa.f(new CoorPoint(0,0), CoorPoint.class);
        b.f(new Point(1,2), Point.class);
        b.f(new Point(0,0), Point.class);
        c.f(new Point(0,0), Point.class);
        c.f(new Point(1,2), Point.class);
        CoorPoint cp = null;
        ((A) b).f(cp, CoorPoint.class);
        b.f((Point) null, Point.class);
    }
    
    public RectTest() { super(); }
    
    final void h2$25(int a) {  }
    
    final void h2$26(int a) {  }
    
    static int f(Point arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 1) {
                if (arg1 == null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(1) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 1;
                }
            }
            Object[] retVal$5$1 = null;
            if (arg1 instanceof CoorPoint &&
                  (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) || arg2.isAssignableFrom(CoorPoint.class)) &&
                  arg1 != null)
                retVal$5$1 = ((CoorPoint) arg1).Point$2();
            if (methodChosen != 5) {
                if (arg1 instanceof CoorPoint &&
                      (arg2 == null || CoorPoint.class.isAssignableFrom(arg2) ||
                         arg2.isAssignableFrom(CoorPoint.class)) &&
                      arg1 != null &&
                      retVal$5$1 != null &&
                      ((Integer) retVal$5$1[0]).intValue() == 0 &&
                      ((Integer) retVal$5$1[1]).intValue() == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(5) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 5;
                }
            }
            Object[] retVal$4$1 = null;
            if (arg1 != null) retVal$4$1 = arg1.Point$2();
            if (methodChosen != 4 && methodChosen != 5) {
                if (arg1 != null && retVal$4$1 != null && ((Integer) retVal$4$1[0]).intValue() == 0 &&
                      ((Integer) retVal$4$1[1]).intValue() == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(4) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 4;
                }
            }
            Object[] retVal$2$1 = null;
            if (arg1 != null) retVal$2$1 = arg1.Point$2();
            if (methodChosen != 2 && methodChosen != 4 && methodChosen != 5) {
                if (arg1 != null && retVal$2$1 != null) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(2) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 2;
                }
            }
            if (methodChosen != 3 && methodChosen != 1 && methodChosen != 2 && methodChosen != 4 && methodChosen != 5) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(3) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 3;
                }
            }
            switch (methodChosen) {
                case 1: return f$1(); case 5: return f$5(); case 4: return f$4(); case 2:
                    return f$2(arg1, ((Integer) retVal$2$1[0]).intValue(), ((Integer) retVal$2$1[1]).intValue());
                case 3: return f$3(arg1);
            }
        }
        throw new Error("No method found for call.");
    }
    
    void h(int arg1, int arg2, Class arg3, Class arg4) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 9) {
                if (arg1 == 0 && arg2 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(9) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 9;
                }
            }
            if (methodChosen != 7 && methodChosen != 9) {
                if (arg2 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(7) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 7;
                }
            }
            if (methodChosen != 8 && methodChosen != 9) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(8) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 8;
                }
            }
            if (methodChosen != 6 && methodChosen != 7 && methodChosen != 9 && methodChosen != 8) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(6) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 6;
                }
            }
            switch (methodChosen) {
                case 9:
                    h$9();
                    return;
                case 7:
                    h$7(arg1);
                    return;
                case 8:
                    h$8(arg2);
                    return;
                case 6:
                    h$6(arg1, arg2);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void h2(int arg1, int arg2, Class arg3, Class arg4) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 25) {
                if (arg2 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(25) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 25;
                }
            }
            if (methodChosen != 26 && methodChosen != 25) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(26) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 26;
                }
            }
            if (methodChosen != 10 && methodChosen != 26 && methodChosen != 25) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(10) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 10;
                }
            }
            switch (methodChosen) {
                case 25:
                    h2$25(arg1);
                    return;
                case 26:
                    h2$26(arg2);
                    return;
                case 10:
                    h2$10(arg1, arg2);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(int arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 14) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(14) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 14;
                }
            }
            if (methodChosen != 13 && methodChosen != 14) {
                if (arg1 == 0.0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(13) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 13;
                }
            }
            if (methodChosen != 12 && methodChosen != 13 && methodChosen != 14) {
                if (arg2 == null || byte.class.equals(arg2) || (arg2 == null || short.class.equals(arg2))) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(12) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 12;
                }
            }
            if (methodChosen != 11 && methodChosen != 12 && methodChosen != 13 && methodChosen != 14) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(11) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 11;
                }
            }
            switch (methodChosen) {
                case 14:
                    g$14();
                    return;
                case 13:
                    g$13();
                    return;
                case 12:
                    g$12((short) arg1);
                    return;
                case 11:
                    g$11(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void g(short arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 14) {
                if (arg1 == 0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(14) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 14;
                }
            }
            if (methodChosen != 13 && methodChosen != 14) {
                if (arg1 == 0.0) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(13) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 13;
                }
            }
            if (methodChosen != 12 && methodChosen != 13 && methodChosen != 14) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(12) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 12;
                }
            }
            switch (methodChosen) {
                case 14:
                    g$14();
                    return;
                case 13:
                    g$13();
                    return;
                case 12:
                    g$12(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    static void i(A arg1, Class arg2)throws Exception {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 15) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(15) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 15;
                }
            }
            switch (methodChosen) {
                case 15:
                    i$15(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void testNestedPat(Rect arg1, Class arg2) {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$17$1 = null;
            if (arg1 instanceof ScreenArea &&
                  (arg2 == null || ScreenArea.class.isAssignableFrom(arg2) ||
                     arg2.isAssignableFrom(ScreenArea.class)) &&
                  arg1 != null)
                retVal$17$1 = ((ScreenArea) arg1).Rect$2();
            Object[] retVal$17$1$1 = null;
            if (retVal$17$1 != null && retVal$17$1[0] != null) retVal$17$1$1 = ((Point) retVal$17$1[0]).Point$2();
            if (methodChosen != 17) {
                if (arg1 instanceof ScreenArea &&
                      (arg2 == null || ScreenArea.class.isAssignableFrom(arg2) ||
                         arg2.isAssignableFrom(ScreenArea.class)) &&
                      arg1 != null &&
                      retVal$17$1 != null &&
                      (retVal$17$1 != null && retVal$17$1[0] != null && retVal$17$1$1 != null &&
                         ((Integer) retVal$17$1$1[0]).intValue() == 0 &&
                         ((Integer) retVal$17$1$1[1]).intValue() == 1)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(17) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 17;
                }
            }
            if (methodChosen != 16 && methodChosen != 17) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(16) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 16;
                }
            }
            switch (methodChosen) {
                case 17:
                    testNestedPat$17((Point) retVal$17$1[1]);
                    return;
                case 16:
                    testNestedPat$16(arg1);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void testNullSem(A arg1, A arg2, Class arg3, Class arg4)throws Exception {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$19$2 = null;
            if (arg2 != null) retVal$19$2 = arg2.A$1();
            if (methodChosen != 19) {
                if ((arg1 instanceof B &&
                       (arg3 == null || B.class.isAssignableFrom(arg3) || arg3.isAssignableFrom(B.class)) ||
                       arg1 == null && (arg3 == null || B.class.isAssignableFrom(arg3))) &&
                      (arg2 != null && retVal$19$2 != null && ((Integer) retVal$19$2[0]).intValue() == 0)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(19) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 19;
                }
            }
            if (methodChosen != 18 && methodChosen != 19) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(18) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 18;
                }
            }
            switch (methodChosen) {
                case 19:
                    testNullSem$19((B) arg1);
                    return;
                case 18:
                    testNullSem$18(arg1, arg2);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void testMethSem(int arg1, A arg2, Class arg3, Class arg4)throws Exception {
        int methodChosen = 0;
        {  }
        {
            Object[] retVal$21$2 = null;
            if (arg2 != null) retVal$21$2 = arg2.A$1();
            if (methodChosen != 21) {
                if ((arg3 == null || byte.class.equals(arg3) || (arg3 == null || short.class.equals(arg3))) &&
                      (arg2 != null && retVal$21$2 != null && ((Integer) retVal$21$2[0]).intValue() == 0)) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(21) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 21;
                }
            }
            if (methodChosen != 20 && methodChosen != 21) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(20) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 20;
                }
            }
            switch (methodChosen) {
                case 21:
                    testMethSem$21((short) arg1);
                    return;
                case 20:
                    testMethSem$20(arg1, arg2);
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    void doMain()throws Exception {
        int methodChosen = 0;
        {  }
        {
            if (methodChosen != 23) {
                if (true) {
                    if (methodChosen != 0)
                        throw new Error("The following 2 methods are ambiguous:\n" +
                                        (messageFor1$(23) + (" and \n" + messageFor1$(methodChosen))) +
                                        " in class RectTest.\n");
                    methodChosen = 23;
                }
            }
            switch (methodChosen) {
                case 23:
                    doMain$23();
                    return;
            }
        }
        throw new Error("No method found for call.");
    }
    
    public static String messageFor1$(int m) {
        switch (m) {
            case 3: return "method static int f(Point)"; case 1: return "method static int f(null)"; case 2:
                return "method static int f(Point.Point(int, int))"; case 4:
                return "method static int f(Point.Point(0, 0))"; case 5:
                return "method static int f(CoorPoint.Point(0, 0))"; case 6: return "method  void h(int, int)"; case 7:
                return "method  void h(int, 0)"; case 9: return "method  void h(0, 0)"; case 8:
                return "method  void h(0, int)"; case 10: return "method  void h2(int, int)"; case 26:
                return "method  void h2(0, int)"; case 25: return "method  void h2(int, 0)"; case 11:
                return "method  void g(int)"; case 12: return "method  void g(short)"; case 13:
                return "method  void g(0.0)"; case 14: return "method  void g(0)"; case 15:
                return "method static void i(A) throws java.lang.Exception"; case 16:
                return "method  void testNestedPat(Rect)"; case 17:
                return ("method  void testNestedPat(ScreenArea.Rect(Point.Point(0, 1)" + ", Point))"); case 18:
                return "method  void testNullSem(A, A) throws java.lang.Exception"; case 19:
                return ("method  void testNullSem(B, A.A(0)) throws java.lang.Excepti" + "on"); case 20:
                return "method  void testMethSem(int, A) throws java.lang.Exception"; case 21:
                return ("method  void testMethSem(short, A.A(0)) throws java.lang.Exc" + "eption"); case 22:
                return ("method public static void main(java.lang.String[]) throws ja" + "va.lang.Exception"); case 23:
                return "method  void doMain() throws java.lang.Exception"; case 24:
                return "constructor public RectTest()";
        }
        return "";
    }
    
    public static final String jlc$CompilerVersion$jl = "1.3.4";
    
    public static final long jlc$SourceLastModified$jl = 1181668214000L;
    
    public static final String jlc$ClassType$jl =
      ("rO0ABXNyACtwb2x5Z2xvdC5leHQub29tYXRjaC50eXBlcy5PT01hdGNoQ2xh" +
       "c3NUeXBlAAAAAB18\nKKkCAANMAA5kZWNvbnN0cnVjdG9yc3QAEExqYXZhL3" +
       "V0aWwvTGlzdDtMAAtkb2xsYXJTaWduc3QA\nEkxqYXZhL2xhbmcvU3RyaW5n" +
       "O0wAD3JlbW92ZWRUb3BMZXZlbHEAfgABeHIAJ3BvbHlnbG90LmV4\ndC5qbC" +
       "50eXBlcy5QYXJzZWRDbGFzc1R5cGVfY00lIStq+PKgAgAMWgAPaW5TdGF0aW" +
       "NDb250ZXh0\nTAAMY29uc3RydWN0b3JzcQB+AAFMAAZmaWVsZHNxAH4AAUwA" +
       "BWZsYWdzdAAWTHBvbHlnbG90L3R5\ncGVzL0ZsYWdzO0wACmludGVyZmFjZX" +
       "NxAH4AAUwABGtpbmR0AB9McG9seWdsb3QvdHlwZXMvQ2xh\nc3NUeXBlJEtp" +
       "bmQ7TAANbWVtYmVyQ2xhc3Nlc3EAfgABTAAHbWV0aG9kc3EAfgABTAAEbmFt" +
       "ZXEA\nfgACTAAFb3V0ZXJ0ABpMcG9seWdsb3QvdHlwZXMvQ2xhc3NUeXBlO0" +
       "wACHBhY2thZ2VfdAAYTHBv\nbHlnbG90L3R5cGVzL1BhY2thZ2U7TAAJc3Vw" +
       "ZXJUeXBldAAVTHBvbHlnbG90L3R5cGVzL1R5cGU7\neHIAIXBvbHlnbG90Lm" +
       "V4dC5qbC50eXBlcy5DbGFzc1R5cGVfY5d4uxv8VK95AgAAeHIAJXBvbHln\n" +
       "bG90LmV4dC5qbC50eXBlcy5SZWZlcmVuY2VUeXBlX2MDe90v7Lj9sAIAAHhy" +
       "ABxwb2x5Z2xvdC5l\neHQuamwudHlwZXMuVHlwZV9j7231ZP7TUZMDAAB4cg" +
       "AicG9seWdsb3QuZXh0LmpsLnR5cGVzLlR5\ncGVPYmplY3RfY18H7Y3oGVW3" +
       "AwABTAAIcG9zaXRpb250ABhMcG9seWdsb3QvdXRpbC9Qb3NpdGlv\nbjt4cH" +
       "NyABZwb2x5Z2xvdC51dGlsLlBvc2l0aW9uwFLGWYCqZesCAAVJAAZjb2x1bW" +
       "5JAAllbmRD\nb2x1bW5JAAdlbmRMaW5lSQAEbGluZUwABGZpbGVxAH4AAnhw" +
       "AAAABwAAAAEAAAC8AAAAPnQADFJl\nY3RUZXN0Lm9vbXh0AAhSZWN0VGVzdH" +
       "B4AHNyABdwb2x5Z2xvdC51dGlsLlR5cGVkTGlzdOyyOxCO\nLXO2AgADWgAJ" +
       "aW1tdXRhYmxlTAAMYWxsb3dlZF90eXBldAARTGphdmEvbGFuZy9DbGFzcztM" +
       "AAxi\nYWNraW5nX2xpc3RxAH4AAXhwAHZyACJwb2x5Z2xvdC50eXBlcy5Db2" +
       "5zdHJ1Y3Rvckluc3RhbmNl\nF2c+oLhulyMCAAB4cHNyABRqYXZhLnV0aWwu" +
       "TGlua2VkTGlzdAwpU11KYIgiAwAAeHB3BAAAAAFz\ncgA1cG9seWdsb3QuZX" +
       "h0Lm9vbWF0Y2gudHlwZXMuT09NYXRjaENvbnN0cnVjdG9ySW5zdGFuY2UA\n" +
       "AAAAFEBktgIAB0kAAmlkSQAKanVua1BhcmFtc1oADG5vRGlzcGF0Y2hlckwA" +
       "CGNoaWxkcmVucQB+\nAAFbAAxpc05hbWVkUGFyYW10AAJbWkwACnBhcmFtVH" +
       "lwZXNxAH4AAUwACHJlYWxOYW1lcQB+AAJ4\ncgArcG9seWdsb3QuZXh0Lmps" +
       "LnR5cGVzLkNvbnN0cnVjdG9ySW5zdGFuY2VfY8ChKwwDstPoAgAA\neHIAKX" +
       "BvbHlnbG90LmV4dC5qbC50eXBlcy5Qcm9jZWR1cmVJbnN0YW5jZV9jxQZ7Ao" +
       "mG5WsCAARM\nAAljb250YWluZXJ0AB5McG9seWdsb3QvdHlwZXMvUmVmZXJl" +
       "bmNlVHlwZTtMAAhleGNUeXBlc3EA\nfgABTAAFZmxhZ3NxAH4ABEwAC2Zvcm" +
       "1hbFR5cGVzcQB+AAF4cQB+AAxxAH4AEHhxAH4ADnNxAH4A\nEwF2cgATcG9s" +
       "eWdsb3QudHlwZXMuVHlwZfVR0ap1zCZPAgAAeHBzcgATamF2YS51dGlsLkFy" +
       "cmF5\nTGlzdHiB0h2Zx2GdAwABSQAEc2l6ZXhwAAAAAHcEAAAAAHhzcgAUcG" +
       "9seWdsb3QudHlwZXMuRmxh\nZ3Pa/7bw3cYgAwIAAUoABGJpdHN4cAAAAAAA" +
       "AAABc3EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAA\nAHgAAAAYAAAAAABzcQ" +
       "B+ABh3BAAAAAB4cHNyAB9qYXZhLnV0aWwuQ29sbGVjdGlvbnMkRW1wdHlM\n" +
       "aXN0ergXtDynnt4CAAB4cHQAC1JlY3RUZXN0JDI0eHNxAH4AEwB2cgAccG9s" +
       "eWdsb3QudHlwZXMu\nRmllbGRJbnN0YW5jZdRnviDT7YphAgAAeHBzcQB+AB" +
       "h3BAAAAAJzcgAlcG9seWdsb3QuZXh0Lmps\nLnR5cGVzLkZpZWxkSW5zdGFu" +
       "Y2VfY5HA+XOq+4n7AgABTAAJY29udGFpbmVycQB+AB54cgAjcG9s\neWdsb3" +
       "QuZXh0LmpsLnR5cGVzLlZhckluc3RhbmNlX2OfA1uVPUbcxwIABVoACmlzQ2" +
       "9uc3RhbnRM\nAA1jb25zdGFudFZhbHVldAASTGphdmEvbGFuZy9PYmplY3Q7" +
       "TAAFZmxhZ3NxAH4ABEwABG5hbWVx\nAH4AAkwABHR5cGVxAH4ACHhxAH4ADH" +
       "NxAH4ADwAAAAcAAAANAAAAQAAAAEBxAH4AEXgAcHNxAH4A\nJQAAAAAAAAAI" +
       "dAABeHNyACVwb2x5Z2xvdC5leHQuamwudHlwZXMuUHJpbWl0aXZlVHlwZV9j" +
       "71Pr\nGvcKEsQCAAFMAARraW5kdAAjTHBvbHlnbG90L3R5cGVzL1ByaW1pdG" +
       "l2ZVR5cGUkS2luZDt4cQB+\nAAtweHQAA2ludHB4c3IAIXBvbHlnbG90LnR5" +
       "cGVzLlByaW1pdGl2ZVR5cGUkS2luZMQrIax+Ut5i\nAgAAeHIAEnBvbHlnbG" +
       "90LnV0aWwuRW51bbDk3swnbMoJAgABTAAEbmFtZXEAfgACeHBxAH4AO3EA\n" +
       "fgAOc3EAfgAxc3EAfgAPAAAABwAAAA8AAABBAAAAQXEAfgAReABwcQB+ADZ0" +
       "AAFhc3IAI3BvbHln\nbG90LmV4dC5qbC50eXBlcy5QbGFjZUhvbGRlcl9jSv" +
       "TWWjbIvHQCAAFMAARuYW1lcQB+AAJ4cHQA\nBVBvaW50cQB+AA54c3EAfgAl" +
       "AAAAAAAAAAFzcQB+ABMAcQB+ACJzcQB+ABh3BAAAAAB4c3IAHXBv\nbHlnbG" +
       "90LnR5cGVzLkNsYXNzVHlwZSRLaW5kh1jxDIZhxF0CAAB4cQB+AD10AAl0b3" +
       "AtbGV2ZWxz\ncQB+ABMAcQB+ACJzcQB+ABh3BAAAAAB4c3EAfgATAHZyAB1w" +
       "b2x5Z2xvdC50eXBlcy5NZXRob2RJ\nbnN0YW5jZVxkhQgJKXzpAgAAeHBzcQ" +
       "B+ABh3BAAAAAtzcgAwcG9seWdsb3QuZXh0Lm9vbWF0Y2gu\ndHlwZXMuT09N" +
       "YXRjaE1ldGhvZEluc3RhbmNlAAAAACwdpH8CAAhaAA5oYXNXaGVyZUNsYXVz" +
       "ZUkA\nAmlkWgAMbm9EaXNwYXRjaGVyTAAFY2hpbGR0AB9McG9seWdsb3QvdH" +
       "lwZXMvTWV0aG9kSW5zdGFu\nY2U7TAAIY2hpbGRyZW5xAH4AAVsADGlzTmFt" +
       "ZWRQYXJhbXEAfgAbTAAKcGFyYW1UeXBlc3EAfgAB\nTAAIcmVhbE5hbWVxAH" +
       "4AAnhyACZwb2x5Z2xvdC5leHQuamwudHlwZXMuTWV0aG9kSW5zdGFuY2Vf\n" +
       "Y4xXCMkBC2X7AgACTAAEbmFtZXEAfgACTAAKcmV0dXJuVHlwZXEAfgAIeHEA" +
       "fgAdc3EAfgAPAAAA\nCwAAABkAAABPAAAAT3EAfgAReHEAfgAOc3EAfgATAX" +
       "EAfgAic3EAfgAjAAAAAHcEAAAAAHhxAH4A\nNnNxAH4AIwAAAAF3BAAAAAFx" +
       "AH4AQ3h0AAFmcQB+ADoAAAAAAwBwc3EAfgAYdwQAAAACc3EAfgBR\nc3EAfg" +
       "APAAAACwAAABYAAABJAAAASXEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfg" +
       "AjAAAAAHcE\nAAAAAHhxAH4ANnNxAH4AIwAAAAF3BAAAAAFzcgAgcG9seWds" +
       "b3QuZXh0LmpsLnR5cGVzLk51bGxU\neXBlX2OmVGj2p+bNQQIAAHhxAH4AC3" +
       "B4eHh0AAFmcQB+ADoAAAAAAQBwc3EAfgAYdwQAAAAAeHVy\nAAJbWlePIDkU" +
       "uF3iAgAAeHAAAAABAHNxAH4AGHcEAAAAAXNyACZwb2x5Z2xvdC5leHQub29t" +
       "YXRj\naC50eXBlcy5WYWx1ZVR5cGVfYwAAAAAEB4wPAgACTAANY29uc3Rhbn" +
       "RWYWx1ZXEAfgAzTAALdHlw\nZU9mVmFsdWVxAH4ACHhxAH4AC3NxAH4ADwAA" +
       "ABEAAAAVAAAASQAAAElxAH4AEXh4cHEAfgBheHQA\nA2YkMXNxAH4AUXNxAH" +
       "4ADwAAAAgAAAAkAAAASgAAAEpxAH4AEXhxAH4ADnNxAH4AEwFxAH4AInNx\n" +
       "AH4AIwAAAAB3BAAAAAB4cQB+ADZzcQB+ACMAAAABdwQAAAABcQB+AEN4dAAB" +
       "ZnEAfgA6AAAAAAIA\ncHNxAH4AGHcEAAAAAXNxAH4AUXNxAH4ADwAAAAgAAA" +
       "AaAAAAUQAAAFFxAH4AEXhxAH4ADnNxAH4A\nEwFxAH4AInNxAH4AIwAAAAB3" +
       "BAAAAAB4cQB+ADZzcQB+ACMAAAABdwQAAAABcQB+AEN4dAABZnEA\nfgA6AA" +
       "AAAAQAcHNxAH4AGHcEAAAAAXNxAH4AUXNxAH4ADwAAAAsAAAAhAAAAVQAAAF" +
       "VxAH4AEXhx\nAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4cQB+" +
       "ADZzcQB+ACMAAAABdwQAAAABc3EA\nfgBCdAAJQ29vclBvaW50eHQAAWZxAH" +
       "4AOgAAAAAFAHBzcQB+ABh3BAAAAAB4dXEAfgBkAAAAAQBz\ncQB+ABh3BAAA" +
       "AAFzcgAocG9seWdsb3QuZXh0Lm9vbWF0Y2gudHlwZXMuUGF0dGVyblR5cGVf" +
       "YwAA\nAAAqAsQ4AgAFTAAFZGVjb250ADJMcG9seWdsb3QvZXh0L29vbWF0Y2" +
       "gvdHlwZXMvRGVjb25zdHJ1\nY3Rvckluc3RhbmNlO0wAEWRlY29uc3RydWN0" +
       "b3JUeXBlcQB+AAZbAAxpc05hbWVkUGFyYW1xAH4A\nG0wAB3BhdHRlcm5xAH" +
       "4AAUwAB3Zhck5hbWVxAH4AAnhxAH4AC3NxAH4ADwAAABEAAAAgAAAAVQAA\n" +
       "AFVxAH4AEXh4c3IAMHBvbHlnbG90LmV4dC5vb21hdGNoLnR5cGVzLkRlY29u" +
       "c3RydWN0b3JJbnN0\nYW5jZQAAAAAFsX40AgAFSQACaWRMAARuYW1lcQB+AA" +
       "JMAAZvblR5cGVxAH4ABkwACnBhcmFtTmFt\nZXNxAH4AAUwACHJlYWxOYW1l" +
       "cQB+AAJ4cQB+AB1zcQB+AA8AAAAEAAAAJQAAAAYAAAAGdAAJUG9p\nbnQub2" +
       "9teHEAfgBDc3EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHhzcQB+ACUAAA" +
       "AAAAAAAXNx\nAH4AEwFxAH4AInNxAH4AIwAAAAJ3BAAAAAJzcQB+ADhweHEA" +
       "fgA7cHhxAH4APnEAfgCReAAAAAJ0\nAAVQb2ludHBzcQB+ACMAAAACdwQAAA" +
       "ACdAABeHQAAXl4dAAHUG9pbnQkMnEAfgB+dXEAfgBkAAAA\nAgAAc3EAfgAY" +
       "dwQAAAACc3EAfgBnc3EAfgAPAAAAGwAAABwAAABVAAAAVXEAfgAReHhzcgAR" +
       "amF2\nYS5sYW5nLkludGVnZXIS4qCk94GHOAIAAUkABXZhbHVleHIAEGphdm" +
       "EubGFuZy5OdW1iZXKGrJUd\nC5TgiwIAAHhwAAAAAHEAfgA6c3EAfgBnc3EA" +
       "fgAPAAAAHgAAAB8AAABVAAAAVXEAfgAReHhzcQB+\nAJsAAAAAcQB+ADp4dA" +
       "AAeHQAA2YkNXh1cQB+AGQAAAABAHNxAH4AGHcEAAAAAXNxAH4AhHNxAH4A\n" +
       "DwAAAA4AAAAZAAAAUQAAAFFxAH4AEXh4cQB+AIlxAH4AQ3VxAH4AZAAAAAIA" +
       "AHNxAH4AGHcEAAAA\nAnNxAH4AZ3NxAH4ADwAAABQAAAAVAAAAUQAAAFFxAH" +
       "4AEXh4c3EAfgCbAAAAAHEAfgA6c3EAfgBn\nc3EAfgAPAAAAFwAAABgAAABR" +
       "AAAAUXEAfgAReHhzcQB+AJsAAAAAcQB+ADp4cQB+AKF4dAADZiQ0\neHVxAH" +
       "4AZAAAAAEAc3EAfgAYdwQAAAABc3EAfgCEc3EAfgAPAAAADgAAACMAAABKAA" +
       "AASnEAfgAR\neHhxAH4AiXEAfgBDdXEAfgBkAAAAAgAAc3EAfgAYdwQAAAAC" +
       "cQB+ADpxAH4AOnh0AAFweHQAA2Yk\nMnh1cQB+AGQAAAABAHNxAH4AGHcEAA" +
       "AAAXEAfgBDeHQAA2YkM3NxAH4AUXNxAH4ADwAAAAEAAAAV\nAAAAWwAAAFtx" +
       "AH4AEXhxAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4c3EAfgAl" +
       "AAAA\nAAAAAABzcQB+ACMAAAACdwQAAAACcQB+ADpxAH4AOnh0AAFoc3EAfg" +
       "A4cHh0AAR2b2lkcHhzcQB+\nADxxAH4AwwAAAAAGAHBzcQB+ABh3BAAAAAJz" +
       "cQB+AFFzcQB+AA8AAAABAAAAEQAAAFwAAABccQB+\nABF4cQB+AA5zcQB+AB" +
       "MBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeHEAfgC/c3EAfgAjAAAAAncEAAAA\n" +
       "AnEAfgA6cQB+ADp4dAABaHEAfgDCAAAAAAcAcHNxAH4AGHcEAAAAAXNxAH4A" +
       "UXNxAH4ADwAAAAEA\nAAANAAAAXgAAAF5xAH4AEXhxAH4ADnNxAH4AEwFxAH" +
       "4AInNxAH4AIwAAAAB3BAAAAAB4cQB+AL9z\ncQB+ACMAAAACdwQAAAACcQB+" +
       "ADpxAH4AOnh0AAFocQB+AMIAAAAACQBwc3EAfgAYdwQAAAAAeHVx\nAH4AZA" +
       "AAAAIAAHNxAH4AGHcEAAAAAnNxAH4AZ3NxAH4ADwAAAAgAAAAJAAAAXgAAAF" +
       "5xAH4AEXh4\nc3EAfgCbAAAAAHEAfgA6c3EAfgBnc3EAfgAPAAAACwAAAAwA" +
       "AABeAAAAXnEAfgAReHhzcQB+AJsA\nAAAAcQB+ADp4dAADaCQ5eHVxAH4AZA" +
       "AAAAIAAHNxAH4AGHcEAAAAAnEAfgA6c3EAfgBnc3EAfgAP\nAAAADwAAABAA" +
       "AABcAAAAXHEAfgAReHhzcQB+AJsAAAAAcQB+ADp4dAADaCQ3c3EAfgBRc3EA" +
       "fgAP\nAAAAAQAAABEAAABdAAAAXXEAfgAReHEAfgAOc3EAfgATAXEAfgAic3" +
       "EAfgAjAAAAAHcEAAAAAHhx\nAH4Av3NxAH4AIwAAAAJ3BAAAAAJxAH4AOnEA" +
       "fgA6eHQAAWhxAH4AwgAAAAAIAHBzcQB+ABh3BAAA\nAAFxAH4AzXh1cQB+AG" +
       "QAAAACAABzcQB+ABh3BAAAAAJzcQB+AGdzcQB+AA8AAAAIAAAACQAAAF0A\n" +
       "AABdcQB+ABF4eHNxAH4AmwAAAABxAH4AOnEAfgA6eHQAA2gkOHh1cQB+AGQA" +
       "AAACAABzcQB+ABh3\nBAAAAAJxAH4AOnEAfgA6eHQAA2gkNnNxAH4AUXNxAH" +
       "4ADwAAAAEAAAAWAAAAYQAAAGFxAH4AEXhx\nAH4ADnNxAH4AEwFxAH4AInNx" +
       "AH4AIwAAAAB3BAAAAAB4cQB+AL9zcQB+ACMAAAACdwQAAAACcQB+\nADpxAH" +
       "4AOnh0AAJoMnEAfgDCAAAAAAoAcHNxAH4AGHcEAAAAAXNxAH4AUXNxAH4ADw" +
       "AAAAIAAAAT\nAAAAYwAAAGNxAH4AEXhxAH4ADnNxAH4AEwFxAH4AInNxAH4A" +
       "IwAAAAB3BAAAAAB4cQB+AL9zcQB+\nACMAAAACdwQAAAACcQB+ADpxAH4AOn" +
       "h0AAJoMnEAfgDCAAAAABoAc3EAfgBRc3EAfgAPAAAAAQAA\nABIAAABiAAAA" +
       "YnEAfgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHhxAH4A" +
       "v3Nx\nAH4AIwAAAAJ3BAAAAAJxAH4AOnEAfgA6eHQAAmgycQB+AMIAAAAAGQ" +
       "Bwc3EAfgAYdwQAAAAAeHVx\nAH4AZAAAAAIAAHNxAH4AGHcEAAAAAnEAfgA6" +
       "c3EAfgBnc3EAfgAPAAAAEAAAABEAAABiAAAAYnEA\nfgAReHhzcQB+AJsAAA" +
       "AAcQB+ADp4dAAFaDIkMjVzcQB+ABh3BAAAAAFxAH4BAHh1cQB+AGQAAAAC\n" +
       "AABzcQB+ABh3BAAAAAJzcQB+AGdzcQB+AA8AAAAKAAAACwAAAGMAAABjcQB+" +
       "ABF4eHNxAH4AmwAA\nAABxAH4AOnEAfgA6eHQABWgyJDI2eHVxAH4AZAAAAA" +
       "IAAHNxAH4AGHcEAAAAAnEAfgA6cQB+ADp4\ndAAFaDIkMTBzcQB+AFFzcQB+" +
       "AA8AAAAEAAAAEQAAAGgAAABocQB+ABF4cQB+AA5zcQB+ABMBcQB+\nACJzcQ" +
       "B+ACMAAAAAdwQAAAAAeHEAfgC/c3EAfgAjAAAAAXcEAAAAAXEAfgA6eHQAAW" +
       "dxAH4AwgAA\nAAALAHBzcQB+ABh3BAAAAAFzcQB+AFFzcQB+AA8AAAAEAAAA" +
       "EwAAAGoAAABqcQB+ABF4cQB+AA5z\ncQB+ABMBcQB+ACJzcQB+ACMAAAAAdw" +
       "QAAAAAeHEAfgC/c3EAfgAjAAAAAXcEAAAAAXNxAH4AOHB4\ndAAFc2hvcnRw" +
       "eHNxAH4APHEAfgEkeHQAAWdxAH4AwgAAAAAMAHBzcQB+ABh3BAAAAAFzcQB+" +
       "AFFz\ncQB+AA8AAAAEAAAADwAAAGsAAABrcQB+ABF4cQB+AA5zcQB+ABMBcQ" +
       "B+ACJzcQB+ACMAAAAAdwQA\nAAAAeHEAfgC/c3EAfgAjAAAAAXcEAAAAAXNx" +
       "AH4AOHB4dAAGZG91YmxlcHhzcQB+ADxxAH4BLnh0\nAAFncQB+AMIAAAAADQ" +
       "Bwc3EAfgAYdwQAAAABc3EAfgBRc3EAfgAPAAAABAAAAA0AAABuAAAAbnEA\n" +
       "fgAReHEAfgAOc3EAfgATAXEAfgAic3EAfgAjAAAAAHcEAAAAAHhxAH4Av3Nx" +
       "AH4AIwAAAAF3BAAA\nAAFxAH4AOnh0AAFncQB+AMIAAAAADgBwc3EAfgAYdw" +
       "QAAAAAeHVxAH4AZAAAAAEAc3EAfgAYdwQA\nAAABc3EAfgBnc3EAfgAPAAAA" +
       "CwAAAAwAAABuAAAAbnEAfgAReHhzcQB+AJsAAAAAcQB+ADp4dAAE\nZyQxNH" +
       "h1cQB+AGQAAAABAHNxAH4AGHcEAAAAAXNxAH4AZ3NxAH4ADwAAAAsAAAAOAA" +
       "AAawAAAGtx\nAH4AEXh4c3IAEGphdmEubGFuZy5Eb3VibGWAs8JKKWv7BAIA" +
       "AUQABXZhbHVleHEAfgCcAAAAAAAA\nAABxAH4BLXh0AARnJDEzeHVxAH4AZA" +
       "AAAAEAc3EAfgAYdwQAAAABcQB+ASN4dAAEZyQxMnh1cQB+\nAGQAAAABAHNx" +
       "AH4AGHcEAAAAAXEAfgA6eHQABGckMTFxAH4BHnNxAH4AUXNxAH4ADwAAAAsA" +
       "AAAW\nAAAAcwAAAHNxAH4AEXhxAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAA" +
       "F3BAAAAAFzcQB+AEJ0ABNq\nYXZhLmxhbmcuRXhjZXB0aW9ueHEAfgA2c3EA" +
       "fgAjAAAAAXcEAAAAAXNxAH4AQnQAAUF4dAABaXEA\nfgDCAAAAAA8AcHNxAH" +
       "4AGHcEAAAAAHh1cQB+AGQAAAABAHNxAH4AGHcEAAAAAXEAfgFTeHQABGkk\n" +
       "MTVzcQB+AFFzcQB+AA8AAAAEAAAAHgAAAHUAAAB1cQB+ABF4cQB+AA5zcQB+" +
       "ABMBcQB+ACJzcQB+\nACMAAAAAdwQAAAAAeHEAfgC/c3EAfgAjAAAAAXcEAA" +
       "AAAXNxAH4AQnQABFJlY3R4dAANdGVzdE5l\nc3RlZFBhdHEAfgDCAAAAABAA" +
       "cHNxAH4AGHcEAAAAAXNxAH4AUXNxAH4ADwAAAAQAAAA4AAAAegAA\nAHpxAH" +
       "4AEXhxAH4ADnNxAH4AEwFxAH4AInNxAH4AIwAAAAB3BAAAAAB4cQB+AL9zcQ" +
       "B+ACMAAAAB\ndwQAAAABc3EAfgBCdAAKU2NyZWVuQXJlYXh0AA10ZXN0TmVz" +
       "dGVkUGF0cQB+AMIAAAAAEQBwc3EA\nfgAYdwQAAAAAeHVxAH4AZAAAAAEAc3" +
       "EAfgAYdwQAAAABc3EAfgCEc3EAfgAPAAAAFwAAADcAAAB6\nAAAAenEAfgAR" +
       "eHhzcQB+AIhzcQB+AA8AAAAEAAAAOAAAAAcAAAAHdAAIUmVjdC5vb214cQB+" +
       "AV9z\ncQB+ABMBcQB+ACJzcQB+ACMAAAAAdwQAAAAAeHNxAH4AJQAAAAAAAA" +
       "ABc3EAfgATAXEAfgAic3EA\nfgAjAAAAAncEAAAAAnEAfgBDcQB+AEN4AAAA" +
       "AnQABFJlY3Rwc3EAfgAjAAAAAncEAAAAAnQAB3Rv\ncExlZnR0AAtib3R0b2" +
       "1SaWdodHh0AAZSZWN0JDJxAH4BaHVxAH4AZAAAAAIAAHNxAH4AGHcEAAAA\n" +
       "AnNxAH4AhHNxAH4ADwAAACIAAAAtAAAAegAAAHpxAH4AEXh4cQB+AIlxAH4A" +
       "Q3VxAH4AZAAAAAIA\nAHNxAH4AGHcEAAAAAnNxAH4AZ3NxAH4ADwAAACgAAA" +
       "ApAAAAegAAAHpxAH4AEXh4c3EAfgCbAAAA\nAHEAfgA6c3EAfgBnc3EAfgAP" +
       "AAAAKwAAACwAAAB6AAAAenEAfgAReHhzcQB+AJsAAAABcQB+ADp4\ncQB+AK" +
       "FxAH4AQ3hxAH4AoXh0ABB0ZXN0TmVzdGVkUGF0JDE3eHVxAH4AZAAAAAEAc3" +
       "EAfgAYdwQA\nAAABcQB+AV94dAAQdGVzdE5lc3RlZFBhdCQxNnNxAH4AUXNx" +
       "AH4ADwAAAAQAAAAgAAAAfwAAAH9x\nAH4AEXhxAH4ADnNxAH4AEwFxAH4AIn" +
       "NxAH4AIwAAAAF3BAAAAAFxAH4BUHhxAH4Av3NxAH4AIwAA\nAAJ3BAAAAAJx" +
       "AH4BU3EAfgFTeHQAC3Rlc3ROdWxsU2VtcQB+AMIAAAAAEgBwc3EAfgAYdwQA" +
       "AAAB\nc3EAfgBRc3EAfgAPAAAABAAAAB8AAACCAAAAgnEAfgAReHEAfgAOc3" +
       "EAfgATAXEAfgAic3EAfgAj\nAAAAAXcEAAAAAXEAfgFQeHEAfgC/c3EAfgAj" +
       "AAAAAncEAAAAAnNxAH4AQnQAAUJxAH4BU3h0AAt0\nZXN0TnVsbFNlbXEAfg" +
       "DCAAAAABMAcHNxAH4AGHcEAAAAAHh1cQB+AGQAAAACAABzcQB+ABh3BAAA\n" +
       "AAJxAH4BmXNxAH4AhHNxAH4ADwAAABoAAAAeAAAAggAAAIJxAH4AEXh4c3EA" +
       "fgCIc3EAfgAPAAAA\nBAAAABoAAAAVAAAAFXEAfgAReHEAfgFTc3EAfgATAX" +
       "EAfgAic3EAfgAjAAAAAXcEAAAAAXEAfgFQ\neHNxAH4AJQAAAAAAAAABc3EA" +
       "fgATAXEAfgAic3EAfgAjAAAAAXcEAAAAAXEAfgA6eAAAAAF0AAFB\ncHNxAH" +
       "4AIwAAAAF3BAAAAAF0AAF4eHQAA0EkMXEAfgFTdXEAfgBkAAAAAQBzcQB+AB" +
       "h3BAAAAAFz\ncQB+AGdzcQB+AA8AAAAcAAAAHQAAAIIAAACCcQB+ABF4eHNx" +
       "AH4AmwAAAABxAH4AOnhxAH4AoXh0\nAA50ZXN0TnVsbFNlbSQxOXh1cQB+AG" +
       "QAAAACAABzcQB+ABh3BAAAAAJxAH4BU3EAfgFTeHQADnRl\nc3ROdWxsU2Vt" +
       "JDE4c3EAfgBRc3EAfgAPAAAABAAAACIAAACGAAAAhnEAfgAReHEAfgAOc3EA" +
       "fgAT\nAXEAfgAic3EAfgAjAAAAAXcEAAAAAXEAfgFQeHEAfgC/c3EAfgAjAA" +
       "AAAncEAAAAAnEAfgA6cQB+\nAVN4dAALdGVzdE1ldGhTZW1xAH4AwgAAAAAU" +
       "AHBzcQB+ABh3BAAAAAFzcQB+AFFzcQB+AA8AAAAE\nAAAAIwAAAIkAAACJcQ" +
       "B+ABF4cQB+AA5zcQB+ABMBcQB+ACJzcQB+ACMAAAABdwQAAAABcQB+AVB4\n" +
       "cQB+AL9zcQB+ACMAAAACdwQAAAACcQB+ASNxAH4BU3h0AAt0ZXN0TWV0aFNl" +
       "bXEAfgDCAAAAABUA\ncHNxAH4AGHcEAAAAAHh1cQB+AGQAAAACAABzcQB+AB" +
       "h3BAAAAAJxAH4BI3NxAH4AhHNxAH4ADwAA\nAB4AAAAiAAAAiQAAAIlxAH4A" +
       "EXh4cQB+AaFxAH4BU3VxAH4AZAAAAAEAc3EAfgAYdwQAAAABc3EA\nfgBnc3" +
       "EAfgAPAAAAIAAAACEAAACJAAAAiXEAfgAReHhzcQB+AJsAAAAAcQB+ADp4cQ" +
       "B+AKF4dAAO\ndGVzdE1ldGhTZW0kMjF4dXEAfgBkAAAAAgAAc3EAfgAYdwQA" +
       "AAACcQB+ADpxAH4BU3h0AA50ZXN0\nTWV0aFNlbSQyMHNxAH4AUXNxAH4ADw" +
       "AAAA8AAAAnAAAAjQAAAI1xAH4AEXhxAH4ADnNxAH4AEwFx\nAH4AInNxAH4A" +
       "IwAAAAF3BAAAAAFxAH4BUHhzcQB+ACUAAAAAAAAACXNxAH4AIwAAAAF3BAAA" +
       "AAFz\ncgAhcG9seWdsb3QuZXh0LmpsLnR5cGVzLkFycmF5VHlwZV9jPcvH1I" +
       "atQB0CAARMAARiYXNlcQB+\nAAhMAAZmaWVsZHNxAH4AAUwACmludGVyZmFj" +
       "ZXNxAH4AAUwAB21ldGhvZHNxAH4AAXhxAH4ACnNx\nAH4ADwAAABkAAAAfAA" +
       "AAjQAAAI1xAH4AEXh4c3EAfgBCdAAQamF2YS5sYW5nLlN0cmluZ3BwcHh0\n" +
       "AARtYWlucQB+AMIAAAAAFgBwc3EAfgAYdwQAAAAAeHVxAH4AZAAAAAEAc3EA" +
       "fgAYdwQAAAABcQB+\nAdd4cQB+AdtzcQB+AFFzcQB+AA8AAAAEAAAAEQAAAK" +
       "AAAACgcQB+ABF4cQB+AA5zcQB+ABMBcQB+\nACJzcQB+ACMAAAABdwQAAAAB" +
       "cQB+AVB4cQB+AL9zcQB+ACMAAAAAdwQAAAAAeHQABmRvTWFpbnEA\nfgDCAA" +
       "AAABcAcHNxAH4AGHcEAAAAAHh1cQB+AGQAAAAAc3EAfgAYdwQAAAAAeHQACW" +
       "RvTWFpbiQy\nM3hxAH4AEnBwc3EAfgBCdAAQamF2YS5sYW5nLk9iamVjdHNx" +
       "AH4AGHcEAAAAAHh0AAEkc3EAfgAY\ndwQAAAAAeA==");
}
