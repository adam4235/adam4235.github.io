package polyglot.ext.oomatch.parse;

import polyglot.util.ErrorQueue;

/**Extend the generated lexer to add new keywords, rather than modifying
 * Polyglot's lexer
 */
public class OOMatchLexer extends Lexer_c {
    protected void init_keywords() 
    {
    	super.init_keywords();
        keywords.put("deconstructor", new Integer(sym.DECONSTRUCTOR));
        keywords.put("inc", new Integer(sym.INC));
        //keywords.put("select", new Integer(sym.SELECT));
        keywords.put("on", new Integer(sym.ON));
        keywords.put("let", new Integer(sym.LET));
        keywords.put("where", new Integer(sym.WHERE));

    }
	
    public OOMatchLexer(java.io.InputStream in, String file, ErrorQueue eq) {
        super(in, file, eq);
    }

    public OOMatchLexer(java.io.Reader reader, String file, ErrorQueue eq) {
        super(reader, file, eq);
    }

}
