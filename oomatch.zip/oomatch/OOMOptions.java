package polyglot.ext.oomatch;

import java.util.Set;

import polyglot.frontend.ExtensionInfo;
import polyglot.main.*;

/** Options object to allow new options allowed in OOMatch */
public class OOMOptions extends Options
{

    public OOMOptions(ExtensionInfo extension)
    {
        super(extension);
    }

    private boolean compatWarnings = false;
    public boolean compatWarnings() { return compatWarnings; }
    protected int parseCommand(String args[], int i, Set source) 
    throws UsageError, Main.TerminationException {
        if (args[i].equals("-compat-warnings"))
        {
            compatWarnings = true; 
            i++;
            return i;
        }
        else return super.parseCommand(args, i, source);
    }
}
