#ifndef BUILD_TN_FROM_TYPE_H
#define BUILD_TN_FROM_TYPE_H

class TypeNode;
class UserTypeNode;
class Type;

/** Create a new TypeNode (which will need memory management
 * or insertion into the AST) from a Type
 */
TypeNode* buildTNFromType(Type t);

/** Create a typenode to replace the UserTypeNode n, whose
target has been looked up (as refType)*/
TypeNode* buildUserTN(UserTypeNode* n, const Type& refType);

#endif

