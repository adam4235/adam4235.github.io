#ifndef TEMPNAME_H_
#define TEMPNAME_H_

#include <string>

using std::string;

/** Make up a temporary name, based on the prefix prefix,
 * and return it.
 * Later this will have to be changed
 * to not conflict with any other name in the input, by
 * using the symbol table.
 */
string tempName(string prefix);

#endif /*TEMPNAME_H_*/
