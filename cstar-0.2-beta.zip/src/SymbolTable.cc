/*Implementation file for SymbolTable.h.  See that file. */

#include "SymbolTable.h"
#include "ast/Function.h"
#include "ast/VarDecl.h"
#include "ast/Enum.h"

using namespace std;

//****Constructors/destructors*****

symtab_entry::symtab_entry(const Type& type, SymbolTable* parent, bool isDefn, Node* pointOfDefn, string realName)
	: type(type), parent(parent), pointOfDefnOrDecl(pointOfDefn), isDefn(isDefn), realName(realName)
{
	if (type.isFunction() || type.getType() == Type::BLOCK)
		//Entries which have a scope within them need a child symbol table
		child = new SymbolTable(this);
	else
		child = 0;
	assert(parent != 0);
}

symtab_entry::symtab_entry(const symtab_entry& c) 
	: type(c.type), parent(c.parent), 
	pointOfDefnOrDecl(c.pointOfDefnOrDecl), isDefn(c.isDefn), realName(c.realName)
{
	if (c.child == 0)
		child = 0;
	else
	{
	   //make a copy of the old SymbolTable, but ensure that its scope is set to
	   //this symtab_entry instead of that of the copy
		child = new SymbolTable(*c.child, this);
	}
}

symtab_entry::~symtab_entry()
{
	if (child != 0) delete child;
}

SymbolTable::SymbolTable(symtab_entry* scope) : 
	multimap<string, symtab_entry>(), scope(scope)
{
}

SymbolTable::SymbolTable(const SymbolTable& c, symtab_entry* scope) : 
	multimap<string, symtab_entry>(c), scope(scope)													 
{
}


//*****Add built-in operators*****

void SymbolTable::addOper(string name, const Type& op1, const Type& op2, Type retVal, string realName) {
	vector<Type> parameters;
	parameters.push_back(op1);
	if (op2.getType() != Type::VOID) parameters.push_back(op2);
	symtab_entry newEntry(Type(Type::FUNCTION, parameters, retVal), this, true, 0, realName);
	insert(make_pair(name, newEntry));
}

void SymbolTable::addRel(string oper) {
//These are all needed so that duplicate definitions can
//be prevented when users try to redefine the built-in operators.
	addOper(oper, Type::LDOUBLE, Type::LDOUBLE, Type::BOOL);
	addOper(oper, Type::DOUBLE, Type::DOUBLE, Type::BOOL);
	addOper(oper, Type::FLOAT, Type::FLOAT, Type::BOOL);
	addOper(oper, Type::INT, Type::INT, Type::BOOL);
}

void SymbolTable::addEquality(string oper) {
	addRel(oper);
	addOper(oper, Type::CHAR, Type::CHAR, Type::BOOL);
	addOper(oper, Type::BOOL, Type::BOOL, Type::BOOL);
}

void SymbolTable::addArithmetic(string oper, bool unary) {
    //We need all these different operators so that the result type will
    //be correct.
	addOper(oper, Type::DOUBLE, unary? Type::VOID : Type::DOUBLE, Type::DOUBLE);
	addOper(oper, Type::LDOUBLE, unary? Type::VOID : Type::LDOUBLE, Type::LDOUBLE);
	addOper(oper, Type::FLOAT, unary? Type::VOID : Type::FLOAT, Type::FLOAT);
	addOper(oper, Type::INT, unary? Type::VOID : Type::INT, Type::INT);
}

void SymbolTable::addBuiltIns() {
	assert(globalScope());

	//Arithmetic operators and the corresponding equality operators
	string arithOpers[] = { "+", "-", "*", "/", "%" };
	string eqOpers[] = { "=", "+=", "-=", "*=", "/=", "%=" };
	for (unsigned int i = 0; i < sizeof(arithOpers) / sizeof(string); ++i)
	{
		addArithmetic(arithOpers[i]);
		addArithmetic(eqOpers[i]);
	}
	
	addOper("\\", Type::INT, Type::INT, Type::INT); //, "__builtin_idiv11");
	addOper("\\=", Type::INT, Type::INT, Type::INT); //, "__builtin_idivequal11");
	addArithmetic("-", true);

	//Relational operators
	string relOpers[] = { "<", ">", "<=", ">=" };
	for (unsigned int i = 0; i < sizeof(relOpers) / sizeof(string); ++i)
	{
		addRel(relOpers[i]);
	}
	addEquality("==");
	addEquality("!=");

	//Logical operators
	addOper("and", Type::BOOL, Type::BOOL, Type::BOOL);
	addOper("or", Type::BOOL, Type::BOOL, Type::BOOL);
	addOper("not", Type::BOOL, Type::VOID, Type::BOOL);

	//Increment and decrement
	addOper("++", Type::INT, Type::VOID, Type::INT);
	addOper("--", Type::INT, Type::VOID, Type::INT);
    
    //Assert
	vector<Type> parameters;
	parameters.push_back(Type::BOOL);
	symtab_entry newEntry(Type(Type::FUNCTION, parameters, Type::VOID), this, true, 0);
	insert(make_pair("assert", newEntry));    
}


//******Add functions*******

SymbolTable::iterator 
SymbolTable::changeDefn(const string& name, const symtab_entry& newEntry) {
    if (newEntry.isDefn)  //Definition
    {
        assert(!hasDefn(name, newEntry.type));  //Can't have a duplicate defn
#ifdef DEBUG
        try {
            if (getPointOfDefn(name, newEntry.type) != 0) {
                cout << name << endl;
                cout << newEntry.type << endl;
            }
        }
        catch (SymbolNotFound s) {
            cout << name << endl;
            cout << newEntry.type << endl;
            assert(0 == 1);
        }
#endif
        return setPointOfDefn(name, newEntry.type, newEntry.pointOfDefnOrDecl);
          //Set it to have a definition
    }
    else return lookupInScope(name, newEntry.type);
}

bool SymbolTable::add(VarDecl* n, bool alwaysDefn)
{
	string variable = n->getName();
	Node* initVal = n->getInitVal();
	
	bool defn = (initVal != 0 || alwaysDefn);  //Whether it's a 
		//definition (as opposed to a declaration)

	symtab_entry newEntry(n->getTypeNode()->getType(), this, defn, n);
	
    if (existsThisScope(variable))
    {
        if (lookUpType(variable) != newEntry.type)
        	//It's an error to have 2 declarations (or a declaration and a definition) for
            //variables of the same name but different types.
            return false;
        else
        {
            changeDefn(variable, newEntry);
            return true;
        }
    }

	insert(make_pair(variable, newEntry));
	return true;
}

void SymbolTable::addLabel(const string& label)
{
    SymbolTable* toAddTo = currentFunction()->child;
    assert(!exists(label));
    symtab_entry newEntry(Type::LABEL, this, false, 0);
    toAddTo->insert(make_pair(label, newEntry));
}

void SymbolTable::addType(Node* n, string name, const Type& type)
{
	assert(name != "");

	//Add the enum type to the symbol table

	//if (existsThisScope(name)) return name;
	assert(!existsThisScope(name));

	Type t(Type::TYPE, type);
	symtab_entry newEntry(t, this, true, n);
	insert(make_pair(name, newEntry));
}

string SymbolTable::addEnumerators(Enum* n)
{
	//Add all the enumerators
	
	for (vector<string>::const_iterator i = n->getEnumerators().begin();
			i != n->getEnumerators().end(); ++i)
	{
		const string& enumerator = *i;

		vector<string> enumerators(1);  //Used to create the type
			//of the enumerator - it needs its name in the
			//type info.
		enumerators[0] = enumerator;

		if (existsThisScope(enumerator)) return enumerator;

		Type t(Type::ENUMERATOR, enumerators);
		symtab_entry newEntry(t, this, true, n);
		insert(make_pair(enumerator, newEntry));
	}
	return "";
}

SymbolTable* SymbolTable::addFunction(Function* n)
{
	string funcName = n->getName();
    string realName = "";
    if (n->isMainWithArgs())
    {
        realName = "__csMain11";
        argv_used = true;
    }
    else realName = findOpName(funcName);

    n->setRealName(realName);  //Store it in the function so it doesn't have
        //to be looked up later.
    
	Type t = n->getType();
	symtab_entry newEntry(t, this, (n->getBody() != 0), n, realName); 

    if (existsThisScope(funcName, newEntry.type))  //functions
        //can be overloaded, so it's only a redeclaration if
        //the types are the same.
        //It's OK if there are functions with different return types,
        //because they will just result in an ambiguity when you try
        //to call them.
    {
		iterator retVal = changeDefn(funcName, newEntry); 
		return retVal->second.child;        
    }
    
	return insertAndReturnEntry(funcName, newEntry).child;
	
//		return newEntry.child;    This doesn't work because newEntry was
//only a temporary symbol table entry that has been copied into the 
//symbol table.
//	return lookup(funcName).child;  This option would be inefficient
}

SymbolTable* SymbolTable::addScope(const string& name)
{
	symtab_entry newEntry(Type(Type::BLOCK), this, false, 0);
	return insertAndReturnEntry(name, newEntry).child;
}

const symtab_entry& SymbolTable::insertAndReturnEntry(const string& name, const symtab_entry& newEntry)
{
	//The insert method returns the thing inserted
	iterator ptrToEntry = insert(make_pair(name, newEntry));
    
	//The inserted thing was the <name, entry> pair - get the entry part of it
	const symtab_entry& actualNewEntry = ptrToEntry->second;
	return actualNewEntry;
}

//***Lookup functions***

SymbolTable::iterator 
SymbolTable::lookupInScope(const string& symbol, const Type& type)
{
	for (iterator i = begin(); i != end(); ++i)
	{
		if (i->first == symbol && i->second.type == type)
			return i;
	}
	throw SymbolNotFound();
}

vector<symtab_entry*> SymbolTable::lookup(const string& symbol, const Type& t, bool requireDefn)
{
	SymbolTable* symTableToCheck = this; 
	while (0 == 0)
	{
		vector<symtab_entry*> retVal;
		for (iterator i = symTableToCheck->begin(); i != symTableToCheck->end(); ++i)
		{
			if (i->first == symbol)
			{
                Type potentialMatchingType = i->second.type;
                bool matches = (t == Type::VOID || t == potentialMatchingType);
				if (matches &&
					(!requireDefn || (i->second).isDefn))
				{
					retVal.push_back(&(i->second));
					if (t != Type::VOID) return retVal;  //speed things up
				}
			}
		}
        
		if (retVal.size() > 0) return retVal;
		
		/*
		 It seems i->second is a reference to an existing object,
		 so it's OK to return it.  The below test was used to verify that.
         {
         iterator j =
         symTableToCheck->multimap<string, symtab_entry>::find(symbol);
         assert( &(i->second) == &(j->second));
         return i->second;
         }
         */
		if (symTableToCheck->globalScope()) throw SymbolNotFound();
		symTableToCheck = symTableToCheck->scope->parent;
	}
}

bool SymbolTable::exists(const string& symbol, const Type& t)
{
	try {
		vector<symtab_entry*> result = lookup(symbol, t);
		return result.size() > 0;
	}
	catch(const SymbolNotFound& s) {
		return false;
	}
}

bool SymbolTable::exists(const string& symbol)
{
	try {
		lookup(symbol);
	}
	catch(const SymbolNotFound& s) {
		return false;
	}
	return true;
}

bool SymbolTable::existsThisScope(const string& symbol)
{
	return (find(symbol) != end());
}

bool SymbolTable::existsThisScope(const string& symbol, const Type& t)
{
	try {
		lookupInScope(symbol, t);
	}
	catch(const SymbolNotFound& err)
	{
		return false;
	}
	return true;
}

//***Point of definition/declaration functions***

Node* SymbolTable::getPointOfDefnOrDecl(const string& name, const Type& type)
{
	return getDefnOrDeclGeneral(name, type, false);
}

Node* SymbolTable::getPointOfDefnOrDecl(const string& name)
{
    return getDefnOrDeclGeneral(name, Type::VOID, false);
}

Node* SymbolTable::getPointOfDefn(const string& name, const Type& type)
{
	return getDefnOrDeclGeneral(name, type, true);
}

Node* SymbolTable::getDefnOrDeclGeneral(const string& name, const Type& type, bool requireDefn) {
	const vector<symtab_entry*> result = lookup(name, type, requireDefn);
    if (result.size() == 0) throw SymbolNotFound();
    else return result[0]->pointOfDefnOrDecl;
}

SymbolTable::iterator 
SymbolTable::setPointOfDefn(const string& name, 
	const Type& type, Node* pointOfDefn) 
{
	for (iterator i = begin(); i != end(); ++i)
	{
		if (i->first == name && i->second.type == type)
		{
			i->second.pointOfDefnOrDecl = pointOfDefn;
			i->second.isDefn = true;
			return i;
		}
	}
	throw SymbolNotFound();
}

bool SymbolTable::hasDefn(const string& name, const Type& type) {
	try {
		//getPointOfDefn(name, type);
        lookup(name, type, true);
	}
	catch(SymbolNotFound& err)
	{
		return false;
	}
	return true;
}

/**Look up a symbol which has a sub-scope (e.g. a function or block).*/
SymbolTable* SymbolTable::findScope(const string& symbol, const Type& type) {
	iterator i = lookupInScope(symbol, type);
	const symtab_entry& entry = i->second;
	if (entry.child == 0)
		throw symbol + " not a scope.";
	return entry.child;
}

Type SymbolTable::lookUpType(const string& s) {
	vector<symtab_entry*> result = lookup(s);
	assert(result.size() >= 1);
	if (result.size() == 1)
	{
		return result[0]->type;
	}
	//From here on, we have an ambiguous type - i.e.
	//there are multiple things named s in the symbol table.
	vector<Type> choices;
	vector<Node*> pointsOfDefnOrDecl;
	for (vector<symtab_entry*>::iterator i = result.begin();
			i != result.end(); ++i)
	{
		choices.push_back((*i)->type);
		pointsOfDefnOrDecl.push_back((*i)->pointOfDefnOrDecl);
	}
	return Type(Type::AMB, choices, pointsOfDefnOrDecl);
}

//***Other functions***

const symtab_entry*const SymbolTable::currentFunction() const {
	//Keep going up to the parent scope until it's a function.
	symtab_entry* curScope = scope;
	assert(curScope != 0);
	while (!(curScope->type).isFunction()) {
		curScope = curScope->parent->scope;
		assert(curScope != 0);
	}
	return curScope;
}

string SymbolTable::getRealName(const string& name, const Type& type) {
	try {
        vector<symtab_entry*> result = lookup(name, type);
        if (result.size() == 0) return "";
        string retVal = result[0]->realName;
        if (retVal == "") return name;
        else return retVal;
	}
	catch (SymbolNotFound e) {
		return name;  //Made-up variables won't be in the symbol table.
        //They don't have a realName, so just return them.
	}
	
}

//***Print function***

void printBlocks(int indent, ostream& os) {
	for (int ind = 0; ind < indent; ++ind)
		os << "  ";  //2 spaces per indentation
}

void SymbolTable::print(int depth, ostream& os, int indent) const {
	if (depth == 0) return;
	for (const_iterator i = begin();
		i != end(); ++i)
	{
		printBlocks(indent, os);
		
		os << i->first << ": " << i->second.type;
        if (i->second.realName != "") os << " (realname: " << i->second.realName << ")";
		const SymbolTable* child = i->second.child;
		if (child != 0)
		{
			os << " {\n";
			child->print(depth - 1, os, indent + 1);
			printBlocks(indent, os);
			os << "}";
		}
		os << "\n";
	}
}

SymbolTable symtable;
