/** Output the carray and darray C++ classes
 * that the transformed code uses. */
void outputArrayClasses();

