/* This file is just for debugging.  It allows me to see the list
of tokens that the lexical analyzer produces for a piece of code.*/

#include <iostream>
#include "parser.h"

using namespace std;

int main() {
	while (int t = yylex()) {
		if (t == '\n')
			cout << '\n';
		else if (t <= 255)
			cout << char(t) << '\t';
		else {
			switch(t) {
				case INTCONST: cout << "INTCONST"; break;
				case FLOATCONST: cout << "FLOATCONST"; break;
				case IDENT: cout << "IDENT"; break;
				case KEY_FOR: cout << "KEY_FOR"; break;
				case KEY_SELECT: cout << "KEY_SELECT"; break;
				case KEY_STEP: cout << "KEY_STEP"; break;
				case KEY_CASE: cout << "KEY_CASE"; break;
				case KEY_ELSE: cout << "KEY_ELSE"; break;
				case KEY_INT: cout << "KEY_INT"; break;
				case KEY_DOUBLE: cout << "KEY_DOUBLE"; break;
				case OP_RANGE: cout << "OP_RANGE"; break;
				case DECL: cout << "DECL"; break;
				case DECL_ASSIGN: cout << "DECL_ASSIGN"; break;
				case ELEMENT_ASSIGN: cout << "ELEMENT_ASSIGN"; break;
				case ELEMENT_RANGE_ASSIGN: cout << "ELEMENT_RANGE_ASSIGN"; break;
				case ARRAY_RANGE: cout << "ARRAY_RANGE"; break;
				case ARRAY_LIST: cout << "ARRAY_LIST"; break;
				case ARRAY_SUBSCRIPT_RANGE: cout << "ARRAY_SUBSCRIPT_RANGE"; break;
				case ARRAY_INIT: cout << "ARRAY_INIT"; break;
				case FOR_HEADER: cout << "FOR_HEADER"; break;
				case INPUT: cout << "INPUT"; break;
				case OUTPUT: cout << "OUTPUT"; break;
				case UMINUS: cout << "UMINUS"; break;
				case STRING: cout << "STRING"; break;
				case KEY_FUNCTION: cout << "KEY_FUNCTION"; break;
				case KEY_RETURNS: cout << "KEY_RETURNS"; break;
				case KEY_RETURN: cout << "KEY_RETURN"; break;
				default: cout << "Unrecognized token"; break;
			}
			cout << '\t';
		}
	}
	cout << '\n';
}
