#include "outputThing.h"
#include <iostream>
#include <cstddef>

using namespace std;

void outputThing() {
#include "gen_thing.h"
	for (size_t line = 0; line < thing_size; ++line)
	{
		cout << thing_file[line] << endl;
	}
}
	
