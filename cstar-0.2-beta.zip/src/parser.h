/* This file is part of the C* compiler.  See the file README.TXT.
parser.tab.hpp really needs an include for the AST in it, but 
for some reason it isn't getting put there.  So I made
this file, which should be #included instead of
parser.tab.hpp

It also has the declarations of yylex, yyerror, and 
compileError (the last is defined in error.h)
 */
 
#include "ast_decl.h"
class Type;
#include "parser.tab.hpp"
#include "error.h"

int yylex();
void yyerror(const char* s);
