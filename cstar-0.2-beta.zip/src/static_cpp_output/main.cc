int main(int argc, char** argv)
{
	int maxlen = 0;
	for (int i = 0; i < argc; ++i)
	{
		int j = 0;
		for (; argv[i][j] != '\0'; ++j)
			;
		if (j > maxlen) maxlen = j;
	}
	darray<darray<char> > args(argc, darray<char>(maxlen));
	for (int i = 0; i < argc; ++i)
	{
		for (int j = 0; argv[i][j] != '\0'; ++j)
			args[i][j] = argv[i][j];
	}
	__csMain11(args);
}

