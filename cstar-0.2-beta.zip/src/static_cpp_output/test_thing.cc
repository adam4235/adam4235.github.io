#include "thing.cc"

//Test code

class X : public Thing {
	public:
		int getX() { return 1; }
};

#include <iostream>

using namespace std;

void const_ptr() {
	int i = 1;
	const int* pt = &i;
	thing t2;
	t2 = pt;
	(const int*)t2;

}
	enum color {R, G, B};
	color e;

int main() {
	const_ptr();
	thing t = X();
	X x = (X)t;
	cout << x.getX() << endl;
	/*
	thing t = 1;
	(char)t;
	*/

	/*
	thing y = e;
	(color)int(y);
*/

	thing z;
	z = e;

	int i = 1;
	int* pt = &i;
	thing t2;
	t2 = pt;
	(int*)t2;

	cout << sizeof(t) << endl;
	cout << sizeof(thing) << endl;
	cout << sizeof(long double) << endl;
	cout << sizeof(double) << endl;
	cout << sizeof(t.val) << endl;
	cout << sizeof(t.type) << endl;
}

