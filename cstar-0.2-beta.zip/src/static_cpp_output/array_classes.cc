class RangeError : public Thing {};
class bottom : public Thing {};

//Forward declaration
template<typename T> class darray;

//General array class.
//Can only have pointers to these.
template<typename T> class garray : public Thing {
public:
	virtual darray<T> construct() = 0;
	virtual std::size_t getSize() const = 0;
};

template<typename T, std::size_t size>
class carray : public garray<T> {
private:
	void copyFrom(const carray<T, size>& that)
	{
//		memcpy(v, that.v, sizeof(v));
		for (std::size_t i = 0; i < size; ++i)
			v[i] = that.v[i];
	}

	template<typename U>
	void loopCopyFrom(const U* thatV)
	{
		for (std::size_t i = 0; i < size; ++i)
		{
			v[i] = thatV[i];
		}
	}

public:
	T v[size];

	//Subscript
	T& operator[](std::size_t i) { 
		if (i >= size) throw RangeError();
		return v[i]; 
	}
	const T& operator[](std::size_t i) const { 
		if (i >= size) throw RangeError();
		return v[i]; 
	}

	//Constructors
	
	//Construct an empty array
	carray<T, size>() {}

	//Copy one carray to another
	carray<T, size>(const carray<T, size>& that) {
		copyFrom(that);
	}

	//Copy from a darray to a carray
	template<typename U>
	carray<T, size>(const darray<U>& that) {
		loopCopyFrom(that.v);
	}

	//Copy a regular C array of size size to a carray
	carray<T, size>(T* c_arr) {
//		memcpy(v, c_arr, size * sizeof(T));
		for (std::size_t i = 0; i < size; ++i)
			v[i] = c_arr[i];

	}

	//Copy from a subtype
	template<typename U>
	carray<T, size>(const carray<U, size>& that) {
		loopCopyFrom(that.v);
	}
	template<typename U>
	carray<T, size>(U* c_arr) {
		loopCopyFrom(c_arr);
	}

	//Array := scalar
	carray<T, size>(T scalar) {
		for (std::size_t i = 0; i < size; ++i)
		{
			v[i] = scalar;
		}
	}

	//Assignment operator
	carray<T, size>& operator=(const carray<T, size>& that) {
		if (this != &that) {
			copyFrom(that);
		}
		return *this;
	}

	//Output operator
	friend std::ostream& operator<<(std::ostream& o, const carray<T, size>& arr)
	{
		for (std::size_t i = 0; i < size; ++i)
			o << arr.v[i];
		return o;
	}
	std::size_t getSize() const { return size; }
	darray<T> construct();
#include "rangeops.cc"
};

template<typename T>
class darray : public garray<T> {
private:
	bool dontDeleteData;

	void copyFrom(const darray<T>& that)
	{
		size = that.size;
		copyFromArr(that.v);
	}
	template <typename U>
	void copyFromArr(const U that[])
	{
		v = new T[size];
//		memcpy(v, that, size * sizeof(T));
		for (std::size_t i = 0; i < size; ++i)
			v[i] = that[i];
	}

public:
	std::size_t size;
	T* v;

	//Subscript
	T& operator[](std::size_t i) { 
		rangeCheck(i);
		return v[i]; 
	}
	const T& operator[](std::size_t i) const { 
		rangeCheck(i);
		return v[i]; 
	}

	//Constructors
	
	//[]
	darray<T>(bottom b) : dontDeleteData(false) {
		size = 0;
		v = 0;
	}

	//Copy constructor
	darray<T>(const darray<T>& that): dontDeleteData(false) 
	{
		copyFrom(that);
	}

	//Copy from carray to darray
	template <typename U, std::size_t carr_size>
	darray<T>(const carray<U, carr_size>& that): dontDeleteData(false) 
	{
		size = carr_size;
		copyFromArr(that.v);
	}

	//Copy from a subtype
	template<typename U>
	darray<T>(const darray<U>& that) : dontDeleteData(false) {
		size = that.size;
		copyFromArr(that.v);
	}

	//Allocate a dynamic array of a variable size
	darray<T>(std::size_t sz): dontDeleteData(false) 
	{
		size = sz;
		v = new T[sz];
	}

	//Create a temporary dynamic array to refer to existing data
	darray<T>(std::size_t sz, T* data)
	{
		size = sz;
		v = data;
		dontDeleteData = true;
	}

	//Array := scalar
	darray<T>(std::size_t sz, T scalar) {
		size = sz;
		v = new T[sz];
		for (std::size_t i = 0; i < size; ++i)
		{
			v[i] = scalar;
		}
	}

	//Destructor
	~darray<T>() {
		if (size > 0 && !dontDeleteData) delete [] v;
	}

	//Assignment operator
	darray<T>& operator=(const darray<T>& that) {
		if (this != &that) {
			this->~darray<T>();
			copyFrom(that);
		}
		return *this;
	}

	//Construct an empty darray - only needed in the array classes
	darray<T>() : dontDeleteData(false) 
	{
		size = 0;
		v = 0;
	}

	//Output operator
	friend std::ostream& operator<<(std::ostream& o, const darray<T>& arr)
	{
		for (std::size_t i = 0; i < arr.size; ++i)
			o << arr.v[i];
		return o;
	}
	std::size_t getSize() const { return size; }
	darray<T> construct();

	#include "rangeops.cc"
};

template<typename T, std::size_t sz>
darray<T> carray<T, sz>::construct() {
	return darray<T>(sz, &(v[0]));
}

template<typename T>
darray<T> darray<T>::construct() {
	return darray<T>(size, v);
}


