//A class which all other classes inherit from.
class Thing {
public:
	virtual ~Thing() {}
};

//Exception thrown when you try to cast a thing
//to a type which the value stored in it is not.
class CastError : public Thing {};

class thing {
public:
	union {
		int intVal;  //int
		unsigned int uintVal;  //unsigned int
		float floatVal;  //float

		//For efficiency, double and long double are stored
		//as pointers within the union, with the actual value
		//going on the heap for the case when the thing's value
		//is actually a double or long double.
		//This allows the union to occupy only 4 bytes on a
		//32-bit system, and improves performance when the
		//value isn't double or long double.
		double* doubleVal;  //double
		long double* ldoubleVal;  //long double

		bool boolVal;  //bool
		char charVal;  //char
		Thing* classVal;  //class
		void* ptrVal;  //pointer
		const void* cPtrVal;  //pointer to const
#if 0
//		FUNCTION;  //function type
//		OPER;  //operator
		ARRAY;  //array type
		DARRAY;  //dynamic array
		ENUM;  //Enumeration
		ENUMERATOR;  //A single value within an enumeration
//		TYPE;     //A type name (such as the name of an enum type)
		PTR;  //Pointer
		CONST_PTR;  //Constant pointer
//		REF;  //Reference
//		NUL;  //Null (subtype of every pointer type)
#endif
	} val;

	enum Kind {
		VOID,  //Doesn't hold a valid value
		INT,  //int
		UINT,  //unsigned int
		FLOAT,  //float
		DOUBLE,  //double
		LDOUBLE,  //long double
		BOOL,  //bool
		CHAR,  //char
		CLASS,  //class
		FUNCTION,  //function type
		OPER,  //operator
		ARRAY,  //array type
		DARRAY,  //dynamic array
		ENUM,  //Enumeration
		ENUMERATOR,  //A single value within an enumeration
//		TYPE,     //A type name (such as the name of an enum type)
		PTR,  //Pointer
		PTR_TO_CONST  //pointer to const
	} type;

	//Pointers
	template<typename T>
	thing(T* initVal) {
		val.ptrVal = initVal;
		type = PTR;
	}

	//Pointers
	template<typename T>
	thing(const T* initVal) {
		val.cPtrVal = initVal;
		type = PTR_TO_CONST;
	}


	//Classes
	template<typename T>
	thing(const T& initVal) {
		val.classVal = new T(initVal);
		type = CLASS;
	}
	
	//Primitive types
	thing(int v) {
		val.intVal = v;
		type = INT;
	}
	thing(unsigned int v) {
		val.uintVal = v;
		type = UINT;
	}
	thing(float v) {
		val.floatVal = v;
		type = FLOAT;
	}
	thing(double v) {
		val.doubleVal = new double(v);
		type = DOUBLE;
	}
	thing(long double v) {
		val.ldoubleVal = new long double(v);
		type = LDOUBLE;
	}
	thing(bool v) {
		val.boolVal = v;
		type = BOOL;
	}
	thing(char v) {
		val.charVal = v;
		type = CHAR;
	}

	//Casts to get back the original value
	operator int() {
		if (type != INT) throw CastError();
		return val.intVal;
	}
	operator unsigned int() {
		if (type != UINT) throw CastError();
		return val.uintVal;
	}
	operator float() {
		if (type != FLOAT) throw CastError();
		return val.floatVal;
	}
	operator double() {
		if (type != DOUBLE) throw CastError();
		return *val.doubleVal;
	}
	operator long double() {
		if (type != LDOUBLE) throw CastError();
		return *val.ldoubleVal;
	}
	operator bool() {
		if (type != BOOL) throw CastError();
		return val.boolVal;
	}
	operator char() {
		if (type != CHAR) throw CastError();
		return val.charVal;
	}
	//classes
	template<typename T>
	operator T() {
		T* retVal = dynamic_cast<T*>(val.classVal);
		if (retVal == 0) throw CastError();
		return *(retVal);
	}
	//Pointers
	template<typename T>
	operator T*() {
		if (type != PTR) throw CastError();
		return (T*)val.ptrVal;
	}

	//Pointers to constant
	template<typename T>
	operator const T*() {
		if (type != PTR_TO_CONST) throw CastError();
		return (const T*)val.cPtrVal;
	}

	//Destructor
	virtual ~thing()
	{
		if (type == CLASS)
			delete val.classVal;
		else if (type == LDOUBLE)
			delete val.ldoubleVal;
		else if (type == DOUBLE)
			delete val.doubleVal;
	}

	//Default constructor
	thing() {
		type = VOID;
	}

	void copyFrom(const thing& that) {
		type = that.type;
		val = that.val;
	}

	//Copy constructor
	thing(const thing& that) {
		copyFrom(that);
	}
	//Assignment operator
	thing& operator=(const thing& that) {
		if (this != &that) {
			this->~thing();
			copyFrom(that);
		}
		return *this;
	}
};

#include <cstddef>
#include <cstring>
#include <iostream>

class RangeError : public Thing {};
class bottom : public Thing {};


template<typename T> class darray;



template<typename T> class garray : public Thing {
public:
 virtual darray<T> construct() = 0;
 virtual std::size_t getSize() const = 0;
};

template<typename T, std::size_t size>
class carray : public garray<T> {
private:
 void copyFrom(const carray<T, size>& that)
 {

  for (std::size_t i = 0; i < size; ++i)
   v[i] = that.v[i];
 }

 template<typename U>
 void loopCopyFrom(const U* thatV)
 {
  for (std::size_t i = 0; i < size; ++i)
  {
   v[i] = thatV[i];
  }
 }

public:
 T v[size];


 T& operator[](std::size_t i) {
  if (i >= size) throw RangeError();
  return v[i];
 }
 const T& operator[](std::size_t i) const {
  if (i >= size) throw RangeError();
  return v[i];
 }




 carray<T, size>() {}


 carray<T, size>(const carray<T, size>& that) {
  copyFrom(that);
 }


 template<typename U>
 carray<T, size>(const darray<U>& that) {
  loopCopyFrom(that.v);
 }


 carray<T, size>(T* c_arr) {

  for (std::size_t i = 0; i < size; ++i)
   v[i] = c_arr[i];

 }


 template<typename U>
 carray<T, size>(const carray<U, size>& that) {
  loopCopyFrom(that.v);
 }
 template<typename U>
 carray<T, size>(U* c_arr) {
  loopCopyFrom(c_arr);
 }


 carray<T, size>(T scalar) {
  for (std::size_t i = 0; i < size; ++i)
  {
   v[i] = scalar;
  }
 }


 carray<T, size>& operator=(const carray<T, size>& that) {
  if (this != &that) {
   copyFrom(that);
  }
  return *this;
 }


 friend std::ostream& operator<<(std::ostream& o, const carray<T, size>& arr)
 {
  for (std::size_t i = 0; i < size; ++i)
   o << arr.v[i];
  return o;
 }
 std::size_t getSize() const { return size; }
 darray<T> construct();
private:
 void rangeCheck(std::size_t i)
 {
  if (i >= size) throw RangeError();
 }
 void rangeCheck(std::size_t x, std::size_t y)
 {
  if (x > y) throw RangeError();
  rangeCheck(y);
 }
 static void sizeCheck(std::size_t thisSize, std::size_t thatSize)
 {
  if (thisSize != thatSize) throw RangeError();
 }

public:

 darray<T> rangeSubscriptNoCheck(std::size_t x, std::size_t y)
 {
  return darray<T>(y - x + 1, &(v[x]));
 }


 darray<T> rangeSubscriptNoCheck(std::size_t x)
 {
  return rangeSubscriptNoCheck(x, size - 1);
 }


 darray<T> rangeSubscript(std::size_t x, std::size_t y)
 {
  rangeCheck(x, y);
  return rangeSubscriptNoCheck(x, y);
 }


 darray<T> rangeSubscript(std::size_t x)
 {
  rangeCheck(x);
  return rangeSubscriptNoCheck(x);
 }

 template<typename U>
 darray<T> rangeAssignNoCheck(std::size_t x, const U* thatV, std::size_t thatSize)
 {
  return rangeAssignNoCheck(x, size - 1, thatV, thatSize);
 }


 template<typename U>
 darray<T> rangeAssignNoCheck(std::size_t x, std::size_t y, const U* thatV, std::size_t thatSize)
 {
  if ((void*)(&(thatV[0])) < (void*)(&(v[x])))

  {
   for (std::size_t i = y, j = thatSize - 1; i >= x; --i, --j)
   {
    v[i] = thatV[j];
    if (i == 0) break;

   }
  }
  else
  {
   for (std::size_t i = x, j = 0; i <= y; ++i, ++j)
   {
    v[i] = thatV[j];
   }
  }

  return rangeSubscript(x, y);

 }


 template<typename U>
 darray<T> rangeAssign(std::size_t x, std::size_t y, const U* thatV, std::size_t thatSize)
 {
  rangeCheck(x, y);
  sizeCheck(y - x + 1, thatSize);
  return rangeAssignNoCheck(x, y, thatV, thatSize);
 }


 template<typename U>
 darray<T> rangeAssign(std::size_t x, std::size_t y, const darray<U>& that)
 {
  return rangeAssign(x, y, that.v, that.size);
 }
 template<typename U>
 darray<T> rangeAssign(std::size_t x, const darray<U>& that)
 {
  return rangeAssign(x, that.v, that.size);
 }


 template<typename U>
 darray<T> rangeAssign(std::size_t x, const U* thatV, std::size_t thatSize)
 {
  rangeCheck(x);
  sizeCheck(size - x, thatSize);
  return rangeAssignNoCheck(x, thatV, thatSize);
 }


 darray<T> rangeAssignNoCheck(std::size_t x, std::size_t y, const T& that)
 {
  for (std::size_t i = x; i <= y; ++i)
   v[i] = that;
  return rangeSubscript(x, y);

 }

 darray<T> rangeAssignNoCheck(std::size_t x, const T& that)
 {
  return rangeAssignNoCheck(x, size - 1, that);
 }


 darray<T> rangeAssign(std::size_t x, std::size_t y, const T& that)
 {
  rangeCheck(x, y);
  return rangeAssignNoCheck(x, y, that);
 }


 darray<T> rangeAssign(std::size_t x, const T& that)
 {
  rangeCheck(x);
  return rangeAssignNoCheck(x, that);
 }
};

template<typename T>
class darray : public garray<T> {
private:
 bool dontDeleteData;

 void copyFrom(const darray<T>& that)
 {
  size = that.size;
  copyFromArr(that.v);
 }
 template <typename U>
 void copyFromArr(const U that[])
 {
  v = new T[size];

  for (std::size_t i = 0; i < size; ++i)
   v[i] = that[i];
 }

public:
 std::size_t size;
 T* v;


 T& operator[](std::size_t i) {
  rangeCheck(i);
  return v[i];
 }
 const T& operator[](std::size_t i) const {
  rangeCheck(i);
  return v[i];
 }




 darray<T>(bottom b) : dontDeleteData(false) {
  size = 0;
  v = 0;
 }


 darray<T>(const darray<T>& that): dontDeleteData(false)
 {
  copyFrom(that);
 }


 template <typename U, std::size_t carr_size>
 darray<T>(const carray<U, carr_size>& that): dontDeleteData(false)
 {
  size = carr_size;
  copyFromArr(that.v);
 }


 template<typename U>
 darray<T>(const darray<U>& that) : dontDeleteData(false) {
  size = that.size;
  copyFromArr(that.v);
 }


 darray<T>(std::size_t sz): dontDeleteData(false)
 {
  size = sz;
  v = new T[sz];
 }


 darray<T>(std::size_t sz, T* data)
 {
  size = sz;
  v = data;
  dontDeleteData = true;
 }


 darray<T>(std::size_t sz, T scalar) {
  size = sz;
  v = new T[sz];
  for (std::size_t i = 0; i < size; ++i)
  {
   v[i] = scalar;
  }
 }


 ~darray<T>() {
  if (size > 0 && !dontDeleteData) delete [] v;
 }


 darray<T>& operator=(const darray<T>& that) {
  if (this != &that) {
   this->~darray<T>();
   copyFrom(that);
  }
  return *this;
 }


 darray<T>() : dontDeleteData(false)
 {
  size = 0;
  v = 0;
 }


 friend std::ostream& operator<<(std::ostream& o, const darray<T>& arr)
 {
  for (std::size_t i = 0; i < arr.size; ++i)
   o << arr.v[i];
  return o;
 }
 std::size_t getSize() const { return size; }
 darray<T> construct();

private:
 void rangeCheck(std::size_t i)
 {
  if (i >= size) throw RangeError();
 }
 void rangeCheck(std::size_t x, std::size_t y)
 {
  if (x > y) throw RangeError();
  rangeCheck(y);
 }
 static void sizeCheck(std::size_t thisSize, std::size_t thatSize)
 {
  if (thisSize != thatSize) throw RangeError();
 }

public:

 darray<T> rangeSubscriptNoCheck(std::size_t x, std::size_t y)
 {
  return darray<T>(y - x + 1, &(v[x]));
 }


 darray<T> rangeSubscriptNoCheck(std::size_t x)
 {
  return rangeSubscriptNoCheck(x, size - 1);
 }


 darray<T> rangeSubscript(std::size_t x, std::size_t y)
 {
  rangeCheck(x, y);
  return rangeSubscriptNoCheck(x, y);
 }


 darray<T> rangeSubscript(std::size_t x)
 {
  rangeCheck(x);
  return rangeSubscriptNoCheck(x);
 }

 template<typename U>
 darray<T> rangeAssignNoCheck(std::size_t x, const U* thatV, std::size_t thatSize)
 {
  return rangeAssignNoCheck(x, size - 1, thatV, thatSize);
 }


 template<typename U>
 darray<T> rangeAssignNoCheck(std::size_t x, std::size_t y, const U* thatV, std::size_t thatSize)
 {
  if ((void*)(&(thatV[0])) < (void*)(&(v[x])))

  {
   for (std::size_t i = y, j = thatSize - 1; i >= x; --i, --j)
   {
    v[i] = thatV[j];
    if (i == 0) break;

   }
  }
  else
  {
   for (std::size_t i = x, j = 0; i <= y; ++i, ++j)
   {
    v[i] = thatV[j];
   }
  }

  return rangeSubscript(x, y);

 }


 template<typename U>
 darray<T> rangeAssign(std::size_t x, std::size_t y, const U* thatV, std::size_t thatSize)
 {
  rangeCheck(x, y);
  sizeCheck(y - x + 1, thatSize);
  return rangeAssignNoCheck(x, y, thatV, thatSize);
 }


 template<typename U>
 darray<T> rangeAssign(std::size_t x, std::size_t y, const darray<U>& that)
 {
  return rangeAssign(x, y, that.v, that.size);
 }
 template<typename U>
 darray<T> rangeAssign(std::size_t x, const darray<U>& that)
 {
  return rangeAssign(x, that.v, that.size);
 }


 template<typename U>
 darray<T> rangeAssign(std::size_t x, const U* thatV, std::size_t thatSize)
 {
  rangeCheck(x);
  sizeCheck(size - x, thatSize);
  return rangeAssignNoCheck(x, thatV, thatSize);
 }


 darray<T> rangeAssignNoCheck(std::size_t x, std::size_t y, const T& that)
 {
  for (std::size_t i = x; i <= y; ++i)
   v[i] = that;
  return rangeSubscript(x, y);

 }

 darray<T> rangeAssignNoCheck(std::size_t x, const T& that)
 {
  return rangeAssignNoCheck(x, size - 1, that);
 }


 darray<T> rangeAssign(std::size_t x, std::size_t y, const T& that)
 {
  rangeCheck(x, y);
  return rangeAssignNoCheck(x, y, that);
 }


 darray<T> rangeAssign(std::size_t x, const T& that)
 {
  rangeCheck(x);
  return rangeAssignNoCheck(x, that);
 }
};

template<typename T, std::size_t sz>
darray<T> carray<T, sz>::construct() {
 return darray<T>(sz, &(v[0]));
}

template<typename T>
darray<T> darray<T>::construct() {
 return darray<T>(size, v);
}
