#include "error.h"
#include "ast/Node.h"
#include <sstream>


using namespace std;

string linenum(const Node* n) {
	return "Error at line "  +
		CompileError::getLineInfo(n) + ": ";
}

string linenum()
{
	ostringstream err;
	err << lineno;
	return "Error at line " + err.str() + ": ";
}

string CompileError::getLineInfo(const Node* n)
{
	ostringstream err;

	err << n->getPos().getErrString();
	return err.str();
}

//Initialize the variables from error.h and parser.h
bool errorFound = false;
CompileError compileError;
unsigned long lineno = 1;
bool io_used = false;
bool array_used = false;
bool argv_used = false;

