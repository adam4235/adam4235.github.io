/* This file defines the Type class for the compiler.
See the file README.TXT.
Type describes the type information (int/double, array size, etc. )
for both a node in the parse
tree and an entry in the symbol table. */

#ifndef TYPEINFO_CC
#define TYPEINFO_CC

/*The different possible types are 
 given in the declaration of Kind below. */

//In a truly good design, this class would be a base class, with the
//different types being subclasses of it, forming a class hierarchy of types.
//But in C++, that's too difficult, because you can only have
//polymorphic behaviour for pointers and newed objects, which would
//introduce garbage collection difficulties.  (This is what I did for the
//AST, but it was much more worthwhile to have a class hierarchy for the AST).

#include <vector>
#include <string>
#include <cassert>
#include <fstream>

class Node;

using std::string;
using std::vector;
using std::ostream;

class Type {
public:
	enum Kind {
		VOID = 0,  //No type assigned yet
		INT,  //int
		UINT,  //unsigned int
		FLOAT,  //float
		DOUBLE,  //double
		LDOUBLE,  //long double
		BOOL,  //bool
		CHAR,  //char
		FUNCTION,  //function type
//		OPER,  //operator
		ARRAY,  //array type
		DARRAY,  //dynamic array
		BLOCK,  //block (of statments)
        LABEL, //label (for a statement)
		ENUM,  //Enumeration
		ENUMERATOR,  //A single value within an enumeration
		TYPE,     //A type name (such as the name of an enum type)
		USER,   //A reference to a type (class, enum, etc.), which is being
			//referred to by name.
			//e.g. in Shape s, the Type of s is Type(USER, "Shape"),
			//while the Type of Shape is Type(TYPE, ...)
		PTR,  //Pointer
		CONST_PTR,  //Constant pointer
//		REF,  //Reference
		NUL,  //Null (subtype of every pointer type)
		BOT,  //Bottom (subtype of every type).  Can't actually have
			//variables of this type, but [] is an array of bottom.
		THING,  //The supertype of all other types
		AMB   //ambiguous type - it could be one of many types.
			//In this case, the possibilities can be acquired from
			//"getChoices()"
	};

	//Type qualifiers
	enum Quals {
		NO_FLAG = 0,
		CONST_FLAG = 1,
		REF_FLAG = 2,
		STATIC_FLAG = 4
	};

private:
	Kind type;

	Quals quals;  //The type qualifiers attached to the type

	//This stuff could possibly be made more efficient using unions
	//or something, since for arrays you only need the array variables,
	//and for functions you only need the function variables.
	//But using unions required 2 more dereferences before getting to
	//the variables themselves.

	//ARRAYS:
	size_t m_size;  /* The number of elements, for arrays */
	long m_li;                 /* Lower index, for arrays */
	Type* baseType;  //Base type for array

	//FUNCTIONS:
	//Note: the Type*s point to new Types that have
	//to be deleted when this typeinfo is deleted.
	vector<Type>* parameters;  //Parameters of the function
		//Making it a pointer to a vector saves memory for
		//Types that aren't functions.
	Type* returnType;  //Return type for functions
	vector<Node*>* pointsOfDefnOrDecl;  //For an ambiguous type,
		//all the places where the different choices were defined/declared

	//ENUMS:
	vector<string>* enumerators;  //The possible values
		//of the enumeration.
		//Also used for the ENUMERATOR type - constants
		//of type ENUMERATOR puts only 1 item in this
		//list, namely their name

	//USER:
	string* refName;

    //Used by the copy constructor and assigment operator to
    //copy t into this type.
	void copyFrom(const Type& t);
	
	//Used by all the constructors to initialize everything.
	void initAll();

public:
    //KIND
    
	/** @return The type (kind) of this type (int, double, array, function, ...) */
	Kind getType() const { return type; }

	/**@return Whether the type is a primitive type*/
	bool isPrimitive() const;
    
    bool isInt() const {
        return type == INT || type == UINT;
    }
    
	bool isArray() const { return type == ARRAY || type == DARRAY; }
	
	/** @return Whether this is a function (or operator) */
    bool isFunction() const { 
        return type == FUNCTION; 
    }
    
	/**@return whether this is an enum*/
	bool isEnum() const { return type == ENUM; }
    
	/**@return whether this is an enumerator*/
	bool isEnumerator() const { return type == ENUMERATOR; }
    
    /**@return Whether it's an enum or an enumerator*/
    bool isEnumVal() const { return isEnum() || isEnumerator(); }
    
	/**@return Whether this type is an alias type (reference, pointer, const pointer). */
	bool isAlias() const {
		return hasFlag(REF_FLAG) || isPtr();
	}
	bool isPtr() const {
		return type == PTR || type == CONST_PTR;
	}
    bool isPtrVal() const {
        return isPtr() || type == NUL;
    }
    
    //FLAGS/QUALS
    
	/**@return Whether flag, a type qualifier, is set for this type.*/
	bool hasFlag(Quals flag) const {
		return (quals & flag) == flag;
	}

	/**Add the type qualifiers specified in flag.*/
	void setQuals(Quals flag) {
		quals = Quals(quals | flag);
	}
	/**Clear all type qualifiers.*/
	void clearQuals() {
		quals = NO_FLAG;
	}

	/**Clear flag, or do nothing if flag is already set*/
	void clearQuals(Quals flag) {
		if (hasFlag(flag)) quals = Quals(quals - flag);
	}

	/**@return The type qualifiers for this */
	Quals getQuals() {
		return quals;
	}

	/**@return Whether the type is constant. */
	bool isConst() const { 
		if (type == PTR) return false;
		else if (type == CONST_PTR) return true;
		else return hasFlag(CONST_FLAG); 
	}
    
    /**@return whether the type is a plain constant
     (not ptr to const*/
    bool isNonPtrConst() const {
        if (isPtr()) return false;
		else return hasFlag(CONST_FLAG); 
    }        

	bool isStatic() const {
		return hasFlag(STATIC_FLAG);
	}

	/** Return a type with the prefixed "reference to"
	 * removed, if any.*/
	Type stripRef() const;

	//ARRAYS:
	/** Get the base type for an array type*/
	Type getBaseType() const {
		assert(isArray() || isPtr());
		return *baseType; 
	}
	/** Set the base type */
	void setBaseType(const Type& baseType) {
		assert(isArray() || isPtr());
		if (this->baseType != 0)
		{
			delete this->baseType;
		}
		this->baseType = new Type(baseType);  
	}
	
	/** @return the upper index of the array*/
	long ui() const {
		assert(type == ARRAY);
		return m_size - 1 + m_li;
	}
	/** @return the size of the array */
	size_t size() const { 
		return m_size; 
	}
	/** @return the lower index of the array */
	long li() const { 
		assert(isArray());
		return m_li; 
	}
	
	/** Set the size of the array to size.
	 * Called after the size has been calculated from the
	 * array initializer.*/
	void setSize(size_t size) {
		m_size = size;
	}
	
	//FUNCTIONS:

//Note that many of the get functions below can't return
//a const &, if they're returning the value of something,
//because the value of something is a temporary and you can't
//return a reference to a temporary.
	
	/** Get the return type */
	Type getRetType() const {
		assert(isFunction());
		return *returnType;
	}

	/** Get the parameters */
	vector<Type> getParams() const {
		assert(isFunction());
		return *parameters;
	}

	vector<Node*> getPointsOfDefnOrDecl() const {
		assert(type == AMB);
		return *pointsOfDefnOrDecl;
	}

	/** @return Whether the function represented by this is
	 * more specific that the function represented by that.
	 * Both types must be functions.*/
	bool isMoreSpecific(const Type& that) const;

	vector<string> getEnumerators() const {
		assert(isEnum());
		return *enumerators;
	}

    string getEnumeratorVal() const {
		assert(isEnumerator());
		return (*enumerators)[0];
	}

	//AMBIGUOUS TYPES:
    vector<Type> getChoices() const {
        assert(getType() == AMB);
        return *parameters;
    }
    
    
	//TYPE types:
	Type getReferredType() const {
		assert(type == TYPE); 
		return *baseType; 
	}
	
	//USER types:
	string getRefName() const {
		assert(type == USER);
		return *refName;
	}

	/* Create a type info structure for an array */
	Type(const Type& baseType, size_t arr_size, long li = 0);

	/* Create a new dynamic array type */
	Type(Kind type, Type referredType, long li);

	/* Create a new type info structure for a scalar */
	Type(Kind type);

	/* Create a new type info structure for a function or operator*/
	Type(Kind type, const vector<Type>& parameters, const Type& returnType);

	/* Create a new type type (i.e. the type of a name which refers to a type) */
	Type(Kind type, Type referredType);

	/* Create a new enum or enumerator type. */
	Type(Kind type, const vector<string>& enumerators);

	/* Create a new type reference (which has to be looked up
	 * in the symbol table) */
	Type(Kind type, string name);

	/* Create a new ambiguous type*/
	Type(Kind type, const vector<Type>& choices, const vector<Node*>& pointsOfDefnOrDecl);
	
	/* Create a new unknown type */
	Type();

	/* Copy constructor */
	Type(const Type& t);
	Type& operator=(const Type& t);
	
	bool operator==(const Type& that) const;
	bool operator!=(const Type& that) const {
		return !(*this == that);
	}

	/** @return Whether this is a subtype of that 
	 * @param allowConstOnLeft For declarations, you're allowed to have
	 * 		const := non-const.  Set this flag to true in those situations.*/
	bool isSubType(const Type& that, bool allowConstOnLeft = false) const;

	/** @return The common supertype that both this and that is
	 * a subtype of (least upper bound). */
	Type mostGeneral(const Type& that) const;

	/** @return A list of the immediate supertype to this type. */
	vector<Type> superTypes() const;

	/**Output*/
	friend ostream& operator<<(ostream& os, const Type& t);
	static string typeAsString(Type::Kind t);
	 
	virtual ~Type();
};

/**@return t with const set.*/
inline Type constOf(Type t) {
	t.setQuals(Type::CONST_FLAG);
	return t;
}

#endif

