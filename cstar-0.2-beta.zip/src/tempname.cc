#include "tempname.h"
#include <sstream>
#include "error.h"
#include <climits>

using namespace std;

string tempName(string prefix) {
	static unsigned long counter = 0;  //A number to add to the temporary name
		//to make it unique.
	
	//Simply use the prefix and concatenate a new ID to the end of it.
	
	ostringstream s;

	//Check for overflow
	if (counter < ULONG_MAX)
		s << counter++;
	else
		compileError << "Too many made-up names.  Make your compilation unit smaller." << endl;
	
	return prefix + s.str();
}
