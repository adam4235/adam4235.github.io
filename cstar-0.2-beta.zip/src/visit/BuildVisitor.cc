#include "BuildVisitor.h"
#include "BuildVarDecls.h"
#include "ast/Enum.h"
#include "ast/TypeVar.h"

using namespace std;

void BuildVisitor::buildEnum(Enum* n) {
	if (buildType(n, n->getName(), n->getType()))
	{
		currentSymTable->addEnumerators(n);  //Add the enum and all its enumerators
	}
}

bool BuildVisitor::buildType(Node* n, string name, const Type& type) {

	//Add variable to the symbol table	
	if (currentSymTable->existsThisScope(name)) {
		compileError << linenum(n) << "Duplicate definition of `" <<
			name << "'.  ";
		outputPrevDefn(name, currentSymTable->lookUpType(name));
		cerr << endl;
		return false;
	}
	else
	{
		currentSymTable->addType(n, name, type);
		return true;
	}
}

void BuildVisitor::buildTypeVar(TypeVar* n) {
	//First look up any referenced types in the type decl
	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->accept(varDecls.get());

	buildType(n, n->getName(), n->getType());
}

