#ifndef BUILD_VAR_DECLS_H
#define BUILD_VAR_DECLS_H

//Look up any user-defined types referenced in a variable declaration.
//Meant to be called from other visitors, not to process
//the whole AST.

#include "ContextVisitor.h"

class BuildVarDecls : public ContextVisitor {
public:
	BuildVarDecls(SymbolTable* s) : ContextVisitor(s) {}
	
	virtual Node* visit(UserTypeNode* n);
};

#endif

