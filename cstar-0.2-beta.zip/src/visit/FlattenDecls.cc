#include "FlattenDecls.h"
#include "ast/Stmts.h"
#include "ast/DeclStmt.h"
#include "StmtVisitor.h"

class FlattenDecl : public StmtVisitor {
public:
    Node* visit(DeclStmt* n);
};

Node* FlattenDecl::visit(DeclStmt* n) {
    vector<VarDecl*>& varDecls = n->getDecls()->decls;

    //Split the decl statement into multiple individual declarations.
    //In the case of single declarations, this loop won't enter its body.
    for (vector<VarDecl*>::iterator j = varDecls.begin(); j != varDecls.end() - 1; ++j)
    {
        stmts.push_back(new DeclStmt(*j));
    }
    
    //Leave the last declaration in n.  The others have been added
    //to the new statement, so delete them.
    varDecls.erase(varDecls.begin(), varDecls.end() - 1);
    return n;
}

void FlattenDecls::postVisit(Stmts* n) {
    transStmts<FlattenDecl>(n);
}

