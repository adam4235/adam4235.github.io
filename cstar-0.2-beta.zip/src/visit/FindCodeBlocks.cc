#include "FindCodeBlocks.h"
#include "ast/Function.h"
#include "BuildSymTab.h"

using namespace std;

Node* FindCodeBlocks::visit(Function* n) {
	SymbolTable* s = currentSymTable;
	auto_ptr<BuildSymTab> builder(new BuildSymTab(currentSymTable));
	n->accept(builder.get());
	assert(s == currentSymTable);  //Make sure it was pushed/popped correctly
		//within builder
	return n;
}

