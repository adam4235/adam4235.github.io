#ifndef FLATTENDECLS_H
#define FLATTENDECLS_H

/** Convert declarations which contain lists of variables
 * to a list of statements each of which declares only 1
 * variable.
 
 This has to be done in a visitor pass to make the array
 transformation work correctly - since the array transformation
 pulls out array literals, if we have:
 int x := 0, y[] := [x, j];
 We want [i,j] to be pulled out after the declaration
 of x, not y.
 */

#include "FixedVisitor.h"

class FlattenDecls : public FixedVisitor {
public:
	virtual void postVisit(Stmts* n);
};

#endif

