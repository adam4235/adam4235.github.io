#include "PullOutDeclExpr.h"
#include "whole_ast.h"
#include "StmtVisitor.h"

//This used to be complicated, until I turned it into a use of transStmts
//The decls need to be placed in a new block, so that they only apply to the statement with
//the DeclExpr (e.g. a decl in a while expression should only apply to the while loop's body).
//This is now done by surrounding all ifs and loops with a new Block in the parser.

//Sub-visitor to find the DeclExprs and convert them
//to assignment statements (or variables if there's no
//initval in the declaration), while keeping track of the
//declarations that need to be made.
class PullDeclExprs : public StmtVisitor {
public:
//	vector<Stmt*> newDecls;
	virtual Node* visit(DeclExpr* n);
};

Node* PullDeclExprs::visit(DeclExpr* n)
{
	Variable* v = new Variable(n->getDecl()->getName());   //the variable should
		//get its type later


	Node* newN;

	if (n->getDecl()->getInitVal() == 0)
		newN = v;
	else
	{
	//Create an assignment expression to replace n with
	 	newN = new AssignExpr("=", v, n->getDecl()->snipInitVal());
	}

	//Add the variable declaration to a new decl
	Stmt* newDecl = new DeclStmt(n->snipDecl());

	stmts.push_back(newDecl);

	delete n;

	return newN;
}
#if 0
//Traverse a statement (loop or if) and get some
//decls out of it, replacing it with another statement
//with the decls replaced with assignment statements.
//Make sure the declaration gets put in a block, so its
//scope remains only the scope of the loop or if.
template<typename T>
Node* pull(Stmt* n, T** exprToSearch) {
	auto_ptr<PullDeclExprs> pull(new PullDeclExprs());
	*exprToSearch = (T*)(*exprToSearch)->accept(pull.get());

	vector<Stmt*> newStmts = pull.get()->newDecls;
	if (newStmts.size() > 0) {
		newStmts.push_back(n);
		return new Block(new Stmts(newStmts));
	}
	else return n;
}

//Look for declarations in input statements
class InputDecls : public StmtVisitor {
	Node* visit(InputExpr* n) {
		auto_ptr<PullDeclExprs> pull(new PullDeclExprs());
		Node* result = n->accept(pull.get());
		stmts = pull.get()->newDecls;
		return result;
	}
};
#endif

void PullOutDeclExpr::postVisit(Stmts* n) {
	transStmts<PullDeclExprs>(n);
}

#if 0
Node* PullOutDeclExpr::visit(For* n) {
	if (n->getBody() != 0) 
		n->body = (Stmt*)n->getBody()->accept(this);
	return pull(n, &(n->loopVar));
}

Node* PullOutDeclExpr::visit(If* n) {
	n->ifPart = (Stmt*)n->getIf()->accept(this);
	if (n->getElse() != 0) 
		n->elsePart = (Stmt*)n->getElse()->accept(this);
	return pull(n, &(n->cond));
}

Node* PullOutDeclExpr::visit(While* n) {
	if (n->isDoWhile())
	{
		//visit body first for a do ... while (...);
		n->body = (Stmt*)n->getBody()->accept(this);
		n->cond = (Expr*)n->getCond()->accept(this);
	}
	else {
		n->cond = (Expr*)n->getCond()->accept(this);
		n->body = (Stmt*)n->getBody()->accept(this);
	}
	return pull(n, &(n->cond));
}

#endif
