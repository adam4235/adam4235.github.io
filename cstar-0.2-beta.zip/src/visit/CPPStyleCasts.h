#ifndef CPP_STYLE_CASTS_H
#define CPP_STYLE_CASTS_H

//Convert what appeared to be a call to a C++-style cast,
//if the name of the call is a type.
//
//TODO later: Constructor calls

#include "ContextVisitor.h"

class CPPStyleCasts : public ContextVisitor {
public:
	virtual Node* visit(Call* n);
};

#endif

