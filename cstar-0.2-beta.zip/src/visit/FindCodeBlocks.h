#ifndef BUILDCODEBLOCKS_H
#define BUILDCODEBLOCKS_H

#include "ContextVisitor.h"

//Called from the top-level or a context where there is a list
//of declarations but no executable statements.  Finds blocks
//of code and calls the symbol table builder on those blocks.
//(Since blocks of code have to be treated differently than
//"top-level" lists of declarations.)

class FindCodeBlocks : public ContextVisitor {
public:
	virtual Node* visit(Function* n);
};

#endif

