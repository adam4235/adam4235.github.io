#include "CPPStyleCasts.h"
#include "whole_ast.h"
#include "buildTNFromType.h"

Node* CPPStyleCasts::visit(Call* n) {
    //Don't forget to visit the function name and arguments too
    n->name = (Expr*)n->getName()->accept(this);
	n->args = (Exprs*)n->getArgs()->accept(this);

	Variable* possibleType = dynamic_cast<Variable*>(n->getName());
	if (possibleType != 0 && currentSymTable->exists(possibleType->getName()))
	{
		Type t = currentSymTable->lookUpType(possibleType->getName()); 
		if (t.getType() == Type::TYPE && n->getArgs()->getExprs().size() == 1)
		{
			//The "Call", it turns out, is really a C++-style cast

			TypeNode* tn = buildUserTN(new UserTypeNode(possibleType->getName()), t.getReferredType());
			Cast* newN = new Cast(tn, n->getArgs()->snipValue(0));
			delete n;
			return newN;
		}
	}
	return n;
}

