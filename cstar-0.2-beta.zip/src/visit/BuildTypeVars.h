#ifndef BUILD_TYPE_VARS_H
#define BUILD_TYPE_VARS_H

#include "BuildVisitor.h"

//Add global type variables to the symbol table

class BuildTypeVars : public BuildVisitor {
public:
	Node* visit(Function* n);
	void postVisit(TypeVar* n);
};

#endif

