/**Various transformations on arrays, to implement the
 * matrix operations*/

#include "ArrayTransform.h"
#include "whole_ast.h"
#include "tempname.h"
#include <vector>
#include "buildTNFromType.h"
#include "ArrayConstSearch.h"
#include "StmtVisitor.h"

using namespace std;

/* Array literals are allowed anywhere in C*,
 * whereas they're only allowed in declarations
 * in C++.
 * The below visitor translates array literals
 * to be replaced with a temporary variable, which
 * is declared before the statement containing the
 * array literal.
 * It's called from ArrayTransform.
 */
class ArrayLiteralTransform : public StmtVisitor {
private:
	Expr* andOrOr(Expr* ifExpr, Expr* boolLiteral, Expr* right);
	void addStmt(Stmt* n) {
		stmts.push_back(n);
	}
public:

	virtual Node* visit(Call* n);
	virtual Node* visit(Unop* n);
	virtual Node* visit(AssignExpr* n);
	virtual Node* visit(Binop* n);
	virtual Node* visit(ArrayList* n);
};

//Translate various kinds of expressions containing array
//literals so that the array literal is pulled out and declared
//in its own variable.
//The different cases are given below in the different visit functions.

/** Return whether the expression n is an empty array literal ([])*/
bool isEmptyArray(Expr* n) {
	ArrayList* nAsArrayList = dynamic_cast<ArrayList*>(n);
	return nAsArrayList != 0 && nAsArrayList->getSize() == 0;
}

/*
f(x1, ..., xn) becomes:

t1 := x1;  (declaration of temporary t1)
t2 := x2;
...
tn := xn;
f(t1, ..., tn);

The reason calls have to have all their arguments pulled out
is to preserve the execution order of expressions with side effects.

 */ 
Node* ArrayLiteralTransform::visit(Call* n) {
	if (!containsArrayConst(n, true)) return n;

	//The call now has an array literal in it.
	//Convert it to a bunch of declarations of temporaries,
	//then a call on those temporaries.
	
	for (vector<Expr*>::iterator i = n->args->exprs.begin(); i != n->args->exprs.end(); ++i)
	{
		//Declare the temporary
		string varName = tempName("_temp");

		//TODO later: When an expression has no side effect, it's OK to
		//leave it as an argument to the call.  Once I have a way
		//of telling whether expressions have side effects, do that
		//optimization here.
		if (isEmptyArray(*i))
		{
			//Don't pull out [], because that would cause problems if we try to
			//declare a temporary to hold it.
			continue;
		}
		
		addStmt(
				new DeclStmt(
					new VarDecl(
						buildTNFromType((*i)->getType()), 
						varName, 
						*i)));

		//Modify the call to refer to the temporary
		*i = new Variable(
				varName, 
				(*i)->getType());
	}
	return n;
}

//Unops are handled the same as method calls.
Node* ArrayLiteralTransform::visit(Unop* n) {
	return visit((Call*)n);
}
	
//For an assignment expression you just transform the RHS.
//The RHS may be evaluated before the LHS in C*.
Node* ArrayLiteralTransform::visit(AssignExpr* n) {
	n->args->exprs[1] = (Expr*)n->args->exprs[1]->accept(this);
	return n;
}

//See the example for && below.
//This is a common method for && and ||, which are
//similar enough that we need to avoid code duplication.
Expr* ArrayLiteralTransform::andOrOr(Expr* ifExpr, Expr* boolLiteral, Expr* right) {
	string name = tempName("_temp");
	addStmt(
			new DeclStmt(
				new VarDecl(
					new PrimTypeNode(Type::BOOL), 
					name)));
	Stmt* ifPart = new ExprStmt(new AssignExpr("=", new Variable(name, Type::BOOL), boolLiteral));
	Stmt* elsePart = new ExprStmt(new AssignExpr("=", new Variable(name, Type::BOOL), right));
	addStmt(new If(ifExpr, ifPart, elsePart));
	return new Variable(name, Type::BOOL);
}

//The type of the "not" operator
Type notType() {
	vector<Type> parameters;
	parameters.push_back(Type::BOOL);
	return Type(Type::FUNCTION, parameters, Type::BOOL);
}

Node* ArrayLiteralTransform::visit(Binop* n) {
	if (n->getOper() == "and")
	{
		/* 2. x1 && x2 is translated to:
		 *
bool result;
if (!x1)
	result := false;
else
{
	result := x2;
}
result;
			This translation is necessary because if we were to
			blindly pull out array literals from an expression with
			&& or ||, the expression that would have been short
			circuited might be evaluated.
		 */
		Expr* result = andOrOr(
				new Unop(
					new Variable("not", notType()), 
					n->snipLeft()),
				new BoolConst(false), 
				n->snipRight());
		delete n;  //The && is being replaced with a literal, so we have to delete
			//it to avoid a memory leak.
		return result;
	}
	else if (n->getOper() == "or")
	{
		//See "and" above.
		Expr* result = andOrOr(n->snipLeft(), new BoolConst(true), n->snipRight());
		delete n;
		return result;
	}
	else
	{
		//Most Binops are handled the same as method calls.
		return visit((Call*)n);
	}
}

/*
3. [ x1, ..., xn ]

Figure out the type of the elements; call it T.  Translate it to:

T temp[n];
temp[0] := x1;
temp[1] := x2;
...
temp[n-1] := xn;
Then replace the array literal with temp.
*/
Node* ArrayLiteralTransform::visit(ArrayList* n) {
	if (n->getSize() == 0)
	{
		//Empty array literal
		return n;
	}

	string name = tempName("_temp");
	Type t = n->getType();
	VarDecl* decl = 
		new VarDecl(
			buildTNFromType(t),
			name);
	if (!n->containsNonConsts())
	{
		//n contains only constants.  We can
		//make a more efficient transformation by
		//letting the array list be a C++ initializer list.

		string temp2 = tempName("_temp");
		
		n->makeCPPInitializer();
		addStmt(new DeclStmt(
					new VarDecl(
						new RealCPPArray(
							buildTNFromType(t.getBaseType()), t.size()),
						temp2,
						n)));

		decl->setInitExpr(new Variable(temp2, t));

		addStmt(
			new DeclStmt(
				decl));
	}
	else
	{
		addStmt(
			new DeclStmt(
				decl));

		Exprs* values = n->getValues();
		for (int i = t.li(); i <= t.ui(); ++i)
		{
			Variable* tempVar = new Variable(name, t);
			Subscript* sub = new Subscript(tempVar, new IntConst(i));
			AssignExpr* ae = new AssignExpr("=", sub, values->snipValue(i));
			addStmt(new ExprStmt(ae));
		}
		delete n;
	}
	return new Variable(name, t);
}

void ArrayTransform::postVisit(RangeSubscript* n) {
	//Infer the equivalent indices for expressions
	//like arr[..5].
	if (n->getLeft() == 0) {
		long li = n->getBase()->getType().li();
		n->setLeft(new IntConst(li));
	}
	if (n->getRight() == 0 && n->getType().getType() != Type::DARRAY)
	{
		n->setRight(new IntConst(n->getType().ui()));
	}
}

//Only call ArrayLiteralTransform on statements with array literals in them.
bool hasArrayLiteral(Stmt* n) {
    return containsArrayConst(n);
}

void ArrayTransform::postVisit(Stmts* n) {
    transStmts<ArrayLiteralTransform>(n, hasArrayLiteral, true);
}

void ArrayTransform::postVisit(New* n) {
	//A new static array should be treated as a new dynamic array,
	//since you can't have a pointer to a static array.
	SArrayTypeNode* stn = dynamic_cast<SArrayTypeNode*>(n->getTypeNode());
	if (stn != 0)
	{
		Expr* dynSize;  //If the array has an initial value, then
			//it must have been inferred, so we can just make
			//the array dimensions empty in the output.
			//If there's no initial value, then we need an explicit
			//dynamic size.
			//(Remember an array initialization can't have both an initial value and a
			//dynamic size.)
		if (n->getArgs()->size() == 0)
			dynSize = new IntConst(stn->getType().ui());
		else 
			dynSize = 0;
		DArrayTypeNode* dtn = new DArrayTypeNode(
				stn->snipBase(), stn->getLi(), dynSize);
		dtn->setQuals(stn->getType().getQuals());
		n->setTypeNodeNoDelete(dtn);
		delete stn;
	}
}

