#ifndef BUILDTYPES_H
#define BUILDTYPES_H

#include "BuildVisitor.h"

//Build the types in the top-level of the symbol table
//(currently enums, later classes and other things as well)

class BuildTypes : public BuildVisitor {
public:
	virtual Node* visit(Enum* n);
	virtual Node* visit(Function* n);
};

#endif

