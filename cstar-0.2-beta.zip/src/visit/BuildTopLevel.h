#ifndef BUILDTOPLEVEL_H_
#define BUILDTOPLEVEL_H_

#include "BuildVisitor.h"

//Initial pass to build the top level of the symbol table.
//(currently functions and global variable declarations).
//In this section, declarations may appear after use, and
//there may be multiple declarations.

class BuildTopLevel : public BuildVisitor {
private:
	void conflict(Node* n, const string& name);
public:
	virtual Node* visit(Function* n);
	virtual Node* visit(VarDecl* n);
};

#endif /*BUILDTOPLEVEL_H_*/
