#ifndef BUILDTYPESVISITOR_H_
#define BUILDTYPESVISITOR_H_

/** Visitor which builds code blocks with declarations and definitions.
 * Gives an error for duplicate definitions.
 * Remember that declarations can now appear after use, except within code blocks.
 */

#include "BuildVisitor.h"
#include "SymbolTable.h"

class BuildSymTab : public BuildVisitor {
public:
	BuildSymTab() : BuildVisitor() {}
	BuildSymTab(SymbolTable* s) : BuildVisitor() {
		currentSymTable = s;
	}

	virtual Node* visit(Variable* n);
	virtual Node* visit(Block* n);
	virtual void preVisit(Enum* n);
	virtual Node* visit(AssignExpr* n);
	virtual void preVisit(VarDecl* n);	
	virtual void postVisit(Cast* n);
	virtual Node* visit(TypeVar* n);
    virtual void preVisit(LabelledStmt* n);

};

#endif /*BUILDTYPESVISITOR_H_*/
