#ifndef BREAK_CONTINUE_H
#define BREAK_CONTINUE_H

//Convert break and continue statements with
//labels to gotos, and insert target labels
//for the gotos.
//
//	-break is translated to a "goto" a NOOP statement after the loop.
//	-continue is translated to a "goto" a NOOP statement at the end of the
//	loop

//The loop is translated as follows:
//
//	label: for (...) stmt
//
//	becomes:
//
//	{label: for (...) { stmt label_continue: ; } label_break: ;}

#include "FixedVisitor.h"

class BreakContinue : public FixedVisitor {
private:
    long inLoop;
public:
    BreakContinue() : inLoop(0) {}
    
    virtual void preVisit(While* n);
    virtual void preVisit(For* n);
    virtual void postVisit(While* n);
    virtual void postVisit(For* n);
    virtual void postVisit(Break* n);
    virtual void postVisit(Continue* n);
	virtual Node* visit(LabelledStmt* n);
};

#endif

