#ifndef TYPECHECKER_H_
#define TYPECHECKER_H_

#include "ContextVisitor.h"

//Do typechecking (error checking), and set the type
//of variable (and a few other) AST nodes

class TypeChecker : public ContextVisitor {
protected:
/**@return Whether the arguments args are applicable to
 * the parameters in functionType */
bool applicable(Exprs* args, const Type& functionType);

/** Figure out which function the call n is calling.
 * (Overload resolution algorithm.)
 * @return True iff there was no error.
 */
bool disambiguate(Call* n);

/**@return whether fromNode can be treated as a to.*/
bool convertible(Expr*fromNode, Type to);

/** Check whether rhsNode can be assigned (with an assignment
 * expression or initial value in a declaration) to something of
 * type lhs.
 * @param missingDimensions Set to true for a
 * 		declaration where there are missing (inferred) array dimensions.
 * 		When there are, array := scalar is not allowed.
 * @param allowConstOnLeft Set to true for initial value of a
 * declaration, so that const int x := y doesn't generate an error.
 * @param assignExpr For error reporting.
 * @return rhsNode, coerced if necessary (see coerce function).
 * */
Expr* assignableFrom(Node* assignExpr, const Type& lhs, Expr* rhsNode, bool allowConstOnLeft = false);

/** Do typechecking on an initialization of something of type tn,
    being inialized with the value *ptrInitVal.
    ptrInitVal is a pointer to pointer because we might need to do
    a coercion on it to get it to a type acceptable for assignment to tn.
    E.g. int x := 1.0 might be valid if we can change 1.0 to int(1.0)
    (if the user has defined an implicit cast from float => int) */
void initialize(TypeNode* tn, Expr** ptrInitVal, Node* n);

/** Convert fromNode to type to.
 * @param assignExpr For error reporting.
 * @return Either fromNode (if no special conversion is necessary) 
 * or an explicit cast to to.  Generates an error if the coercion could not be
 * done. */
Expr* coerce(Node* assignExpr, Expr* fromNode, Type to);

private:
	/** Common function to implement both convertible and coerce,
	 * which looks for a user-defined cast from the type of fromNode to
	 * to.
	 * @param createNode True iff we should create a node for coercion.
	 * If false, makes it return fromNode if a user-defined cast was found,
	 * 		0 otherwise.
	 */
	Expr* convertibleGeneral(Expr* fromNode, Type to, bool createNode);

public:
virtual void postVisit(ArrayList* n);
virtual void postVisit(ArrayProp* n);
//virtual void postVisit(ArrayRange* n);
virtual void postVisit(Binop* n);
//virtual void postVisit(Block* n);
virtual void postVisit(Call* n);
virtual void postVisit(Cast* n);
virtual void postVisit(CaseStmt* n);
//virtual void postVisit(Const* n);
//virtual void postVisit(DeclList* n);
//virtual void postVisit(DeclOrDefn* n);
//virtual void postVisit(Decls* n);
//virtual void postVisit(DeclStmt* n);
//virtual void postVisit(Expr* n);
//virtual void postVisit(Exprs* n);
//virtual void postVisit(ExprStmt* n);
//virtual void postVisit(FloatConst* n);
virtual void postVisit(For* n);
virtual void postVisit(Function* n);
virtual void postVisit(GlobalVarDecls* n);
virtual void postVisit(InputExpr* n);
//virtual void postVisit(IntConst* n);
//virtual void postVisit(Node* n);
//virtual void postVisit(NormalParam* n);
virtual void postVisit(OutputStmt* n);
//virtual void postVisit(Param* n);
//virtual void postVisit(Params* n);
//virtual void postVisit(PrimType* n);
virtual void postVisit(RangedCaseStmt* n);
virtual void postVisit(RangeSubscript* n);
virtual void postVisit(Return* n);
virtual void postVisit(Select* n);
//virtual void postVisit(Stmt* n);
//virtual void postVisit(Stmts* n);
virtual void postVisit(Subscript* n);
//virtual void postVisit(Type* n);
//virtual void postVisit(UIntConst* n);
virtual void postVisit(Unop* n);
virtual void postVisit(VarDecl* n);
virtual void postVisit(Variable* n);
virtual void postVisit(While* n);
virtual void postVisit(If* n);
virtual void postVisit(IfExpr* n);
virtual void postVisit(AssignExpr* n);
virtual void postVisit(ValueOf* n);
virtual void postVisit(AddressOf* n);
//virtual void postVisit(BoolConst* n);
virtual void postVisit(DeclExpr* n);
virtual void postVisit(Break* n);
virtual void postVisit(Continue* n);
virtual void postVisit(New* n);
virtual void postVisit(Delete* n);
virtual void postVisit(Goto* n);


};

#endif /*TYPECHECKER_H_*/
