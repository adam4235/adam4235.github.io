#include "TypeChecker.h"
#include "typeinfo.h"
#include "error.h"
#include "SymbolTable.h"
#include "whole_ast.h"
#include "ArrayConstSearch.h"
#include <memory>

using namespace std;

//Give an error when a type can't t2 be treated as another type t1
void typeError(Node* assignExpr, const Type& t1, const Type& t2)
{
	compileError << linenum(assignExpr) << "Unmatched types: Can't have " 
				 << t1 << " := " 
				 << t2 << "." << endl;
}

Expr* TypeChecker::convertibleGeneral(Expr* fromNode, Type to, bool createNode) {
	Type from = fromNode->getType();
	if (!from.isConst() && to.isConst()) return 0;  //Can't
		//have const := non-const

	//Ignore qualifiers like const in determining whether a cast exists
	from.clearQuals();
	to.clearQuals();

	string toAsString = Type::typeAsString(to.getType());
    
    //Create the type of the user-defined operator that would have to exist
	vector<Type> params;
	params.push_back(from);
	Type fType = Type(Type::FUNCTION, params, to);
	if (currentSymTable->exists(toAsString, fType))
	{
		if (createNode)
			return new Call(new Variable(toAsString, fType), fromNode);
		else return fromNode;
	}
	else return 0;
}

bool TypeChecker::convertible(Expr* fromNode, Type to)
{
	if (fromNode->getType().isSubType(to)) return true;
	else return convertibleGeneral(fromNode, to, false) != 0;
}

Expr* TypeChecker::coerce(Node* assignExpr, Expr* fromNode, Type to)
{
	if (fromNode->getType().isSubType(to)) return fromNode;  //No coercion necessary
	else 
	{
		Expr* result = convertibleGeneral(fromNode, to, true);
		if (result == 0)
		{
        	compileError << linenum(assignExpr) << "Unmatched types.  Found: " 
                << fromNode->getType() << ".  Expected: " 
                << to << "." << endl;
            
			return fromNode;
		}
		else return result;
	}
}

Expr* TypeChecker::assignableFrom(Node* assignExpr, const Type& lhs, Expr* rhsNode, bool allowConstOnLeft) {
	const Type& rhs = rhsNode->getType();

    //First check whether it can be be assigned by the language's subtyping rules
	if (rhs.isSubType(lhs, allowConstOnLeft)) return rhsNode;
    
    //Next check whether the user has defined a cast from the RHS to the LHS
	Expr* newRHS = convertibleGeneral(rhsNode, lhs, true);
	if (newRHS != 0) return newRHS;

	//Finally, check whether it's a case of array := scalar
	
	//Might have e.g. reference to array := scalar
	Type l = lhs.stripRef(), r = rhs.stripRef();

	if (l.isArray())// && !r.isArray())
	{
		if (!r.isSubType(l.getBaseType()))
		{
            //Error - but should it be an array := scalar error?
            //It seems a normal error is more user-friendly.
#if 0
			compileError << linenum(assignExpr) << "Assignment of array to scalar must have matching types.  ("
				<< r << " not a subtype of " << l.getBaseType() << ")" << endl;
#endif
            typeError(assignExpr, lhs, rhs);
		}
		return rhsNode;
	}

    //Nothing worked; the assignment is invalid
	typeError(assignExpr, lhs, rhs);
	return rhsNode;
}

void notArray(Node* n) {
	compileError << linenum(n) << "Expression is not an array.  Only arrays can be the base operand of the [] operator.\n";
}

void checkForInt(Expr* e, string errPrefix)
{
	const char* endingError = " operand of `..' must have type integer, but doesn't.\n";
	
	if (e != 0)
	{
		const Type& t = e->getType();
		if (!t.isInt())
			compileError << linenum(e) << errPrefix << endingError;
	}
}

/* Check that the range is an integer range */
void TypeChecker::postVisit(RangeSubscript* n) {
	checkForInt(n->getLeft(), "Left");
	checkForInt(n->getRight(), "Right");
		
	if (!n->getBase()->getType().isArray())
		notArray(n->getBase());
}

void TypeChecker::postVisit(Subscript* n) {
	bool baseIsArray = n->getBase()->getType().isArray(); 
	if (!baseIsArray)
		notArray(n->getBase());
	const Type& elementType = n->getElement()->getType();
	if (!elementType.isInt())
		compileError << linenum(n->getElement()) << "Subscript must have integer type, but doesn't.\n";
}

void TypeChecker::postVisit(Unop* n) {
	if (n->isIncOrDec())
	{
		if (!n->getOperand()->isLvalue())
		{
			compileError << linenum(n->getOperand()) << 
				"Can only use `" << n->getOper() << "' operator on an l-value (storage location)." 
				"  Expression is not an l-value." << endl;
		}
	}
	postVisit((Call*)n);
}

/** Called on the LHS of an assignment expression.
 * Checks that there are the correct number of range subscript brackets
 * in the expression.
 * E.g. if you have arr := arr2, and arr is an array, it would give an
 * error because the user must change it to arr[..] := arr2.
 *
 * @param numAllowedBases The number of dimensions allowed in
 * 	n (i.e. the number of range subscripts we've seen so far)
 */
bool checkArrayLHS(Expr* n, int numAllowedBases)
{
	RangeSubscript* nAsRange;
	if ((nAsRange = dynamic_cast<RangeSubscript*>(n)) == 0)
	{
		Type t = n->getType();
		for (int i = numAllowedBases; i > 0; --i)
		{
			t = t.getBaseType();  //t must be an array because of the
				//typechecking done on the sub-AST branches
		}
		return !t.isArray();
	}
	else 
		return checkArrayLHS(nAsRange->getBase(), numAllowedBases + 1);
}

void assignmentChecks(Node* n, const Type& targetType, Expr* rhs)
{
	const Type& srcType = rhs->getType();
	if (rhs->isLvalue() && srcType.isPtr() && srcType.hasFlag(Type::CONST_FLAG) && !targetType.isConst())
	{
		compileError << linenum(n) << "Can't assign a pointer to constant to"
			" a pointer to non-constant." << endl;
	} 
}

void TypeChecker::postVisit(AssignExpr* n) {
	const Type& targetType = n->getLeft()->getType();
	if (!n->getLeft()->isLvalue()) {
		compileError << linenum(n->getLeft()) << "Left hand side of assignment must be an l-value "
			"(storage location).  Expression is not an l-value." << endl;
	}
	else if (n->getLeft()->isConst()) {
		compileError << linenum(n->getLeft()) << "Left hand side of assignment can't be constant." << endl;
	}
	assignmentChecks(n, targetType, n->getRight());
	
	if (!checkArrayLHS(n->getLeft(), 0))
	{
		compileError << linenum(n->getLeft()) << "Left hand side of assignment needs to "
			"be subscripted.  Use [..] for an array copy." << endl;
	}
	n->setRightNoDelete(assignableFrom(n, targetType, n->getRight()));
    if (n->getOper() == "/=" && targetType.isInt())
    {
        compileError << linenum(n) << "Can't have an integer on the LHS of /=, because it's always floating point division in C*.  (Use \\= for integer division.)" << endl;
    }
	if (!errorFound)
	{
        
		if (n->getOper() != "=")
			postVisit((Call*)n);  //For +=, -=, etc. we have to typecheck
		//it as a call and look up the operator in the symbol table.
		//The := operator isn't in the symbol table, so don't do the Call
		//processing for it.
	}
}

void TypeChecker::postVisit(Binop* n) {
    if (n->isEnumEquality()) return;  //== and != for enum types
        //won't be in the symbol table.
    else if (n->isPtrEquality()) return;  //Likewise for == and != for pointers
    
    //Most binary operators are treated like a method call
    //Look up the operator in the symbol table and get the return value.
    postVisit((Call*)n);
}

void checkDimsWithInitval(TypeNode* tn) {
	const TypeNode* badNode = tn->checkDimsWithInitval();
	if (badNode != 0) compileError << linenum(badNode) << 
		"Can't give both an initial value and explicit dynamic array dimensions." << endl;
}

void TypeChecker::initialize(TypeNode* tn, Expr** ptrInitVal, Node* n)
{
	bool hasInit;
	Expr* initVal;
	if (ptrInitVal == 0)
	{
		hasInit = false;
		initVal = 0;
	}
	else
	{
		hasInit = *ptrInitVal != 0;
		initVal = *ptrInitVal;
	}
	const Type& t = tn->getType();

	if (hasInit)
	{
		Expr* initExpr = initVal;
		assignmentChecks(n, t, initExpr);
		*ptrInitVal = 
				assignableFrom(n, t, 
					initExpr, 
					true);
		if (tn->isArrayEqualsScalar(initVal->getType())) 
		{
			//In array := scalar, the LHS must have the form:
			//int arr[C1][C2]...[Cn][y] := scalar
			//where Ci are constants.
			//(If there's a pointer in there somewhere, then the pointer can
			//be a pointer to a dynamic array; see checkPtr called below.)
			ArrayTypeNode* atn = dynamic_cast<ArrayTypeNode*>(tn);
			DArrayTypeNode* dtn = dynamic_cast<DArrayTypeNode*>(tn);
			if ((dtn != 0 && dtn->getSize() == 0) || tn->dimensionsOmitted())
			{
				compileError << linenum(tn) << 
					"Missing size for array.  Assignment of array to"
					" scalar requires all sizes to be explicit." << endl;
			}
			else {
				checkDimsWithInitval(atn->getBase());  //The above call to dimensionsOmitted checked
					//for empty dimensions.  This checks for explicit dynamic dimensions.  The only thing
					//still allowed (up to the first pointer) is static dimensions.
			}
		}
		else
		{
			checkDimsWithInitval(tn);
		}
	} 

	const TypeNode* badNode = tn->checkPtr();
	if (badNode != 0)
	{
		compileError << linenum(badNode) << 
			"Can't have a pointer to an array with explicit size.  Leave the size unspecified." << endl;
	}

	if (t.hasFlag(Type::REF_FLAG)) //getType() == Type::REF)
	{
		if (!hasInit)
			compileError << linenum(n) << "Missing initial value for reference." << endl;
		else if (!t.isConst() && !initVal->isLvalue())
			compileError << linenum(n) << "Initial value for non-const reference must be an l-value." << endl;
	}
}

void TypeChecker::postVisit(VarDecl* n) {
	initialize(n->getTypeNode(), &(n->initVal), n);
}

void TypeChecker::postVisit(For* n) {
	if (n->getStep() == 0)
		compileError << linenum(n) << "Step of 0 not allowed.\n";
	const Type& varType = n->getLoopVar()->getType(),
		type1 = n->getLeft()->getType(),
		type2 = n->getRight()->getType();
	bool errFound = false; 

	if (type1.isArray()) {
		compileError << linenum(n->getLeft()) << "Array not allowed to the left of `..'.\n";
		errFound = true;
	}
	if (type2.isArray()) {
		compileError << linenum(n->getRight()) << "Array not allowed to the right of `..'.\n";
		errFound = true;
	}
	if (varType.isArray()) {
		compileError << linenum(n->getLoopVar()) << "Array not allowed as a loop counter.\n";
		errFound = true;
	}
	if (!errFound)
	{
		n->setLeftNoDelete(coerce(n, n->getLeft(), varType));
		n->setRightNoDelete(coerce(n, n->getRight(), varType));
	}
}

void TypeChecker::postVisit(Variable* n) {
    Type t = currentSymTable->lookUpType(n->getName()); 
    if (t.getType() == Type::TYPE)
    {
        compileError << linenum(n) << "Type `" << n->getName() << "' "
            "cannot be used as a variable." << endl;
    }
    n->setType(t);
}

void TypeChecker::postVisit(ArrayList* n) {
	bool noRangesAllowed = n->containsNonConsts();

	//Figure out the type of the list of values from the
	//types of all the elements
	Type type(Type::BOT);
	const vector<Expr*> & list = n->getValues()->getExprs();
	for (vector<Expr*>::const_iterator i = list.begin();
		i != list.end(); ++i)
	{
		Type newType = (*i)->getType();

		if (dynamic_cast<ArrayRange*>(*i) != 0)
		{
			if (noRangesAllowed)
			{
				//TODO later: If .. becomes an operator that can have variables,
				//inform the user that they could use concatenation instead.
				compileError << linenum(*i) << "Array ranges only allowed in literals "
					"composed entirely of constants." << endl;
				return;
			}
					
			//For ranges of values, e.g. 1..100,
			//we have to consider the base type
			//of the range.
			newType = newType.getBaseType();
		}
					
		type = type.mostGeneral(newType);
	}
	
	long size = n->getSize();  //The size of the
		//list is not the number of elements in the vector list,
		//but the size calculated during parsing.
		//Remember that we can have array literals like
		//[1..100], which has 1 list item but size 100.
	
	n->setType(Type(type, size));
}

void TypeChecker::postVisit(InputExpr* n) {
	//The values in an input statement can't be arrays.
	//(Later, this will be replaced by a check for the existence
	//of an operator matching the operand types). 
	
	vector<Expr*>& list = n->getInputs();
	for (vector<Expr*>::iterator i = list.begin(); i != list.end(); ++i)
	{
		const Type& t = (*i)->getType();
		if (t.isArray())
		{
			compileError << linenum(*i) << "Can't input into an array.\n";
		}
	}
}

void TypeChecker::postVisit(OutputStmt* n) {
	//The values in an output statement can't be arrays.
	//(Later, this will be replaced by a check for the existence
	//of an operator matching the operand types). 
	
	vector<Expr*>& list = n->getOutputs();
	for (vector<Expr*>::iterator i = list.begin(); i != list.end(); ++i)
	{
		const Type& t = (*i)->getType();
		if (t.isArray() && t.getBaseType() != Type::CHAR)
			//Can't output arrays, with the exception of strings
		{
			compileError << linenum(*i) << "Can't output an array.\n";
		}
	}
}

void TypeChecker::postVisit(Select* n) {
	if (n->getSelectExpr()->getType().isArray())
	{
		compileError << linenum(n->getSelectExpr()) << "Can't have an array in a selection statement.\n";
	}
}

void TypeChecker::postVisit(CaseStmt* n) {
	if (n->getCaseExpr() != 0 && n->getCaseExpr()->getType().isArray())
	{
		compileError << linenum(n->getCaseExpr()) << "Can't have an array in a case statement.\n";
	}
}

void TypeChecker::postVisit(RangedCaseStmt* n) {
	checkForInt(n->getLeft(), "Left");
	checkForInt(n->getRight(), "Right");
}

void TypeChecker::postVisit(ArrayProp* n) {
	if (!n->getLeft()->getType().isArray())
	{
		compileError << linenum(n->getLeft()) << "Left hand side of array property expression is not an array.\n";
	}
}

void TypeChecker::postVisit(Return* n) {
	//get return type of current function
	Type returnType = currentSymTable->currentFunction()->type.getRetType();
	
    if (returnType == Type::VOID)
    {
        if (n->getRetVal() != 0)
        {
            compileError << linenum(n) << "Can't return a value from a void function." << endl;
        }
    }
	else n->setRetValNoDelete(coerce(n, n->getRetVal(), returnType));
}

bool TypeChecker::applicable(Exprs* args, const Type& functionType)
{
	const vector<Expr*>& argList = args->getExprs();
	const vector<Type>& paramList = functionType.getParams();

	//#args must = #params for the call to be applicable
	if (argList.size() != paramList.size()) return false;
	vector<Expr*>::const_iterator i = argList.begin();
	vector<Type>::const_iterator j = paramList.begin();

	//All the argument types must be subtypes of the parameter types
	for (; i != argList.end() && j != paramList.end(); ++i, ++j)
	{
		if (!convertible((*i), (*j))) return false;
	}
	return true;
}

void noSuchFunction(Call* n)
{
    Variable* name = dynamic_cast<Variable*>(n->getName());
    string nameAsString = (name == 0)? "" : " to `" + name->getName() + "'";
    compileError << linenum(n) << "No function found to apply to call"
            << nameAsString << " with arguments (";
    const vector<Expr*>& list = n->getArgs()->getExprs();
    for (vector<Expr*>::const_iterator i = list.begin(); i != list.end(); ++i)
    {
            compileError << (*i)->getType();
            if (i + 1 != list.end()) compileError << ", ";
    }
    compileError << ")" << endl;
}
            
void ambiguousCall(Call* n, const vector<Type>& choices, const vector<Node*>& linenums)
{
	compileError << linenum(n) << "Ambiguous call: multiple functions match.  Possible matches:" << endl;

	vector<Node*>::const_iterator j = linenums.begin();
	for (vector<Type>::const_iterator i = choices.begin(); i != choices.end(); ++i, ++j)
	{
		compileError << *i << " (See line " << CompileError::getLineInfo(*j) << ")" << endl;
	}
}

bool TypeChecker::disambiguate(Call* n) {
	const Type& ambType = n->getName()->getType();
	if (ambType.getType() != Type::AMB) return true;

	//Now we have an ambiguous type to disambiguate as much as possible
	
	//1. Remove any function possibilities that are not applicable
	vector<Type> choices;
	vector<Node*> linenums;
    vector<Node*> allLinenums = ambType.getPointsOfDefnOrDecl();
	vector<Node*>::const_iterator j = allLinenums.begin();
    vector<Type> allChoices = ambType.getChoices();
	for (vector<Type>::const_iterator i = allChoices.begin(); 
			i != allChoices.end(); ++i, ++j)
	{
		if (applicable(n->getArgs(), *i))
		{
//			cout << "Applicable type: " << *i << endl;  //DEBUG
			choices.push_back(*i);
			linenums.push_back(*j);
		}
	}

	if (choices.size() == 0) 
	{
        noSuchFunction(n);
		return false;
	}

//cout << choices.size() << endl;  //DEBUG
	
	//2. Search for a function that's more specific than all the others
	for (vector<Type>::const_iterator i = choices.begin(); i != choices.end(); ++i)
	{
		bool iMostSpecific = true;  //assume it's the most specific until proven otherwise
		for (vector<Type>::const_iterator j = choices.begin(); 
				j != choices.end() && iMostSpecific; ++j)
		{
			if (!i->isMoreSpecific(*j))
			{
//				cout << *i << " is not more specific than " << *j << endl;  //DEBUG
				iMostSpecific = false;
			}
//			else cout << *i << " is more specific than " << *j << endl;  //DEBUG
		}
		if (iMostSpecific)
		{
			n->disambiguate(*i);
			return true;
		}
	}
	ambiguousCall(n, choices, linenums);
	return false;
}

void TypeChecker::postVisit(Call* n) {
	bool disamSuccess = true;
	if (n->getName()->getType().getType() == Type::AMB)
	{
		disamSuccess = disambiguate(n);  //overloading resolution
	}
	if (disamSuccess)  //Still have to coerce the arguments below
		//if disambiguation was done.  (Also if the type wasn't ambiguous.)
	{
		if (!n->getName()->getType().isFunction())
		{
			compileError << linenum(n->getName()) << "Attempt to call a non-function." << endl;
		}
		else
		{
			//Give specific error messages for the most common case of only 1
			//function of the given name
			vector<Type> parameters = n->getName()->getType().getParams();
			vector<Expr*> arguments = n->getArgs()->getExprs();
			if (arguments.size() < parameters.size())
			{
				compileError << linenum(n) << "Too few arguments in function call.\n";
			}
			else if ( arguments.size() > parameters.size())
			{
				compileError << linenum(n) << "Too many arguments in function call.\n";
			}
			else
			{
				std::size_t sz = arguments.size();
				Exprs* args = n->getArgs();
				Exprs* newArgs = new Exprs();
				for (std::size_t i = 0; i < sz; ++i)
				{
					Type param = parameters[i];
					Expr* arg = args->snipValue(i);
					newArgs->add(coerce(arg, arg, param));
				}
				n->setArgs(newArgs);
			}
		}
	}
}

//Checks the condition of a while or if to see whether
//it has type bool
void checkCond(Expr* cond) {
	Type condType = cond->getType();
	if (condType.getType() != Type::BOOL)
	{
		compileError << linenum(cond) << "Condition must be a boolean.  `" 
			<< condType << "' is not allowed." << endl;
	}
}

//Check whether a while loop contains an array literal somewhere in it.
//This isn't allowed because array literals are pulled out, so it would
//be difficult to ensure that the expressions in them are re-evaluated
//each time through the loop.
//This check isn't needed for for loops because they only execute each
//of their expressions once.
void checkLoopForArray(Expr* cond) {
	if (containsArrayConst(cond))
	{
		compileError << linenum(cond) << "Can't have array constants in loop conditions.  (Yet.)" << endl;
	}
}

void TypeChecker::postVisit(While* n) {
	checkLoopForArray(n->getCond());
	checkCond(n->getCond());
}

void TypeChecker::postVisit(If* n) {
	checkCond(n->getCond());
}

void TypeChecker::postVisit(Cast* n) {
	Type castType = n->getTargetType()->getType();
	if (castType.isArray()) {
		compileError << linenum(n->getTargetType()) << "Can't cast to an array type." << endl;
	}
	else if (castType.isFunction()) {
        //This currently isn't possible.
		compileError << linenum(n->getTargetType()) << "Can't cast to a function type." << endl;
	}
}

void TypeChecker::postVisit(ValueOf* n) {
	const Type& baseType = n->getBaseExpr()->getType();
	if (!baseType.isPtr())
	{
		compileError << linenum(n->getBaseExpr()) << "`$' can only be applied to a pointer.  Expression is not a pointer." << endl;
	}
}

void TypeChecker::postVisit(AddressOf* n) {
	if (!n->getBaseExpr()->isLvalue())
	{
		compileError << linenum(n->getBaseExpr()) << "`@' can only be applied to an l-value (storage location).  Expression is not an l-value." << endl;
	}
}

void TypeChecker::postVisit(GlobalVarDecls* n) {
	if (containsArrayConst(n, true))
	{
		//if there was an array constant within composed of non-constants
		compileError << linenum(n) << "Array initializations in global variables may only"
			" be composed of constants." << endl;
	}
}

void TypeChecker::postVisit(DeclExpr* n) {
	compileError << linenum(n) << "Declaration not allowed in this expression.  "
		"Declarations in expressions "
		"only allowed in if conditions, while loop conditions, expression statements, "
		"or input expressions appearing in one of those types of statements"
		"." << endl;
}

void TypeChecker::postVisit(IfExpr* n) {
	checkCond(n->getIfCond());
}

//Break and continue with labels should have been desugared
//in the cases where they're allowed.

void TypeChecker::postVisit(Break* n) {
    if (n->getTarget() != "")
        compileError << linenum(n) << "Not in a loop labelled `" << n->getTarget() << "'." << endl;
}

void TypeChecker::postVisit(Continue* n) {
    if (n->getTarget() != "")
        compileError << linenum(n) << "Not in a loop labelled `" << n->getTarget() << "'." << endl;
}

void TypeChecker::postVisit(New* n) {
	Type consType = n->getTypeNode()->getType();
	if (consType.getQuals() != Type::NO_FLAG)
	{
		compileError << linenum(n) << "Type in a new expression can't be qualified." << endl;
	}
	else if (consType.isAlias())
	{
		compileError << linenum(n) << "Can't new a pointer or reference." << endl;
	}
	else if (consType.getType() == Type::THING)
	{
		compileError << linenum(n) << "Can't create an object of type thing on the heap." << endl;
	}
	else if (consType.isArray())
	{
		//Arrays may have 0 or 1 arguments
		size_t numArgs = n->getArgs()->size();
		if (numArgs == 0)
		{
			initialize(n->getTypeNode(), 0, n);
		}
		else if (numArgs == 1)
		{
			initialize(n->getTypeNode(), &(n->args->exprs[0]), n);
		}
		else
		{
			compileError << linenum(n) << 
				"Array new expressions may have at most one argument." << endl;
		}
	}
	else if (consType.isPrimitive())
	{
		//Primitive types must have exactly 1 argument
		if (n->getArgs()->size() == 1)
		{
			initialize(n->getTypeNode(), &(n->args->exprs[0]), n);
		}
		else
		{
			compileError << linenum(n) << 
				"Constructors for primitive types must have exactly one argument." << endl;
		}
	}
    else if (consType.isEnum())
    {
        //Enums must have exactly 1 argument
        if (n->getArgs()->size() == 1)
        {
            initialize(n->getTypeNode(), &(n->args->exprs[0]), n);
        }
        else
        {
			compileError << linenum(n) << 
                "Constructors for enums must have exactly one argument." << endl;
		}        
    }
	else
	{
		//newing a class (user-defined type)
		compileError << linenum(n) << "User-defined types can't be constructed in new expressions.  (Yet.)"
			<< endl;
	}
}

void TypeChecker::postVisit(Delete* n) {
	const vector<Expr*>& list = n->getVariables()->getExprs();
	for (vector<Expr*>::const_iterator i = list.begin(); i != list.end(); ++i)
	{
		const Type& t = (*i)->getType();
		if (!t.isPtr()) {
			compileError << linenum(*i) << "Can only delete pointers.  Expression is not a pointer." << endl;
		}
	}
}

void TypeChecker::postVisit(Function* n)
{
	//Make sure user-defined casts have the proper form
	//and aren't defining a cast that isn't needed.
	if (isUserCast(n->getName()))
	{
		if (n->getParams()->getParams().size() != 1)
		{
			compileError << linenum(n) << "User-defined casts must have exactly one parameter." << endl;
		}
		else
		{
			Type retType = n->getRetType();
			Type paramType = n->getParams()->getParams()[0]->getType();
			if (paramType.isSubType(retType))
			{
				compileError << linenum(n) << "Type `" << paramType << 
					"' is already a subtype of type `" << retType << "'.  Can't define a cast"
					" from a subtype to a supertype." << endl;
			}
		}
	}
	else if (n->isMain())
	{
		//Typecheck the main function
		Type t = n->getType();
		string usageError = "  `main' must have no parameters or a single parameter of type char[][].";
		if (t.getRetType() != Type::INT)
		{
			compileError << linenum(n) << "`main' must return an int." << endl;
		}
		else if (t.getParams().size() > 1)
		{
			compileError << linenum(n) << "Too many parameters to `main'." << usageError << endl;
		}
		else if (t.getParams().size() == 1 && !n->isMainWithArgs())
		{
			compileError << linenum(n) << "Invalid parameter to main." << usageError << endl;
		}
	}
}

void TypeChecker::postVisit(Goto* n) {
    const string& label = n->getTarget();
    bool labelExists = currentSymTable->exists(label);
    if (!(labelExists &&
        currentSymTable->lookUpType(label) == Type::LABEL))
    {
        compileError << linenum(n) << "Label not found: `" << label << "'" << endl;
    }
}
