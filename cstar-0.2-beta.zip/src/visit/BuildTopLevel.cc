#include "BuildTopLevel.h"
#include "ast/Function.h"
#include "ast/VarDecl.h"
#include "BuildVarDecls.h"
#include "error.h"
#include "tempname.h"

using namespace std;

void BuildTopLevel::conflict(Node* n, const string& name) {
	compileError << linenum(n) << "Conflict with previous definition/declaration of `"
		<< name << "'" << endl;
	outputPrevDefn(name);
	cerr << endl;
}

Node* BuildTopLevel::visit(Function* n) {
	SymbolTable* s = currentSymTable;

	//First build the types in the function's parameters and return
	//type
	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->getParams()->accept(varDecls.get());
	if (n->getRetTypeNode() != 0) n->getRetTypeNode()->accept(varDecls.get());

	//Now build the type of the function itself
	n->buildType();

	//Finally, add the function to the symbol table.
	if (n->getBody() != 0 && currentSymTable->hasDefn(n->getName(), n->getType())) {
	//Multiple declarations are allowed, but not multiple definitions
		compileError << linenum(n) << "Duplicate definition of `" << n->getName() << "'.  ";
		outputPrevDefn(n->getName(), n->getType());
		cerr << endl;
	}
	else {
		//Can't have a function of the same name with a different type as
		//in a previous declaration/definition.
		if (currentSymTable->addFunction(n) == 0) {
			conflict(n, n->getName());
		}
	}
	assert(s == currentSymTable);
	return n;
}

Node* BuildTopLevel::visit(VarDecl* n) {
	//See visit(Function*)
	
	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->accept(varDecls.get());
	
	if (n->getInitVal() != 0 && currentSymTable->hasDefn(n->getName(), n->getType())) {
		compileError << linenum(n) << "Duplicate definition of `" << n->getName() << "'.  ";
		outputPrevDefn(n->getName(), n->getType());
		cerr << endl;
	}
	else {
		if (!currentSymTable->add(n)) {
			conflict(n, n->getName());
		}
	}

	if (n->getType().isStatic()) {
		compileError << linenum(n) << "Only local variables can be static." << endl;
	}
	return n;
}

