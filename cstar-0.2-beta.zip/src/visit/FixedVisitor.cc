#include "FixedVisitor.h"
#include "whole_ast.h"

using namespace std;

Node* FixedVisitor::visit(ArrayList* n) {
	preVisit(n);
	n->values = (Exprs*)(n->getValues()->accept(this));
	assert(n->values != 0);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(ArrayProp* n) {
	preVisit(n);
	n->left = (Expr*)n->getLeft()->accept(this);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(ArrayRange* n) {
	preVisit(n); 
	n->left = (Expr*)n->getLeft()->accept(this);
	n->right = (Expr*)n->getRight()->accept(this);
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(Binop* n) {
	preVisit(n);
	n->name = (Expr*)n->getName()->accept(this);  //Ensure the operator is looked up in the symbol table
	n->args = (Exprs*)n->getArgs()->accept(this);
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(Block* n) {
	preVisit(n); 
	n->stmts = (Stmts*)n->getStmts()->accept(this);
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(Call* n) {
	preVisit(n); 
	n->name = (Expr*)n->getName()->accept(this);
	n->args = (Exprs*)n->getArgs()->accept(this);
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(CaseStmt* n) {
	preVisit(n);
	if (n->getCaseExpr() != 0) 
		n->caseExpr = (Expr*)n->getCaseExpr()->accept(this);
	n->subStmt = (Stmt*)n->getSubStmt()->accept(this);
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(Const* n) {
	preVisit(n);  postVisit(n); return n; }

	/*
template<class U, class T = vector<U> > void FixedVisitor::acceptList(T begin, T end) {
	for (T i = begin;
		i!= end; ++i)
	{
		Node** n = i;
		*n = (*i)->accept(this);
	}
}
*/


Node* FixedVisitor::visit(DeclList* n) {
	preVisit(n);
//	acceptList(n->decls.begin(), n->decls.end());
	for (vector<DeclOrDefn*>::iterator i = n->decls.begin(); i != n->decls.end(); ++i)
	{
		*i = (DeclOrDefn*)(*i)->accept(this);
	}


	 postVisit(n); return n;
}
Node* FixedVisitor::visit(DeclOrDefn* n) {
	preVisit(n);  postVisit(n); return n; }
Node* FixedVisitor::visit(Decls* n) {
	preVisit(n);
	for (vector<VarDecl*>::iterator i = n->decls.begin(); i != n->decls.end(); ++i)
	{
		*i = (VarDecl*)(*i)->accept(this);
	}

	//acceptList(n->getDecls().begin(), n->getDecls().end());
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(DeclStmt* n) {
	preVisit(n);
	n->decls = (Decls*)n->getDecls()->accept(this); 
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(Expr* n) {
	preVisit(n);  postVisit(n); return n; }
Node* FixedVisitor::visit(Exprs* n) {
	preVisit(n); 
	for (vector<Expr*>::iterator i = n->exprs.begin(); i != n->exprs.end(); ++i)
		*i = (Expr*)(*i)->accept(this);
	//acceptList(n->getExprs().begin(), n->getExprs().end()); 
	 postVisit(n); return n; }
Node* FixedVisitor::visit(ExprStmt* n) {
	preVisit(n); 
	n->expr = (Expr*)n->getExpr()->accept(this);
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(FloatConst* n) {
	preVisit(n);  postVisit(n); return n; }
Node* FixedVisitor::visit(For* n) {
	preVisit(n);
	n->loopVar = (Expr*)n->getLoopVar()->accept(this);
	n->left = (Expr*)n->getLeft()->accept(this);
	n->right = (Expr*)n->getRight()->accept(this);
	if (n->body != 0) 
		n->body = (Stmt*)n->body->accept(this);
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(Function* n) {
	preVisit(n);
	n->params = (Params*)n->getParams()->accept(this);
	if (n->getBody() != 0) 
		n->body = (Stmts*)n->getBody()->accept(this); 
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(GlobalVarDecls* n) {
	preVisit(n);
	n->decls = (Decls*)n->getDecls()->accept(this); 
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(InputExpr* n) {
	preVisit(n);
	for (vector<Expr*>::iterator i = n->inputs.begin(); i != n->inputs.end(); ++i)
	{
		*i = (Expr*)(*i)->accept(this);
	}
	//acceptList(n->getInputs().begin(), n->getInputs().end());
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(IntConst* n) {
	preVisit(n);  postVisit(n); return n; }
Node* FixedVisitor::visit(NullConst* n) {
	preVisit(n);  postVisit(n); return n; }
Node* FixedVisitor::visit(Node* n) {
	preVisit(n);  postVisit(n); return n; }
Node* FixedVisitor::visit(NormalParam* n) {
	preVisit(n);
	n->decl = (VarDecl*)n->getDecl()->accept(this); 
	 postVisit(n); return n; }
Node* FixedVisitor::visit(OutputStmt* n) {
	preVisit(n);
	for (vector<Expr*>::iterator i = n->outputs.begin(); i != n->outputs.end(); ++i)
	{
		*i = (Expr*)(*i)->accept(this);
	}
	//acceptList(n->getOutputs().begin(), n->getOutputs().end()); 
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(Param* n) {
	preVisit(n);  postVisit(n); return n; }
Node* FixedVisitor::visit(Params* n) {
	preVisit(n);
	for (vector<Param*>::iterator i = n->params.begin(); i != n->params.end(); ++i)
		*i = (Param*)(*i)->accept(this);
	//acceptList(n->getParams().begin(), n->getParams().end()); 
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(RangedCaseStmt* n) {
	preVisit(n);
	n->caseExpr = (Expr*)n->getLeft()->accept(this);
	n->secondExpr = (Expr*)n->getRight()->accept(this);
	if (n->getSubStmt() != 0) 
		n->subStmt = (Stmt*)n->getSubStmt()->accept(this); 
	 postVisit(n); return n; 
}
Node* FixedVisitor::visit(RangeSubscript* n) {
	preVisit(n);
	n->base = (Expr*)n->getBase()->accept(this);
	if (n->getLeft() != 0)
		n->left = (Expr*)n->getLeft()->accept(this);
	if (n->getRight() != 0)
		n->right = (Expr*)n->getRight()->accept(this);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Return* n) {
	preVisit(n);
	n->retVal = (Expr*)n->getRetVal()->accept(this);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Select* n) {
	preVisit(n);
	n->selectExpr = (Expr*)(n->getSelectExpr()->accept(this));
	n->selectBlock = (Block*)(n->getSelectBlock()->accept(this));
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Stmt* n) {
	preVisit(n);	 postVisit(n); return n; }
Node* FixedVisitor::visit(Stmts* n) {
	preVisit(n);
	for (vector<Stmt*>::iterator i = n->stmts.begin(); i != n->stmts.end(); ++i)
		*i = (Stmt*)(*i)->accept(this);
	//acceptList(n->getStmts().begin(), n->getStmts().end());
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Subscript* n) {
	preVisit(n);
	n->base = (Expr*)n->getBase()->accept(this);
	n->element = (Expr*)n->getElement()->accept(this);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(CharConst* n) {
	preVisit(n);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Unop* n) {
	preVisit(n);
	n->name = (Expr*)n->getName()->accept(this);  //Ensure the operator is looked up in the symbol table
	n->args = (Exprs*)n->getArgs()->accept(this);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(VarDecl* n) {
	preVisit(n);
	n->type = (TypeNode*)n->type->accept(this);
	if (n->getInitVal() != 0)
		n->initVal = (Expr*)n->getInitVal()->accept(this);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Variable* n) {
	preVisit(n);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(If* n) {
	preVisit(n);
	n->cond = (Expr*)n->getCond()->accept(this);
	n->ifPart = (Stmt*)n->getIf()->accept(this);
	if (n->getElse() != 0) 
		n->elsePart = (Stmt*)n->getElse()->accept(this);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(While* n) {
	preVisit(n);
	if (n->isDoWhile())
	{
		//visit body first for a do ... while (...);
		n->body = (Stmt*)n->getBody()->accept(this);
		n->cond = (Expr*)n->getCond()->accept(this);
	}
	else {
		n->cond = (Expr*)n->getCond()->accept(this);
		n->body = (Stmt*)n->getBody()->accept(this);
	}
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Goto* n) {
	preVisit(n);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Break* n) {
	preVisit(n);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(Continue* n) {
	preVisit(n);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(StrConst* n) {
	preVisit(n);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(LabelledStmt* n) {
	preVisit(n);
	n->subStmt = (Stmt*)n->getSubStmt()->accept(this);
	 postVisit(n); return n;
}
Node* FixedVisitor::visit(AssignExpr* n) {
	preVisit(n);
	n->name = (Expr*)n->getName()->accept(this);  //Ensure the operator is looked up in the symbol table
	n->args = (Exprs*)n->getArgs()->accept(this);
	 postVisit(n); return n;
}

Node* FixedVisitor::visit(Cast* n) {
	preVisit(n);
	n->targetType = (TypeNode*)n->getTargetType()->accept(this);
	n->subject = (Expr*)n->getSubject()->accept(this);
	
	postVisit(n); return n;
}

Node* FixedVisitor::visit(Enum* n) {
	preVisit(n);
	n->initVariables = (Decls*)n->getDecls()->accept(this);
	
	postVisit(n); return n;
}
Node* FixedVisitor::visit(TypeDecl* n) {
	preVisit(n);
	n->initVariables = (Decls*)n->getDecls()->accept(this);
	
	postVisit(n); return n;
}
Node* FixedVisitor::visit(GlobalTypeDecl* n) {
	preVisit(n);
	n->typeDecl = (TypeDecl*)n->getTypeDecl()->accept(this);
	
	postVisit(n); return n;
}
Node* FixedVisitor::visit(TypeDeclStmt* n) {
	preVisit(n);
	n->typeDecl = (TypeDecl*)n->getTypeDecl()->accept(this);
	
	postVisit(n); return n;
}

Node* FixedVisitor::visit(ValueOf* n) {
	preVisit(n);
	n->baseExpr = (Expr*)n->getBaseExpr()->accept(this);
	
	postVisit(n); return n;
}

Node* FixedVisitor::visit(AddressOf* n) {
	preVisit(n);
	n->baseExpr = (Expr*)n->getBaseExpr()->accept(this);
	
	postVisit(n); return n;
}

Node* FixedVisitor::visit(BoolConst* n) {
	preVisit(n);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(TypeNode* n) {
	preVisit(n);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(ContainerTypeNode* n) {
	preVisit(n);
	n->base = (TypeNode*)n->base->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(ArrayTypeNode* n) {
	preVisit(n);
	n->base = (TypeNode*)n->base->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(PrimTypeNode* n) {
	preVisit(n);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(UserTypeNode* n) {
	preVisit(n);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(SArrayTypeNode* n) {
	preVisit(n);
	n->base = (TypeNode*)n->base->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(RealCPPArray* n) {
	return visit((SArrayTypeNode*)n);
}

Node* FixedVisitor::visit(DArrayTypeNode* n) {
	preVisit(n);
	n->base = (TypeNode*)n->base->accept(this);
	if (n->size != 0) n->size = (Expr*)n->size->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(PointerTypeNode* n) {
	preVisit(n);
	n->base = (TypeNode*)n->base->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(DeclExpr* n) {
	preVisit(n);
	n->decl = (VarDecl*)n->decl->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(TypeVar* n) {
	preVisit(n);
	n->type = (TypeNode*)n->type->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(IfExpr* n) {
	preVisit(n);
	n->ifCond = (Expr*)n->ifCond->accept(this);
	n->ifPart = (Expr*)n->ifPart->accept(this);
	n->elsePart = (Expr*)n->elsePart->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(Loop* n) {
	preVisit(n);
	n->body = (Stmt*)n->body->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(New* n) {
	preVisit(n);
	n->typeNode = (TypeNode*)n->typeNode->accept(this);
	n->args = (Exprs*)n->args->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(Delete* n) {
	preVisit(n);
	n->variables = (Exprs*)n->variables->accept(this);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(CPPBlock* n) {
	preVisit(n);
	n->decls = (DeclList*)n->decls->accept(this);
	
	postVisit(n);
	return n;
}	
Node* FixedVisitor::visit(CPPInclude* n) {
	preVisit(n);
	
	postVisit(n);
	return n;
}		

Node* FixedVisitor::visit(CPPUsing* n) {
	preVisit(n);
	
	postVisit(n);
	return n;
}

Node* FixedVisitor::visit(CPPElement* n) {
	preVisit(n);
	
	postVisit(n);
	return n;
}
