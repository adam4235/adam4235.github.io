#include "BuildTypes.h"
#include "ast/Function.h"
#include "ast/Enum.h"

//Don't visit function bodies
Node* BuildTypes::visit(Function* n) { return n; }

Node* BuildTypes::visit(Enum* n) {
	buildEnum(n);
	return n;
}

