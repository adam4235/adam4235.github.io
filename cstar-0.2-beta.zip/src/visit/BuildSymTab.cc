#include "BuildSymTab.h"
#include "tempname.h"
#include "whole_ast.h"
#include "BuildVarDecls.h"

using namespace std;

Node* BuildSymTab::visit(Block* n) {
	
	//Make up a name for the block
	string blockName = tempName("block");
	n->setLabel(blockName);
	
	//Push the scope
	currentSymTable = currentSymTable->addScope(blockName);

	//Do the substatements
	n->getStmts()->accept(this);
	
	//Pop the scope
	popScope();
	return n;
}

void BuildSymTab::postVisit(Cast* n) {
	//Casts also need any user types looked up
	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->accept(varDecls.get());
}

void BuildSymTab::preVisit(VarDecl* n) {
	SymbolTable* s = currentSymTable;

	auto_ptr<BuildVarDecls> varDecls(new BuildVarDecls(currentSymTable));
	n->accept(varDecls.get());

#if 0
	cout << "BuildSymTab: Type of " << n->getName() << ": " << n->getType() << endl;
#endif

	if (n->getInitVal() == 0 && n->getType().isConst())
	{
		compileError << linenum(n) << "Missing initial expression for const." << endl;
	}

	if (n->getName() == "") return;  //parameter declarations
		//with the name omitted within function declarations

	if (n->getType() == Type::VOID) return;  //Means there was an 
		//error looking up the type
	
	//Add variable to the symbol table	
	if (currentSymTable->existsThisScope(n->getName())) {
		compileError << linenum(n) << "Duplicate definition of `" <<
			n->getName() << "'.  ";
		outputPrevDefn(n->getName(), currentSymTable->lookUpType(n->getName()));
		cerr << endl;
	}
	else if (!currentSymTable->add(n, true))  //true means it's definitely a definition
		//All VarDecls within code blocks are definitions.
	{
		assert(0 == 1);
	}

	assert(s == currentSymTable);
}

//It has to be a previsit so that any initial variables in the enum
//declaration will then get handled by the preVisit(VarDecl*) function.
void BuildSymTab::preVisit(Enum* n) {
	buildEnum(n);
}

Node* BuildSymTab::visit(TypeVar* n) {
	buildTypeVar(n);
	return n;
}

Node* BuildSymTab::visit(AssignExpr* n) {
	//Skip checking the name of an assignment expression, because we know
	//= is a valid method.
	n->getArgs()->accept(this);
	return n;
}

Node* BuildSymTab::visit(Variable* n) {
	//Check that the variable has been defined before this point.
	SymbolTable* s = currentSymTable;
	if (!currentSymTable->exists(n->getName())) {
		compileError << linenum(n) << "Variable not found: `" << n->getName() << "'" << endl;
	}
	assert(s == currentSymTable);
	return n;
}

void BuildSymTab::preVisit(LabelledStmt* n) {
    string label = n->getLabel();
    if (currentSymTable->exists(label)) {
        compileError << linenum(n) << "Duplicate definition of `" <<
            label << "'.  ";
		outputPrevDefn(label, currentSymTable->lookUpType(label));
		cerr << endl;
    }
    else currentSymTable->addLabel(label);
}
