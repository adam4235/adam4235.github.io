#ifndef DESUGARSTRING_H
#define DESUGARSTRING_H

#include "FixedVisitor.h"

//Convert string literals to arrays of characters

class DesugarString : public FixedVisitor {
public:
	virtual Node* visit(StrConst* n);
	virtual Node* visit(OutputStmt* n);
};

#endif

