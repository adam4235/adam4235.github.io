#include "PrintAST.h"
#include <iostream>

using namespace std;

void PrintAST::print(const string& s) {
	for (int i = 0; i < indent; ++i) 
		cout << " ";
	cout << s << endl;
}

