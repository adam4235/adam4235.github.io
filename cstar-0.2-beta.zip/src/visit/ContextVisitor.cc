#include "ContextVisitor.h"
#include "ast/Block.h"
#include "ast/Function.h"

using namespace std;

void ContextVisitor::outputPrevDefn(const string& name, const Type& t) {
    Node* pointOfDefn = currentSymTable->getPointOfDefn(name, t);
    if (pointOfDefn == 0)  //built-in symbol
        cerr << "(Which is a built-in symbol.)";
    else
        cerr << "Previous definition at line " << 
            CompileError::getLineInfo(pointOfDefn) << ".";
}

void ContextVisitor::outputPrevDefn(const string& name) {
    Node* pointOfDefn = currentSymTable->getPointOfDefnOrDecl(name);
    if (pointOfDefn == 0)  //built-in symbol
        cerr << "(Which is a built-in symbol.)";
    else
        cerr << "Previous definition/declaration at line " << 
            CompileError::getLineInfo(pointOfDefn) << ".";
}

Node* ContextVisitor::visit(Block* n) {
	preVisit(n);
	pushScope(n->getLabel()); 
	n->getStmts()->accept(this);
	popScope();
	postVisit(n); 
	return n;
}

Node* ContextVisitor::visit(Function* n) {
	preVisit(n);
	pushScope(n->getName(), n->getType()); 
	n->getParams()->accept(this);
	if (n->getBody() != 0) n->getBody()->accept(this); 
	popScope();
	postVisit(n); 
	return n;
}
