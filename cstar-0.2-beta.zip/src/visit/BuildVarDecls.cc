#include "BuildVarDecls.h"
#include "buildTNFromType.h"
#include "whole_ast.h"

using namespace std;

Node* BuildVarDecls::visit(UserTypeNode* n) {
	const string& refName = n->getName();
	if (currentSymTable->exists(refName)) {
		Type lookedUpType = currentSymTable->lookUpType(refName);
		if (lookedUpType.getType() == Type::TYPE) {
			const Type& refType = lookedUpType.getReferredType();
            return buildUserTN(n, refType);
		}
		else {
			compileError << linenum(n) << "`" << refName << "' is not a type." << endl;
			outputPrevDefn(refName);
			cerr << endl;
		}
	}
	else {
		compileError << linenum(n) << "Type not found: `" << refName << "'." << endl;
	}
	return n;
}
