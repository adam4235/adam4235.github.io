#include "BreakContinue.h"
#include "whole_ast.h"
#include "tempname.h"

using namespace std;

/** Create a new statement that does nothing and return it, to be
    added to the AST. */
Stmt* noOpStmt() {
	return new ExprStmt(new IntConst(0));
}

//Visitor to transform break and continue statements
//with labels to gotos.
//Called on the bodies of labelled loops.
class ConvertBreakCont : public FixedVisitor {
private:
	string label, brk, cnt;
    
    //Common function called to transform either a
    //break with a label or a continue with a label
    //(passed in as n) to a goto with newLabel
    Node* mkGoto(Goto* n, string newLabel) {
		if (n->getTarget() == label) {
			Goto* retVal = new Goto(newLabel);
			delete n;
			return retVal;
		}
		else return n;
    }
    
public:
	ConvertBreakCont(const string& label,
			const string& brk, const string& cnt) 
		: label(label), brk(brk), cnt(cnt) {}

	Node* visit(Break* n)
	{
        return mkGoto(n, brk);
	}
	
	Node* visit(Continue* n)
	{
        return mkGoto(n, cnt);
	}
};

void BreakContinue::preVisit(While* n) {
    ++inLoop;
}

void BreakContinue::preVisit(For* n) {
    ++inLoop;
}

void BreakContinue::postVisit(For* n) {
    --inLoop;
}

void BreakContinue::postVisit(While* n) {
    --inLoop;
}

void BreakContinue::postVisit(Break* n) {
    if (inLoop == 0)
        compileError << linenum(n) << "Can't break out of a non-loop." << endl;
}

void BreakContinue::postVisit(Continue* n) {
    if (inLoop == 0)
        compileError << linenum(n) << "Can't continue a non-loop." << endl;
}

Node* BreakContinue::visit(LabelledStmt* n) {
	//Process any labelled loops within the current loop
	n->subStmt = (Stmt*)n->subStmt->accept(this);

	if (!n->isLabelledLoop()) return n;

	string label = n->getLabel();

	//TODO later: It should be safe to make up these tempnames and then convert 
	//any break/continue statements within n to be based on that name, after tempName
	//both looks for the name in the symbol table AND looks for all subscopes from the
	//current scope, and looks for the name within there.
	//That's necessary to avoid name conflicts in several cases anyway.
	//Also, have to be able to fix tempnames that are invented before the
	//symbol table is built, which is probably necessary in general as well.
	string tempBreak = tempName(label + "_brk")
		, tempContinue = tempName(label + "_con");

	auto_ptr<ConvertBreakCont> convert(new ConvertBreakCont(label, tempBreak, tempContinue));
	n->accept(convert.get());

	Stmt* continueLabel = new LabelledStmt(tempContinue, noOpStmt());
	n->insertContinueLabel(continueLabel);
	Stmts* blockStmts = new Stmts();
	blockStmts->add(n);
	blockStmts->add(new LabelledStmt(tempBreak, noOpStmt()));
	return new Block(blockStmts);

}

