#ifndef PULLOUTDECLEXPR_H
#define PULLOUTDECLEXPR_H

#include "FixedVisitor.h"

//Convert if and while statements with declarations in
//them to a block which declares the variables, then
//uses them in the if or while condition.
//Also does for loops that have a declaration in them, and
//input statements.

class PullOutDeclExpr : public FixedVisitor {
public:
#if 0
	virtual Node* visit(If* n);
	virtual Node* visit(While* n);
	virtual Node* visit(For* n);
#endif
	virtual void postVisit(Stmts* n);
};

#endif

