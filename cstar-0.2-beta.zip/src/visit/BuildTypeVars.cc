#include "BuildTypeVars.h"
#include "ast/TypeVar.h"
#include "ast/Function.h"

//Don't visit function bodies
Node* BuildTypeVars::visit(Function* n) { return n; }

void BuildTypeVars::postVisit(TypeVar* n) {
	buildTypeVar(n);
}

