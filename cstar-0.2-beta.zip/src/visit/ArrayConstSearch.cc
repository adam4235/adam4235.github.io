#include "ArrayConstSearch.h"
#include "ast/ArrayList.h"
#include "ast/Expr.h"
#include <memory>

using namespace std;

Node* ArrayConstSearch::visit(ArrayList * n) {
	if (checkForConsts)
	{
		if (n->containsNonConsts()) result = true;
	}
	else if (!n->isCPPInitializer()) result = true;
	return n;
}

bool containsArrayConst(Node* n, bool checkForConsts)
{
	auto_ptr<ArrayConstSearch> visitor(new ArrayConstSearch());
	n->accept(visitor.get());
	return visitor.get()->getResult();
}

