#include "typeinfo.h"
#include "error.h"

void Type::initAll() {
	type = VOID;
	baseType = 0; 
	m_size = 1;
	m_li = 0;
	returnType = 0;
	parameters = 0;
	enumerators = 0;
	pointsOfDefnOrDecl = 0;
	quals = NO_FLAG;
}

/* Create a type info structure for an array */
Type::Type(const Type& baseType, size_t arr_size, long li)
{
	initAll();
	this->baseType = new Type(baseType); 
	this->type = ARRAY;
	this->m_size = arr_size;
	this->m_li = li;
}

Type::Type(Kind type, Type referredType, long li)
{
	assert(type == DARRAY);
	initAll();
	this->type = type;
	this->baseType = new Type(referredType);
	this->m_li = li;
}

/* Create a new type info structure for a scalar */
Type::Type(Kind type) 
{
	assert(type != FUNCTION && type != ARRAY 
		&& type != ENUM && type != TYPE && type != ENUMERATOR);
	initAll();
	this->type = type;
}

Type::Type() 
{
	initAll();
}

Type::Type(Kind type, const vector<Type>& parameters, const Type& returnType)
{
	assert(type == FUNCTION);
	initAll();
	this->type = type;
	this->parameters = new vector<Type>(parameters);
	this->returnType = new Type(returnType);
}

Type::Type(Kind type, const vector<Type>& choices, const vector<Node*>& pointsOfDefnOrDecl)
{
	assert(type == AMB);
	initAll();
	this->type = type;
	this->parameters = new vector<Type>(choices);  //The choices are stored in the
		//same place as function parameters for efficiency
	this->pointsOfDefnOrDecl = new vector<Node*>(pointsOfDefnOrDecl);
}

Type::Type(Kind type, Type referredType) {
	initAll();
	this->type = type;
	assert(type == TYPE || isPtr());
	this->baseType = new Type(referredType);  //Stored in the
		//same place as the array base type for efficiency
}

Type::Type(Kind type, const vector<string>& enumerators) {
	assert(type == ENUM || type == ENUMERATOR);
	initAll();
	this->type = type;
	this->enumerators = new vector<string>(enumerators);
}

Type::Type(Kind type, string name) {
	assert(type == USER);
	initAll();
	this->type = type;
	this->refName = new string(name);
}

void Type::copyFrom(const Type& t) {
	type = t.type;
	quals = t.quals;
	if (t.isFunction() || t.type == AMB) {
		parameters = new vector<Type>(*t.parameters);
		if (t.type == AMB) {
			pointsOfDefnOrDecl = new vector<Node*>(*t.pointsOfDefnOrDecl);
		}
		if (t.isFunction()) {	
			returnType = new Type(t.getRetType());
		}
	}
	else if (t.isArray() || t.isPtr()) {
		baseType = new Type(t.getBaseType());
	}
	else if (t.type == TYPE) {
		baseType = new Type(t.getReferredType());
	}
	else if (t.isEnum() || t.isEnumerator()) {
		enumerators = new vector<string>(*(t.enumerators));
	}
	else if (t.type == USER) {
		refName = new string(*t.refName);
	}
	m_size = t.m_size;
	m_li = t.m_li;
}

Type::Type(const Type& t) {
	copyFrom(t);
}

Type& Type::operator=(const Type& t) {
	if (this != &t) {
		this->~Type();  //This seems to just be like a normal
			//function call.  The destructor deletes the
			//components of this.
		copyFrom(t);
	}
	return *this;
}

Type::~Type() {
	if (type == FUNCTION)
	{
		delete parameters;
		delete returnType;
	}
	else if (type == ARRAY || type == DARRAY || type == TYPE || isPtr())
		delete baseType;
	else if (type == AMB)
	{
		delete parameters;
		delete pointsOfDefnOrDecl;
	}
	else if (type == ENUM || type == ENUMERATOR)
		delete enumerators;
	else if (type == USER)
		delete refName;
}

bool Type::operator==(const Type& that) const {
	if (this == &that) return true;
	if (type != that.type) return false;
	if (quals != that.quals) return false;
	if (isFunction()) {
		if (!that.isFunction()) return false;

		return *parameters == *that.parameters && *(this->returnType) == *(that.returnType);
	}
	else if (type == AMB)
	{
		if (that.type != AMB) return false;
		return *parameters == *that.parameters && *pointsOfDefnOrDecl == *(that.pointsOfDefnOrDecl);
	}
	else if (type == DARRAY)
	{
		return m_size == that.m_size &&
			m_li == that.m_li &&
			*baseType == *(that.baseType);
	}
	else if (type == ARRAY) {
		return m_size == that.m_size && 
			m_li == that.m_li && 
			*baseType == *(that.baseType);
	}
	else if (isEnum()) {
		return that.isEnum() && getEnumerators() == that.getEnumerators();
	}
	else if (isEnumerator()) {
		return that.isEnumerator() && getEnumeratorVal() == that.getEnumeratorVal();
	}
	else if (type == USER) {
		return *refName == *that.refName;
	}
	else if (isPtr())
		return *baseType == *that.baseType;
	else {
		return type == that.type;
	}
}

void printList(const vector<Type>& list, ostream& os) {
	for (vector<Type>::const_iterator i = list.begin();
		i != list.end();)
	{
		os << *i;
		++i;
		if (i != list.end())
			os << ", ";
	}
}

//For some reason I can't make a template function for this
//and the above.
void printStrList(const vector<string>& list, ostream& os) {
	for (vector<string>::const_iterator i = list.begin();
		i != list.end();)
	{
		os << *i;
		++i;
		if (i != list.end())
			os << ", ";
	}
}
ostream& operator<<(ostream& os, const Type& t) {
	if (t.hasFlag(Type::STATIC_FLAG))
		os << "static ";
	if (t.hasFlag(Type::CONST_FLAG))
		os << "const ";
    if (t.hasFlag(Type::REF_FLAG))
        os << "ref ";
	if (t.isFunction()) {
		os << "(";
		printList(*t.parameters, os);
		os << ") => " << *(t.returnType);
	}
	else if (t.isArray()) {
		os << *(t.baseType) << "[";
		if (t.type == Type::DARRAY)
			os << t.li() << ".." << "?";
		else
			os << t.li() << ".." << t.ui();
		os << "]";
	}
	else if (t.type == Type::BLOCK) {}
	else if (t.type == Type::AMB) {
		os << "AMB : {";
		printList(*t.parameters, os);
		os << "}";
	}
	else if (t.isEnum()) {
		os << "enum { ";
		printStrList(*t.enumerators, os);
		os << "}";
	}
	else if (t.isEnumerator()) {
		printStrList(*t.enumerators, os);
	}
	else if (t.type == Type::TYPE) {
		os << "type " << t.getReferredType();
	}
	else if (t.type == Type::USER) {
		os << t.getRefName();
	}
	else if (t.type == Type::PTR)
	{
		os << t.getBaseType() << "@";
	}
	else if (t.type == Type::CONST_PTR)
	{
		os << t.getBaseType() << "@const";
	}
	else {
		string toPrint = Type::typeAsString(t.type);
		assert(toPrint != "");
		os << toPrint;
	}
	return os;
}

string Type::typeAsString(Type::Kind t) {
	switch (t) {
		case Type::VOID: return "void"; break;
		case Type::INT: return "int"; break;
		case Type::DOUBLE: return "double"; break;
		case Type::LDOUBLE: return "long double"; break;
		case Type::FLOAT: return "float"; break;
		case Type::BOOL: return "bool"; break;
		case Type::UINT: return "unsigned int"; break;
		case Type::CHAR: return "char"; break;
		case Type::NUL: return "null"; break;
		case Type::BOT: return "bottom"; break;
		case Type::THING: return "thing"; break;
        case Type::LABEL: return "label"; break;
		default: return "";
	}
}

Type Type::stripRef() const {
    Type t = *this;
    t.clearQuals(REF_FLAG);
    return t;
}

bool Type::isSubType(const Type& that, bool allowConstOnLeft) const {
	
	if (allowConstOnLeft && that.isConst())
	{
		Type t = that;
		t.clearQuals(CONST_FLAG);
        
        //You're allowed to have:
        //int x := 1;
        //int ptr@const := @x;
        if (t.type == CONST_PTR) t.type = PTR;
		return isSubType(t);  //I think I'm not supposed to pass
			//allowConstOnLeft on to apply more than once if the
			//base type is const as well.
	}
	
	//All types are subtypes of themselves
	if (*this == that) return true;

    //Bottom is a subtype of everything
	else if (type == BOT) return true;

	else if (isNonPtrConst())
	{
        //Const is a subtype of either const or non-const
        
		Type t1 = *this, t2 = that;
		t1.clearQuals(CONST_FLAG);
		t2.clearQuals(CONST_FLAG);
		
		return t1.isSubType(t2, allowConstOnLeft);
	}
	else if (!isNonPtrConst() && that.isNonPtrConst())
		return false;
	else if (that.type == THING) 
        return true;
    
#if 0
	//For references, check the type it's referring to
	else if (type == REF || that.type == REF)
	{
		if (getBaseType().isArray())
		{
			//LHS is a reference to array.  These are special
			//because the base types being compared must match,
			//rather than be subtypes of each other.
			//Remember, you can't have a reference to a reference.
			Type t1 = stripRef(), t2 = that.stripRef();
			t1.m_li = 0;
			t2.m_li = 0;
			return t1 == t2;
		}
		return stripRef().isSubType(that.stripRef(), allowConstOnLeft);
	}
#endif

    //Quals shouldn't affect subtyping
    else if (quals != NO_FLAG || that.quals != NO_FLAG)
    {
        Type t1 = *this, t2 = that;
        t1.clearQuals();
        t2.clearQuals();
        return t1.isSubType(t2);
    }
    
	//Null is a subtype of every pointer
	else if (type == NUL) return that.type == PTR || that.type == CONST_PTR;

    else if (type == UINT)
    {
		return that.type == INT || that.type == DOUBLE || that.type == LDOUBLE;
    }
	//Subtype relationships among primitive numeric types
	else if (type == INT)
	{
		//int is not a subtype of float, because there would be
		//a loss of precision in doing the conversion.
		return that.type == DOUBLE || that.type == LDOUBLE;
	}
	else if (type == FLOAT)
		return that.type == DOUBLE || that.type == LDOUBLE;
	else if (type == DOUBLE)
		return that.type == LDOUBLE;
	else if (type == ENUMERATOR)
	{
		if (that.type == ENUM) {
			//An enumerator is a subtype of an enum if the enumerator
			//is one of the options in the enum
			const string& enumeratorVal = getEnumeratorVal();
            const vector<string>& enumerators = that.getEnumerators();
			return (find(enumerators.begin(), 
						enumerators.end(), enumeratorVal) 
					!= enumerators.end());
		}
	}
	else if (type == PTR)
	{
		return that.type == PTR && getBaseType().isSubType(that.getBaseType(), allowConstOnLeft);
	}
	else if (type == CONST_PTR)
	{
		return (that.type == CONST_PTR || that.type == PTR) && getBaseType().isSubType(that.getBaseType(), allowConstOnLeft);
	}
	else if (type == ARRAY)
	{
		//If T <: U:
		//T[x] <: U[x]  (even if li is different)
		//T[x] <: U[]
		return (that.type == DARRAY || (that.type == ARRAY && m_size == that.m_size))
			&& getBaseType().isSubType(that.getBaseType(), allowConstOnLeft);
	}
	else if (type == DARRAY)
	{
		//T[] <: U[]
		return that.type == DARRAY
			&& getBaseType().isSubType(that.getBaseType(), allowConstOnLeft);
	}

	return false;
}

bool Type::isMoreSpecific(const Type& that) const {
	assert(isFunction());
	assert(that.isFunction());

	if (parameters->size() != that.parameters->size()) return false;

	bool equalParams = true;
	for (vector<Type>::iterator i = parameters->begin(), j = that.parameters->begin();
			i != parameters->end(); ++i, ++j)
	{
		if (!i->isSubType(*j)) return false;
		if (equalParams && *i != *j) equalParams = false;
	}
	return (!equalParams) || 
		*returnType == *(that.returnType);  //TODO Later: Currently, this makes
		//functions with the same parameters but different return types be
		//ambiguous.  Later, could introduce covariant return types or similar
		//nicer rules.
}

Type Type::mostGeneral(const Type& that) const
{
	if (isSubType(that)) return that;
	else if (that.isSubType(*this)) return *this;

#if 0
	//For references, consider the referring type.
	if (type == REF) return getBaseType().mostGeneral(that);
	else if (that.type == REF) return mostGeneral(that.getBaseType());
#endif

	//For arrays, find the most general type of the base type,
	//then find a size bound.
	if (isArray() && that.isArray())
	{
		Type base = getBaseType().mostGeneral(that.getBaseType());
		if (getType() == DARRAY || that.getType() == DARRAY)
		{
			//If either is a dynamic array, the most general type
			//is a dynamic array
			return Type(DARRAY, base);
		}
		else
		{
			//Otherwise, they have to have the same size
			//to have a most general type.
			if (size() == that.size())
			{
				return Type(base, size());
			}
			else
			{
				return THING;
			}
		}
	}

	Type bestType = THING;  //thing is an upper bound on any 2 types.
	
	//Now check if there's a smaller upper bound than thing.
	//If we check only the supertypes of that recursively, ignoring the supertypes
	//of this, we'll still find the least upper bound, because any upper bound is
	//also a supertype of this.
	//This algorithm is exponential, but the type tree shouldn't be too big.
	vector<Type> thatSuperTypes = that.superTypes();
	for (vector<Type>::const_iterator i = thatSuperTypes.begin(); i != thatSuperTypes.end(); ++i)
	{
		Type toConsider = mostGeneral(*i);

		//Set bestType to the minimum of its old value
		//and this new value we've just found.
		if (toConsider.isSubType(bestType))
			bestType = toConsider;
	}
	return bestType;
}

vector<Type> Type::superTypes() const {
	vector<Type> retVal;

	//Primitive types.
	if (type == INT || type == UINT || type == FLOAT)
		retVal.push_back(DOUBLE);
	else if (type == DOUBLE)
		retVal.push_back(LDOUBLE);
	else retVal.push_back(THING);
	return retVal;
}

bool Type::isPrimitive() const
{
	return type == INT 
		|| type == UINT 
		|| type == FLOAT 
		|| type == DOUBLE 
		|| type == LDOUBLE 
		|| type == BOOL
		|| type == CHAR
		|| type == THING;
}

