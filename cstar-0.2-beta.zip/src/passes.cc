#include "passes.h"
#include "ast/Node.h"
#include "parser.h"
#include "error.h"
#include "all_passes.h"
#include "SymbolTable.h"
#include "outputArrayClasses.h"
#include "outputThing.h"
#include "outputMain.h"

#include <memory>

using namespace std;

void passes(Node* n) {
	auto_ptr<InferArraySize> inferArray(new InferArraySize());
	auto_ptr<DesugarString> deString(new DesugarString());
	auto_ptr<PullOutDeclExpr> pull(new PullOutDeclExpr());
	auto_ptr<BuildTypes> typeBuilder(new BuildTypes());
	auto_ptr<BuildTypeVars> typeVars(new BuildTypeVars());
	auto_ptr<BuildTopLevel> topBuilder(new BuildTopLevel());
	auto_ptr<FindCodeBlocks> builder(new FindCodeBlocks());
	auto_ptr<BreakContinue> brkCon(new BreakContinue());
	auto_ptr<CPPStyleCasts> casts(new CPPStyleCasts());
	auto_ptr<TypeChecker> tc(new TypeChecker());
	auto_ptr<CheckCPPBlocks> cpp(new CheckCPPBlocks());
	auto_ptr<FlattenDecls> flatten(new FlattenDecls());
	auto_ptr<ArrayTransform> array(new ArrayTransform());
	auto_ptr<CodeGenerator> code(new CodeGenerator());
	auto_ptr<PrintAST> printAST(new PrintAST());
	
	//Add type declarations (including classes) to the symbol table
    symtable.addBuiltIns();
    
	try {
		n->accept(inferArray.get());  //infer array sizes
        
		n->accept(deString.get());  //Convert strings to char[]

		n->accept(pull.get());  //Convert declarations in statements to
			//the declarations followed by the statement

#ifdef DEBUG
		n->accept(printAST.get());  //DEBUG
		return;
#endif

		n->accept(brkCon.get());  //Break and continue with labels

		n->accept(typeBuilder.get());  //Add type declarations

		n->accept(typeVars.get());  //Add type variables

		n->accept(topBuilder.get());  //Add other top-level declarations
			//to the symbol table 
			//(now that their type can be referenced)

#ifdef DEBUG
		symtable.print();
#endif

		n->accept(builder.get());  //Add all other declarations
			//to the symbol table 
	
#ifdef DEBUG
	symtable.print();
	
	ContextVisitor* cv = new ContextVisitor();
	n->accept(cv);
	assert(cv->getSymTable() == &symtable);
	delete cv;
#endif

		n->accept(casts.get());  //Convert calls to C++-style casts

		n->accept(tc.get());   //typechecking (and error checking)

		n->accept(cpp.get());  //Check for errors related to cpp {} blocks

#ifdef DEBUG	
		symtable.print();
#endif

		n->accept(flatten.get());

		n->accept(array.get());  //array transformations
					
		outputThing();

		if (io_used) cout << "#include <iostream>\n";
        cout << "#include <cassert>\n";
        
		if (array_used)
		{
			outputArrayClasses();
		}

		n->accept(code.get());        //code generation

		if (argv_used)
			outputMain();
	}
	catch (const CompileError& ce) {
		//Catching the compile error merely prevents any future passes from being run.
	}
}
