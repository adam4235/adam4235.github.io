void outputThing();

