//Generated file - do not edit
virtual Node* visit(AddressOf* n);
virtual void postVisit(AddressOf* n) {}
virtual void preVisit(AddressOf* n) {}
virtual Node* visit(ArrayList* n);
virtual void postVisit(ArrayList* n) {}
virtual void preVisit(ArrayList* n) {}
virtual Node* visit(ArrayProp* n);
virtual void postVisit(ArrayProp* n) {}
virtual void preVisit(ArrayProp* n) {}
virtual Node* visit(ArrayRange* n);
virtual void postVisit(ArrayRange* n) {}
virtual void preVisit(ArrayRange* n) {}
virtual Node* visit(ArrayTypeNode* n);
virtual void postVisit(ArrayTypeNode* n) {}
virtual void preVisit(ArrayTypeNode* n) {}
virtual Node* visit(AssignExpr* n);
virtual void postVisit(AssignExpr* n) {}
virtual void preVisit(AssignExpr* n) {}
virtual Node* visit(Binop* n);
virtual void postVisit(Binop* n) {}
virtual void preVisit(Binop* n) {}
virtual Node* visit(Block* n);
virtual void postVisit(Block* n) {}
virtual void preVisit(Block* n) {}
virtual Node* visit(BoolConst* n);
virtual void postVisit(BoolConst* n) {}
virtual void preVisit(BoolConst* n) {}
virtual Node* visit(Break* n);
virtual void postVisit(Break* n) {}
virtual void preVisit(Break* n) {}
virtual Node* visit(CPPBlock* n);
virtual void postVisit(CPPBlock* n) {}
virtual void preVisit(CPPBlock* n) {}
virtual Node* visit(CPPElement* n);
virtual void postVisit(CPPElement* n) {}
virtual void preVisit(CPPElement* n) {}
virtual Node* visit(CPPInclude* n);
virtual void postVisit(CPPInclude* n) {}
virtual void preVisit(CPPInclude* n) {}
virtual Node* visit(CPPUsing* n);
virtual void postVisit(CPPUsing* n) {}
virtual void preVisit(CPPUsing* n) {}
virtual Node* visit(Call* n);
virtual void postVisit(Call* n) {}
virtual void preVisit(Call* n) {}
virtual Node* visit(CaseStmt* n);
virtual void postVisit(CaseStmt* n) {}
virtual void preVisit(CaseStmt* n) {}
virtual Node* visit(Cast* n);
virtual void postVisit(Cast* n) {}
virtual void preVisit(Cast* n) {}
virtual Node* visit(CharConst* n);
virtual void postVisit(CharConst* n) {}
virtual void preVisit(CharConst* n) {}
virtual Node* visit(Const* n);
virtual void postVisit(Const* n) {}
virtual void preVisit(Const* n) {}
virtual Node* visit(ContainerTypeNode* n);
virtual void postVisit(ContainerTypeNode* n) {}
virtual void preVisit(ContainerTypeNode* n) {}
virtual Node* visit(Continue* n);
virtual void postVisit(Continue* n) {}
virtual void preVisit(Continue* n) {}
virtual Node* visit(DArrayTypeNode* n);
virtual void postVisit(DArrayTypeNode* n) {}
virtual void preVisit(DArrayTypeNode* n) {}
virtual Node* visit(DeclExpr* n);
virtual void postVisit(DeclExpr* n) {}
virtual void preVisit(DeclExpr* n) {}
virtual Node* visit(DeclList* n);
virtual void postVisit(DeclList* n) {}
virtual void preVisit(DeclList* n) {}
virtual Node* visit(DeclOrDefn* n);
virtual void postVisit(DeclOrDefn* n) {}
virtual void preVisit(DeclOrDefn* n) {}
virtual Node* visit(DeclStmt* n);
virtual void postVisit(DeclStmt* n) {}
virtual void preVisit(DeclStmt* n) {}
virtual Node* visit(Decls* n);
virtual void postVisit(Decls* n) {}
virtual void preVisit(Decls* n) {}
virtual Node* visit(Delete* n);
virtual void postVisit(Delete* n) {}
virtual void preVisit(Delete* n) {}
virtual Node* visit(Enum* n);
virtual void postVisit(Enum* n) {}
virtual void preVisit(Enum* n) {}
virtual Node* visit(Expr* n);
virtual void postVisit(Expr* n) {}
virtual void preVisit(Expr* n) {}
virtual Node* visit(ExprStmt* n);
virtual void postVisit(ExprStmt* n) {}
virtual void preVisit(ExprStmt* n) {}
virtual Node* visit(Exprs* n);
virtual void postVisit(Exprs* n) {}
virtual void preVisit(Exprs* n) {}
virtual Node* visit(FloatConst* n);
virtual void postVisit(FloatConst* n) {}
virtual void preVisit(FloatConst* n) {}
virtual Node* visit(For* n);
virtual void postVisit(For* n) {}
virtual void preVisit(For* n) {}
virtual Node* visit(Function* n);
virtual void postVisit(Function* n) {}
virtual void preVisit(Function* n) {}
virtual Node* visit(GlobalTypeDecl* n);
virtual void postVisit(GlobalTypeDecl* n) {}
virtual void preVisit(GlobalTypeDecl* n) {}
virtual Node* visit(GlobalVarDecls* n);
virtual void postVisit(GlobalVarDecls* n) {}
virtual void preVisit(GlobalVarDecls* n) {}
virtual Node* visit(Goto* n);
virtual void postVisit(Goto* n) {}
virtual void preVisit(Goto* n) {}
virtual Node* visit(If* n);
virtual void postVisit(If* n) {}
virtual void preVisit(If* n) {}
virtual Node* visit(IfExpr* n);
virtual void postVisit(IfExpr* n) {}
virtual void preVisit(IfExpr* n) {}
virtual Node* visit(InputExpr* n);
virtual void postVisit(InputExpr* n) {}
virtual void preVisit(InputExpr* n) {}
virtual Node* visit(IntConst* n);
virtual void postVisit(IntConst* n) {}
virtual void preVisit(IntConst* n) {}
virtual Node* visit(LabelledStmt* n);
virtual void postVisit(LabelledStmt* n) {}
virtual void preVisit(LabelledStmt* n) {}
virtual Node* visit(Loop* n);
virtual void postVisit(Loop* n) {}
virtual void preVisit(Loop* n) {}
virtual Node* visit(New* n);
virtual void postVisit(New* n) {}
virtual void preVisit(New* n) {}
virtual Node* visit(Node* n);
virtual void postVisit(Node* n) {}
virtual void preVisit(Node* n) {}
virtual Node* visit(NormalParam* n);
virtual void postVisit(NormalParam* n) {}
virtual void preVisit(NormalParam* n) {}
virtual Node* visit(NullConst* n);
virtual void postVisit(NullConst* n) {}
virtual void preVisit(NullConst* n) {}
virtual Node* visit(OutputStmt* n);
virtual void postVisit(OutputStmt* n) {}
virtual void preVisit(OutputStmt* n) {}
virtual Node* visit(Param* n);
virtual void postVisit(Param* n) {}
virtual void preVisit(Param* n) {}
virtual Node* visit(Params* n);
virtual void postVisit(Params* n) {}
virtual void preVisit(Params* n) {}
virtual Node* visit(PointerTypeNode* n);
virtual void postVisit(PointerTypeNode* n) {}
virtual void preVisit(PointerTypeNode* n) {}
virtual Node* visit(PrimTypeNode* n);
virtual void postVisit(PrimTypeNode* n) {}
virtual void preVisit(PrimTypeNode* n) {}
virtual Node* visit(RangeSubscript* n);
virtual void postVisit(RangeSubscript* n) {}
virtual void preVisit(RangeSubscript* n) {}
virtual Node* visit(RangedCaseStmt* n);
virtual void postVisit(RangedCaseStmt* n) {}
virtual void preVisit(RangedCaseStmt* n) {}
virtual Node* visit(RealCPPArray* n);
virtual void postVisit(RealCPPArray* n) {}
virtual void preVisit(RealCPPArray* n) {}
virtual Node* visit(Return* n);
virtual void postVisit(Return* n) {}
virtual void preVisit(Return* n) {}
virtual Node* visit(SArrayTypeNode* n);
virtual void postVisit(SArrayTypeNode* n) {}
virtual void preVisit(SArrayTypeNode* n) {}
virtual Node* visit(Select* n);
virtual void postVisit(Select* n) {}
virtual void preVisit(Select* n) {}
virtual Node* visit(Stmt* n);
virtual void postVisit(Stmt* n) {}
virtual void preVisit(Stmt* n) {}
virtual Node* visit(Stmts* n);
virtual void postVisit(Stmts* n) {}
virtual void preVisit(Stmts* n) {}
virtual Node* visit(StrConst* n);
virtual void postVisit(StrConst* n) {}
virtual void preVisit(StrConst* n) {}
virtual Node* visit(Subscript* n);
virtual void postVisit(Subscript* n) {}
virtual void preVisit(Subscript* n) {}
virtual Node* visit(TypeDecl* n);
virtual void postVisit(TypeDecl* n) {}
virtual void preVisit(TypeDecl* n) {}
virtual Node* visit(TypeDeclStmt* n);
virtual void postVisit(TypeDeclStmt* n) {}
virtual void preVisit(TypeDeclStmt* n) {}
virtual Node* visit(TypeNode* n);
virtual void postVisit(TypeNode* n) {}
virtual void preVisit(TypeNode* n) {}
virtual Node* visit(TypeVar* n);
virtual void postVisit(TypeVar* n) {}
virtual void preVisit(TypeVar* n) {}
virtual Node* visit(Unop* n);
virtual void postVisit(Unop* n) {}
virtual void preVisit(Unop* n) {}
virtual Node* visit(UserTypeNode* n);
virtual void postVisit(UserTypeNode* n) {}
virtual void preVisit(UserTypeNode* n) {}
virtual Node* visit(ValueOf* n);
virtual void postVisit(ValueOf* n) {}
virtual void preVisit(ValueOf* n) {}
virtual Node* visit(VarDecl* n);
virtual void postVisit(VarDecl* n) {}
virtual void preVisit(VarDecl* n) {}
virtual Node* visit(Variable* n);
virtual void postVisit(Variable* n) {}
virtual void preVisit(Variable* n) {}
virtual Node* visit(While* n);
virtual void postVisit(While* n) {}
virtual void preVisit(While* n) {}
