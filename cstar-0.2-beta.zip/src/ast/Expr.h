#ifndef EXPR_H_
#define EXPR_H_

//Expression

#include "Node.h"

class Expr : public Node {
public:
#include "accept.h"
	/** Get the type of the expression. 
	 * All expressions need a type, including compiler-generated ones
	 * (in case further transformations need to create a temporary
	 * variable from the expression).
	 * To avoid the need to set too many types during transformations,
	 * I've adopted a policy of mostly calculating types on the spot
	 * for nodes, rather than remembering them.
	 * For the exceptions where the type is remembered, the AST node
	 * has an alternate constructor which takes a Type, which the
	 * transformations should call. */
	virtual Type getType() const = 0;
	
	/**Evaluate the expression and return the simplest
	 * form of the expression the compiler is able to.
	 * Currently, no simplification is done, but 
	 * theoretically, looking up values of constants
	 * etc. could be done. */
	virtual Expr*const eval() {
		return this;
	}

	/** Check whether the expression is an lvalue
	 * (can be used on the LHS of an assignment).
	 * This version returns false; subclasses which
	 * are lvalues should override the method and return true.*/
	virtual bool isLvalue() const {
		return false;
	}

	/**@return Whether the expression has const type (including variables
	 * delcared const).*/
	virtual bool isConst() const {
		return getType().isConst();
	}

	/**@return Whether the expression can be replaced with a literal
	 * value*/
	virtual bool isRealConst() const {
		return false;
	}

	/** @return Whether this node is an integer constant. */
	virtual bool isIntConst() const { return false; }

	/** @return An integer value equal to the value of this node. */
	virtual long getIntValue() const { assert("Not a constant." == ""); return 0; } 

};

#endif /*EXPR_H_*/
