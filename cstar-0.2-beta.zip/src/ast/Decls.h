#ifndef DECLS2_H
#define DECLS2_H

#include <vector>
#include "VarDecl.h"

using std::vector;

//A common node for a list of declarations
//(which are present both in a global variable declaration
//and a declaration statement within a function)
class Decls : public Node {
private:
	vector<VarDecl*> decls;
public:
	virtual const vector<VarDecl*>& getDecls() { return decls; }
#if 0
	virtual vector<VarDecl*> snipDecls() {
		vector<VarDecl*> retVal = decls;
		decls.clear();
		return retVal;
	}
#endif

	//Decls() {}
    
	virtual ~Decls() {
		for (vector<VarDecl*>::iterator i = decls.begin(); 
			i != decls.end(); ++i)
		{
			delete *i;
		}
	}
	
    /**Add typespec, which is a base type, to each of the decls.
    E.g. say you have: int x, y@;
    Then combineEach would be called on x and y, with typespec being int.
    */
	void combineEach(TypeNode* typespec);
    
	virtual void add(VarDecl* decl) {
		decls.push_back(decl);
	}
    
    friend class FlattenDecl;
#include "accept.h"
};

#endif
