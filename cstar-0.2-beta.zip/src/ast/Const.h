#ifndef CONST_H_
#define CONST_H_

//Base class for constants

#include "Expr.h"

class Const : public Expr {
protected:
	Const() : Expr() {}
	virtual bool isRealConst() const {
		return true;
	}
#include "accept.h"
};

#endif /*CONST_H_*/
