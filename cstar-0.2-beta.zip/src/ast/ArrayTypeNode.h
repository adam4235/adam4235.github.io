#ifndef ARRAY_TYPE_NODE_H
#define ARRAY_TYPE_NODE_H

//Common base class for a type node holding an array type.

#include "ContainerTypeNode.h"

class ArrayTypeNode : public ContainerTypeNode {
protected:
	ArrayTypeNode(TypeNode* base) 
		: ContainerTypeNode(base) {}
public:
#include "accept.h"
	virtual TypeNode* copy() const = 0;
	virtual ~ArrayTypeNode() {}
};

#endif

