#ifndef NORMALPARAM_H_
#define NORMALPARAM_H_

//A normal function parameter, consisting of a type and a name

#include "Param.h"
#include "VarDecl.h"
#include <string>

using std::string;

class NormalParam : public Param {
private:
	VarDecl* decl;  //The declaration
public:
	virtual Type getType() const { return decl->getTypeNode()->getType(); }
	NormalParam() {}
	NormalParam(TypeNode* t, string name) 
		: Param() 
	{
		decl = new VarDecl(t, name);
	} 
	VarDecl *const getDecl() const { return decl; }
	virtual string getName() { return decl->getName(); }
#include "accept.h"
};

#endif /*NORMALPARAM_H_*/
