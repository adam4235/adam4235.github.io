#ifndef SARRAY_TYPE_NODE_H
#define SARRAY_TYPE_NODE_H

//Static array

#include "ArrayTypeNode.h"

class SArrayTypeNode : public ArrayTypeNode {
private:
	long li;  //Lower index of the array
	size_t size;  //Size of the array
	bool inf;  //True if the array was inferred.
public:
	size_t getSize() { return size; }
	long getLi() { return li; }
	virtual TypeNode* copy() const 
	{
		return new SArrayTypeNode(base, li, size + li - 1);
	}
	
	SArrayTypeNode(TypeNode* base, long li, long ui, bool inf = false) 
		: ArrayTypeNode(base), li(li), size(ui - li + 1), inf(inf) 
	{
	}
	SArrayTypeNode(TypeNode* base, size_t size) 
		: ArrayTypeNode(base), li(0), size(size) 
	{
	}
	Type getTypeWoQuals() const {
		return Type(baseType(), size, li);
	}
	virtual bool dimensionsOmitted() const { 
		if (inf) return true; 
		else return base->dimensionsOmitted();
	}

#include "accept.h"
};

#endif

