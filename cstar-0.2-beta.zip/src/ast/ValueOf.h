#ifndef VALUE_H
#define VALUE_H

//$ (value of, for pointers) operator

#include "Expr.h"

class ValueOf : public Expr {
	Expr* baseExpr;  //The expression to the right of the operator
public:
	ValueOf(Expr* baseExpr) : baseExpr(baseExpr) {}
	virtual ~ValueOf() {
		delete baseExpr;
	}
	Expr*const getBaseExpr() const { return baseExpr; }

	virtual bool isLvalue() const {
		return true;
	}
	virtual Type getType() const {
        if (baseExpr->getType().isPtr())
        {
            Type retVal = baseExpr->getType().getBaseType();
            if (baseExpr->getType().hasFlag(Type::CONST_FLAG))
                retVal.setQuals(Type::CONST_FLAG);
            return retVal;
        }
        else return Type::VOID;
	}
#include "accept.h"

};

#endif

