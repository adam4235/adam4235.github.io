#ifndef NODE_H_
#define NODE_H_

//The base class for AST nodes.

#include "Pos.h"
#include "typeinfo.h"
#include "visit/Visitor.h"
#include "error.h"
#include <cstddef>

//DEBUG
#include <iostream>
using namespace std;

/*Descendents of Node need the following:
 * -Child nodes (as pointers, private variables)
 * -Getter methods for the child nodes
 * -Constructor (protected if the class is abstract)
 * -Destructor
 * -#include "accept.h" for visitors
 
 Sometimes, they need snip* or set*NoDelete methods for their
 members.  The snip methods removes the member and returns it,
 so that when building a new AST piece it can be put somewhere else.
 The set*NoDelete methods allow you to change a member without deleting
 the old one, in case it has been moved somewhere else and shouldn't
 be deleted.
 
 */
 
class Node {
protected:
	Pos pos;  /*Line number where the code for the node starts*/
	Node() : pos(Pos(lineno)) {}
public:

	virtual const Pos& getPos() const { return pos; }

	void setPos(Node* fromNode) {
		pos = fromNode->getPos();
	}

	virtual ~Node() {}
#include "accept.h"

	/**A method that can be overridden to do something
	 * after accepting this node.*/
	virtual void onAccept() {}
};

#endif /*NODE_H_*/
