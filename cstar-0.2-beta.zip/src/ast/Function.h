#ifndef FUNCTION_H_
#define FUNCTION_H_

//Function definition (or declaration)

#include "Params.h"
#include "DeclOrDefn.h"
#include "Stmts.h"
#include "replace.h"
#include "TypeNode.h"
#include "opname.h"
#include <string>

using std::string;

class Function : public DeclOrDefn {
private:
	Type type;
	string name;  //Name of the function
	Params* params;  //Function parameters
	TypeNode* retType;  //Return type
	Stmts* body;  //If null, we have a declaration
    string realName;
protected:
	void setType(const Type& that) { type = that; }
public:
    void setRealName(const string newRealName) {
        assert(realName == "");
        realName = newRealName;
    }
    string getRealName() const { return realName; }
	Type getType() const { return type; }
	virtual ~Function() {
		delete params;
		if (body != 0)
			delete body;
		if (retType != 0)
			delete retType;
	}
	Function(string name, Params* params, TypeNode* retType) :
		name(name), params(params), retType(retType), body(0), realName("")
	{
	}

	virtual string getName() { return name; }
	virtual Params*const getParams() { return params; }
	virtual TypeNode*const getRetTypeNode() const { return retType; }
	virtual Type getRetType() 
	{ 
		if (retType == 0) return Type::VOID;
		else return retType->getType(); 
	}
	virtual Stmts*const getBody() { return body; }
	
	/** Check that all parameters of the function have a name.
	 * Function declarations are allowed to omit the name, but
	 * definitions must include it.*/
	virtual void checkAllParamsNamed();
	
	/** Construct and set the type of the function from the
	 * types of its components.*/
	virtual void buildType();
	virtual void setBody(Stmts* newBody) { replace(&body, newBody); } 
	virtual bool isMain() const {
		return name == "main";
	}
    
    /**@return Whether this function is the main 
    method and takes command-line arguments (properly).*/
	virtual bool isMainWithArgs() const;
#include "accept.h"
};

#endif /*FUNCTION_H_*/
