#ifndef STMTS_H_
#define STMTS_H_

#include <vector>
#include "Node.h"
#include "Stmt.h"

/*A list of statements.
 */
 
using std::vector;

class Stmts : public Node {
private:
	vector<Stmt*> stmts;	
public:
	virtual vector<Stmt*> & getStmts() { return stmts; }

	/** Set stmts without deleting the individual underlying
	 * statements.  Useful when doing rearranging of a list of
	 * statements, so that only the pointers can be copied and
	 * most of the statement objects can remain as-is.*/
	virtual void setStmtsWithoutDelete(vector<Stmt*> newStmts) {
		stmts = newStmts;
	}

	Stmts() {}
	Stmts(const vector<Stmt*>& stmts) : stmts(stmts) {}

	virtual void add(Stmt* s) { stmts.push_back(s); }
	virtual ~Stmts() {
		for (vector<Stmt*>::iterator i = stmts.begin(); 
			i != stmts.end(); ++i)
		{
			delete *i;
		}
	}
	virtual bool empty() const { return stmts.size() == 0; }
#include "accept.h"
};

#endif /*STMTS_H_*/
