#ifndef DARRAY_TYPE_NODE_H
#define DARRAY_TYPE_NODE_H

//Dynamic array

#include "ArrayTypeNode.h"
#include "IntConst.h"

class DArrayTypeNode : public ArrayTypeNode {
private:
	long li;  //Lower index of the array
	Expr* size;  //Size of the array - evaluated at run-time
		//If null, it means it's an array declared T[]
public:
	virtual TypeNode* copy() const 
	{
		DArrayTypeNode* retVal = new DArrayTypeNode(base, size);
		retVal->li = li;
		return retVal;
	}
	virtual ~DArrayTypeNode() {
		if (size != 0) delete size;
	}

	DArrayTypeNode(TypeNode* base, long li, Expr* ui = 0)
		: ArrayTypeNode(base), li(li)
	{
		if (ui == 0)
		{
			this->size = 0;
		}
		else
		{
			//When an array is declared of the form T arr[1..x], 
			//the size is actually ui - (li - 1) = ui - li + 1.
			//(Whereas with T arr[x], the size is x.)
			Binop* minus = new Binop("-", ui, new IntConst(li - 1));
			//Set the type of "-", in case the node was created after
			//typechecking.
			vector<Type> params;
			params.push_back(Type::INT);
			params.push_back(Type::INT);
			Type fType(Type::FUNCTION, params, Type::INT);
			minus->setFunType(fType);
			this->size = minus;
		}
	}
	DArrayTypeNode(TypeNode* base, Expr* size = 0)
		: ArrayTypeNode(base), li(0), size(size)
	{
	}

	Expr*const getSize() const { return size; }
	long getLi() const { return li; }

	Type getTypeWoQuals() const {
		return Type(Type::DARRAY, baseType(), li);
	}

	virtual bool dimensionsOmitted() const {
		if (size == 0) return true;
		else return base->dimensionsOmitted();
	}
	virtual bool hasDynamicDimensions() const {
		if (size != 0) return true;
		else return base->hasDynamicDimensions();
	}
	virtual const TypeNode* checkDimsWithInitval() const {
		if (size != 0) return this;
		else return base->checkDimsWithInitval();
	}

#include "accept.h"
};

#endif

