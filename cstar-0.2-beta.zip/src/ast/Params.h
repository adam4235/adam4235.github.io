#ifndef PARAMS_H_
#define PARAMS_H_

#include <vector>
#include "Node.h"
#include "Param.h"

/*A list of parameters.
 * The reason we need a separate class for this is because
 * of the stupidity that yacc won't let one of the returned
 * $$ objects be vector<something> because it's a template.
 */
 
using std::vector;

class Params : public Node {
private:
	vector<Param*> params;	
public:
	virtual const vector<Param*> & getParams() { return params; }
	Params() {}
	virtual void add(Param* p) { params.push_back(p); }
	virtual ~Params() {
		for (vector<Param*>::iterator i = params.begin(); 
			i != params.end(); ++i)
		{
			delete *i;
		}
	}
#include "accept.h"
};

#endif /*PARAMS_H_*/
