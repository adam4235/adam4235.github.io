#ifndef BOOLCONST_H
#define BOOLCONST_H

//Boolean constant (true or false)

#include "Const.h"

class BoolConst : public Const {
private:
	bool value;
public:
	bool getValue() { return value; }
	BoolConst(bool value) 
		: value(value) {}
	virtual ~BoolConst() {}
	virtual Type getType() const { 
		return constOf(Type::BOOL);
	}
#include "accept.h"
};

#endif

