#include "ArrayProp.h"

long ArrayProp::getValue() {
	const Type& t = left->getType();

	assert(t.getType() == Type::ARRAY);  //This function should only
		//be called on static arrays
	if (tp == LI)
		return t.li();
	else if (tp == UI)
		return t.ui();
	else if (tp == SIZE)
		return t.size();
	else
		throw "ArrayProp is invalid";
}
