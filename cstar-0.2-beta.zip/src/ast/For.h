#ifndef FOR_H_
#define FOR_H_

#include "Loop.h"
#include "Expr.h"
#include "replace.h"

//For loop

class For : public Loop {
private:
	Expr* loopVar;  //Either a declaration 
		//or an lvalue, for the loop variable
	Expr *left, *right;  //The parts to the left and 
		//right of the ..
	long step;  //Step value
public:
	For(Expr* loopVar, Expr* left, Expr* right, long step = 0) :
		loopVar(loopVar), left(left), right(right), step(step)
	{}
	virtual ~For() {
		delete loopVar;
		delete left;
		delete right;
	}
	
	void setLeftNoDelete(Expr* newLeft) { left = newLeft; }
	void setRightNoDelete(Expr* newRight) { right = newRight; }

	virtual Expr*const getLoopVar() { return loopVar; }
	virtual Expr*const getLeft() { return left; }
	virtual Expr*const getRight() { return right; }
	virtual long getStep() { return step; }

	friend class PullOutDeclExpr;
#include "accept.h"
};

#endif /*FOR_H_*/
