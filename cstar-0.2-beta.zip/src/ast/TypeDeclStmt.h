#ifndef TYPE_DECL_STMT_H
#define TYPE_DECL_STMT_H

//Statement consisting of a type declaration

#include "TypeDecl.h"
#include "Stmt.h"

class TypeDeclStmt : public Stmt {
private:
	TypeDecl* typeDecl;
public:
	TypeDeclStmt(TypeDecl* typeDecl) : typeDecl(typeDecl) {}
	virtual ~TypeDeclStmt() {
		delete typeDecl;
	}
	TypeDecl*const getTypeDecl() { return typeDecl; }
#include "accept.h"
};

#endif

