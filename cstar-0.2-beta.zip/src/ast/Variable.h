#ifndef VARIABLE_H_
#define VARIABLE_H_

//A reference to a variable 
//(including the name of a function in a call)

#include <string>
#include "Expr.h"

using std::string;

class Variable : public Expr {
private:
	string name;
	Type type;  //Type of the variable that has been looked up
public:
	Variable(string name) 
		: name(name), type(Type::VOID) {}
	Variable(char* name) 
		: name(string(name)), type(Type::VOID) {}

	/** Compiler-generated AST nodes should use the following
	 * constructor, because they must give a type to the
	 * variable.*/
	Variable(string name, Type type) 
		: name(name), type(type) {}

	virtual ~Variable() {} 

	string getName() { return name; }

	virtual Type getType() const { 
		assert(type != Type::VOID);  //Make sure it's been set
		return type; 
	}
	virtual bool isLvalue() const {
		return true;
	}

	void setType(const Type& that) { type = that; }
#include "accept.h"
};

#endif /*VARIABLE_H_*/
