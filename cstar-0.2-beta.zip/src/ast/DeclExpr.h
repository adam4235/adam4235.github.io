#ifndef DECL_EXPR_H
#define DECL_EXPR_H

//A declaration of a variable that's treated as an expression.
//Useful in a few situations, such as to allow declarations
//in an input statement, a for loop, or within an 
//if or while condition.

#include "Expr.h"
#include "VarDecl.h"

class DeclExpr : public Expr {
private:
	VarDecl* decl;  //The declaration
public:
	VarDecl*const getDecl() const { return decl; }
	VarDecl*const snipDecl() {
		VarDecl* retVal = decl;
		decl = 0;
		return retVal;
	}
	DeclExpr(VarDecl* decl) 
        : decl(decl) {}

	virtual ~DeclExpr() {
		delete decl;
	}
	virtual Type getType() const {
		return decl->getType();
	}
#include "accept.h"
};

#endif

