#ifndef TYPEVAR_H
#define TYPEVAR_H

//A variable of type type (e.g. type size_t := int)

#include "TypeDecl.h"
#include "TypeNode.h"

class TypeVar : public TypeDecl {
private:
	TypeNode* type;
public:
#include "accept.h"
	TypeVar(string name, TypeNode* type) :type(type) {
		this->name = name;
	}

	virtual Type getType() const { return type->getType(); }

	virtual ~TypeVar() {
		delete type;
	}
};

#endif

