#include "Function.h"
#include "error.h"

using namespace std;

void Function::checkAllParamsNamed() {
	const vector<Param*>& list = params->getParams();
	for (vector<Param*>::const_iterator i = list.begin(); i != list.end(); ++i)
	{
		if ((*i)->getName() == "")
		{
			compileError << linenum(*i) << "Parameter must be given a name." << endl;
		}
	}
}

void Function::buildType() {
	vector<Type> params;
	
	//We must get extract the parameters of the function because they're part 
	//of the type
	//of the function, to be stored in the Type structure
	const vector<Param*>& list = getParams()->getParams(); 
	for (vector<Param*>::const_iterator i = list.begin(); i != list.end(); ++i)
	{
	//for each parameter
		params.push_back(Type((*i)->getType()));
	}

	setType(Type(Type::FUNCTION, params, getRetType()));
}

bool Function::isMainWithArgs() const
{
    if (!isMain()) return false;

    Type t = getType();
    
    //Check that t is a function taking char[][]
    if (t.getParams().size() != 1) return false;
    t = t.getParams()[0];
    if (!t.isArray()) return false;
    t = t.getBaseType();
    if (!t.isArray()) return false;
    t = t.getBaseType();
    return t.getType() == Type::CHAR;
}
