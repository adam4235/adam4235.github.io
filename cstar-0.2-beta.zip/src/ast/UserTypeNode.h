#ifndef USER_TYPE_NODE_H
#define USER_TYPE_NODE_H

//Node for a reference to a user-defined type
//(e.g. when you have a variable of class type Point,
//this node holds the name "Point" to be looked up later.)

#include "TypeNode.h"

class UserTypeNode : public TypeNode {
private:
	Type type;
	string name;  //The name of the type being referred to
public:
	string getName() const { return name; }
	virtual TypeNode* copy() const
	{
		return new UserTypeNode(name);
	}
	UserTypeNode(const string& s) : name(s) {}

	virtual Type getTypeWoQuals() const { return type; }

	/** Set the type.  Called when looking up the type being
	 * referred to.*/
	virtual void setLookedUpType(Type newType) {
		type = newType;	
	}
#include "accept.h"
};

#endif

