#ifndef FLOATCONST_H_
#define FLOATCONST_H_

#include "Const.h"

class FloatConst : public Const {
private:
	string value;  //The floating point value is stored as a string to
		//avoid loss of precision
public:
	FloatConst(char* value) : value(string(value)) {
	}
	const string& getValue() const { return value; }
	virtual ~FloatConst() {}
#include "accept.h"
	virtual Type getType() const {
		//A floating constant must have type float so it
		//can be copied into all floating point variables.
		//However, in code generation, it must become a
		//long double, so no precision is lost.
		return constOf(Type::FLOAT);
	}
};

#endif /*FLOATCONST_H_*/
