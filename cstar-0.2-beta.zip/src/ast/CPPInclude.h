#ifndef CPP_INCLUDE_H
#define CPP_INCLUDE_H

//C++ include statement (found inside a cpp {} block to include C++ code).

#include "DeclOrDefn.h"
#include "CPPElement.h"

class CPPInclude : public CPPElement {
private:
	string includeFile;
public:

	CPPInclude(const string& s) 
		: includeFile(s) {}
	string getInclude() const { return includeFile; }
#include "accept.h"
};

#endif

