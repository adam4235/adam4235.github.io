#ifndef ARRAYPROP_H_
#define ARRAYPROP_H_

/** Array property reference (e.g. A.li) */

#include "Expr.h"

class ArrayProp : public Expr {
public:
	enum PropType { LI, UI, SIZE };
private:
	Expr* left;  //The array being queried
	PropType tp;
public:
	ArrayProp(Expr* left, PropType tp) : left(left), tp(tp) {}
	virtual ~ArrayProp() {
		delete left;
	}
	Expr*const getLeft() { return left; }
	PropType getPropType() { return tp; }
	/* Get the li, ui, or size value from the type information of left. */
	virtual long getValue();
#include "accept.h"
	virtual Type getType() const {
		return constOf(Type(Type::INT));
	}
};

#endif /*ARRAYPROP_H_*/
