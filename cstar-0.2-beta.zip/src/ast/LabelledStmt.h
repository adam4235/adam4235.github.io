#ifndef LABELLED_STMT_H
#define LABELLED_STMT_H

//A statement with a label in front of it

#include "Stmt.h"

class LabelledStmt : public Stmt {
private:
	string label;
	Stmt* subStmt;
public:
	friend class BreakContinue;
	LabelledStmt(const string& label, Stmt* subStmt)
		: label(label), subStmt(subStmt)
	{}
	virtual ~LabelledStmt() {
		delete subStmt;
	}
	virtual const string& getLabel() const { return label; }
	virtual Stmt*const getSubStmt() const { return subStmt; }
    
    /**@return Whether the statement is a loop,
    which means there might be break or continues in it
    referencing the label.*/
	virtual bool isLabelledLoop() {
        return getLoop() != 0;
    }
    virtual Loop* getLoop() {
//		return dynamic_cast<Loop*>(subStmt) != 0;
        //The parser surrounds loops with Blocks, so a labelled loop will
        //always be a label referring to a block containing 1 statement, a loop.
        Block* b = dynamic_cast<Block*>(subStmt);
        if (b == 0) return 0;
        if (b->getStmts()->getStmts().size() != 1) return 0;
        Stmt* maybeLoop = b->getStmts()->getStmts()[0];
        return dynamic_cast<Loop*>(maybeLoop);
	}
    
    /** Insert continueLabel at the end of the loop,
    so that gotos can get to it.*/
	virtual void insertContinueLabel(Stmt* continueLabel)
	{
		Loop* loop = getLoop();
		assert(loop != 0);
		Stmts* newBody = new Stmts();
		newBody->add(loop->getBody());
		newBody->add(continueLabel);
		loop->setBodyNoDelete(new Block(newBody));
	}

#include "accept.h"
};

#endif

