#ifndef CONTINUE_H
#define CONTINUE_H

//continue statement
//currently can't have a label

#include "Goto.h"

class Continue : public Goto {
public:
	Continue() : Goto("") {}
	Continue(const string& target) : Goto(target) {}
#include "accept.h"

};

#endif
