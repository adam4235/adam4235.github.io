#ifndef STRCONST_H_
#define STRCONST_H_

//String constant

#include "Const.h"
#include <string>

using std::string;

class StrConst : public Const {
private:
	string value;
public:
	StrConst(const string& value) {
	//When parsed, strings contain a starting " and ending ".
	//No need to store that.
		this->value = value.substr(1, value.length() - 2);
	}
	const string& getValue() { return value; }
	virtual ~StrConst() {}
	virtual Type getType() const {
		return Type(Type(Type::CHAR), value.size());
	}
#include "accept.h"
};

#endif /*STRCONST_H_*/
