#ifndef CALL_H_
#define CALL_H_

//function call

#include "Exprs.h"
#include "Variable.h"
#include "replace.h"

class Call : public Expr {
protected:
	Expr* name;  //The function being called (currently must be a Varible.
        //Later, first class functions are planned.)
	Exprs* args;  //Arguments to the call.
public:
	Call(Expr* name, Exprs* args)
		: name(name), args(args)
	{}
	
	//Convenience constructor for constructing Binops and Unops
	Call(Expr* name, Expr* arg1 = 0, Expr* arg2 = 0)
		: name(name)
	{
		args = new Exprs();
		if (arg1 != 0) args->add(arg1);
		if (arg2 != 0) args->add(arg2);
	}
	virtual ~Call() {
		delete name;
		delete args;
	}
	Expr*const getName() const { return name; }
	Exprs*const getArgs() const { return args; }

	virtual bool isLvalue() const {
		return getType().hasFlag(Type::REF_FLAG);
	}
	virtual Type getType() const {
		if (name->getType().getType() == Type::AMB)
			return Type::VOID;
		else return name->getType().getRetType();
	}
	
	/** Set which function the target is actually referring to,
	 * if it was ambiguous before.*/
	virtual void disambiguate(const Type& t) {
		Variable* nameAsVar = dynamic_cast<Variable*>(name);
		assert(nameAsVar != 0);  //Only variables could possibly
			//be ambiguous because only a name could be referring
			//multiple things of the same name
		nameAsVar->setType(t);
	}
	void setArgs(Exprs* newArgs) {
		replace(&args, newArgs);
	}

	friend class ArrayLiteralTransform;
    friend class CPPStyleCasts;
#include "accept.h"
};

#endif /*CALL_H_*/
