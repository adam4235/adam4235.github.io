#ifndef ARRAYRANGE_H_
#define ARRAYRANGE_H_

//Numeric array expression represented by a range of values
//E.g. [1..10] represents an array of the integers 1 through 10.

#include "Expr.h"

class ArrayRange : public Expr {
private:
	Expr *left, *right;
	size_t size;  //Size of the array.  If 0,
		//the size is unknown.
public:
	ArrayRange(Expr* left, Expr* right) 
		: left(left), right(right), size(0) {}

	virtual ~ArrayRange() {
		delete left;
		delete right;
	}

	Expr*const getLeft() const { return left; }
	Expr*const getRight() const { return right; }

	void setSize(size_t newSize) { size = newSize; }
	virtual Type getType() const {
        Type baseT;
        if (left->isIntConst() && left->getIntValue() >= 0
            && right->isIntConst() && right->getIntValue() >= 0)
            baseT = Type::UINT;
        else
            baseT = Type::INT;
		//size could be 0 here if an error occurred.
		return Type(constOf(baseT), size);
	}
#include "accept.h"
};

#endif /*ARRAYRANGE_H_*/
