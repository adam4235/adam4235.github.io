#ifndef LOOP_H
#define LOOP_H

//Base class for the different loops (for, while, do-while)

#include "Stmt.h"

class Loop : public Stmt {
protected:
	Stmt* body;  //Loop body
	Loop() { body = 0; }
	Loop(Stmt* body) : body(body) {}
public:
#include "accept.h"
	virtual Stmt*const getBody() { return body; }
	virtual void setBody(Stmt* newBody) { replace(&body, newBody); }
	virtual void setBodyNoDelete(Stmt* newBody) { body = newBody; }
	virtual ~Loop() {
		if (body != 0) delete body;
	}
};

#endif

