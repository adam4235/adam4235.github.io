#ifndef ASSIGNEXPR_H_
#define ASSIGNEXPR_H_

//Assignment expression (:=, +=, etc.)

#include "Binop.h"
#include "RangeSubscript.h"

class AssignExpr : public Binop {
public:
	
	AssignExpr(string oper, Expr* lhs, Expr* rhs)
		: Binop(oper, lhs, rhs)
	{}
	
#include "accept.h"
	
	/**@return true iff the binop is an assignment with an array on the
	 * left */
	bool isRangeAssign() const {
		return getOper() == "=" && dynamic_cast<RangeSubscript*>(getLeft()) != 0;
	}

    /**@return Whether the LHS is an array of the type
        of the LHS (which means assign all the elements of the
        array the value in the RHS)*/
	bool isArrayEqualsScalar() const {
		RangeSubscript* lhs = dynamic_cast<RangeSubscript*>(getLeft());
		if (lhs == 0) 
			return false;
		else
			return getRight()->getType().isSubType(lhs->getBase()->getType().getBaseType());
	}

	virtual Type getType() const {
		//The type of a X := Y is the type of X
		return getLeft()->getType();
	}
};

#endif /*ASSIGNEXPR_H_*/
