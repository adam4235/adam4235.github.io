#ifndef CASESTMT_H_
#define CASESTMT_H_

//Case statement, as part of a select or switch.
//The sub-statement doesn't necessarily include the whole
//case block, but maybe only the first statement in the block.

#include "replace.h"
#include "Stmt.h"
#include "Expr.h"

class CaseStmt : public Stmt {
protected:
	Expr* caseExpr;  //Case expression.  Null means "case else".
	Stmt* subStmt;   //Sub statement.  Might be null, meaning an
		//empty case.
public:
	CaseStmt(Expr* caseExpr, Stmt* subStmt) : 
		caseExpr(caseExpr), subStmt(subStmt) {}
	virtual ~CaseStmt() {
		if (caseExpr != 0)
			delete caseExpr;
		if (subStmt != 0)
			delete subStmt;
	}
	Expr*const getCaseExpr() { return caseExpr; }
	Stmt*const getSubStmt() { return subStmt; }
	void setSubStmt(Stmt* newSubStmt) {
		replace(&subStmt, newSubStmt);
	}
#include "accept.h"
};

#endif /*CASESTMT_H_*/
