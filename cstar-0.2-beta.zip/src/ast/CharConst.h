#ifndef CHARCONST_H
#define CHARCONST_H

//Character constant

#include "Const.h"
#include <string>
using std::string;

class CharConst : public Const {
private:
	char value;
	bool isBackSlash;  //Remember that a character might be preceded by a backslash escape character
public:
	CharConst(char value, bool isBackSlash = false) : value(value), isBackSlash(isBackSlash) {}

    /** Create a character constant from a string
    that has been parsed as a CHARCONST*/
    CharConst(string strValue) {
		//Remember that value[0] is a single quote
		if (strValue[1] == '\\')
		{
			isBackSlash = true;
			value = strValue[2];
		}
		else
		{
			isBackSlash = false;
			value = strValue[1];
		}
    }
    
	string getValue() const { 
		string retVal = "";
		if (isBackSlash)
			retVal += "\\";
		retVal += value;
		return retVal;
	}
	virtual ~CharConst() {}
	virtual Type getType() const {
		return Type::CHAR;
	}
#include "accept.h"
};

#endif

