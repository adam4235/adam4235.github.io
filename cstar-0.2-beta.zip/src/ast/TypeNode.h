#ifndef TYPENODE_H
#define TYPENODE_H

//A node which holds a type.
//Appears in variable declarations.

#include "Node.h"

class TypeNode : public Node {
private:
	Type::Quals quals;  //qualifiers of the node
protected:
	TypeNode() : Node(), quals(Type::NO_FLAG) {}
public:
	Type getType() const
	{
		Type retVal = getTypeWoQuals();
		retVal.setQuals(quals);
		return retVal;
	}
	/** Get the type of the TypeNode, not counting the quals, which are
	 * stored in quals. */
	virtual Type getTypeWoQuals() const = 0;

	/** Determine whether this TypeNode is an array with dimensions
	 * missing (e.g. int[][5]). 
	 * Inferred dimensions count as omitted dimensions.
	 * Dimensions past a pointer are allowed to be omitted; e.g.
	 * int []@[5]
	 * returns false, because pointers always have to point to empty dimensions
	 * or static dimensions.*/
	virtual bool dimensionsOmitted() const {
		return false;
	}

	/** Determine whether there are explicitly given dynamic array dimensions. 
	 * (e.g. int arr[sz] where sz is not a constant). */
	virtual bool hasDynamicDimensions() const {
		return false;
	}

	/** Check for errors where you have a dynamic explicit dimension
	 * and an initial value both. 
       @return the TypeNode that caused the error, or 0 if there's no error.
       */
	virtual const TypeNode* checkDimsWithInitval() const {
		return 0;
	}

	/** Check that pointers don't point to dynamic arrays with explicit
	 * sizes. */
	virtual const TypeNode* checkPtr() const {
		return 0;
	}

	void setQuals(Type::Quals quals) { this->quals = quals; }
    Type::Quals getQuals() const { return quals; }
    
	/** Return a new copy of this TypeNode.
	 * It must then be attached somewhere to prevent
	 * memory leaks. */
	virtual TypeNode* copy() const = 0;

	/** Return whether the initialization is an array := scalar shortcut,
	 * such as int arr[5] := 1. */
	bool isArrayEqualsScalar(const Type& initValType) const {
		const Type& lhsType = getType();
		return lhsType.isArray() && initValType.isSubType(lhsType.getBaseType());
	}


#include "accept.h"

};

#endif

