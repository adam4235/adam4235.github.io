#ifndef OUTPUTSTMT_H_
#define OUTPUTSTMT_H_

#include <vector>
#include "Stmt.h"
#include "Expr.h"

/*An output statement, which may have several 
 *expressions or declarations within it.*/

using std::vector;

class OutputStmt : public Stmt {
private:
	vector<Expr*> outputs;	
public:
	virtual vector<Expr*> & getOutputs() { return outputs; }
	OutputStmt() {}
	virtual void add(Expr* n) { outputs.push_back(n); }
	virtual ~OutputStmt() {
		for (vector<Expr*>::iterator i = outputs.begin(); 
			i != outputs.end(); ++i)
		{
			delete *i;
		}
	}
#include "accept.h"
};

#endif /*OUTPUTSTMT_H_*/
