#ifndef RANGECASESTMT_H_
#define RANGECASESTMT_H_

//A ranged case, such as:
//case 1..10:

#include "CaseStmt.h"

class RangedCaseStmt : public CaseStmt {
protected:
	Expr* secondExpr;  //The 2nd part of the range (1st part
		//is in the superclass)
public:
	RangedCaseStmt (Expr* firstExpr, Expr* secondExpr, 
		Stmt* subStmt) : 
		CaseStmt(firstExpr, subStmt), secondExpr(secondExpr)
	{}
	virtual ~RangedCaseStmt() { 
		delete secondExpr;
	}
	Expr*const getLeft() { return getCaseExpr(); }
	Expr*const getRight() { return secondExpr; }
#include "accept.h"
};

#endif /*RANGECASESTMT_H_*/
