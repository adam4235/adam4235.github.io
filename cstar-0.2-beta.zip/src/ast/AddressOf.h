#ifndef ADDRESS_H
#define ADDRESS_H

//@ (address of, for pointers) operator

#include "Expr.h"

class AddressOf : public Expr {
	Expr* baseExpr;  //The expression to the right of the operator
public:
	AddressOf(Expr* baseExpr) : baseExpr(baseExpr) {}
	virtual ~AddressOf() {
		delete baseExpr;
	}
	Expr*const getBaseExpr() const { return baseExpr; }

#include "accept.h"
	virtual Type getType() const {
		const Type& baseType = getBaseExpr()->getType();

		//Can't change an address of something, so it should be constant.
		return Type(Type::CONST_PTR, baseType);
	}
};

#endif
