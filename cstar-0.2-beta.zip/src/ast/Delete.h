#ifndef DELETE_H
#define DELETE_H

//A delete statement

#include "Stmt.h"
#include "Exprs.h"

class Delete : public Stmt {
private:
	Exprs* variables;
public:
#include "accept.h"
	Exprs*const getVariables() const { return variables; }
	Delete(Exprs* variables) 
		: variables(variables) {}

	virtual ~Delete() {
		delete variables;
	}
};

#endif

