#ifndef PRIM_TYPE_NODE_H
#define PRIM_TYPE_NODE_H

//A node to hold a primitive type.

#include "TypeNode.h"

class PrimTypeNode : public TypeNode {
private:
	Type type;
public:
	virtual TypeNode* copy() const
	{
		return new PrimTypeNode(getType());
	}
	virtual Type getTypeWoQuals() const { return type; }
	PrimTypeNode(Type type) : type(type) {}
#include "accept.h"

};

#endif

