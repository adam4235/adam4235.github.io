#ifndef PARAM_H_
#define PARAM_H_

//Base class for different kinds of function parameters

#include "Node.h"
#include <string>

class Param : public Node {
public:
	Param() {}
#include "accept.h"
	virtual std::string getName() { return ""; }

	/** The type of the parameter. */
	virtual Type getType() const = 0;
};

#endif /*PARAM_H_*/
