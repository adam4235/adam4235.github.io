#ifndef EXPRSTMT_H_
#define EXPRSTMT_H_

/**An expression statement (whose execution is the
 * evaluation of the expression*/
 
#include "Stmt.h"
#include "Expr.h"

class ExprStmt : public Stmt {
private:
	Expr* expr;
public:
	virtual Expr*const getExpr() { return expr; }
	ExprStmt(Expr* expr) : expr(expr) {}
	virtual ~ExprStmt() {
		delete expr;
	}
#include "accept.h"
};

#endif /*EXPRSTMT_H_*/
