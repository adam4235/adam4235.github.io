#ifndef UNOP_H_
#define UNOP_H_

//Unary operator

#include "Expr.h"
#include <string>

using std::string;

class Unop : public Call {
private:
	bool postFix;  //By default, unary operators are prefix.
		//Set this to create a postfix operator.
public:
	bool isPostFix() const { return postFix; }
	//Allow constants with negative signs in front to be considered constants
	virtual bool isIntConst() const { 
		return getOper() == "-" && getOperand()->isIntConst(); 
	}
	virtual bool isRealConst() const { 
		return getOper() == "-" && getOperand()->isRealConst(); 
	}
	virtual long getIntValue() const 
	{ 
		if (getOper() == "-") return - getOperand()->getIntValue();
		else return Expr::getIntValue();  //Expr::getIntValue prints an error
	}
	Unop(Variable* oper, Expr* operand, bool postFix = false) 
		: Call(oper, operand), postFix(postFix) 
	{}
	Unop(const string& oper, Expr* operand, bool postFix = false) 
		: Call(new Variable(oper), operand), postFix(postFix) 
	{}
	string getOper() const { 
		Variable* oper = dynamic_cast<Variable*>(name);
		assert(oper != 0);
		return oper->getName();
	}	
	bool isIncOrDec() const {
		string o = getOper();
		return o == "++" || o == "--";
	}
	Expr*const getOperand() const { return getArgs()->getExprs()[0]; }
#include "accept.h"
};

#endif /*UNOP_H_*/
