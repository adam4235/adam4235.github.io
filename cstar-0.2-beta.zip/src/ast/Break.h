#ifndef BREAK_H
#define BREAK_H

//break statement
//May have a label too

#include "Goto.h"

class Break : public Goto {
public:
	Break() : Goto("") {}
	Break(const string& label) : Goto(label) {}
#include "accept.h"
};

#endif

