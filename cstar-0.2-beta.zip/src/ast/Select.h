#ifndef SELECT_H_
#define SELECT_H_

//Select statement

#include "Expr.h"
#include "Block.h"

class Select : public Stmt {
private:	
	Expr* selectExpr;
	Block* selectBlock;
public:
	Select(Expr* selectExpr, Stmts* selectStmts) 
		: selectExpr(selectExpr)
	{
		selectBlock = new Block(selectStmts);
	}
	virtual ~Select() {
		delete selectExpr;
		delete selectBlock;
	}
	Expr*const getSelectExpr() { return selectExpr; }
	Block*const getSelectBlock() { return selectBlock; }
	Stmts*const getSelectStmts() { return selectBlock->getStmts(); }
#include "accept.h"
};

#endif /*SELECT_H_*/
