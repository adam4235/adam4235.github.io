#ifndef GOTO_H
#define GOTO_H

//Goto statement

class Goto : public Stmt {
private:
	string target;
public:
	Goto(const string& target)
		: target(target)
	{}
	virtual const string& getTarget() const { return target; }
#include "accept.h"
};

#endif

