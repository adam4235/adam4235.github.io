#ifndef GLOBALVARDECLS_H_
#define GLOBALVARDECLS_H_

/*A global variable declaration, which holds a 
 * list of Decl*/
 
#include "DeclOrDefn.h"
#include "Decls.h"

class GlobalVarDecls : public DeclOrDefn {
private:
	Decls* decls;
public:
	GlobalVarDecls(Decls* decls) : decls(decls) {}
	virtual ~GlobalVarDecls() {
		delete decls;
	}
	Decls*const getDecls() { return decls; }
#include "accept.h"
};

#endif /*GLOBALVARDECLS_H_*/
