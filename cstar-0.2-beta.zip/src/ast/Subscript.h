#ifndef SUBSCRIPT_H_
#define SUBSCRIPT_H_

//Array subscript expression (not range subscript)
//E.g. x[1]

#include "Expr.h"

class Subscript : public Expr {
private:
	Expr* base;
	Expr* element;
public:
	Subscript(Expr* base, Expr* element) : base(base), element(element) {}
	virtual ~Subscript() {
		delete base;
		delete element;
	}
	virtual Expr*const getBase() const { return base; }
	virtual Expr*const getElement() const { return element; }
	virtual bool isLvalue() const {
		return true;
	}
	virtual Type getType() const {
        Type baseT = getBase()->getType();
		Type retVal = baseT.getBaseType();
        if (baseT.isConst()) {
            retVal.setQuals(Type::CONST_FLAG);
        }
        return retVal;
	}
#include "accept.h"
};

#endif /*SUBSCRIPT_H_*/
