#ifndef INPUTSTMT_H_
#define INPUTSTMT_H_

#include <vector>
#include "Expr.h"

/*An input statement, which may have several 
 *expressions or declarations within it.*/

using std::vector;

class InputExpr : public Expr {
private:
	vector<Expr*> inputs;	
public:
	//An input expression returns whether it's at EOF
	virtual Type getType() const { return Type::BOOL; }

	virtual vector<Expr*> & getInputs() { return inputs; }
	InputExpr() {}
	virtual void add(Expr* n) { inputs.push_back(n); }
	virtual ~InputExpr() {
		for (vector<Expr*>::iterator i = inputs.begin(); 
			i != inputs.end(); ++i)
		{
			delete *i;
		}
	}
#include "accept.h"
};

#endif /*INPUTSTMT_H_*/
