#ifndef INTCONST_H_
#define INTCONST_H_

//Integer constant

#include "Const.h"

class IntConst : public Const {
private:
	long value;  //Make it a long to make sure there's enough space for it
public:
	virtual bool isIntConst() const { return true; }
	virtual long getIntValue() const { return value; }
	long getValue() { return value; }
	IntConst(long value) 
		: value(value) {}
	virtual ~IntConst() {}
	virtual Type getType() const {
        if (value < 0)
            return constOf(Type::INT);
        else
            return constOf(Type::UINT);
	}
#include "accept.h"
};

#endif /*INTCONST_H_*/
