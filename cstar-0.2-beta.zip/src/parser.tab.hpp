/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     INTCONST = 258,
     IDENT = 259,
     STRING = 260,
     FLOATCONST = 261,
     CHARCONST = 262,
     KEY_FOR = 263,
     KEY_SELECT = 264,
     KEY_STEP = 265,
     KEY_CASE = 266,
     KEY_ELSE = 267,
     OP_RANGE = 268,
     OUTPUT = 269,
     INPUT = 270,
     KEY_INT = 271,
     KEY_DOUBLE = 272,
     KEY_UINT = 273,
     KEY_FLOAT = 274,
     KEY_LDOUBLE = 275,
     KEY_BOOL = 276,
     KEY_CHAR = 277,
     KEY_THING = 278,
     KEY_TYPE = 279,
     KEY_FUNCTION = 280,
     KEY_OPERATOR = 281,
     KEY_RETURNS = 282,
     KEY_RETURN = 283,
     KEY_BREAK = 284,
     KEY_CONTINUE = 285,
     KEY_GOTO = 286,
     KEY_IF = 287,
     KEY_WHILE = 288,
     KEY_DO = 289,
     KEY_ENUM = 290,
     KEY_CAST = 291,
     KEY_CONST = 292,
     KEY_REF = 293,
     KEY_STATIC = 294,
     KEY_NULL = 295,
     KEY_TRUE = 296,
     KEY_FALSE = 297,
     KEY_NEW = 298,
     KEY_DELETE = 299,
     EQ = 300,
     LE = 301,
     GE = 302,
     NE = 303,
     INC = 304,
     DEC = 305,
     KEY_AND = 306,
     KEY_OR = 307,
     KEY_NOT = 308,
     PLUS_EQ = 309,
     MINUS_EQ = 310,
     TIMES_EQ = 311,
     DIV_EQ = 312,
     IDIV_EQ = 313,
     MOD_EQ = 314,
     APPROX_EQUAL = 315,
     BOR_EQ = 316,
     POWER = 317,
     KEY_XOR = 318,
     RSH_EQ = 319,
     BAND_EQ = 320,
     LSH_EQ = 321,
     KEY_CPP = 322,
     KEY_INCLUDE = 323,
     KEY_USING = 324,
     KEY_NAMESPACE = 325,
     COLON_COLON = 326,
     IFX = 327,
     CAST = 328,
     UMINUS = 329,
     CALL = 330,
     PAREN = 331,
     HIGH = 332
   };
#endif
/* Tokens.  */
#define INTCONST 258
#define IDENT 259
#define STRING 260
#define FLOATCONST 261
#define CHARCONST 262
#define KEY_FOR 263
#define KEY_SELECT 264
#define KEY_STEP 265
#define KEY_CASE 266
#define KEY_ELSE 267
#define OP_RANGE 268
#define OUTPUT 269
#define INPUT 270
#define KEY_INT 271
#define KEY_DOUBLE 272
#define KEY_UINT 273
#define KEY_FLOAT 274
#define KEY_LDOUBLE 275
#define KEY_BOOL 276
#define KEY_CHAR 277
#define KEY_THING 278
#define KEY_TYPE 279
#define KEY_FUNCTION 280
#define KEY_OPERATOR 281
#define KEY_RETURNS 282
#define KEY_RETURN 283
#define KEY_BREAK 284
#define KEY_CONTINUE 285
#define KEY_GOTO 286
#define KEY_IF 287
#define KEY_WHILE 288
#define KEY_DO 289
#define KEY_ENUM 290
#define KEY_CAST 291
#define KEY_CONST 292
#define KEY_REF 293
#define KEY_STATIC 294
#define KEY_NULL 295
#define KEY_TRUE 296
#define KEY_FALSE 297
#define KEY_NEW 298
#define KEY_DELETE 299
#define EQ 300
#define LE 301
#define GE 302
#define NE 303
#define INC 304
#define DEC 305
#define KEY_AND 306
#define KEY_OR 307
#define KEY_NOT 308
#define PLUS_EQ 309
#define MINUS_EQ 310
#define TIMES_EQ 311
#define DIV_EQ 312
#define IDIV_EQ 313
#define MOD_EQ 314
#define APPROX_EQUAL 315
#define BOR_EQ 316
#define POWER 317
#define KEY_XOR 318
#define RSH_EQ 319
#define BAND_EQ 320
#define LSH_EQ 321
#define KEY_CPP 322
#define KEY_INCLUDE 323
#define KEY_USING 324
#define KEY_NAMESPACE 325
#define COLON_COLON 326
#define IFX 327
#define CAST 328
#define UMINUS 329
#define CALL 330
#define PAREN 331
#define HIGH 332




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 30 "parser.ypp"
{
	int intVal;
	char* strVal;
	Node* nodeVal;
	DeclList* declListVal;
	Params* parametersVal;
	Param* paramVal;
	Stmts* stmtsVal;
	Stmt* stmtVal;
	Exprs* exprsVal;
	Expr* exprVal;
	TypeNode* TypeVal;
	ContainerTypeNode* ConTypeVal;
	ArrayList* arrayListVal;
	For* forVal;
	InputExpr* inputStmtVal;
	OutputStmt* outputStmtVal;
	CaseStmt* caseStmtVal;
	DeclOrDefn* declOrDefnVal;
	VarDecl* declVal;
	DeclStmt* declStmtVal;
	Function* functionVal;
	Variable* variableVal;
	Decls* declsVal;
	TypeDecl* typeDeclVal;
	Enum* enumVal;
	CPPUsing* cppUsingVal;
}
/* Line 1529 of yacc.c.  */
#line 232 "parser.tab.hpp"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

