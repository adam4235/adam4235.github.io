#ifndef PASSES_H_
#define PASSES_H_

class Node;

/** Execute all the compiler passes required to output the
 * AST rooted at n */
void passes(Node* n);

#endif /*PASSES_H_*/
