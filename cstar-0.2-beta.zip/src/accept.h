//A file to be included in each AST node to enable
//it to be traversed with a visitor.
//@return The node to replace this node with
//(see visit/Visitor.h for details)
 
//IMPORTANT: When changing this code, change ast/DeclList.h too.
virtual Node* accept(Visitor* v) {
	Node* n = v->visit(this);
	n->onAccept();  //See ast/Node.h
	return n;
}
friend class FixedVisitor;  //FixedVisitor needs to replace the
	//sub-AST nodes of each node, and this is made much easier
	//if it can directly assign the instance variables.

