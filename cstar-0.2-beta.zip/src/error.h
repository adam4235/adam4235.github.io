#ifndef ERROR_H
#define ERROR_H

/* This file deals with error messages for the CFlat compiler.
See the file README.TXT.
The main purpose of this file is to set up an object called
compileError, which can be used like cerr except it sets a
flag saying an error occurred and prints information about
the current line number.  This is instead of calling the yyerror
function, which makes it difficult to output various parts of output
such as integers. */

#include <iostream>
#include <string>

//The following set of boolean flags keeps track of whether certain C*
//features were used in the translation unit being compiled.  If they
//aren't used, certain boilerplate code can be omitted for efficiency.
extern bool io_used;  /* True if I/O has been used in the compilation
	unit, which means that the output C++ must include iostream. */
extern bool array_used;  /* True if arrays have been used in the program,
	which means the array classes have to be included in the output. 
	It gets set in the parser when an array is declared or an array
	literal is used.*/
extern bool argv_used;  /* True if the program contains a main method
						   with command-line arguments to the program.*/

extern bool errorFound;     /* If the code has an error, code generation must be skipped.
		Error handling works like this: if there's an error, the parse tree must still be built
		as usual, because each node that has been created must be deleted later on.  Also, this
		way all errors are reported instead of just the first one. */
extern unsigned long lineno;  /* Used for knowing and reporting 
the line number where a compile error occurred.  Though it's an
unsigned long, it really should have no limit. */

class Node;

class CompileError {
public:
	/* Output the line information
	 * of the current line in parsing or
	 * the current node in visitor traversal*/
	static std::string getLineInfo(const Node* curNode);

	template <typename T>
	std::ostream& operator <<(const T& toWrite) {
		errorFound = true;   //Now we know not to do future passes

		std::cerr << toWrite;

		return std::cerr;   /*The rest of the error message gets 
			written to cerr, so the heading only appears once*/
	}

};

/** Return a string representation for the line number
portion of the error message, using n's line number.*/
std::string linenum(const Node* n);

/** Same as linenum(Node*), but for giving errors during parsing.
Returns the line number that the parser is at.*/
std::string linenum();

extern CompileError compileError;

#endif
