/* This file defines the symbol table.
See the file README.TXT.
The symbol table in compilers is normally a hash table, but to simplify 
the programming, I just used the multimap class from the C++ standard library.
The symbol table is therefore a multimap from a string to a symtab_entry, a
class which contains the information for the symbol table entry.
*/

#ifndef SYMBOL_H
#define SYMBOL_H

#include <map>
#include <string>
#include <fstream>
#include <iostream>
#include <cassert>
#include "typeinfo.h"
#include <vector>

using std::string;
using std::vector;

class SymbolTable;
class Function;
class VarDecl;
class Node;
class Enum;

/** Exception class to represent a symbol not found in the symbol table. */
class SymbolNotFound {};

/* An entry in the symbol table.
 * Not to be used by clients (but can't
 * easily be private or nested because the superclass
 * of SymbolTable references symtab_entry). */
class symtab_entry {
public:
	Type type;   /* Type of the identifier */
	SymbolTable* parent;  /*SymbolTable that the entry is contained in*/
	SymbolTable* child;   /*SymbolTable that the entry contains, if it's a function for example.
							Might be null.*/
	Node* pointOfDefnOrDecl;    /*Points to the node in the AST where the entry in the symbol table is defined.*/
	bool isDefn;          /*True iff the entry is a definition.
							Everything must have exactly one definition by the end of the parsing.*/
    string realName;    /* The C++ name to output for the symbol.*/
    
	/* Create an entry - function, block or variable */
	symtab_entry(const Type& type, SymbolTable* parent, bool isDefn, 
                 Node* pointOfDefn, string realName = "");

	/* Seems necessary to use multimap::operator[] */
	symtab_entry() {}

	virtual ~symtab_entry();

	/* Allow copy constructor - potentially expensive!
	 * (copies the whole sub-symbol table for functions)*/
	symtab_entry(const symtab_entry& c);
private:
	//prevent assignment
	symtab_entry& operator=(const symtab_entry& c);
};

class SymbolTable: public std::multimap<string, symtab_entry>
{
public:
	friend class symtab_entry;

	/** @param scope The scope the symbol table is contained in.
	 * 0 means it's the global symbol table. */
	SymbolTable(symtab_entry* scope = 0);
	
	/** Copy constructor - but do a shallow copy of the
	 * scope c is contained in */
	SymbolTable(const SymbolTable& c, symtab_entry* scope);
	
	virtual ~SymbolTable() {}

	/**True if this is the symbol table for the global scope*/
	bool globalScope() const { return scope == 0; };  
    
	/**Pop a scope pointer keeping track of the current
	 * scope in the symbol table we're working with (used
	 * when leaving a function or block).
	 * @param toPop a pointer to a pointer to the current 
	 * symbol table.  *toPop gets modified to point to a different
	 * SymbolTable (different scope) */
	friend void pop(SymbolTable** toPop)
	{
		*toPop = ((*toPop)->scope->parent);
	}
    
	/** Add the built-in operators.  Called on the global
	 * symbol table.*/
	void addBuiltIns();

	/**Try to add a variable declaration.  Returns false if it's a 
	 * duplicate definition.
	 * @param alwaysDefn True if we always want to make it a definition - 
	 * used with the initializer of "for
	 * loops, which don't get an initial value in their declaration.*/
	bool add(VarDecl* decl, bool alwaysDefn = false);
	
	/**Try to add a function.  If it's a definition as opposed to a
	 * declaration, pass the point of definition too.
	 * @return the new function's symbol table, so we can switch 
	 * to the scope of the function, or null if 
	 * it's an error. */
	SymbolTable* addFunction(Function* n);
	
	/**Add a set of {} to the symbol table - i.e. a new sub-symbol table within it.
	 * @param name The name to give the block (would have been made up,
	 * unless a label was used).*/
	SymbolTable* addScope(const string& name);
	
	/**Add all n's enumerators to the symbol table.
	 * If there's a duplicate definition, returns the name that
	 * was already defined.  (There are no declarations of enums,
	 * only definitions.) */
	string addEnumerators(Enum* n);

	/**Add a type to the symbol table (currently enum or variable
	 * of type type.)*/
	void addType(Node* n, string name, const Type& type);

    /**Add a label to the symbol table
    @param label The label's name.*/
    void addLabel(const string& label);

	/**Get the sub-symbol table of a symbol which has 
	 * a sub-scope (e.g. a function or block).
	 * @param type The type of the function.  If BLOCK, the type is a block
	 * and there should only be one symbol of that name.*/
	virtual SymbolTable* findScope(const string& symbol, const Type& type = Type::BLOCK);
	
	/**Look up the type of a variable in the current symbol table*/ 
	virtual Type lookUpType(const string& s);

	/**@return whether symbol exists in the symbol table (or one of its parents)*/
	virtual bool exists(const string& symbol);

	/**@return whether symbol of type t exists in the symbol table (or one of its parents)*/
	virtual bool exists(const string& symbol, const Type& t);

	/**@return Whether symbol exists just in the current scope.
	 * Used to allow shadowing but disallow duplicate definitions.*/
	bool existsThisScope(const string& symbol);
    
	/**@return the type information for the current function
	 * (needed to typecheck return statements)*/
    const symtab_entry*const currentFunction() const;
	
    /**Get the realname of name - that is, the name to be output in
     the C++ output.  (The realname of operator * is __times11 or something,
     for example)*/
	string getRealName(const string& name, const Type& type);

	/**@return the point of definition for name with type type */
	Node* getPointOfDefn(const string& name, const Type& type);

	/**@return A point of definition or declaration for name with type type */
	Node* getPointOfDefnOrDecl(const string& name, const Type& type);

	/**@return A point of definition/declaration for name */
	Node* getPointOfDefnOrDecl(const string& name);

	/** Set the point of definition for the name with type type to pointOfDefn.
	 * @return the changed entry.*/
	iterator
	setPointOfDefn(const string& name, const Type& type, Node* pointOfDefn);
	 
	/**@return Whether name has been defined yet with type type.*/
	bool hasDefn(const string& name, const Type& type);

	/**Print the symbol table to os, printing only depth nested scopes.
	 * Depth of -1 means print the whole thing.
	 * @param indent the number of indentations to start printing the table at. */
	void print(int depth = -1, std::ostream& os = std::cout, int indent = 0) const;
	
	/** Add an operator to the symbol table.  Used to add the built-in operators. */
	void addOper(string name, const Type& op1, const Type& op2, Type retVal, string realName = "");
    
private:
	//Used to implement getPointOfDefn* functions
	Node* getDefnOrDeclGeneral(const string& name, const Type& type, bool requireDefn);

	/** Add a built-in arithmetic operator named oper to the symbol table.
	 * These need to be overloaded for all the primitive types.
	 * @param unary true if it's a unary operator.*/
	void addArithmetic(string oper, bool unary = false);
	
	/** Add a relational operator named oper to the symbol table.
	 * Need to be overloaded for all the numeric types, and always
	 * return boolean.*/
	void addRel(string oper);

	/** Add an equality operator (== or !=) to the symbol table.
	 * Need to be overloaded for all primitive types, and return
	 * boolean. */
	void addEquality(string oper);

	/**Look up a symbol.  Must be overridden so we can search symbol tables in more global scopes.
	 * 	@param symbol The symbol to find.
	 * 	@param t Only look for symbols of type t.  Void means look for symbols of any type.
	 * 	@param requireDefn Only look for definitions if true.*/
	virtual vector<symtab_entry*> lookup(const string& symbol, const Type& t = Type::VOID, bool requireDefn = false);

	/**Insert newEntry, then return the newly inserted entry. 
	 * Note that the returned value will actually be a different object,
	 * the permanent one, whereas newEntry can be a temporary object.*/
	const symtab_entry& insertAndReturnEntry(const string& name, const symtab_entry& newEntry);

	/**Find an entry in the current scope named symbol with type type. 
     Returns the first entry found, even if there were multiple.*/
	iterator 
	lookupInScope(const string& symbol, const Type& type);

	/**@return Whether symbol with type t exists in this scope.*/
	bool existsThisScope(const string& symbol, const Type& t);

	/** Called when newEntry is already in the current scope,
	 * to give the existing entry the point of definition
	 * in newEntry if necessary
	 * (if newEntry contains the definition of the symbol, but the 
	 * existing entry was merely a declaration)
	 * @return the (name, entry) pair that was modified.*/
	iterator 
	changeDefn(const string& name, const symtab_entry& newEntry);
	
	/**Returns whether newEntry is a duplicate definition in the SymbolTable*/
	bool duplicateDefn(string variable, symtab_entry& newEntry);
	symtab_entry* scope;   //Where the SymbolTable is (e.g. a function name if this is the symbol table for
		//a function).  If null, it's the SymbolTable for the global scope
		
	//prevent assignment and direct copying (to copy, use the constructor which
	//takes a new scope)
	SymbolTable(const SymbolTable& c);
	SymbolTable& operator=(const SymbolTable& c);
};

extern SymbolTable symtable;

#endif
