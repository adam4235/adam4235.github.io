/** Output the compiler-generated main, which is done when
 * the user provides a main that takes arguments.*/
void outputMain();

